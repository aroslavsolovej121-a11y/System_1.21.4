# mcgui-clean - System 1.21.4 clean source

Decompiled from System 1.21.4.jar, cleaned, pretty, buildable.

## Where is client core?

- Modules: src/main/java/client/core/ (93 modules: AimAssist, AirStuck, Sprint, etc.)
- Base: src/main/java/client/Feature.java, Setting.java, Category.java, Modules.java
- Wrappers: src/main/java/client/mc/Client.java, Entity.java, BlockPos.java
- GUI: src/main/java/client/gui/, src/main/java/client/hud/
- Entry: src/main/java/gui/ClientEntry.java

## Build jar (2 ways, no python, no nodejs, only JDK)

### A) Plain (no internet, 30 sec, just double-click)

    build.bat

Output: build/plain/mcgui-clean-plain.jar (237 classes + resources + native DLLs)

### B) Full Fabric mod (needs internet)

    gradlew.bat build

Output: build/libs/mcgui-clean-1.0.0-clean.jar (remapped)
Requires JDK 21, MC 1.21.4, Yarn 1.21.4+build.8, loader 0.16.10.

## Gradle files
.gradle/ is cache, do not edit. Real files:
- settings.gradle (project name + repos)
- build.gradle (fabric-loom 1.7, versions from gradle.properties)
- gradle.properties (MC 1.21.4, yarn, loader, mod_version)
- gradle/wrapper/ (gradle-8.11.1, jar + scripts)
- gradlew, gradlew.bat
- .gitignore (.gradle/, build/)

## What was cleaned

- 3293 native lines removed: RVA_*, VTABLE_*, OFF_*, VA_*, IMAGE_END, MODULES_*, etc.
- gui.ClientEntry: removed Unsafe dumper, kept DLL loader
- SLOT_SETTER obf list removed, single Mojang setSelectedSlot
- flag16e8 to isFogEnabled, flagC48 to isPulseEnabled, dead flags removed
- fabric.mod.json version fixed to 1.0.0-clean (works plain + loom, no expand needed)

NOTE: client.mc.Client are native stubs. Real logic in src/main/resources/native/ClientGUI.dll.

## Remap? Pastable?

- Remap: none. Bytecode refs only client/*, java/*, fabric-loader. No net/minecraft, no method_/field_, no intermediary. Only remap-like strings were SLOT_SETTER_NAMES, cleaned to Mojang setSelectedSlot. Nothing to unremap.
- Buildable: yes. build.bat (javac+jar, no internet) tested OK. gradlew.bat --version OK (8.11.1). gradlew.bat build needs internet + time for MC/Yarn (first run downloads).
- Pastable: yes. Only external import in 237 files is fabric ClientModInitializer (ClientEntry). Copy src/main/java/client/Feature.java, Setting.java, Category.java, Modules.java + any client/core/X.java + client/aim/, client/mc/Entity.java, BlockPos.java. Implement client.mc.Client methods used (stubs return false/0/null, real logic in native DLL) with your own MC calls. GUI in client/gui/, client/hud/ is self-contained.
