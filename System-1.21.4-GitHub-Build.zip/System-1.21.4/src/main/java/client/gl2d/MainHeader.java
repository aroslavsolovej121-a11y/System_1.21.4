package client.gl2d;

public class MainHeader {
   public void renderRightButtons() {
   }
}
