package client.mc;

public class Trajectories {
   public void collectCandidates() {
   }
}
