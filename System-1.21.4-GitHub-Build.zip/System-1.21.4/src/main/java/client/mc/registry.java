package client.mc;

public class registry {
   public void ids() {
   }
}
