package client.mc;

public class ItemStack {
   public void hasMultishot() {
   }
}
