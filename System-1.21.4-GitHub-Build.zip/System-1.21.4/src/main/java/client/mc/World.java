package client.mc;

public class World {
   public void setTimeOfDay() {
   }
}
