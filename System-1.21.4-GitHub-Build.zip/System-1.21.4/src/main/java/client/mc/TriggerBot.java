package client.mc;

public class TriggerBot {
   public void forEachCandidate() {
   }
}
