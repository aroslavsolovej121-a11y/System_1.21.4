package client.mc;

public class Scoreboard {
   public void objectives() {
   }

   public void sidebarLines() {
   }
}
