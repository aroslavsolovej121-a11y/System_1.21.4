package client.mc;

public class hud {
   public void tabPlayers() {
   }
}
