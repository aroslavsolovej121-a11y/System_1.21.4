package client.net;

public class gui {
   public void submit() {
   }
}
