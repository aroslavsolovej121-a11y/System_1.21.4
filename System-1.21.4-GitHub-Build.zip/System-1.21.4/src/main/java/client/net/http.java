package client.net;

public class http {
   public void postSync() {
   }
}
