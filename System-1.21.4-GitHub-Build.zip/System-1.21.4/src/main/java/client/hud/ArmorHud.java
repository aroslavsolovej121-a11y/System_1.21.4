package client.hud;

public class ArmorHud extends client.gui.Component {
}
