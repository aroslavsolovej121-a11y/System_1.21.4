package client.hud;

public class PartyHud extends client.gui.Component {
}
