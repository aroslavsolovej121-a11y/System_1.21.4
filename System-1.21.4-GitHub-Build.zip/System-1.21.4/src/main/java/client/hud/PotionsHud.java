package client.hud;

public class PotionsHud extends client.gui.Component {
}
