package client.hud;

public class GlobalSettingsCard extends client.gui.Component {
}
