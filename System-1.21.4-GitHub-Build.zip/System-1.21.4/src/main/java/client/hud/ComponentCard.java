package client.hud;

public class ComponentCard extends client.gui.Component {
}
