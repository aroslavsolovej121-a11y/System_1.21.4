package client.hud;

public class UseTrackerHud extends client.gui.Component {
}
