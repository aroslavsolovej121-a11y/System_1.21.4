package client.hud;

public class KeyBindsHud extends client.gui.Component {
}
