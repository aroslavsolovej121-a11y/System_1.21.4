package client.hud;

public class CoordsHud extends client.gui.Component {
}
