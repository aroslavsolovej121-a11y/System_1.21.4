package client.hud;

public class Component {
}
