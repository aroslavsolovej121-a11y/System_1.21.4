package client.hud;

public class VisibilityMenu extends client.gui.Component {
}
