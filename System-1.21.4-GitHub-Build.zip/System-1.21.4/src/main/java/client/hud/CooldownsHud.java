package client.hud;

public class CooldownsHud extends client.gui.Component {
}
