package client.hud;

public class WatermarkHud extends client.gui.Component {
}
