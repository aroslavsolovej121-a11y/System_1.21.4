package client.hud;

public class NotificationsHud extends client.gui.Component {
}
