package client.hud;

public class SwapBindsHud extends client.gui.Component {
}
