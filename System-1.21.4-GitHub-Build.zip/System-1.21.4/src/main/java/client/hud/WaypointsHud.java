package client.hud;

public class WaypointsHud extends client.gui.Component {
}
