package client.hud;

public class ListComponent extends client.gui.Component {
}
