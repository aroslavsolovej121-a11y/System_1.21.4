package client.hud;

public class InventoryHud extends client.gui.Component {
}
