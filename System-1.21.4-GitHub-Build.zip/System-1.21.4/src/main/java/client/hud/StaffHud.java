package client.hud;

public class StaffHud extends client.gui.Component {
}
