package client.hud;

public class TargetHud extends client.gui.Component {
}
