package client;

public enum Category {
   Combat,
   Movement,
   Player,
   Visual,
   Render,
   Client;
}
