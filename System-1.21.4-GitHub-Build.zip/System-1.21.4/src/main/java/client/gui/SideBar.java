package client.gui;

public class SideBar extends Component {
   public static final int CALLBACK_A_OFFSET = 152;
   public static final int CALLBACK_B_OFFSET = 216;
   public static final int CALLBACK_C_OFFSET = 280;
   public static final int CALLBACK_D_OFFSET = 344;
   public static final int CALLBACK_E_OFFSET = 408;
   public static final int CALLBACK_F_OFFSET = 472;
   public static final int CALLBACK_G_OFFSET = 536;
   public static final int COLLAPSE_OFFSET = 544;
   public static final int INITIALIZED_OFFSET = 552;
   public static final int SLIDE_ANIM_OFFSET = 560;
   public static final int SLIDE_ANIM_FROM_OFFSET = 560;
   public static final int SLIDE_ANIM_CURRENT_OFFSET = 564;
   public static final int SLIDE_ANIM_TARGET_OFFSET = 568;
   public static final int SLIDE_ANIM_DURATION_OFFSET = 572;
   public static final int SLIDE_ANIM_EASING_OFFSET = 576;
   public static final int SLIDE_ANIM_LAST_TICK_OFFSET = 584;
   public static final int SLIDE_ANIM_RUNNING_OFFSET = 592;
   public static final int HEADER_LABEL_OFFSET = 592;
   public static final int HEADER_BLOCK_OFFSET = 600;
   public static final int HEADER_BLOCK_X_OFFSET = 608;
   public static final int HEADER_BLOCK_Y_OFFSET = 612;
   public static final int HEADER_BLOCK_WIDTH_OFFSET = 616;
   public static final int HEADER_BLOCK_HEIGHT_OFFSET = 620;
   public static final int ICON_FADE_OFFSET = 728;
   public static final int HEADER_ICON_OFFSET = 736;
   public static final int TAB_BUTTON_OFFSET = 744;
   public static final int TAB_BUTTON_X_OFFSET = 752;
   public static final int TAB_BUTTON_Y_OFFSET = 756;
   public static final int TAB_BUTTON_WIDTH_OFFSET = 760;
   public static final int TAB_BUTTON_COLLAPSE_OFFSET = 872;
   public static final int CATEGORY_BLOCK_OFFSET = 880;
   public static final int CATEGORY_BLOCK_X_OFFSET = 888;
   public static final int CATEGORY_BLOCK_Y_OFFSET = 892;
   public static final int CATEGORY_BLOCK_WIDTH_OFFSET = 896;
   public static final int CATEGORY_BLOCK_HEIGHT_OFFSET = 900;
   public static final int CATEGORY_BLOCK_COLLAPSE_OFFSET = 1008;
   public static final int CONFIG_BUTTON_OFFSET = 1272;
   public static final int SETTINGS_BUTTON_OFFSET = 1288;
   public static final int SETTINGS_BUTTON_X_OFFSET = 1296;
   public static final int SETTINGS_BUTTON_Y_OFFSET = 1300;
   public static final int SETTINGS_BUTTON_WIDTH_OFFSET = 1304;
   public static final int SETTINGS_BUTTON_COLLAPSE_OFFSET = 1416;
   public static final int PROFILE_BLOCK_OFFSET = 1424;
   public static final int PROFILE_BLOCK_X_OFFSET = 1432;
   public static final int PROFILE_BLOCK_Y_OFFSET = 1436;
   public static final int PROFILE_BLOCK_WIDTH_OFFSET = 1440;
   public static final int PROFILE_BLOCK_HEIGHT_OFFSET = 1444;
   public static final int PROFILE_BLOCK_COLLAPSE_OFFSET = 1552;
   public static final int PROFILE_BLOCK_FLAG_OFFSET = 1624;
   public static final int CATEGORY_ENTRIES_BEGIN_OFFSET = 1672;
   public static final int CATEGORY_ENTRIES_END_OFFSET = 1680;
   public static final int CATEGORY_ENTRIES_CAP_OFFSET = 1688;
   public static final int ACTION_ENTRIES_BEGIN_OFFSET = 1696;
   public static final int ACTION_ENTRIES_END_OFFSET = 1704;
   public static final int ACTION_ENTRIES_CAP_OFFSET = 1712;
   public static final int FOOTER_ENTRIES_BEGIN_OFFSET = 1720;
   public static final int FOOTER_ENTRIES_END_OFFSET = 1728;
   public static final int FOOTER_ENTRIES_CAP_OFFSET = 1736;
   public static final int ACTION_ITEM_A_OFFSET = 1744;
   public static final int ACTION_ITEM_B_OFFSET = 1752;
   public static final int ACTION_ITEM_C_OFFSET = 1760;
   public static final int FOOTER_ITEM_A_OFFSET = 1768;
   public static final int FOOTER_ITEM_B_OFFSET = 1776;
   public static final int PARTY_ITEM_A_OFFSET = 2080;
   public static final int PARTY_ITEM_B_OFFSET = 2088;
   public static final int PARTY_POPUP_OFFSET = 3504;
   public static final int LAST_MOUSE_X_OFFSET = 3512;
   public static final int ENTRY_X_OFFSET = 8;
   public static final int ENTRY_Y_OFFSET = 12;
   public static final int ENTRY_WIDTH_OFFSET = 16;
   public static final int ENTRY_HEIGHT_OFFSET = 20;
   public static final int ENTRY_COLLAPSE_OFFSET = 16;
   public static final int ENTRY_PAYLOAD_OFFSET = 384;
   public static final int ENTRY_SELECTED_OFFSET = 392;
   public static final int ITEM_CALLBACK_OFFSET = 440;
   public static final int ITEM_FLAG_OFFSET = 576;
   public static final int HEADER_BLOCK_RENDER_OFFSET = 88;
   public static final int EASE_OUT_CUBIC = 0;
   public static final int EASE_OUT_EXPO = 1;
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 1;
   public static final int SLOT_MOUSE_CLICKED = 4;
   public static final int SLOT_SET_POSITION = 11;
   public static final int[] CATEGORY_IDS = new int[]{0, 1, 2, 3, 4, 5};
   public static final int MENU_CONFIGS_ID = 29;
   public static final int MENU_FRIENDS_ID = 34;
   public static final int MENU_WAYPOINTS_ID = 35;
   public static final int MENU_KEYS_ID = 27;
   public static final int MENU_STAFF_ID = 9;
   public static final int MENU_PARTY_ID = 83;
   public static final int HEADER_ICON_ID = 64;
   public static final int MENU_PROFILE = 1;
   public static final int MENU_SETTINGS = 2;
   public static final int MENU_PARTY = 3;
   public static final int SOUND_CLICK = 14;
   public static final float WIDTH = 224.0F;
   public static final float HEIGHT = 700.0F;
   public static final float HEADER_HEIGHT = 49.0F;
   public static final float SLIDE_ANIM_DURATION = 0.22F;
   public static final float COLLAPSE_WIDTH = 208.0F;
   public static final float COLLAPSE_WIDTH_SHIFT = 176.0F;
   public static final float PAD_16 = 16.0F;
   public static final float PAD_2 = 2.0F;
   public static final float PAD_6 = 6.0F;
   public static final float PAD_8 = 8.0F;
   public static final float PAD_9 = 9.0F;
   public static final float PAD_20 = 20.0F;
   public static final float PAD_24 = 24.0F;
   public static final float PAD_36 = 36.0F;
   public static final float PAD_4 = 4.0F;
   public static final float PAD_18 = 18.0F;
   public static final float PAD_15 = 15.0F;
   public static final float PAD_32 = 32.0F;
   public static final float PAD_ONE = 1.0F;
   public static final float HALF = 0.5F;
   public static final float ZERO = 0.0F;
   public static final float ONE = 1.0F;
   public static final float EPSILON = 0.001F;
   public static final float LABEL_WIDTH_MIN = 0.0F;
   public static final float BLOCK_TOP = 49.0F;
   public static final float TAB_OFFSET_A = 18.0F;
   public static final float TAB_OFFSET_B = 16.0F;
   public static final float PAD_38 = 38.0F;
   public static final float LABEL_SIZE = 16.0F;
   public static final float TAB_ROW_STEP = 36.0F;
   public static final float ICON_SIZE = 20.0F;
   public static final int STATUS_COLOR_GREEN = -13919642;
   public static final int STATUS_COLOR_YELLOW = -17896;
   public static final int STATUS_COLOR_RED = -2276315;
   public static final int STATUS_COLOR_GRAY = -8158333;
   public static final int STATUS_ONLINE = 1;
   public static final int STATUS_IDLE = 2;
   public static final int STATUS_DND = 3;
   public static final float PROFILE_ALPHA = 1.0F;
   public static final float ROW_PAD = 20.0F;
   public static final String HEADER_LABEL = "Systеm";
   public static final String TAB_CAPTION = "Сlient categories";
   public static final String SETTINGS_CAPTION = "Sеttings";
   public static final String CONFIGS_CAPTION = "Сонфигз";
   public static final String FRIENDS_CAPTION = "Фриендз";
   public static final String WAYPOINTS_CAPTION = "Шайпоинтз";
   public static final String KEYS_CAPTION = "Зеттингз";
   public static final String STAFF_CAPTION = "Зеарсх";
   public static final String PARTY_CAPTION = "Партй зеттингз";
   public static final String PARTY_FEATURE = "party";
   public Object callbackA;
   public Object callbackB;
   public Object callbackC;
   public Object callbackD;
   public Object callbackE;
   public Object callbackF;
   public Object callbackG;
   protected float collapse;
   protected boolean initialized;
   protected SideBar.Anim slideAnim;
   protected String headerLabel = "Systеm";
   protected Object headerBlock;
   protected float headerBlockX;
   protected float headerBlockY;
   protected float headerBlockWidth;
   protected float headerBlockHeight;
   protected float iconFade;
   protected int headerIcon = 64;
   protected Object tabButton;
   protected float tabButtonX;
   protected float tabButtonY;
   protected float tabButtonWidth;
   protected float tabButtonCollapse;
   protected Object categoryBlock;
   protected float categoryBlockX;
   protected float categoryBlockY;
   protected float categoryBlockWidth;
   protected float categoryBlockHeight;
   protected float categoryBlockCollapse;
   protected boolean configSelected;
   protected Object settingsButton;
   protected float settingsButtonX;
   protected float settingsButtonY;
   protected float settingsButtonWidth;
   protected float settingsButtonCollapse;
   protected ProfileBlock profileBlock = new ProfileBlock();
   protected float profileBlockX;
   protected float profileBlockY;
   protected float profileBlockWidth;
   protected float profileBlockHeight;
   protected float profileBlockCollapse;
   protected boolean profileBlockFlag;
   protected Object[] categoryEntries = new Object[0];
   protected Object[] actionEntries = new Object[0];
   protected Object[] footerEntries = new Object[0];
   protected Object actionItemA;
   protected Object actionItemB;
   protected Object actionItemC;
   protected Object footerItemA;
   protected Object footerItemB;
   protected Object partyItemA;
   protected Object partyItemB;
   protected Object partyPopup;
   protected double lastMouseX;

   public SideBar() {
      this.callbackA = null;
      this.callbackB = null;
      this.callbackC = null;
      this.callbackD = null;
      this.callbackE = null;
      this.callbackF = null;
      this.callbackG = null;
      this.collapse = 0.0F;
      this.initialized = false;
      this.slideAnim = SideBar.Anim.init(0.0F, 0.22F, 0);
      this.headerLabel = "Systеm";
      this.headerBlock = createHeaderBlock(this.headerLabel, 224.0F, 49.0F);
      this.headerIcon = 64;
      this.tabButton = createPlateButton("Сlient categories");
      this.categoryBlock = createCategoryBlock(0);
      this.categoryBlockHeight = 0.0F;
      this.settingsButton = createPlateButton("Sеttings");
      this.profileBlock = new ProfileBlock();
      this.profileBlock.settingsMenu = createSettingsMenu();
      this.profileBlock.profileMenu = createProfileMenu(this.profileBlock);
      this.partyItemA = null;
      this.partyItemB = null;
      this.width = 224.0F;
      this.height = 700.0F;
      this.configSelected = false;

      for (int i = 0; i < CATEGORY_IDS.length; i++) {
         Object entry = createEntry(CATEGORY_IDS[i]);
         this.addCategoryEntry(entry);
      }

      this.actionItemA = createMenuItem(29, "Сонфигз", 1);
      this.addActionEntry(this.actionItemA);
      this.actionItemB = createMenuItem(34, "Фриендз", 2);
      this.addActionEntry(this.actionItemB);
      this.actionItemC = createMenuItem(35, "Шайпоинтз", 3);
      this.addActionEntry(this.actionItemC);
      this.actionItemA = this.actionEntries.length > 0 ? this.actionEntries[0] : null;
      this.actionItemB = this.actionEntries.length > 1 ? this.actionEntries[1] : null;
      this.actionItemC = this.actionEntries.length > 2 ? this.actionEntries[2] : null;
      setItemCallback4(this.actionItemA);
      setItemCallback5(this.actionItemB);
      setItemCallback6(this.actionItemB);
      setItemCallback7(this.actionItemC);
      Object footerA = createMenuItem(27, "Зеттингз", 2);
      this.addFooterEntry(footerA);
      this.footerItemA = footerA;
      Object footerB = createMenuItem(9, "Зеарсх", 1);
      this.addFooterEntry(footerB);
      Object footerC = createMenuItem(83, "Партй зеттингз", 3);
      this.addFooterEntry(footerC);
      this.footerItemB = footerC;
      this.partyItemA = footerB;
      this.partyItemB = footerC;
      createPartyPopup();
   }

   @Override
   public void dispose() {
      disposeBlock(this.categoryBlock);

      for (int i = 0; i < this.categoryEntries.length; i++) {
         disposeBlock(this.categoryEntries[i]);
      }

      this.initialized = false;
      disposeItem(this.headerBlock);
      freeString(this.headerLabel);
      disposeProfileBlock(this.profileBlock);
      disposePartyPopup();
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      if (!this.initialized) {
         layoutBlock(this.categoryBlock);

         for (int i = 0; i < this.categoryEntries.length; i++) {
            layoutEntry(this.categoryEntries[i]);
         }

         this.initialized = true;
      }

      float edge = 16.0F;
      drawSidebarBackdrop(mat, this.x, this.y, this.width, this.height, edge, alpha);
      float iconSize = 20.0F;
      this.tabButtonCollapse = this.collapse;
      this.headerBlockWidth = this.width;
      this.headerBlockX = this.x;
      this.headerBlockY = this.y;
      float iconX = this.x + 16.0F - 2.0F;
      float iconY = this.y + this.headerBlockHeight - 15.0F - 20.0F;
      int color = barThemeColor();
      drawIcon(mat, this.headerIcon, iconX, iconY, 20.0F, 20.0F, color, alpha);
      float fade = 1.0F - this.tabButtonCollapse;
      float labelX = iconX + iconSize + 6.0F;
      float labelWidth = this.headerBlockWidth + this.headerBlockX - 8.0F - labelX;
      if (labelWidth <= 0.0F) {
         labelWidth = 0.0F;
      }

      drawHeaderLabel(this.headerLabel, mat, labelX, iconY + 2.0F, labelWidth, this.headerBlockY, this.headerBlockHeight, 16.0F, edge, fade * alpha);
      float blockX = this.x + 8.0F;
      float blockWidth = 208.0F - this.collapse * 176.0F;
      float slide = this.slideAnim.advance(this.now());
      float blockY = this.y + 49.0F;
      float tabTop = blockY + 18.0F;
      float tabMid = blockY + 16.0F;
      this.tabButtonWidth = blockWidth;
      this.tabButtonX = blockX;
      tabTop--;
      tabMid--;
      this.tabButtonCollapse = this.collapse;
      tabTop -= 9.0F;
      this.tabButtonY = tabTop;
      tabTop += 32.0F;
      renderTabButton(this.tabButton, mat, mouseX, mouseY, alpha);
      this.categoryBlockWidth = blockWidth;
      this.categoryBlockX = blockX;
      this.categoryBlockCollapse = this.collapse;
      this.categoryBlockY = (tabMid - tabTop) * slide + tabTop;
      renderCategoryBlock(this.categoryBlock, mat, mouseX, mouseY, alpha);
      float rowA = tabMid + 32.0F + 4.0F;
      float rowB = tabTop + 32.0F + 4.0F;

      for (int i = 0; i < this.categoryEntries.length; i++) {
         Object entry = this.categoryEntries[i];
         setEntryCollapse(entry, this.collapse);
         setEntryWidth(entry, blockWidth);
         setEntryBounds(entry, blockX, (rowA - rowB) * slide + rowB);
         renderEntry(entry, mat, mouseX, mouseY, alpha);
         rowA += 36.0F;
         rowB += 36.0F;
      }

      float actionTop = rowA;
      float footerTop = rowB;
      if (this.categoryEntries.length != 0) {
         float offset = (this.categoryEntries.length - 1) * 4.0F;
         footerTop = this.categoryEntries.length * 32.0F + rowB + offset;
         actionTop = this.categoryEntries.length * 32.0F + rowA + offset;
      }

      footerTop += 24.0F;
      this.settingsButtonCollapse = this.collapse;
      this.settingsButtonX = blockX;
      actionTop += 24.0F;
      this.settingsButtonWidth = blockWidth;
      this.settingsButtonY = (actionTop - 32.0F - footerTop) * slide + footerTop;
      renderTabButton(this.settingsButton, mat, mouseX, mouseY, alpha);
      renderButtonRow(mat, mouseX, mouseY, alpha, blockX, blockWidth, footerTop + 32.0F, actionTop, this.actionEntries, slide, this.collapse);
      float profileTop = this.y + this.height - 16.0F - 38.0F;
      float count = this.footerEntries.length;
      float footerY = profileTop - ((count - 1.0F) * 4.0F + count * 32.0F) - 24.0F;
      renderButtonRow(mat, mouseX, mouseY, alpha, blockX, blockWidth, footerY, footerY, this.footerEntries, 0.0F, this.collapse);
      this.profileBlockWidth = blockWidth;
      this.profileBlockCollapse = this.collapse;
      this.profileBlockFlag = 0.001F < this.profileBlock.hoverAnim.current || 0.001F < this.profileBlock.hoverAnim.target;
      this.profileBlockX = blockX;
      this.profileBlockY = profileTop;
      this.profileBlock.render(mat, mouseX, mouseY, alpha);
   }

   public void layout(Object mat, float x, float y, float alpha) {
   }

   public void update() {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      this.lastMouseX = mx;
      if (button == 0
         && this.categoryBlockX <= mx
         && mx <= this.categoryBlockX + this.categoryBlockWidth
         && this.categoryBlockY <= my
         && my <= this.categoryBlockY + this.categoryBlockHeight) {
         if (!this.configSelected) {
            this.clearSelection();
            this.configSelected = true;
            Object callback = this.callbackA;
            if (callback == null) {
               return true;
            } else {
               invokeVoid10(callback);
               return true;
            }
         } else {
            Object callback = this.callbackB;
            if (callback == null) {
               return true;
            } else {
               invokeVoid10(callback);
               return true;
            }
         }
      } else {
         for (int i = 0; i < this.categoryEntries.length; i++) {
            Object entry = this.categoryEntries[i];
            if (button == 0
               && entryX(entry) <= mx
               && mx <= entryX(entry) + entryWidth(entry)
               && entryY(entry) <= my
               && my <= entryY(entry) + entryHeight(entry)) {
               if (!entrySelected(entry)) {
                  this.clearSelection();
                  setEntrySelected(entry, true);
                  Object callback = this.callbackA;
                  if (callback == null) {
                     return true;
                  }

                  invokeVoid10(callback, entryPayload(entry));
                  return true;
               }

               Object callback = this.callbackB;
               if (callback == null) {
                  return true;
               }

               invokeVoid10(callback, entryPayload(entry));
               return true;
            }
         }

         for (int ix = 0; ix < this.actionEntries.length; ix++) {
            Object entry = this.actionEntries[ix];
            if (button == 0
               && entryX(entry) <= mx
               && mx <= entryX(entry) + entryWidth(entry)
               && entryY(entry) <= my
               && my <= entryY(entry) + entryHeight(entry)) {
               Object callback = itemCallback(entry);
               if (callback == null) {
                  return true;
               }

               invokeItemCallback(callback);
               return true;
            }
         }

         for (int ixx = 0; ixx < this.footerEntries.length; ixx++) {
            Object entry = this.footerEntries[ixx];
            if (button == 0
               && entryX(entry) <= mx
               && mx <= entryX(entry) + entryWidth(entry)
               && entryY(entry) <= my
               && my <= entryY(entry) + entryHeight(entry)) {
               Object callback = itemCallback(entry);
               if (callback == null) {
                  return true;
               }

               invokeItemCallback(callback);
               return true;
            }
         }

         if (button == 0
            && this.profileBlockX <= mx
            && mx <= this.profileBlockWidth + this.profileBlockX
            && this.profileBlockY <= my
            && my <= this.profileBlockHeight + this.profileBlockY) {
            playSound(14);
            this.openProfileMenu();
            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      return false;
   }

   public boolean keyPressed(int key) {
      return false;
   }

   @Override
   public boolean keyReleased(int key) {
      return false;
   }

   public boolean charTyped(int codePoint) {
      return false;
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   private void clearSelection() {
      this.configSelected = false;

      for (int i = 0; i < this.categoryEntries.length; i++) {
         setEntrySelected(this.categoryEntries[i], false);
      }

      for (int i = 0; i < this.actionEntries.length; i++) {
         setItemFlag(this.actionEntries[i], false);
      }
   }

   private void openSettingsMenu() {
      Object menu = this.profileBlock.settingsMenu;
      openMenuAt(menu, this.lastMouseX);
   }

   private void openProfileMenu() {
      int mode = currentProfileMode();
      Object menu = this.profileBlock.profileMenu;
      setMenuMode(menu, mode);
      openMenuAt(menu);
   }

   private static int currentProfileMode() {
      Object state = sidebarState();
      if (state == null) {
         return 1;
      } else {
         return showStatusList(state) ? 1 : 1;
      }
   }

   private static boolean showStatusList(Object state) {
      return false;
   }

   private static void setMenuMode(Object menu, int mode) {
      int color = -13919642;
      if (mode != 1) {
         color = -17896;
         if (mode != 2) {
            color = -2276315;
            if (mode != 3) {
               color = -8158333;
            }
         }
      }

      setMenuColor(menu, color);
   }

   private static void setMenuColor(Object menu, int color) {
   }

   private void openPartySettings() {
      Object popup = this.partyPopup;
      if (popup != null) {
         setPopupY(popup, popupHeight(popup));
         openMenuAt(popup);
      }
   }

   private static Object createHeaderBlock(String label, float width, float height) {
      return null;
   }

   private static Object createPlateButton(String caption) {
      return null;
   }

   private static Object createCategoryBlock(int id) {
      return null;
   }

   private static Object createEntry(int id) {
      return null;
   }

   private static Object createMenuItem(int id, String caption, int mode) {
      return null;
   }

   private static Object createSettingsMenu() {
      return null;
   }

   private static Object createProfileMenu(ProfileBlock owner) {
      return null;
   }

   private static void createPartyPopup() {
   }

   private static void disposePartyPopup() {
   }

   private static void disposeProfileBlock(ProfileBlock block) {
   }

   private static void disposeItem(Object item) {
   }

   private static void disposeBlock(Object block) {
   }

   private static void freeString(String value) {
   }

   private void addCategoryEntry(Object entry) {
      Object[] next = new Object[this.categoryEntries.length + 1];

      for (int i = 0; i < this.categoryEntries.length; i++) {
         next[i] = this.categoryEntries[i];
      }

      next[this.categoryEntries.length] = entry;
      this.categoryEntries = next;
   }

   private void addActionEntry(Object entry) {
      Object[] next = new Object[this.actionEntries.length + 1];

      for (int i = 0; i < this.actionEntries.length; i++) {
         next[i] = this.actionEntries[i];
      }

      next[this.actionEntries.length] = entry;
      this.actionEntries = next;
   }

   private void addFooterEntry(Object entry) {
      Object[] next = new Object[this.footerEntries.length + 1];

      for (int i = 0; i < this.footerEntries.length; i++) {
         next[i] = this.footerEntries[i];
      }

      next[this.footerEntries.length] = entry;
      this.footerEntries = next;
   }

   private static void setItemCallback4(Object item) {
   }

   private static void setItemCallback5(Object item) {
   }

   private static void setItemCallback6(Object item) {
   }

   private static void setItemCallback7(Object item) {
   }

   private static void layoutBlock(Object block) {
   }

   private static void layoutEntry(Object entry) {
   }

   private static void setEntryCollapse(Object entry, float value) {
   }

   private static void setEntryWidth(Object entry, float value) {
   }

   private static void setEntryBounds(Object entry, float x, float y) {
   }

   private static void renderEntry(Object entry, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void renderTabButton(Object button, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void renderCategoryBlock(Object block, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void renderButtonRow(
      Object mat, float mouseX, float mouseY, float alpha, float x, float width, float top, float bottom, Object[] entries, float slide, float collapse
   ) {
   }

   private static void drawSidebarBackdrop(Object mat, float x, float y, float w, float h, float edge, float alpha) {
   }

   private static void drawHeaderLabel(String label, Object mat, float x, float y, float w, float hostY, float hostHeight, float size, float edge, float alpha) {
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float w, float h, int color, float alpha) {
   }

   private static void playSound(int id) {
   }

   private static void openMenuAt(Object menu) {
   }

   private static void openMenuAt(Object menu, double mouseX) {
   }

   private static void setPopupY(Object popup, float value) {
   }

   private static float popupHeight(Object popup) {
      return 0.0F;
   }

   private static Object sidebarState() {
      return null;
   }

   private static void invokeVoid10(Object callback) {
   }

   private static void invokeVoid10(Object callback, Object payload) {
   }

   private static void invokeItemCallback(Object callback) {
   }

   private static float entryX(Object entry) {
      return 0.0F;
   }

   private static float entryY(Object entry) {
      return 0.0F;
   }

   private static float entryWidth(Object entry) {
      return 0.0F;
   }

   private static float entryHeight(Object entry) {
      return 0.0F;
   }

   private static boolean entrySelected(Object entry) {
      return false;
   }

   private static void setEntrySelected(Object entry, boolean value) {
   }

   private static Object entryPayload(Object entry) {
      return null;
   }

   private static Object itemCallback(Object item) {
      return null;
   }

   private static void setItemFlag(Object item, boolean value) {
   }

   private static int barThemeColor() {
      return 0;
   }

   @Override
   protected long now() {
      return System.nanoTime();
   }

   public static final class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing;
      public long lastTick;
      public boolean animating;

      public Anim() {
      }

      public Anim(float value, float seconds, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = seconds;
         this.easing = easing;
      }

      public static SideBar.Anim init(float value, float seconds, int easing) {
         SideBar.Anim anim = new SideBar.Anim(value, seconds, easing);
         anim.lastTick = System.nanoTime();
         anim.animating = false;
         return anim;
      }

      public float advance(long time) {
         if (this.animating && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.lastTick) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.animating = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = ease(this.easing, k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.animating = false;
            return this.current;
         }
      }

      private static float ease(int easing, float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }
   }
}

