package client.gui;

public class ColorRow extends Component {
}
