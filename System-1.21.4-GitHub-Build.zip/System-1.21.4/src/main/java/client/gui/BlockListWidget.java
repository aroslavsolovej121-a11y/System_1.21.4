package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class BlockListWidget extends Component {
   public static final float WIDGET_WIDTH = 269.0F;
   public static final float ROW_HEIGHT = 32.0F;
   public static final float ALPHA_EPS = 0.001F;
   public static final float ONE = 1.0F;
   public static final float ROW_INSET = 16.0F;
   public static final long TEXT_COLOR_CODE = 62L;
   public static final long LABEL_ALPHA_CODE = 89L;
   public static final String OVERLAY_TITLE = "Введите название блока";
   public static final String LABEL_TEXT = "Cписок блoков";
   public static final String INPUT_ID = "__blocklist_edit";
   private Object setting;
   private float field68 = -1.0F;
   private int field6c;
   private float field70 = -1.0F;
   private int field74;
   private boolean field78;
   private final BlockListWidget.BlockListModal modal = new BlockListWidget.BlockListModal();
   private final float[] triggerAnim = new float[9];
   private float triggerAlpha;
   private Object blockList;
   private final List<Object> items = new ArrayList<>();
   private boolean flag490;
   private final BlockListWidget.PlateInput input = new BlockListWidget.PlateInput();
   private final BlockListWidget.ColorModalHolder colorModal = new BlockListWidget.ColorModalHolder();
   private final StringBuilder draft = new StringBuilder();
   private boolean flag619;
   private float lastRowHeight;
   private int cursorShape;

   public BlockListWidget() {
      this(null);
   }

   public BlockListWidget(Object blockList) {
      this.blockList = blockList;
      this.setting = null;
      this.width = 269.0F;
      this.flags = 256;
      this.field68 = -1.0F;
      this.field70 = -1.0F;
      this.field6c = 0;
      this.field74 = 0;
      this.field78 = false;
      this.triggerAnim[0] = 0.0F;
      this.triggerAnim[2] = 0.0F;
      this.modal.setTitle("Введите название блока");
      this.input.init("__blocklist_edit", -1, true);
      this.colorModal.attach(this.input, 0);
      this.draft.setLength(0);
      this.flag619 = false;
   }

   public float[] triggerAnim() {
      return this.triggerAnim;
   }

   public BlockListWidget.BlockListModal overlay() {
      return this.modal;
   }

   public BlockListWidget.PlateInput inputField() {
      return this.input;
   }

   public List<Object> items() {
      return this.items;
   }

   public boolean isOverlayOpen() {
      return this.modal.openAnim > 0.001F || this.modal.closeAnim > 0.001F;
   }

   public boolean isModalVisible() {
      return this.isOverlayOpen();
   }

   @Override
   public boolean isActive() {
      return false;
   }

   @Override
   public void tick() {
   }

   @Override
   public void render() {
      this.renderInternal(null, 0.0F, 0.0F, 0.0F, 0.0F);
   }

   private void renderInternal(Object matrix, float mx, float my, float scale, float flag) {
      float a = this.measureLayout(this.width);
      float b = this.measureBadge(a, this.width);
      if (b > 0.0F) {
         a = a + 0.0F + b;
      }

      float rowY = a + this.y + 6.0F;
      float hoverTarget = 0.0F;
      if (this.x <= mx && mx <= this.x + this.width && rowY <= my && my <= rowY + 32.0F && (cursorGate() == 0 || cursorOpenFlag())) {
         this.cursorShape = 1;
         hoverTarget = 1.0F;
      }

      if (this.triggerAnim[2] != hoverTarget) {
         this.triggerAnim[0] = this.animValue(this.triggerAnim, this.now());
         this.triggerAnim[2] = hoverTarget;
         this.triggerAnim[6] = (float)this.now();
         this.triggerAnim[8] = 1.0F;
      }

      float alpha = this.animValue(this.triggerAnim, this.now());
      long colorCode = this.textColorCode();
      String label = this.labelText();
      this.drawRow(matrix, (int)this.x, rowY, (int)this.width, label, colorCode, alpha, scale);
      this.height = rowY + 32.0F - this.y;
   }

   private static int cursorGate() {
      return 0;
   }

   private static boolean cursorOpenFlag() {
      return false;
   }

   private long textColorCode() {
      return 62L;
   }

   private String labelText() {
      return "Cписок блoков";
   }

   private float measureLayout(float w) {
      return 0.0F;
   }

   private float measureBadge(float a, float w) {
      return 0.0F;
   }

   private float measureHeight() {
      float a = this.measureLayout(this.width);
      float b = this.measureBadge(a, this.width);
      if (a > 0.0F) {
         b = b + 0.0F + a;
      }

      return b + 6.0F + 32.0F;
   }

   private float layoutRowY() {
      float a = this.measureLayout(this.width);
      float b = this.measureBadge(a, this.width);
      if (a > 0.0F) {
         b = b + 0.0F + a;
      }

      return b + this.y + 6.0F;
   }

   private void drawRow(Object matrix, int rx, float ry, int rw, String label, long color, float alpha, float scale) {
   }

   private float animValue(float[] anim, long time) {
      if (anim[8] == 0.0F) {
         return anim[2];
      } else {
         float t = (float)((time - (long)anim[6]) / 1.0E9);
         if (t <= 0.0F) {
            return anim[0];
         } else if (t >= 0.22F) {
            anim[8] = 0.0F;
            return anim[2];
         } else {
            return anim[0] + (anim[2] - anim[0]) * (t / 0.22F);
         }
      }
   }

   public void renderForward() {
      this.preferredHeight();
   }

   public void renderOverlay(Object matrix, float a, float b, float c, float d) {
      if (this.isOverlayOpen()) {
         this.modal.render(matrix, b, c, d);
      }
   }

   public void layoutOverlay() {
      if (this.isOverlayOpen()) {
         this.overlayLayout();
      }
   }

   private void overlayLayout() {
   }

   public boolean containsModal(double mx, double my) {
      return !this.isOverlayOpen() ? false : this.modal.contains(mx, my);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      boolean active = this.isActive();
      if (active && this.modal.isOpen()) {
         this.modal.mouseClicked(mx, my, button);
         return true;
      } else {
         if (button == 0) {
            float w = this.width;
            float top = this.layoutRowY();
            if (this.x <= mx && mx <= this.x + w && top <= my && my <= top + 32.0F) {
               this.openModal();
               return true;
            }
         }

         return false;
      }
   }

   public void openModal() {
      float[] anchor = this.anchor();
      this.modal.reset();
      this.modal.show(anchor[0], anchor[1]);
   }

   private float[] anchor() {
      Supplier<float[]> supplier = new Supplier<float[]>() {
         public float[] get() {
            return new float[]{BlockListWidget.this.x, BlockListWidget.this.layoutRowY()};
         }
      };
      float[] pair = supplier.get();
      this.field68 = pair[0];
      this.field70 = pair[1];
      return pair;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.isActive() && this.modal.isOpen()) {
         this.modal.mouseReleased(mx, my, button);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      if (this.isActive() && this.modal.isOpen()) {
         this.modal.mouseMoved(mx, my, delta);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (this.isActive() && this.modal.isOpen()) {
         this.modal.mouseScrolled(mx, my, amount);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (this.isActive() && this.modal.isOpen()) {
         this.modal.keyPressed(keyCode, modifiers);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean charTyped(char ch) {
      if (this.isActive() && this.modal.isOpen()) {
         this.modal.charTyped(ch);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public void setPosition(float px, float py) {
      this.x = px;
      this.y = py;
   }

   public int labelAlphaCode() {
      return 89;
   }

   public String panelLabel() {
      return "Cписок блoков";
   }

   public float rowInset() {
      return 16.0F;
   }

   @Override
   public float preferredHeight() {
      return this.measureHeight();
   }

   public static final class BlockListModal {
      public String title = "";
      public boolean showing;
      public float openAnim;
      public float closeAnim;
      public float x;
      public float y;
      public float width;
      public float height;

      public void setTitle(String value) {
         this.title = value == null ? "" : value;
      }

      public float positionX() {
         return this.x;
      }

      public float positionY() {
         return this.y;
      }

      public void show(float atX, float atY) {
         this.x = atX;
         this.y = atY;
         this.showing = true;
      }

      public void reset() {
         this.showing = false;
         this.x = 0.0F;
         this.y = 0.0F;
         this.openAnim = 0.0F;
         this.closeAnim = 0.0F;
      }

      public boolean isOpen() {
         return this.openAnim > 0.001F || this.closeAnim > 0.001F;
      }

      public boolean mouseClicked(double mx, double my, int button) {
         return this.isOpen();
      }

      public boolean mouseReleased(double mx, double my, int button) {
         return this.isOpen();
      }

      public boolean mouseMoved(double mx, double my, double delta) {
         return this.isOpen();
      }

      public boolean mouseScrolled(double mx, double my, double amount) {
         return this.isOpen();
      }

      public boolean keyPressed(int keyCode, int modifiers) {
         return this.isOpen();
      }

      public boolean charTyped(char ch) {
         return this.isOpen();
      }

      public void render(Object matrix, float arg1, float arg2, float arg3) {
      }

      public boolean contains(double mx, double my) {
         return mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
      }

      public void measureAndReset() {
         this.height = 0.0F;
         this.showing = false;
      }
   }

   public static final class ColorModalHolder {
      public BlockListWidget.PlateInput target;
      public int mode;

      public void attach(BlockListWidget.PlateInput input, int value) {
         this.target = input;
         this.mode = value;
      }
   }

   public static final class OverlayAnim {
      public float value;
      public float target;
      public long time;
      public boolean running;
   }

   public static final class PlateInput {
      public String id = "";
      public String text = "";
      public boolean focused;

      public void init(String value, int max, boolean flag) {
         this.id = value == null ? "" : value;
      }

      public void setOnChange(Runnable callback) {
      }
   }
}

