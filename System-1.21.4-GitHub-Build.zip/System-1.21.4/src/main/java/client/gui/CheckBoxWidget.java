package client.gui;

import client.Setting;

public class CheckBoxWidget extends Component {
   public static final int SLOT_DESTROY = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_GET_HEIGHT = 96;
   public static final int SLOT_TYPE_ID = 136;
   public static final int SLOT_VALUE_PAD = 144;
   public static final int SLOT_VALUE_MIN = 152;
   public static final int SLOT_BUTTON_CLICK = 96;
   public static final float BUTTON_SIZE = 16.0F;
   public static final float MIN_HEIGHT = 16.0F;
   public static final float PAD_X = 8.0F;
   public static final float PAD_Y = 6.0F;
   public static final float LABEL_FONT = 12.0F;
   public static final float VALUE_FONT = 14.0F;
   public static final float LABEL_LINE_HEIGHT = 14.4F;
   public static final float VALUE_LINE_HEIGHT = 16.800001F;
   public static final float VALUE_MIN_HEIGHT = 20.0F;
   public static final float TEXT_PAD = 16.0F;
   public static final float HALF = 0.5F;
   public static final float ANIM_DURATION = 0.22F;
   public static final float EPSILON = 0.001F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final long NANOS_PER_SECOND = 1000000000L;
   public static final int TYPE_ID = 65;
   public static final int CHECK_ICON = 20;
   public static final int HOVER_KIND_ROW = 1;
   public static boolean hoverGatePointerNull = true;
   public static boolean mouseInsideWindow;
   public static int hoveredWidget;
   protected Setting setting;
   protected float buttonX;
   protected float buttonY;
   protected float buttonWidth = 16.0F;
   protected float buttonHeight = 16.0F;
   protected boolean checked;
   protected final CheckBoxWidget.Anim checkAnim = new CheckBoxWidget.Anim();
   protected final CheckBoxWidget.Anim crossAnim = new CheckBoxWidget.Anim();
   protected byte checkAnimRunningFlag;
   protected float labelWidthKey = -1.0F;
   protected float labelHeight;
   protected float valueHeightKey = -1.0F;
   protected float valueHeight;

   public CheckBoxWidget() {
   }

   public CheckBoxWidget(Setting setting) {
      this.initSettingWidget(setting);
      this.initButton(setting != null && setting.getBoolean());
   }

   protected void initSettingWidget(Setting setting) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.animXFrom = 0.0F;
      this.animYFrom = 0.0F;
      this.animatingPosition = false;
      this.setting = setting;
      this.width = 269.0F;
      this.buttonX = 0.0F;
      this.buttonY = 0.0F;
      this.buttonWidth = 16.0F;
      this.buttonHeight = 16.0F;
   }

   protected void initButton(boolean value) {
      this.checked = value;
      float flag = value ? 1.0F : 0.0F;
      this.checkAnim.from = flag;
      this.checkAnim.current = flag;
      this.checkAnim.target = flag;
      this.checkAnim.duration = 0.22F;
      this.checkAnim.start = clock();
      this.checkAnim.running = false;
      this.crossAnim.from = flag;
      this.crossAnim.current = flag;
      this.crossAnim.target = flag;
      this.crossAnim.duration = 0.22F;
      this.crossAnim.start = clock();
      this.crossAnim.running = false;
      this.bindCallback();
   }

   public Setting getSetting() {
      return this.setting;
   }

   protected void bindCallback() {
   }

   protected static long clock() {
      return System.nanoTime();
   }

   protected static float advanceAnim(CheckBoxWidget.Anim anim) {
      if (anim.running && !(anim.duration <= 0.0F)) {
         float t = (float)((clock() - anim.start) / 1.0E9) / anim.duration;
         if (t <= 0.0F) {
            anim.current = anim.from;
            return anim.current;
         } else if (t >= 1.0F) {
            anim.running = false;
            anim.current = anim.target;
            return anim.current;
         } else {
            anim.current = easeOutCubic(t) * (anim.target - anim.from) + anim.from;
            return anim.current;
         }
      } else {
         anim.current = anim.target;
         anim.running = false;
         return anim.current;
      }
   }

   protected static void setAnimTarget(CheckBoxWidget.Anim anim, float target) {
      if (anim.target != target) {
         float current = advanceAnim(anim);
         anim.from = current;
         anim.target = target;
         anim.start = clock();
         anim.running = true;
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         return mx >= this.buttonX && mx <= this.buttonX + this.buttonWidth && my >= this.buttonY && my <= this.buttonY + this.buttonHeight
            ? this.buttonClicked(mx)
            : false;
      }
   }

   protected boolean buttonClicked(double mx) {
      return false;
   }

   protected float measureHeight() {
      float minimum = 16.0F;
      float label = this.measureLabelHeight(this.width - 16.0F - 8.0F);
      float value = this.measureValueHeight(this.width);
      if (label > 0.0F) {
         value = value + 0.0F + label;
      }

      if (minimum <= value) {
         minimum = value;
      }

      return minimum;
   }

   public void measure() {
      this.measureHeight();
   }

   protected float measureLabelHeight(float available) {
      if (available != this.labelWidthKey) {
         int lines = wrapLineCount(0, this.settingLabel(), 12.0F, available);
         float measured = lines * 14.4F;
         this.labelWidthKey = available;
         this.labelHeight = measured;
         return measured;
      } else {
         return this.labelHeight;
      }
   }

   protected float measureValueHeight(float available) {
      float local = available - 20.0F;
      if (local <= 0.0F) {
         local = 0.0F;
      }

      if (local != this.valueHeightKey) {
         int lines = wrapLineCount(2, this.settingValue(), 14.0F, local);
         float measured = lines * 16.800001F;
         if (measured < 16.0F) {
            measured = 16.0F;
         }

         this.valueHeightKey = local;
         this.valueHeight = measured;
         return measured;
      } else {
         return this.valueHeight;
      }
   }

   protected float drawHeader(Object mat, float available, float alpha) {
      float measured = this.measureValueHeight(available);
      drawValueTextAtEdge(mat, this.x + this.width, this.y, this.settingValue(), alpha);
      drawValueText(mat, this.x + 20.0F, this.y, 14.0F, available, AbstractTrackChoiceWidget.rendererColor(), alpha);
      return measured;
   }

   protected float drawLabel(Object mat, float yOffset, float alpha) {
      float measured = this.measureLabelHeight(this.width);
      drawLabelText(mat, this.x, yOffset + this.y, 12.0F, AbstractTrackChoiceWidget.rendererColor(), alpha);
      return measured;
   }

   protected String settingLabel() {
      return this.setting == null ? "" : this.setting.getName();
   }

   protected String settingValue() {
      return this.setting == null ? "" : this.setting.getName();
   }

   protected static int wrapLineCount(int align, String text, float size, float available) {
      if (!(available <= 0.0F) && text != null) {
         float measured = AbstractTrackChoiceWidget.textWidth(text, size);

         int lines;
         for (lines = 1; measured > available; lines++) {
            measured -= available;
         }

         return lines;
      } else {
         return available <= 0.0F ? 0 : 1;
      }
   }

   protected static void drawValueTextAtEdge(Object mat, float px, float py, String text, float alpha) {
   }

   protected static void drawValueText(Object mat, float px, float py, float size, float available, int color, float alpha) {
   }

   protected static void drawLabelText(Object mat, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawRowBackground(Object mat, float px, float py, float w, float h, float radius, float alpha) {
   }

   protected static void drawRowDivider(Object mat, float px, float py, float w, float h, int color, float alpha) {
   }

   protected static void drawRowInner(Object mat, float px, float py, float w, float h, float radius, int color, float alpha) {
   }

   protected static void drawButton(Object mat, float px, float py, float w, float h, int icon, float alpha) {
   }

   public void renderWidget(Object mat, float mouseX, float mouseY, float alpha) {
      boolean value = this.setting != null && this.setting.getBoolean();
      if (this.checked != value) {
         this.checked = value;
         float flag;
         if (!value) {
            setAnimTarget(this.checkAnim, 0.0F);
            flag = 0.0F;
         } else {
            setAnimTarget(this.checkAnim, 1.0F);
            flag = 1.0F;
         }

         setAnimTarget(this.crossAnim, flag);
      }

      float minimum = 16.0F;
      float available = this.width - 16.0F - 8.0F;
      float valueMeasured = this.drawHeader(mat, available, alpha);
      float labelMeasured = this.drawLabel(mat, valueMeasured, alpha);
      this.buttonX = this.x + this.width - 16.0F;
      this.buttonY = this.y - 1.0F;
      drawButton(mat, this.buttonX, this.buttonY, this.buttonWidth, this.buttonHeight, 20, alpha);
      if (labelMeasured > 0.0F) {
         valueMeasured = valueMeasured + 0.0F + labelMeasured;
      }

      if (minimum <= valueMeasured) {
         minimum = valueMeasured;
      }

      this.height = minimum;
   }

   @Override
   public void render() {
   }

   protected static final class Anim {
      protected float from;
      protected float current;
      protected float target;
      protected float duration = 0.22F;
      protected long start;
      protected boolean running;

      protected Anim() {
      }

      protected Anim(float value, float duration0) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration0;
         this.start = CheckBoxWidget.clock();
         this.running = false;
      }
   }
}

