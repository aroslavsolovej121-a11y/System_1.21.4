package client.gui;

import client.Setting;

public class ColorPickerWidget extends Component {
   public static final int SLOT_RENDER = 1;
   public static final int SLOT_TICK = 2;
   public static final int SLOT_MOUSE_CLICKED = 4;
   public static final int SLOT_MOUSE_RELEASED = 5;
   public static final int SLOT_MOUSE_MOVED = 6;
   public static final int SLOT_KEY_PRESSED = 8;
   public static final int SLOT_CHAR_TYPED = 10;
   public static final int SLOT_SET_POSITION = 11;
   public static final int SLOT_HEIGHT = 12;
   public static final int SLOT_HEIGHT_ALIAS = 13;
   public static final int SLOT_IS_ACTIVE = 14;
   public static final int SLOT_MODAL_LAYOUT = 15;
   public static final int SLOT_MODAL_CONTAINS = 16;
   public static final int SLOT_KIND = 17;
   public static final int SLOT_MIN_WIDTH = 18;
   public static final int SLOT_MIN_WIDTH_ALIAS = 19;
   public static final float COLOR_MATCH_EPSILON = 0.1F;
   public static final float RGB_SCALE = 255.0F;
   public static final float DISTANCE_DIVISOR = 3.0F;
   public static final float LAYOUT_PAD = 8.0F;
   public static final float LAYOUT_TOP = 6.0F;
   public static final float SWATCH_STEP = 28.0F;
   public static final float SWATCH_SIZE = 26.0F;
   public static final float SWATCH_H = 29.0F;
   public static final float SWATCH_TRIM = 6.5F;
   public static final float SWATCH_ROW_OFFSET = 32.0F;
   public static final float SWATCH_LEFT_PAD = 10.0F;
   public static final float SWATCH_RIGHT_PAD = 16.0F;
   public static final float HEX_FIELD_W = 192.0F;
   public static final float HEX_FIELD_H = 26.0F;
   public static final float LABEL_FONT_SIZE = 12.0F;
   public static final float FALLBACK_WIDTH = 56.0F;
   public static final float MODAL_W = 293.0F;
   public static final float MODAL_H = 383.0F;
   public static final float MODAL_PAD = 20.0F;
   public static final float MODAL_DRAG_BIAS = 16.0F;
   public static final float NEAR_ZERO = 0.001F;
   public static final float SECTION_CORNER = 10.0F;
   public static final float ONE = 1.0F;
   public static final int FLOAT_ONE = 1065353216;
   public static final int KIND = 63;
   public static final float MIN_WIDTH = 16.0F;
   public static final float DEFAULT_WIDTH = 269.0F;
   public static final int PALETTE_COUNT = 7;
   public static final int[] PALETTE = new int[]{-1, -16777216, -1096636, -429290, -340971, -14498466, -12877066};
   private Setting setting;
   private Setting colorSource;
   private Setting gradient;
   private boolean modalVisible;
   private String hexEdit = "";
   private boolean hexEditing;
   private float swatchX;
   private float swatchY;
   private float swatchW;
   private boolean cacheValid;
   private int cachedColor;
   private String hex = "";
   private float hexValue;
   private int paletteIndex = -1;
   private boolean hasSecond;
   private float layoutAnimA;
   private float layoutAnimB;
   private int modalColorA;
   private int modalColorB;
   private int modalColorC;
   private boolean modalFlagDF;
   private boolean modalFlagCC;
   private float modalFlag61C;
   private float modalSwatchC;
   private float labelWidth = -1.0F;
   private float labelWidthCache;
   private float valueWidth = -1.0F;
   private float valueWidthCache;
   public static final float LABEL_GAP = 20.0F;

   public ColorPickerWidget() {
   }

   public ColorPickerWidget(Setting setting) {
      this.init(setting);
      this.syncHex();
      this.runInit();
   }

   public ColorPickerWidget(Setting setting, boolean gradient) {
      this.init(setting);
      if (gradient) {
         this.gradient = setting;
         this.hasSecond = true;
      }

      this.syncHex();
      this.runInit();
   }

   private void init(Setting setting) {
      this.setting = setting;
      this.flags = 256;
      this.width = 269.0F;
      this.colorSource = setting;
      this.gradient = null;
      this.modalVisible = false;
      this.hexEditing = false;
      this.hexEdit = "";
      this.hex = "";
      this.hexValue = 0.0F;
      this.paletteIndex = -1;
      this.cacheValid = false;
      this.hasSecond = false;
      this.modalFlagDF = false;
      this.modalFlagCC = false;
      this.swatchX = 0.0F;
      this.swatchY = 0.0F;
      this.swatchW = 0.0F;
      this.modalFlag61C = 1.0F;
      this.modalColorA = 1065353216;
      this.modalColorB = 1065353216;
      this.modalColorC = 1065353216;
      this.modalSwatchC = 0.0F;
      this.labelWidth = -1.0F;
      this.valueWidth = -1.0F;
   }

   private void runInit() {
      if (this.gradient == null || !this.modalFlagDF) {
         this.syncHex();
         int index = this.paletteIndex;
         if (index < 0) {
            return;
         }

         this.cachedColor = index;
         this.modalColorA = 1065353216;
         this.modalFlag61C = 1.0F;
         this.modalColorB = 1065353216;
         this.modalFlagDF = false;
         float f = index;
         this.swatchW = f;
         this.modalSwatchC = f;
         this.modalColorC = 1065353216;
         this.modalFlagCC = false;
      }
   }

   public int kind() {
      return 63;
   }

   public float minWidth() {
      return 16.0F;
   }

   @Override
   public float preferredWidth() {
      return 16.0F;
   }

   @Override
   public float preferredHeight() {
      return this.measuredHeight();
   }

   public int sourceColor() {
      return this.colorSource == null ? -16777216 : this.colorSource.getColor() | 0xFF000000;
   }

   public Setting setting() {
      return this.setting;
   }

   public boolean modalVisible() {
      return this.modalVisible;
   }

   public String hex() {
      return this.hex;
   }

   public int paletteIndex() {
      return this.paletteIndex;
   }

   public void syncHex() {
      int color = this.sourceColor();
      if (!this.cacheValid || color != this.cachedColor) {
         this.cacheValid = true;
         this.cachedColor = color;
         int r = color >>> 16 & 0xFF;
         int g = color >>> 8 & 0xFF;
         int b = color & 0xFF;
         this.hex = String.format("#%02X%02X%02X", r, g, b);
         this.hexValue = parseHex(this.hex, 12.0F);
         this.paletteIndex = -1;

         for (int i = 0; i < 7; i++) {
            if ((PALETTE[i] & 16777215) == (color & 16777215)) {
               this.paletteIndex = i;
               return;
            }
         }
      }
   }

   public void openModal() {
      this.modalVisible = true;
      if (isModalOpenGlobal()) {
         openModalGlobal();
      } else {
         this.openModalLocal();
      }
   }

   @Override
   public boolean isActive() {
      return this.modalVisible && (26.0F < this.layoutAnimA || 26.0F < this.layoutAnimB);
   }

   public boolean modalContains(double mx, double my) {
      return !this.modalVisible ? false : 26.0F < this.layoutAnimA || 26.0F < this.layoutAnimB;
   }

   @Override
   public void tick() {
      if (this.modalVisible) {
         if (26.0F < this.layoutAnimA || 26.0F < this.layoutAnimB) {
            this.advanceModal();
         }
      }
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      int source = this.sourceColor();
      int theme = uiThemeColor(0);
      int themeAlt = uiThemeColor(1);
      int blended = uiLerpColor(source, theme | 0xFF000000, 0.5F);
      int dr = (blended >>> 16 & 0xFF) - (theme >>> 16 & 0xFF);
      int dg = (blended >>> 8 & 0xFF) - (theme >>> 8 & 0xFF);
      int db = (blended & 0xFF) - (theme & 0xFF);
      float dist = (dg * dg + dr * dr + db * db) / 255.0F;
      dist = (float)Math.sqrt(dist);
      if (dist < 0.1F) {
         blended = uiLerpColor(blended, themeAlt | 0xFF000000, 0.5F);
      }

      this.syncHex();
      if (this.hexEditing) {
         this.formatHexEdit();
      }

      boolean second = this.gradient != null && this.hasSecond;
      renderModal(this, blended, source);
      float swatch = this.swatchHeight();
      float label = this.measureLabel(0.0F);
      float value = this.measureValue();
      float rowY = py - 3.0F;
      float rowH = px + this.width - swatch;
      float swatchTop = rowY + 8.0F;
      float swatchLeft = rowH + 6.0F;
      if (second) {
         renderModalGradient(this, source);
         this.setModalRow(rowH);
      } else if (!this.hexEditing) {
         drawSwatchRow(renderer, rowH, swatchTop, alpha);
         renderHexField(renderer, this.hex, swatchLeft, swatchTop, alpha);
      } else {
         drawSwatchRow(renderer, rowH, swatchTop, alpha);
         renderHexEditor(renderer, this.hexEdit, swatchLeft, swatchTop, alpha);
      }

      this.swatchX = rowH;
      this.swatchY = rowY;
      this.swatchW = swatch;
      if (0.0F < value) {
         label = label + 0.0F + value;
      }

      float bottom = label + py + 8.0F;
      renderSwatch(this, blended, source, bottom, alpha);
      this.height = bottom + 32.0F - this.y;
   }

   @Override
   public void render() {
      this.render(this, this.x, this.y, this.alpha);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (!this.modalVisible) {
         return this.mouseClickedSwatch(mx, my, button, this.x, this.y, this.width);
      } else if (mx >= 20.0 && mx <= 297.0 && my >= 20.0 && my <= 387.0) {
         modalClick(this, mx, my);
         return true;
      } else {
         modalCancel(this);
         return true;
      }
   }

   public boolean mouseClickedSwatch(double mx, double my, int button, float px, float py, float pw) {
      if (button != 0) {
         if (this.hexEditing) {
            this.commitHex(1);
         }

         return false;
      } else if (mx >= this.swatchX && mx <= this.swatchX + this.swatchW && my >= this.swatchY && my <= this.swatchY + 26.0F) {
         if (this.gradient != null && this.hasSecond) {
            this.openModal();
            return true;
         } else if (this.hexEditing) {
            return true;
         } else {
            this.syncHex();
            this.hexEdit = this.hex;
            this.hexEditing = true;
            return true;
         }
      } else {
         if (this.hexEditing) {
            this.commitHex(1);
         }

         float arrowX = px + 10.0F + 16.0F + 26.0F + 8.0F + 32.0F + 8.0F + 10.0F;
         if (mx >= arrowX && mx <= arrowX + 26.0F && my >= this.swatchY + 8.0F + 8.0F && my <= this.swatchY + 8.0F + 8.0F + 26.0F) {
            this.openModal();
            return true;
         } else {
            if (mx >= px && mx <= px + pw && my >= this.swatchY && my <= this.swatchY + 32.0F) {
               for (int i = 0; i < 7; i++) {
                  float itemX = i * 32.0F + px + 8.0F - 6.5F;
                  if (mx >= itemX && mx <= itemX + 29.0F && my >= this.swatchY + 3.0F && my <= this.swatchY + 3.0F + 26.0F) {
                     this.applyPalette(i);
                     return true;
                  }
               }
            }

            return false;
         }
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (!this.modalVisible) {
         return false;
      } else {
         return !(26.0F < this.layoutAnimA) && !(26.0F < this.layoutAnimB) ? false : modalMouseReleased(this);
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      mouseX = (float)mx;
      mouseY = (float)my;
      if (!this.modalVisible) {
         return false;
      } else {
         return !(26.0F < this.layoutAnimA) && !(26.0F < this.layoutAnimB) ? false : modalMouseMoved(this, mx, my, delta);
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      mouseX = (float)mx;
      mouseY = (float)my;
      if (!this.modalVisible) {
         return false;
      } else {
         return !(26.0F < this.layoutAnimA) && !(26.0F < this.layoutAnimB) ? false : modalMouseScrolled(this);
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (!this.modalVisible) {
         if (!this.hexEditing) {
            return false;
         } else if (keyCode == 27) {
            this.hexEditing = false;
            return true;
         } else {
            cursorKey(this.hexEdit, keyCode);
            return true;
         }
      } else {
         return !(26.0F < this.layoutAnimA) && !(26.0F < this.layoutAnimB) ? false : modalKeyPressed(this, keyCode);
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (!this.modalVisible) {
         return false;
      } else {
         return !(26.0F < this.layoutAnimA) && !(26.0F < this.layoutAnimB) ? false : modalKeyReleased(this, keyCode);
      }
   }

   @Override
   public boolean charTyped(char ch) {
      if (!this.modalVisible) {
         if (!this.hexEditing) {
            return false;
         } else {
            if (isHexChar(ch)) {
               cursorChar(this.hexEdit, ch);
            }

            return true;
         }
      } else {
         return !(26.0F < this.layoutAnimA) && !(26.0F < this.layoutAnimB) ? false : modalCharTyped(this, ch);
      }
   }

   public float measuredHeight() {
      float extra;
      if (this.gradient != null && this.hasSecond) {
         extra = 56.0F;
      } else {
         this.syncHex();
         extra = this.hexValue + 32.0F;
      }

      float w1 = this.measureValueFor(this.width - extra - 6.0F);
      float w2 = this.swatchHeight();
      if (0.0F < w1) {
         w2 = w2 + 0.0F + w1;
      }

      return w2 + 8.0F + 32.0F;
   }

   public void commitHex(int apply) {
      if (this.hexEditing) {
         this.hexEditing = false;
         if (apply != 0) {
            int parsed = parseHexColor(this.hexEdit);
            if (parsed >= 0) {
               int alpha = -16777216;
               if (this.colorSource != null && this.colorSource.getColor() != 0) {
                  alpha = this.colorSource.getColor() & 0xFF000000;
               }

               int value = alpha | parsed & 16777215;
               if (this.colorSource != null && this.colorSource.getColor() != value) {
                  this.colorSource.setColor(value);
                  if (this.setting != null && this.setting != this.colorSource) {
                     this.setting.setColor(value);
                  }
               }
            }
         }
      }
   }

   private void applyPalette(int index) {
      int color = PALETTE[index];
      if (this.colorSource != null) {
         this.colorSource.setColor(color);
      }

      if (this.setting != null && this.setting != this.colorSource) {
         this.setting.setColor(color);
      }
   }

   private void setModalRow(float value) {
      this.layoutAnimA = value;
   }

   private float measureLabel(float avail) {
      if (this.labelWidth == avail) {
         return this.labelWidthCache;
      } else {
         this.labelWidth = avail;
         this.labelWidthCache = fontWidth(this.setting == null ? "" : this.setting.getName(), 12.0F);
         return this.labelWidthCache;
      }
   }

   private float measureValue() {
      float avail = this.width - (this.kind() == 89 ? 0.0F : 20.0F);
      if (avail <= 0.0F) {
         avail = 0.0F;
      }

      return this.measureValueFor(avail);
   }

   private float measureValueFor(float avail) {
      if (this.valueWidth == avail) {
         return this.valueWidthCache;
      } else {
         this.valueWidth = avail;
         this.valueWidthCache = fontWidth(this.hex, 12.0F);
         return this.valueWidthCache;
      }
   }

   private float swatchHeight() {
      return 26.0F;
   }

   public static float parseHex(String s, float fallback) {
      int parsed = parseHexColor(s);
      return parsed < 0 ? fallback : parsed;
   }

   public static int parseHexColor(String s) {
      if (s == null) {
         return -1;
      } else {
         String t = s.startsWith("#") ? s.substring(1) : s;
         if (t.length() != 6) {
            return -1;
         } else {
            int value = 0;

            for (int i = 0; i < 6; i++) {
               int d = Character.digit(t.charAt(i), 16);
               if (d < 0) {
                  return -1;
               }

               value = value << 4 | d;
            }

            return value;
         }
      }
   }

   private static boolean isHexChar(char ch) {
      return ch >= '0' && ch <= '9' || ch >= 'a' && ch <= 'f' || ch >= 'A' && ch <= 'F' || ch == '#';
   }

   private static float fontWidth(String s, float size) {
      return s != null && !s.isEmpty() ? s.length() * size : 0.0F;
   }

   private static boolean isModalOpenGlobal() {
      return false;
   }

   private static void openModalGlobal() {
   }

   private void openModalLocal() {
   }

   private void advanceModal() {
   }

   private void formatHexEdit() {
   }

   private static void renderModal(ColorPickerWidget self, int blended, int source) {
   }

   private static void renderModalGradient(ColorPickerWidget self, int source) {
   }

   private static void drawSwatchRow(Object renderer, float px, float py, float alpha) {
   }

   private static void renderHexField(Object renderer, String s, float px, float py, float alpha) {
   }

   private static void renderHexEditor(Object renderer, String s, float px, float py, float alpha) {
   }

   private static void renderSwatch(ColorPickerWidget self, int blended, int source, float py, float alpha) {
   }

   private static boolean modalMouseReleased(ColorPickerWidget self) {
      return false;
   }

   private static boolean modalMouseMoved(ColorPickerWidget self, double mx, double my, double delta) {
      return false;
   }

   private static boolean modalMouseScrolled(ColorPickerWidget self) {
      return false;
   }

   private static boolean modalKeyPressed(ColorPickerWidget self, int keyCode) {
      return false;
   }

   private static boolean modalKeyReleased(ColorPickerWidget self, int keyCode) {
      return false;
   }

   private static boolean modalCharTyped(ColorPickerWidget self, char ch) {
      return false;
   }

   private static void modalClick(ColorPickerWidget self, double mx, double my) {
   }

   private static void modalCancel(ColorPickerWidget self) {
   }

   private static void cursorKey(String s, int keyCode) {
   }

   private static void cursorChar(String s, char ch) {
   }
}

