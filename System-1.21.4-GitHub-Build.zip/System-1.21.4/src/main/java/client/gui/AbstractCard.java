package client.gui;

public class AbstractCard extends Component {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_ATTACH = 16;
   public static final int SLOT_DETACH = 24;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_MOUSE_RELEASED = 40;
   public static final int SLOT_MOUSE_MOVED = 48;
   public static final int SLOT_MOUSE_SCROLLED = 56;
   public static final int SLOT_KEY_PRESSED = 64;
   public static final int SLOT_CHAR_TYPED = 72;
   public static final int SLOT_KEY_RELEASED = 80;
   public static final int SLOT_SET_POSITION = 88;
   public static final int SLOT_SET_STATE = 96;
   public static final int SLOT_RENDER_CONTENT = 104;
   public static final int SLOT_ON_MOUSE = 112;
   public static final float ANIM_DURATION_FAST = 0.15F;
   public static final float ANIM_DURATION_MEDIUM = 0.22F;
   public static final float ANIM_DURATION_SLOW = 0.28F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float EASE_OUT_EXPO_FACTOR = -6.931472F;
   public static final int KEY_ENTER = 13;
   public static final int KEY_ESCAPE = 27;
   public static final int MOD_SHIFT = 2;
   public static final String NEWLINE = "\n";
   protected final AbstractCard.Anim rectAnim = new AbstractCard.Anim(0.0F, 0.0F, 0);
   protected AbstractCard.Anim animX;
   protected AbstractCard.Anim animY;
   protected final AbstractCard.Anim alphaAnim = new AbstractCard.Anim(0.0F, 0.22F, 0);
   protected int state;
   public static final int EASE_OUT_CUBIC = 0;
   public static final int EASE_OUT_EXPO = 1;

   public AbstractCard() {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.animX = null;
      this.animY = null;
      this.animatingPosition = false;
      this.state = 0;
      this.mouseOwned = false;
   }

   public static float ease(int easing, float t) {
      return easing == 1 ? easeOutExponential(t) : easeOutCubic(t);
   }

   public static float easeOutExponential(float t) {
      return t < 1.0F ? 1.0F - (float)Math.exp(t * -6.931472F) : 1.0F;
   }

   @Override
   public void dispose() {
      this.children.clear();
      this.animX = null;
      this.animY = null;
      super.dispose();
   }

   public void renderAnimated(Object renderer, float mouseX, float mouseY, float factor) {
      this.applyPositionAnimation(this.now());
      float value = this.alphaAnim.update(this.now());
      if (0.0F < value * factor) {
         this.render(renderer, mouseX, mouseY, value * factor);
      }
   }

   @Override
   public void render(Object renderer, float mouseX, float mouseY, float alpha) {
   }

   public boolean onMouse(double mx, double my, int button) {
      return false;
   }

   public void setState(int newState, float newWidth) {
      this.width = newWidth;
      this.state = newState;
      this.height = newState == 1 ? 174.0F : 62.0F;
   }

   public void applyPositionAnimation(long time) {
      if (this.animatingPosition && this.animX != null && this.animY != null) {
         this.x = this.animX.update(time);
         this.y = this.animY.update(time);
      }
   }

   public static void blurFocusedChildren(Component parent) {
      for (Component child : parent.children) {
         if (child.focused) {
            String text = child instanceof AbstractCard.InputChild ? ((AbstractCard.InputChild)child).getText() : "";
            child.focused = false;
            if (child instanceof AbstractCard.InputChild input) {
               input.setText("");
               input.blur(text);
            }

            if (!child.children.isEmpty() && child.children.get(0) instanceof AbstractCard.AttachAware) {
               ((AbstractCard.AttachAware)child.children.get(0)).onAttach(child);
            }
         }
      }
   }

   public static Component focusedChild(Component parent) {
      for (Component child : parent.children) {
         if (child.focused) {
            return child;
         }
      }

      return null;
   }

   public static boolean routeKeyPressed(Component parent, int keyCode, int modifiers) {
      Component child = focusedChild(parent);
      if (child == null) {
         return false;
      } else {
         child.lastInputTime = parent.now() / 1000000L;
         if (keyCode == 13) {
            if (child instanceof AbstractCard.InputChild input) {
               if (input.isShiftCommit() && (modifiers & 2) != 0) {
                  input.setText(input.getText() + "\n");
                  return true;
               } else {
                  input.commit();
                  return true;
               }
            } else {
               return false;
            }
         } else if (keyCode == 27) {
            if (child instanceof AbstractCard.InputChild) {
               ((AbstractCard.InputChild)child).cancel();
               return true;
            } else {
               return false;
            }
         } else {
            return child instanceof AbstractCard.InputChild ? handleCharacterInput((AbstractCard.InputChild)child, keyCode, modifiers) : false;
         }
      }
   }

   public static boolean routeKeyReleased(Component parent, int keyCode) {
      Component child = focusedChild(parent);
      if (child == null) {
         return false;
      } else if (child.capture == null || child.capture instanceof AbstractCard.KeyCapture && ((AbstractCard.KeyCapture)child.capture).onKey(keyCode)) {
         child.lastInputTime = parent.now() / 1000000L;
         return child instanceof AbstractCard.InputChild ? insertCodePoint((AbstractCard.InputChild)child, keyCode) : false;
      } else {
         return false;
      }
   }

   public static boolean handleCharacterInput(AbstractCard.InputChild child, int keyCode, int modifiers) {
      return handleCharInput(child, keyCode, modifiers);
   }

   public static boolean handleCharInput(AbstractCard.InputChild child, int keyCode, int modifiers) {
      return false;
   }

   public static boolean insertCodePoint(AbstractCard.InputChild child, int codePoint) {
      if (codePoint >= 32 && codePoint != 127) {
         child.setText(child.getText() + new String(Character.toChars(codePoint)));
         return true;
      } else {
         return false;
      }
   }

   public static void focusChildWithText(Component parent, Component child, String value) {
      for (Component other : parent.children) {
         if (other != child && other instanceof AbstractCard.InputChild) {
            ((AbstractCard.InputChild)other).commit();
         }
      }

      child.focused = true;
      if (child instanceof AbstractCard.InputChild) {
         ((AbstractCard.InputChild)child).setText(value);
      }

      if (!child.children.isEmpty() && child.children.get(0) instanceof AbstractCard.AttachAware) {
         ((AbstractCard.AttachAware)child.children.get(0)).onAttach(child);
      }

      child.lastInputTime = parent.now() / 1000000L;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (!this.mouseOwned) {
         if (this.onMouse(mx, my, button)) {
            return true;
         }

         blurFocusedChildren(this);
      }

      return false;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      return routeKeyPressed(this, keyCode, modifiers);
   }

   @Override
   public boolean keyReleased(int keyCode) {
      return routeKeyReleased(this, keyCode);
   }

   @Override
   public void setPosition(float px, float py) {
      if (this.alphaAnim.current == 0.0F && this.alphaAnim.target == 0.0F) {
         this.alphaAnim.setTarget(1.0F);
      }

      this.setPositionAnimated(px, py);
   }

   public void setPositionAnimated(float px, float py) {
      if (this.animX == null) {
         this.animX = new AbstractCard.Anim(px, 0.0F, 1);
         this.animY = new AbstractCard.Anim(py, 0.0F, 1);
      }

      if (!this.animatingPosition) {
         this.animX.snap(px);
         this.animY.snap(py);
         this.x = px;
         this.y = py;
         this.animatingPosition = true;
      } else {
         this.animX.setTarget(px);
         this.animY.setTarget(py);
      }
   }

   public static final class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing;
      public long start;
      public boolean running;

      public Anim(float value, float duration, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = easing;
         this.start = System.nanoTime();
         this.running = false;
      }

      public float update(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float t = (float)((time - this.start) / 1.0E9) / this.duration;
            if (t <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (1.0F <= t) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = AbstractCard.ease(this.easing, t) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      public void setTarget(float value) {
         if (this.target != value) {
            long time = System.nanoTime();
            float resumed = this.update(time);
            this.from = resumed;
            this.current = resumed;
            this.start = time;
            this.target = value;
            this.running = true;
         }
      }

      public void snap(float value) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.running = false;
      }
   }

   public interface AttachAware {
      void onAttach(Component var1);
   }

   public interface InputChild {
      String getText();

      void setText(String var1);

      boolean isShiftCommit();

      void commit();

      void cancel();

      void blur(String var1);
   }

   public interface KeyCapture {
      boolean onKey(int var1);
   }
}

