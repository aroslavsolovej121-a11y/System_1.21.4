package client.gui;

public class ColorToggleRow extends Component {
}
