package client.gui;

public class AbstractOverlay extends Component {
   public static final int EASE_OUT_CUBIC = 0;
   public static final int EASE_OUT_QUINT = 1;
   public static final int EASE_EXPO_OUT = 2;
   public static final int SOUND_CLOSE = 5;
   public static final int SOUND_ACTIVATE = 10;
   public static final float DEFAULT_RECT_DURATION = 0.15F;
   public static final float DEFAULT_ALPHA_DURATION = 0.38F;
   public static final float CLOSE_ALPHA_DURATION = 0.26F;
   public static final float ACTIVATE_ALPHA_DURATION = 0.38F;
   public static final float ALPHA_REMAP_SCALE = 0.08F;
   public static final float ALPHA_REMAP_BIAS = 0.92F;
   public static final float ALPHA_INVERSE_SCALE = 16.0F;
   public static final float ALPHA_VISIBLE_EPSILON = 0.001F;
   public static final float CONST_EIGHT = 8.0F;
   public static final float RENDER_GATE_ONE = 1.0F;
   public static final float RENDER_GATE_ZERO = 0.0F;
   protected static AbstractOverlay activeOverlay;
   protected boolean closed;
   protected boolean closeOnOutsideClick = true;
   protected boolean closeOnEscape = true;
   protected boolean detached;
   protected Component child;
   protected float rectFrom;
   protected float rectCurrent;
   protected float rectTarget;
   protected float rectDuration = 0.15F;
   protected int rectEasing = 0;
   protected long rectStart;
   protected boolean rectRunning;
   protected int alphaEasing = 1;
   private static boolean FRAME_STAGE_LOCKED = false;
   private static boolean FRAME_READY_A = true;
   private static boolean FRAME_READY_B = true;
   private static boolean FRAME_PRESENT_LOCKED = false;
   private static boolean FRAME_DEFERRED = false;
   private static boolean FRAME_DEFERRED_B = false;

   public AbstractOverlay() {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.initRectAnimator();
      this.animXFrom = 0.0F;
      this.animXCurrent = 0.0F;
      this.animXTarget = 0.0F;
      this.animYFrom = 0.0F;
      this.animYCurrent = 0.0F;
      this.animYTarget = 0.0F;
      this.animatingPosition = false;
      this.animFrom = 0.0F;
      this.alpha = 0.0F;
      this.alphaTarget = 0.0F;
      this.alphaDuration = 0.38F;
      this.alphaEasing = 1;
      this.alphaStart = this.now();
      this.alphaRunning = false;
      this.closed = false;
      this.closeOnOutsideClick = true;
      this.closeOnEscape = true;
      this.detached = false;
      this.child = null;
   }

   protected void initRectAnimator() {
      this.rectFrom = 0.0F;
      this.rectCurrent = 0.0F;
      this.rectTarget = 0.0F;
      this.rectDuration = 0.15F;
      this.rectEasing = 0;
      this.rectStart = this.now();
      this.rectRunning = false;
   }

   public static float clamp01(float value) {
      if (value <= 0.0F) {
         return 0.0F;
      } else {
         return value <= 1.0F ? value : 1.0F;
      }
   }

   public static float easeOutQuint(float t) {
      float inv = 1.0F - t;
      return 1.0F - inv * inv * inv * inv * inv;
   }

   public static float easeExpoOut(float t) {
      return t < 1.0F ? 1.0F - (float)Math.exp(t * -6.931472F) : 1.0F;
   }

   public static float applyEasing(int easing, float t) {
      if (easing == 1) {
         return easeOutQuint(t);
      } else {
         return easing == 2 ? easeExpoOut(t) : easeOutCubic(t);
      }
   }

   public static float advance(AbstractOverlay.Animator anim, long time) {
      if (anim.running && !(anim.duration <= 0.0F)) {
         float t = (float)((time - anim.start) / 1.0E9) / anim.duration;
         if (t <= 0.0F) {
            anim.current = anim.from;
            return anim.current;
         } else if (t >= 1.0F) {
            anim.running = false;
            anim.current = anim.target;
            return anim.current;
         } else {
            float target = anim.target;
            float from = anim.from;
            anim.current = applyEasing(anim.easing, t) * (target - from) + from;
            return anim.current;
         }
      } else {
         anim.current = anim.target;
         anim.running = false;
         return anim.current;
      }
   }

   public static void animate(AbstractOverlay.Animator anim, float value) {
      if (anim.target != value) {
         long time = System.nanoTime();
         float current = advance(anim, time);
         anim.start = time;
         anim.from = current;
         anim.target = value;
         anim.running = true;
      }
   }

   public static void resetAnimator(AbstractOverlay.Animator anim, float value, float duration, int easing) {
      long time = System.nanoTime();
      anim.from = value;
      anim.current = value;
      anim.target = value;
      anim.duration = duration;
      anim.easing = easing;
      anim.start = time;
      anim.running = false;
   }

   public static void resetColorAnimator(AbstractOverlay.ColorAnim anim, int color, float duration) {
      anim.duration = duration;
      anim.easing = 0;
      anim.from = 1.0F;
      anim.current = 1.0F;
      anim.target = 1.0F;
      anim.start = System.nanoTime();
      anim.colorFrom = color;
      anim.colorTarget = color;
      anim.running = false;
   }

   public static int mixColor(int from, int to, float t) {
      if (t <= 0.0F) {
         return from;
      } else if (1.0F <= t) {
         return to;
      } else {
         int out = 0;

         for (int shift = 0; shift < 32; shift += 8) {
            float a = from >>> shift & 0xFF;
            float b = to >>> shift & 0xFF;
            int mix = (int)((long)((b - a) * t + a));
            out |= mix << shift;
         }

         return out;
      }
   }

   public static float repaintScale(float alpha) {
      float clamped = clamp01(alpha);
      return clamped * 0.08F + 0.92F;
   }

   public static float fadeScale(float alpha) {
      float clamped = clamp01(alpha);
      return (1.0F - clamped) * 16.0F;
   }

   public float alphaCurrent() {
      return this.alpha;
   }

   public float alphaRemap() {
      return repaintScale(this.alpha);
   }

   public float alphaInverse() {
      return fadeScale(this.alpha);
   }

   public float overlayConst() {
      return 8.0F;
   }

   public void reset() {
      this.closed = false;
      this.animFrom = 0.0F;
      this.alpha = 0.0F;
      this.alphaTarget = 0.0F;
      this.alphaRunning = false;
   }

   public void activate() {
      this.closed = false;
      this.detached = false;
      this.alphaDuration = 0.38F;
      this.alphaEasing = 1;
      if (this.alphaTarget != 1.0F) {
         long time = this.now();
         float current = this.advanceAlpha(time);
         this.alphaStart = time;
         this.animFrom = current;
         this.alpha = current;
         this.alphaTarget = 1.0F;
         this.alphaRunning = true;
      }

      uiSound(10);
      if (activeOverlay != null && activeOverlay != this) {
         activeOverlay.reset();
      }

      activeOverlay = this;
   }

   public void close() {
      if (!this.closed) {
         this.closed = true;
         uiSound(5);
         this.alphaDuration = 0.26F;
         this.alphaEasing = 0;
         if (this.alphaTarget != 0.0F) {
            long time = this.now();
            float current = this.advanceAlpha(time);
            this.alphaStart = time;
            this.animFrom = current;
            this.alpha = current;
            this.alphaTarget = 0.0F;
            this.alphaRunning = true;
         }

         this.onClosed();
      }
   }

   public float advanceAlpha(long time) {
      if (this.alphaRunning && !(this.alphaDuration <= 0.0F)) {
         float t = (float)((time - this.alphaStart) / 1.0E9) / this.alphaDuration;
         if (t <= 0.0F) {
            this.alpha = this.animFrom;
            return this.alpha;
         } else if (t >= 1.0F) {
            this.alphaRunning = false;
            this.alpha = this.alphaTarget;
            return this.alpha;
         } else {
            this.alpha = applyEasing(this.alphaEasing, t) * (this.alphaTarget - this.animFrom) + this.animFrom;
            return this.alpha;
         }
      } else {
         this.alpha = this.alphaTarget;
         this.alphaRunning = false;
         return this.alpha;
      }
   }

   @Override
   public void updateAlpha(long time) {
      this.advanceAlpha(time);
   }

   public void animateAlphaTo(float target) {
      if (this.alphaTarget != target) {
         long time = this.now();
         float current = this.advanceAlpha(time);
         this.alphaStart = time;
         this.animFrom = current;
         this.alpha = current;
         this.alphaTarget = target;
         this.alphaRunning = true;
      }
   }

   public void setChild(Component value) {
      if (this.child != value) {
         if (this.child != null) {
            this.child = null;
         }

         this.child = value;
      }

      if (this.child != null) {
         this.x = this.child.getX();
         this.y = this.child.getY();
      }

      this.activate();
   }

   public void setChildAlt(Component value) {
      if (this.child != value) {
         if (this.child != null) {
            this.child = null;
         }

         this.child = value;
      }

      if (this.child != null) {
         this.x = this.child.getX();
         this.y = this.child.getY();
      }

      this.relayoutChildren();
   }

   protected void relayoutChildren() {
      this.activate();
   }

   protected void syncChildPosition() {
      if (this.child != null) {
         this.x = this.child.getX();
         this.y = this.child.getY();
      }
   }

   public void renderOverlay(Object target, float rx, float ry, float parentAlpha) {
      long time = this.now();
      float current = this.advanceAlpha(time);
      if (0.001F < current) {
         this.syncChildPosition();
         if (isRenderGateOpen()) {
            prepareFrameStage();
            if (frameQueueHead() != frameQueueTail()) {
               flushFrameQueue();
            }

            presentFrame();
            installShutdownHook();
            resetFrameFlag();
         }

         this.renderBody(target, rx, ry, current * parentAlpha);
      } else if (this.closed) {
         this.onDisposed();
         if (this.child != null) {
            this.child = null;
         }

         if (!this.detached && activeOverlay == this) {
            activeOverlay = null;
         }
      }
   }

   @Override
   public void render() {
      this.renderOverlay(null, this.x, this.y, 1.0F);
   }

   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.closed) {
         return true;
      } else {
         this.syncChildPosition();
         if (button == 0 && this.closeOnOutsideClick && !this.contains(mx, my)) {
            this.close();
            return true;
         } else {
            return this.onMouseClicked(mx, my, button);
         }
      }
   }

   public boolean onMouseClicked(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (this.closeOnEscape && keyCode == 27) {
         this.close();
         return true;
      } else {
         return this.onKeyPressed(keyCode, modifiers);
      }
   }

   public boolean onKeyPressed(int keyCode, int modifiers) {
      return false;
   }

   public void onClosed() {
   }

   public void onDisposed() {
   }

   public boolean isClosed() {
      return this.closed;
   }

   public Component child() {
      return this.child;
   }

   public static AbstractOverlay activeOverlay() {
      return activeOverlay;
   }

   private static boolean isRenderGateOpen() {
      if (FRAME_STAGE_LOCKED) {
         return false;
      } else if (!FRAME_READY_A) {
         return false;
      } else if (!FRAME_READY_B) {
         return false;
      } else {
         return !FRAME_PRESENT_LOCKED ? true : !FRAME_DEFERRED && FRAME_DEFERRED_B;
      }
   }

   private static void prepareFrameStage() {
   }

   private static void flushFrameQueue() {
   }

   private static void presentFrame() {
   }

   private static void installShutdownHook() {
   }

   private static void resetFrameFlag() {
   }

   private static int frameQueueHead() {
      return 0;
   }

   private static int frameQueueTail() {
      return 0;
   }

   private static void playSoundLocal(int id) {
      uiSound(id);
   }

   public static class Animator {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing = 0;
      public long start;
      public boolean running;

      public Animator() {
      }

      public Animator(float value, float duration, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = easing;
         this.start = System.nanoTime();
         this.running = false;
      }
   }

   public static class ColorAnim extends AbstractOverlay.Animator {
      public int colorFrom;
      public int colorTarget;

      public ColorAnim() {
      }

      public ColorAnim(int color, float duration) {
         AbstractOverlay.resetColorAnimator(this, color, duration);
      }
   }
}

