package client.gui;

import java.util.ArrayList;
import java.util.List;

public class SwapWheelModal extends AbstractOverlay {
   public static final int GROUP_STRIDE = 200;
   public static final int ANIM_BASE = 240;
   public static final int ANIM_STRIDE = 40;
   public static final int ANIM_COUNT = 69;
   public static final int ANIM_GRID_BASE = 1440;
   public static final int GRID_ANIM_COUNT = 36;
   public static final int SLOT_COUNT = 6;
   public static final int GRID_SLOTS = 27;
   public static final int GRID_ROWS = 9;
   public static final int GRID_ROW_START = 9;
   public static final int GRID_ROW_END = 36;
   public static final int CHARGE_ON_CHANGE = 224;
   public static final int CHARGE_KEY = 232;
   public static final int CHARGE_MODS = 236;
   public static final int ITEM_TAG = 16;
   public static final float PAD = 16.0F;
   public static final float RADIUS = 12.0F;
   public static final float ONE = 1.0F;
   public static final float HALF = 0.5F;
   public static final float F2 = 2.0F;
   public static final float F4 = 4.0F;
   public static final float F5 = 5.0F;
   public static final float F6 = 6.0F;
   public static final float F7 = 7.0F;
   public static final float F8 = 8.0F;
   public static final float F10 = 10.0F;
   public static final float F12 = 12.0F;
   public static final float F14 = 14.0F;
   public static final float F16 = 16.0F;
   public static final float F18 = 18.0F;
   public static final float F20 = 20.0F;
   public static final float F24 = 24.0F;
   public static final float F26 = 26.0F;
   public static final float F28 = 28.0F;
   public static final float F30 = 30.0F;
   public static final float F31 = 31.0F;
   public static final float F38 = 38.0F;
   public static final float F40 = 40.0F;
   public static final float F48 = 48.0F;
   public static final float F59 = 59.0F;
   public static final float F70 = 70.0F;
   public static final float F78 = 78.0F;
   public static final float F92 = 92.0F;
   public static final float F93 = 93.0F;
   public static final float F100 = 100.0F;
   public static final float F156 = 156.0F;
   public static final float F200 = 200.0F;
   public static final float F204 = 204.0F;
   public static final float F220 = 220.0F;
   public static final float F226 = 226.0F;
   public static final float F254 = 254.0F;
   public static final float F302 = 302.0F;
   public static final float WHEEL_WIDTH = 812.0F;
   public static final float WHEEL_HEIGHT = 310.0F;
   public static final float EPS = 0.001F;
   public static final float ALPHA_EPS = 0.999F;
   public static final float F0_85 = 0.85F;
   public static final float F0_7 = 0.7F;
   public static final float F0_35 = 0.35F;
   public static final float TAU = (float) (Math.PI * 2);
   public static final float PI = (float) Math.PI;
   public static final float ANGLE_STEP = 0.02F;
   public static final float INV_SLOT_STEP = 0.0063661975F;
   public static final float F1_7 = 1.7F;
   public static final float ANIM_DURATION = 0.15F;
   public static final float PANEL_DURATION = 0.55F;
   public static final float BIND_DURATION = 0.28F;
   public static final int THEME_PRIMARY = 0;
   public static final int THEME_BORDER = 4;
   public static final int THEME_SECONDARY = 8;
   public static final int THEME_PANEL = 12;
   public static final int THEME_TEXT = 16;
   public static final int THEME_ACCENT = 20;
   public static final int THEME_MUTED = 24;
   private static final String BIND_PREFIX = "Ячейка ";
   private static final String EMPTY_SLOT = "Ячейка пустая — добавьте предмет из инвентаря";
   private static final String CLEAR_LABEL = "Очистить выбранную ячейку";
   private static final String LEFT_HAND_LABEL = "В левой руке";
   private static final String NONE_LABEL = "None";
   private static final String DOTS_LABEL = "...";
   protected SwapWheelModal.ItemWheel setting;
   protected int selectedIndex;
   protected int hoverIndex = -1;
   protected int hoverSlot = -1;
   protected int captureIndex = -1;
   protected int captureKey;
   protected final AbstractOverlay.Animator[] anims = new AbstractOverlay.Animator[69];
   protected final float[] layout = new float[6];

   public SwapWheelModal(SwapWheelModal.ItemWheel setting) {
      this.setting = setting;
      this.selectedIndex = 0;
      this.hoverIndex = -1;
      this.hoverSlot = -1;
      this.captureIndex = -1;
      this.captureKey = 0;

      for (int i = 0; i < this.anims.length; i++) {
         this.anims[i] = new AbstractOverlay.Animator();
      }

      this.initWheelAnims();

      for (int i = 0; i < 36; i++) {
         resetAnimator(this.animAt(1440 + i * 40), 0.0F, 0.15F, 0);
      }

      resetAnimator(this.animAt(2880), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(2920), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(2960), 0.0F, 0.15F, 0);
      this.width = 812.0F;
      this.height = 310.0F;
      this.closeOnOutsideClick = true;
      this.closeOnEscape = true;
   }

   protected AbstractOverlay.Animator animAt(int offset) {
      return this.anims[(offset - 240) / 40];
   }

   protected AbstractOverlay.Animator gridAnim(int index) {
      return this.animAt(1440 + index * 40);
   }

   protected void initWheelAnims() {
      int base = 240;
      resetAnimator(this.animAt(base + 0), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 40), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 80), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 120), 0.0F, 0.55F, 0);
      resetAnimator(this.animAt(base + 160), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 200), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 240), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 320), 0.0F, 0.55F, 0);
      resetAnimator(this.animAt(base + 360), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 400), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 440), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 520), 0.0F, 0.55F, 0);
      resetAnimator(this.animAt(base + 560), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 600), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 640), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 720), 0.0F, 0.55F, 0);
      resetAnimator(this.animAt(base + 760), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 800), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 840), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 920), 0.0F, 0.55F, 0);
      resetAnimator(this.animAt(base + 960), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 1000), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 1040), 0.0F, 0.15F, 0);
      resetAnimator(this.animAt(base + 1120), 0.0F, 0.55F, 0);
      resetAnimator(this.animAt(base + 1160), 0.0F, 0.15F, 0);
   }

   @Override
   public void reset() {
      super.reset();
      this.captureKey = 0;
      this.captureIndex = -1;
   }

   @Override
   public void dispose() {
      if (this.child != null) {
         this.child = null;
      }

      this.children.clear();
      this.capture = null;
   }

   @Override
   public void setChild(Component value) {
      this.width = 812.0F;
      this.height = 310.0F;
      if (this.setting.slotCount() <= this.selectedIndex) {
         this.selectedIndex = 0;
      }

      this.captureIndex = -1;
      this.captureKey = 0;
      this.centerOnScreen();
      this.activate();
   }

   @Override
   public boolean isActive() {
      return true;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      int index = this.captureIndex;
      if (index < 0) {
         if (this.closeOnEscape && keyCode == 27) {
            this.close();
            return true;
         } else {
            return this.onKeyPressed(keyCode, modifiers);
         }
      } else {
         if (keyCode != 27 && keyCode != 46) {
            if (keyCode - 16 < 3 || keyCode - 160 < 6) {
               this.captureKey = keyCode;
               return true;
            }

            if (index < 6) {
               SwapWheelModal.Charge charge = this.setting.chargeAt(index);
               if (charge != null && (charge.key != keyCode || charge.mods != modifiers)) {
                  charge.key = keyCode;
                  charge.mods = modifiers;
                  if (charge.onChange != null) {
                     charge.onChange.run();
                  }
               }
            }
         } else if (index < 6) {
            SwapWheelModal.Charge charge = this.setting.chargeAt(index);
            if (charge != null && (charge.key != 0 || charge.mods != 0)) {
               charge.key = 0;
               charge.mods = 0;
               if (charge.onChange != null) {
                  charge.onChange.run();
               }
            }
         }

         this.captureKey = 0;
         this.captureIndex = -1;
         return true;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (this.captureIndex >= 0) {
         int bound = this.captureKey;
         if (bound != 0 && keyCode == bound) {
            this.applyCapture(this.captureIndex, bound, 0);
            this.captureIndex = -1;
            this.captureKey = 0;
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      int index = this.captureIndex;
      if (index < 0) {
         int digit = keyCode - 49;
         if (digit < 9 && digit < this.setting.slotCount()) {
            this.selectedIndex = digit;
            return true;
         } else if (keyCode != 46 && keyCode != 8) {
            return false;
         } else {
            this.setting.selectSlot(this.selectedIndex);
            return true;
         }
      } else {
         SwapWheelModal.Charge charge = null;
         if (keyCode != 27 && keyCode != 46) {
            if (keyCode - 16 < 3 || keyCode - 160 < 6) {
               this.captureKey = keyCode;
               return true;
            }

            if (index > 5) {
               this.captureIndex = -1;
               this.captureKey = 0;
               return true;
            }

            charge = this.setting.chargeAt(index);
            if (charge == null || charge.key == keyCode && charge.mods == modifiers) {
               this.captureIndex = -1;
               this.captureKey = 0;
               return true;
            }

            charge.key = keyCode;
            charge.mods = modifiers;
         } else {
            if (index > 5) {
               this.captureIndex = -1;
               this.captureKey = 0;
               return true;
            }

            charge = this.setting.chargeAt(index);
            if (charge == null || charge.key == 0 && charge.mods == 0) {
               this.captureIndex = -1;
               this.captureKey = 0;
               return true;
            }

            charge.key = 0;
            charge.mods = 0;
         }

         if (charge.onChange != null) {
            charge.onChange.run();
         }

         this.captureIndex = -1;
         this.captureKey = 0;
         return true;
      }
   }

   protected void applyCapture(int index, int keyCode, int modifiers) {
      if (index >= 0 && index < 6) {
         SwapWheelModal.Charge charge = this.setting.chargeAt(index);
         if (charge != null && (charge.key != keyCode || charge.mods != modifiers)) {
            charge.key = keyCode;
            charge.mods = modifiers;
            if (charge.onChange != null) {
               charge.onChange.run();
            }
         }
      }
   }

   protected void centerOnScreen() {
      float fx = (screenWidth() / screenScale() - this.width) * 0.5F;
      if (fx <= 0.0F) {
         fx = 0.0F;
      }

      this.x = Math.round(fx);
      float fy = (screenHeight() / screenScale() - this.height) * 0.5F;
      if (fy <= 0.0F) {
         fy = 0.0F;
      }

      this.y = Math.round(fy);
   }

   @Override
   public void renderBody(Object target, float px, float py, float parentAlpha) {
      int slotCount = this.setting.slotCount();
      if (slotCount <= this.selectedIndex) {
         this.selectedIndex = 0;
      }

      this.centerOnScreen();
      float source = parentAlpha;
      if (this.captureIndex >= 0) {
         Screen.textInputActive = true;
      }

      float top = (1.0F - clamp01(parentAlpha)) * 16.0F + this.y;
      Object rect = makeRect(new Object(), target, parentAlpha, this.width * 0.5F + this.x, this.height * 0.5F + top);
      int themePrimary = themeColor(0);
      int themePanel = themeColor(12);
      drawPanel(
         rect,
         this.x,
         top,
         this.width,
         this.height,
         12.0F,
         12.0F,
         12.0F,
         12.0F,
         themePrimary,
         themePanel,
         1.0F,
         436207616,
         0,
         2.0F,
         6.0F,
         parentAlpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      this.renderHeader(target, rect, top, px, py, parentAlpha);
      float pad = 14.0F;
      float rowTop = top + 40.0F + 14.0F;
      float left = this.x + 14.0F;
      float panelTop = rowTop + 10.0F;
      this.renderSlots(target, rect, left, panelTop, px, py, slotCount, parentAlpha);
      left = left + 200.0F + pad;
      this.renderPanel(target, rect, left, panelTop, px, py, parentAlpha);
      float right = left + 302.0F + pad;
      float laterTop = rowTop + 0.0F;
      int themeSecondary = themeColor(8);
      themePanel = themeColor(12);
      drawPanel(
         rect,
         right,
         laterTop,
         254.0F,
         204.0F,
         8.0F,
         8.0F,
         8.0F,
         8.0F,
         themeSecondary,
         themePanel,
         1.0F,
         0,
         0,
         0.0F,
         0.0F,
         parentAlpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      float rowStep = 30.0F;
      int slotIndex = 0;

      do {
         this.renderSlot(target, rect, slotIndex, right + 14.0F, slotIndex * rowStep + laterTop + 14.0F, slotIndex < slotCount, px, py, source);
      } while (++slotIndex < 6);

      this.renderFooter(target, rect, top, px, py, source);
      if (this.hoverSlot >= 0 && this.hoverSlot < slotCount || this.hoverIndex >= 0) {
         Screen.hoveredWidget = 1;
      }
   }

   protected void renderHeader(Object target, Object rect, float top, float mouseX, float mouseY, float alpha) {
      themeColor(0);
      themeColor(12);
      float one = 1.0F;
      float titleY = this.y + 12.0F;
      float titleX = this.x + 14.0F;
      drawIcon(target, 47, titleX, titleY + 1.0F, 14.0F, 14.0F, themeColor(24), alpha);
      drawText(4, target, this.setting.name(), titleX + 14.0F + 8.0F, titleY, 16.0F, themeColor(24), alpha);
      float pad = 20.0F;
      float f10 = 10.0F;
      float closeTop = this.y + 10.0F;
      float closeLeft = this.x + this.width - 14.0F - 20.0F;
      float hoverTarget;
      if (!(closeLeft > mouseX)
         && !(closeLeft + 20.0F < mouseX)
         && !(closeTop > mouseY)
         && !(closeTop + 20.0F < mouseY)
         && (AbstractOverlay.activeOverlay == null || Screen.allowHover)) {
         Screen.hoveredWidget = 1;
         hoverTarget = one;
      } else {
         hoverTarget = 0.0F;
      }

      AbstractOverlay.Animator anim = this.animAt(2920);
      if (anim.target != hoverTarget) {
         animate(anim, hoverTarget);
      }

      float eased = advance(anim, this.now());
      int color = uiLerpColor(themeColor(8), themeColor(12), eased);
      drawBox(target, closeLeft, closeTop, 20.0F, 20.0F, 6.0F, 6.0F, 6.0F, 6.0F, color, 0, 0.0F, 0, 0.0F, 0.0F, 0.0F, alpha, 0);
      drawIcon(target, 22, closeLeft + 5.0F, closeTop + 6.0F, 10.0F, 10.0F, themeColor(24), alpha);
      drawBoxGradient(target, this.x + 14.0F, this.y + 40.0F, this.width - 28.0F, 1.0F, 0.0F, themeColor(12), alpha);
   }

   protected void renderSlots(Object target, Object rect, float left, float top, float mouseX, float mouseY, int slotCount, float alpha) {
      themeColor(0);
      themeColor(12);
      float one = 1.0F;
      drawBox(target, left, top, 200.0F, 200.0F, 6.0F, 6.0F, 6.0F, 6.0F, themeColor(0), themeColor(12), 1.0F, 0, 0.0F, 0.0F, 0.0F, alpha, 0);
      float ring = 78.0F;
      float centerX = left + 100.0F;
      float centerY = this.y + 40.0F + 14.0F + 10.0F + 92.0F;
      float clamped = alpha;
      if (alpha < 0.0F) {
         clamped = 0.0F;
      }

      if (clamped > 1.0F) {
         clamped = 1.0F;
      }

      float radius = (1.0F - clamped) * 16.0F + centerY;
      this.layout[0] = radius;
      this.layout[1] = centerX;
      this.hoverSlot = this.hitWheel(mouseX - centerX, mouseY - centerY, 40.0F, ring);
      if (slotCount > 0) {
         float count = slotCount;
         this.layout[5] = count;
         this.layout[4] = negate(radius);
         this.layout[2] = negate(centerX);
         float spanY = radius - ring;
         float spanX = centerX - ring;
         int index = 0;

         do {
            AbstractOverlay.Animator anim = this.animAt(240 + index * 200);
            int selected = this.selectedIndex;
            float slotTarget = 1.0F;
            if (index != this.hoverSlot && index != selected) {
               slotTarget = 0.0F;
            }

            if (anim.target != slotTarget) {
               animate(anim, slotTarget);
            }

            float scale = 0.7F;
            float blend = 0.35F;
            if (index == selected) {
               themeColor(16);
               scale = 0.35F;
            } else {
               themeColor(16);
            }

            float hovered = advance(anim, this.now());
            themeColor(20);
            float amount = hovered * scale;
            if (0.0F < amount && amount < 1.0F) {
               int steps = 0;

               do {
                  steps += 8;
               } while (steps < 32);
            }

            float angle = index * (float) (Math.PI * 2) / count + 0.02F;
            float cos = (float)Math.cos(angle);
            float sin = (float)Math.sin(angle);
            float rx = rectX(rect);
            float ry = rectY(rect);
            float rw = rectWidth(rect);
            float rh = rectHeight(rect);
            float extra = rectExtra(rect);
            float m0 = rx * cos + sin * rw;
            float m1 = ry * cos + sin * rh;
            float m2 = cos * rw - rx * sin;
            float m3 = cos * rh - ry * sin;
            float tx = this.layout[4] * m3 + this.layout[2] * m1 + rh * this.layout[0] + ry * this.layout[1] + extra;
            float ty = this.layout[4] * m2 + this.layout[2] * m0 + rw * this.layout[0] + rx * centerX + rectExtraLow(rect);
            transformQuad(target, m0, m1, m2, m3, ty, tx, spanX, spanY, 156.0F);
         } while (++index < slotCount);

         float step = (float) Math.PI / count;
         int label = 1;

         do {
            float angle = (label - 1) * (float) (Math.PI * 2) / count + step;
            float sin = (float)Math.sin(angle);
            float labelY = sin * 59.0F + centerX;
            float cos = (float)Math.cos(angle);
            float labelX = cos * 59.0F + centerX;
            Object slot = this.setting.slotAt(label - 1);
            if (slot != null && slotTag(slot) != null) {
               drawText(2, target, slot, labelY - 8.0F, labelX - 8.0F, 8.0F, themeColor(16), alpha);
            } else {
               drawText(2, target, Integer.toString(label), labelY - 8.0F);
            }
         } while (++label <= slotCount);
      }
   }

   protected int hitWheel(float dx, float dy, float inner, float outer) {
      float distance = (float)Math.sqrt(dx * dx + dy * dy);
      return !(distance < inner) && !(outer < distance) ? clampSlot((int)((float)Math.atan2(dy, dx) / (float) (Math.PI * 2) * 6.0F)) : -1;
   }

   protected static int clampSlot(int value) {
      return value;
   }

   protected void renderPanel(Object target, Object rect, float left, float top, float mouseX, float mouseY, float alpha) {
      themeColor(0);
      themeColor(12);
      drawBox(target, left, top, 226.0F, 200.0F, 6.0F, 6.0F, 6.0F, 6.0F, themeColor(0), themeColor(12), 1.0F, 0, 0.0F, 0.0F, 0.0F, alpha, 0);
      left += 14.0F;
      top += 14.0F;
      List<SwapWheelModal.WheelEntry> items = this.setting.itemList();
      int count = items.size();
      this.hoverIndex = -1;
      int index = 9;

      for (int cursor = 9; index < 36; cursor++) {
         int column = (index - 9) / 9;
         int row = (index - 9) % 9;
         SwapWheelModal.WheelEntry entry = cursor < count ? items.get(cursor) : null;
         float cellX = row * 31.0F + left;
         float cellY = column * 31.0F + top;
         this.renderGridSlot(target, rect, index, entry, cellX, cellY, mouseX, mouseY, alpha);
         index++;
      }

      float lowerTop = top + 93.0F + 26.0F;
      index = 0;

      do {
         SwapWheelModal.WheelEntry entry = index < count ? items.get(index) : null;
         this.renderGridSlot(target, rect, index, entry, index * 31.0F + left, lowerTop, mouseX, mouseY, alpha);
      } while (++index < 9);

      float finish = lowerTop + 8.0F + 26.0F + 8.0F;
      SwapWheelModal.WheelEntry placeholder = this.defaultEntry();
      float hoverTarget = 0.0F;
      if (!(left > mouseX)
         && !(left + 26.0F < mouseX)
         && !(finish > mouseY)
         && !(finish + 26.0F < mouseY)
         && (AbstractOverlay.activeOverlay == null || Screen.allowHover)) {
         this.hoverIndex = 40;
         hoverTarget = 1.0F;
      }

      AbstractOverlay.Animator anim = this.animAt(2880);
      if (anim.target != hoverTarget) {
         animate(anim, hoverTarget);
      }

      float eased = advance(anim, this.now()) * 0.7F;
      if (0.0F < eased && eased < 1.0F) {
         int steps = 0;

         do {
            steps += 8;
         } while (steps < 32);
      }

      if (placeholder != null) {
         transformEntry(target, transformMatrix(placeholder), left + 5.0F, finish + 5.0F);
         drawEntryIcon(target, placeholder, left, finish);
      }

      drawText(2, target, "Ячейка пустая — добавьте предмет из инвентаря", left + 26.0F + 10.0F);
   }

   protected void renderGridSlot(
      Object target, Object rect, int index, SwapWheelModal.WheelEntry entry, float cellX, float cellY, float mouseX, float mouseY, float alpha
   ) {
      float size = 26.0F;
      float one = 1.0F;
      float hoverTarget;
      if (!(cellX > mouseX)
         && !(cellX + 26.0F < mouseX)
         && !(cellY > mouseY)
         && !(cellY + 26.0F < mouseY)
         && (AbstractOverlay.activeOverlay == null || Screen.allowHover)) {
         this.hoverIndex = index;
         hoverTarget = one;
      } else {
         hoverTarget = 0.0F;
      }

      AbstractOverlay.Animator anim = this.gridAnim(index);
      if (anim.target != hoverTarget) {
         animate(anim, hoverTarget);
      }

      float hovered = advance(anim, this.now()) * 0.7F;
      int color = uiLerpColor(themeColor(4), themeColor(12), hovered);
      drawBox(target, cellX, cellY, 26.0F, 26.0F, 6.0F, 6.0F, 6.0F, 6.0F, color, themeColor(12), 1.0F, 0, 0.0F, 0.0F, 0.0F, alpha, 0);
      if (entry != null && slotTag(entry) != null) {
         transformEntry(target, transformMatrix(entry), cellX + 5.0F, cellY + 5.0F);
         drawEntryIcon(target, entry, cellX, cellY);
      }
   }

   protected void renderSlot(Object target, Object rect, int index, float left, float top, boolean usable, float mouseX, float mouseY, float alpha) {
      themeColor(0);
      float edge = 8.0F;
      float panelWidth = 226.0F;
      drawPanel(
         rect,
         left,
         top,
         226.0F,
         200.0F,
         6.0F,
         6.0F,
         6.0F,
         6.0F,
         themeColor(0),
         themeColor(12),
         1.0F,
         0,
         0,
         0.0F,
         0.0F,
         alpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      float iconX = left + 8.0F;
      float iconY = top + 5.0F;
      SwapWheelModal.WheelEntry entry = this.setting.itemAt(index);
      if (usable && entry != null && slotTag(entry) != null) {
         iconX = left + 8.0F;
         float iconSize = 16.0F;
         drawIcon(target, 33, iconX, iconY);
         drawIcon(target, 68, left + 8.0F, top + 5.0F);
         this.drawSlotLabel(target, rect, index, left + 8.0F, iconY, 16.0F, alpha);
      } else {
         themeColor(0);
         float iconSize = 16.0F;
         drawIcon(target, 33, iconX, iconY);
         if (!usable) {
            themeColor(0);
         } else {
            if (iconX <= mouseX
               && mouseX <= iconX + iconSize
               && iconY <= mouseY
               && mouseY <= iconY + iconSize
               && (AbstractOverlay.activeOverlay == null || Screen.allowHover)) {
               showTooltip("Ячейка пустая — добавьте предмет из инвентаря");
            }

            themeColor(0);
         }

         this.drawSlotLabel(target, rect, index, iconX, iconY, iconSize, alpha);
      }

      AbstractOverlay.Animator itemAnim = this.animAt(280 + index * 200);
      float itemTarget = 1.0F;
      float itemHover = itemAnim.target;
      if (index != this.hoverSlot) {
         itemTarget = 0.0F;
      }

      if (itemHover != itemTarget) {
         animate(itemAnim, itemTarget);
      }

      AbstractOverlay.Animator actionAnim = this.animAt(320 + index * 200);
      float actionTarget = usable ? 1.0F : 0.0F;
      if (actionAnim.target != actionTarget) {
         animate(actionAnim, actionTarget);
      }

      float action = advance(actionAnim, this.now());
      float actionX = left + 226.0F - 8.0F - 20.0F;
      float actionY = left + this.width - 8.0F - 20.0F;
      if (this.hoverTest(actionX, actionY, mouseX, mouseY)) {
         Screen.hoveredWidget = 1;
      }

      drawIcon(target, 68, actionX, actionY);
   }

   protected void drawSlotLabel(Object target, Object rect, int index, float iconX, float iconY, float iconSize, float alpha) {
      float labelX = iconX + iconSize + 6.0F;
      String label = "Ячейка " + (index + 1);
      drawText(2, target, label, labelX);
   }

   protected void renderFooter(Object target, Object rect, float top, float mouseX, float mouseY, float alpha) {
      float lineTop = top + this.height - 38.0F;
      drawBoxGradient(target, this.x + 14.0F, lineTop, this.width - 28.0F, 1.0F, 0.0F, themeColor(12), alpha);
      float buttonTop = lineTop + 7.0F;
      float buttonLeft = (this.width - 220.0F) * 0.5F + this.x;
      float hoverTarget;
      if (!(buttonLeft > mouseX)
         && !(buttonLeft + 220.0F < mouseX)
         && !(buttonTop > mouseY)
         && !(buttonTop + 24.0F < mouseY)
         && (AbstractOverlay.activeOverlay == null || Screen.allowHover)) {
         Screen.hoveredWidget = 1;
         hoverTarget = 1.0F;
      } else {
         hoverTarget = 0.0F;
      }

      AbstractOverlay.Animator anim = this.animAt(2960);
      if (anim.target != hoverTarget) {
         animate(anim, hoverTarget);
      }

      float eased = advance(anim, this.now());
      int color = uiLerpColor(themeColor(8), themeColor(12), eased);
      drawBox(target, buttonLeft, buttonTop, 220.0F, 24.0F, 6.0F, 6.0F, 6.0F, 6.0F, color, themeColor(12), 1.0F, 0, 0.0F, 0.0F, 0.0F, alpha, 0);
      drawIcon(target, 32, buttonLeft + 10.0F, buttonTop + 6.0F, 12.0F, 12.0F, themeColor(24), alpha);
      drawText(2, target, "Очистить выбранную ячейку", buttonLeft + 28.0F, buttonTop + 6.0F, 18.0F, themeColor(24), alpha);
   }

   protected boolean hoverTest(float left, float top, float mouseX, float mouseY) {
      return left <= mouseX && mouseX <= left + 20.0F && top <= mouseY && mouseY <= top + 20.0F && (AbstractOverlay.activeOverlay == null || Screen.allowHover);
   }

   protected SwapWheelModal.WheelEntry fetchEntry() {
      List<SwapWheelModal.WheelEntry> items = this.setting.itemList();
      int index = this.selectedIndex;
      return index >= 0 && items.size() > index ? items.get(index) : this.defaultEntry();
   }

   protected SwapWheelModal.WheelEntry defaultEntry() {
      SwapWheelModal.WheelEntry entry = new SwapWheelModal.WheelEntry();
      entry.nameA = "None";
      entry.nameB = "...";
      entry.nameC = "";
      entry.nameD = "";
      entry.key = -1;
      entry.flag = 0;
      return entry;
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      int index = 0;
      int mode = 0;
      SwapWheelModal.ItemWheel wheel = this.setting;
      int slotCount = wheel.slotCount();
      int captured = this.captureIndex;
      if (captured < 0) {
         float baseX = this.x;
         float baseY = this.y;
         float column = baseX + 14.0F + 200.0F + 14.0F + 302.0F + 14.0F + 14.0F + 226.0F - 8.0F - 20.0F;

         for (float wide = column - 4.0F - 70.0F; index < 6; index++) {
            float rowTop = index * 30.0F + baseY + 40.0F + 14.0F + 0.0F + 14.0F + 4.0F;
            byte var22;
            if (wide <= mx && mx <= wide + 70.0F && rowTop <= my && my <= rowTop + 18.0F) {
               var22 = 1;
            } else {
               if (!(column <= mx) || !(mx <= column + 20.0F) || !(rowTop <= my) || !(my <= rowTop + 18.0F)) {
                  continue;
               }

               var22 = 2;
            }

            if (index >= 0 && index < slotCount && button == 0) {
               if (var22 == 1) {
                  this.captureIndex = index;
                  this.captureKey = 0;
                  return true;
               }

               if (var22 == 2) {
                  if (index < 6) {
                     SwapWheelModal.Charge charge = wheel.chargeAt(index);
                     if (charge != null) {
                        beginKeyCapture();
                     }
                  }

                  AbstractOverlay.Animator anim = this.animAt(360 + index * 200);
                  anim.from = 0.0F;
                  anim.current = 0.0F;
                  anim.target = 0.0F;
                  anim.running = false;
                  animate(anim, 1.0F);
                  return true;
               }
            }
            break;
         }

         float closeTop = baseY + 10.0F;
         float closeLeft = baseX + this.width - 14.0F - 20.0F;
         if (button == 0 && !(mx < closeLeft) && !(closeLeft + 20.0F < mx) && !(my < closeTop) && !(closeTop + 20.0F < my)) {
            this.close();
            return true;
         } else {
            int hover = this.hoverSlot;
            if (hover >= 0 && slotCount > hover) {
               if (button == 0) {
                  this.selectedIndex = hover;
                  return true;
               }

               if (button == 1) {
                  wheel.selectSlot(this.selectedIndex);
                  return true;
               }
            } else if (button == 0 && this.hoverIndex >= 0) {
               SwapWheelModal.WheelEntry source = this.hoverIndex != 40 ? this.fetchEntry() : this.defaultEntry();
               SwapWheelModal.WheelEntry entry = this.copyEntry(source);
               if (entry.nameA.length() != 0) {
                  SwapWheelModal.ItemWheel owner = this.setting;
                  int target = this.selectedIndex;
                  if (target < 6) {
                     owner.setItem(target, entry);
                     if (owner.onSlotChange != null) {
                        owner.onSlotChange.run();
                     }
                  }

                  this.selectedIndex = (this.selectedIndex + 1) % slotCount;
               }

               return true;
            }

            float clearLeft = (this.width - 220.0F) * 0.5F + baseX;
            float clearTop = baseY + this.height - 38.0F + 7.0F;
            if (button == 0 && !(mx < clearLeft) && !(clearLeft + 220.0F < mx) && !(my < clearTop) && !(clearTop + 24.0F < my)) {
               wheel.selectSlot(this.selectedIndex);
               return true;
            } else {
               return !(mx < baseX) && !(baseX + this.width < mx) && !(my < baseY) && !(baseY + this.height < my);
            }
         }
      } else {
         if (captured < 6) {
            SwapWheelModal.Charge charge = wheel.chargeAt(captured);
            if (charge != null) {
               int state = 0;
               if (button == 0) {
                  state = 1;
               } else if (button == 1) {
                  state = 2;
               } else if (button == 2) {
                  state = 4;
               } else if (button == 3) {
                  state = 5;
               } else if (button == 4) {
                  state = 6;
               }

               if (charge.key != state || charge.mods != 0) {
                  charge.key = state;
                  charge.mods = 0;
                  if (charge.onChange != null) {
                     charge.onChange.run();
                  }
               }
            }
         }

         this.captureIndex = -1;
         this.captureKey = 0;
         return true;
      }
   }

   protected SwapWheelModal.WheelEntry copyEntry(SwapWheelModal.WheelEntry source) {
      SwapWheelModal.WheelEntry out = new SwapWheelModal.WheelEntry();
      out.nameA = source.nameA;
      out.nameB = source.nameB;
      out.key = source.key;
      out.nameC = source.nameC;
      out.nameD = source.nameD;
      out.flag = source.flag;
      return out;
   }

   protected static float negate(float value) {
      return value == 0.0F ? 0.0F : -value;
   }

   protected static float rectX(Object rect) {
      return 0.0F;
   }

   protected static float rectY(Object rect) {
      return 0.0F;
   }

   protected static float rectWidth(Object rect) {
      return 0.0F;
   }

   protected static float rectHeight(Object rect) {
      return 0.0F;
   }

   protected static float rectExtra(Object rect) {
      return 0.0F;
   }

   protected static float rectExtraLow(Object rect) {
      return 0.0F;
   }

   protected static Object slotTag(Object slot) {
      return slot;
   }

   protected static Object slotTag(SwapWheelModal.WheelEntry entry) {
      return entry.nameA;
   }

   protected static Object transformMatrix(Object slot) {
      return slot;
   }

   protected static void transformQuad(Object target, float m0, float m1, float m2, float m3, float tx, float ty, float left, float top, float size) {
   }

   protected static void transformEntry(Object target, Object matrix, float px, float py) {
   }

   protected static void drawEntryIcon(Object target, Object entry, float px, float py) {
   }

   protected static void showTooltip(String text) {
   }

   protected static void beginKeyCapture() {
   }

   protected static float screenWidth() {
      return 0.0F;
   }

   protected static float screenHeight() {
      return 0.0F;
   }

   protected static float screenScale() {
      return 1.0F;
   }

   protected static int themeColor(int index) {
      return 0;
   }

   protected static void drawPanel(
      Object rect,
      float px,
      float py,
      float pw,
      float ph,
      float r1,
      float r2,
      float r3,
      float r4,
      int colorA,
      int colorB,
      float alpha1,
      int border,
      int borderWidth,
      float cornerSpread,
      float thickness,
      float alpha2,
      int z1,
      int z2,
      int z3,
      int z4,
      int z5,
      int z6,
      int z7,
      int z8,
      int z9,
      int z10,
      int z11,
      int z12,
      int z13
   ) {
   }

   protected static void drawBox(
      Object target,
      float px,
      float py,
      float pw,
      float ph,
      float r1,
      float r2,
      float r3,
      float r4,
      int fillTop,
      int fillBottom,
      float fillAlpha,
      int border,
      float borderWidth,
      float borderAlpha,
      float shadowAlpha,
      float alpha,
      int flags
   ) {
   }

   protected static void drawBoxGradient(Object target, float px, float py, float pw, float ph, float f1, int color, float alpha) {
   }

   protected static void drawText(int mode, Object target, Object text, float px) {
   }

   protected static void drawText(int mode, Object target, Object text, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawIcon(Object target, int icon, float px, float py) {
   }

   protected static void drawIcon(Object target, int icon, float px, float py, float pw, float ph, int color, float alpha) {
   }

   protected static float measureText(Object target, Object text, float size) {
      return 0.0F;
   }

   protected static Object makeRect(Object out, Object target, float alpha, float px, float py) {
      return out;
   }

   protected static void setScissor(float px, float py, float pw, float ph) {
   }

   protected static void resetScissor() {
   }

   public static class Charge {
      public Runnable onChange;
      public int key;
      public int mods;
   }

   public static class ItemWheel {
      public Runnable onSlotChange;
      private final List<SwapWheelModal.Charge> charges = new ArrayList<>();
      private final List<SwapWheelModal.WheelEntry> items = new ArrayList<>();
      private final List<SwapWheelModal.WheelEntry> slots = new ArrayList<>();

      public int slotCount() {
         return this.items.size();
      }

      public String name() {
         return "";
      }

      public SwapWheelModal.Charge chargeAt(int index) {
         if (index >= 0 && index < 6) {
            while (this.charges.size() <= index) {
               this.charges.add(new SwapWheelModal.Charge());
            }

            return this.charges.get(index);
         } else {
            return null;
         }
      }

      public SwapWheelModal.WheelEntry itemAt(int index) {
         return index >= 0 && index < this.items.size() ? this.items.get(index) : null;
      }

      public Object slotAt(int index) {
         return index >= 0 && index < this.items.size() ? this.items.get(index) : null;
      }

      public void setItem(int index, SwapWheelModal.WheelEntry entry) {
      }

      public void selectSlot(int index) {
      }

      public List<SwapWheelModal.WheelEntry> itemList() {
         return this.items;
      }
   }

   public static class WheelEntry {
      public String nameA = "";
      public String nameB = "";
      public int key;
      public String nameC = "";
      public String nameD = "";
      public int flag;
   }
}

