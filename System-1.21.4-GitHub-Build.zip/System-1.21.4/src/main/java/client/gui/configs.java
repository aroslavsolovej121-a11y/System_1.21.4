package client.gui;

public class configs {
   public void cover() {
   }

   public void create() {
   }

   public void createKey() {
   }

   public void deleteConfig() {
   }

   public void deleteKey() {
   }

   public void exportConfig() {
   }

   public void importByKey() {
   }

   public void listKeys() {
   }

   public void refresh() {
   }

   public void rename() {
   }

   public void saveCurrent() {
   }

   public void setActive() {
   }

   public void setDescription() {
   }

   public void setPrivate() {
   }
}
