package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class ConfigsPart extends AbstractCollectionPart {
   public static final int TAB_ALL = 0;
   public static final int TAB_PRIVATE = 1;
   public static final int TAB_PUBLIC = 2;
   public static final int TAB_STRIDE = 200;
   public static final int TAB_SLOTS = 3;
   public static final int SORT_SMALL_LIMIT = 33;
   public static final int NAME_ATTEMPTS = 33;
   public static final int CONFIG_INFO_ACTIVE = 96;
   public static final int CONFIG_INFO_PRIVATE = 97;
   public static final int CARD_ANIM_FROM = 96;
   public static final int CARD_ANIM_CURRENT = 100;
   public static final int CARD_ANIM_TARGET = 104;
   public static final int CARD_ANIM_START = 120;
   public static final int CARD_ANIM_RUNNING = 128;
   public static final int CARD_NAME = 752;
   public static final int CARD_ACTIVE = 864;
   public static final int CARD_HIDDEN = 168;
   public static final int DETAILS_SELECTED = 208;
   public static final int DETAILS_TOGGLE_ACTIVE = 224;
   public static final int DETAILS_TOGGLE_PRIVATE = 472;
   public static final int DETAILS_CB_ACTIVATE = 1696;
   public static final int DETAILS_CB_REFRESH = 1760;
   public static final int DETAILS_CB_CLOSE = 1824;
   public static final int DETAILS_CB_PRIVATE = 1888;
   public static final int DETAILS_ANCHOR = 144;
   public static final int ADD_TILE_ICON = 29;
   public static final int ADD_TILE_ICON_RIGHT = 54;
   public static final float ADD_TILE_HEIGHT = 62.0F;
   public static final int TOOLBAR_INPUT = 576;
   public static final String TEXT_TAB = "Сонфигз";
   public static final String TEXT_TAB_PRIVATE = "Привате";
   public static final String TEXT_TAB_PUBLIC = "Публис";
   public static final String TEXT_ADD_TITLE = "Адд неш сонфигуратион";
   public static final String TEXT_ADD_SUBTITLE = "Нажмите, чтобы создать новый конфиг";
   public static final String TEXT_ADD_PLACEHOLDER = "Вставьте ключ...";
   public static final String TEXT_FILTER_LIST = "Списком";
   public static final String TEXT_FILTER_TILES = "Плитками";
   public static final String KEY_THEME = "theme";
   public static final String KEY_LANG = "lang";
   public static final String KEY_WORDS = "words";
   public static final String KEY_BINDS = "binds";
   public static final String KEY_BOARDS = "boards";
   public static final String KEY_SCROLL = "scroll";
   public static final String KEY_OFFSET_X = "offset_x";
   public static final String KEY_OFFSET_Y = "offset_y";
   public static final String KEY_SIDEBAR_COLLAPSED = "sidebar_collapsed";
   public static final float SLOT12_VALUE = 174.0F;
   public static final float FADE_DURATION = 0.16F;
   public static final float CARD_ANIM_DURATION = 0.28F;
   public static final float DETAILS_GAP = 16.0F;
   public static final float DETAILS_WIDTH = 250.0F;
   public static final float DETAILS_OFFSET_Y = 1.75F;
   private static final String[] NAME_WORDS = new String[]{"кфг", "конфиг"};
   private static final String[] NOTE_WORDS = new String[]{"описание", "описалово", "дескрипшн"};
   private static final String NAME_SEPARATOR = "-";
   private static final int NAME_RANDOM_BOUND = 9000;
   private static final int NAME_RANDOM_BASE = 1000;
   private static final int BASE36 = 36;
   private static final String BASE36_DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz";
   private final List<String> names = new ArrayList<>();
   private final List<ConfigsPart.ConfigInfo> entries = new ArrayList<>();
   private int tabFilter;
   private Runnable pendingTransition;
   private ConfigsPart.ConfigDetailsCard details;
   private ConfigsPart.ConfigDetailsCard detailsPrev;

   public ConfigsPart() {
      this.names.clear();
      this.entries.clear();
      this.tabFilter = 0;
      this.pendingTransition = null;
      this.details = null;
      this.detailsPrev = null;
      this.boardToolbar.onTabChanged = new IntConsumer() {
         @Override
         public void accept(final int index) {
            ConfigsPart.this.beginDeferredLayout(new Runnable() {
               @Override
               public void run() {
                  ConfigsPart.this.tabFilter = index;
                  ConfigsPart.this.syncRows();
                  ConfigsPart.this.layoutDirty = true;
               }
            });
         }
      };
      this.boardToolbar.onTitleChanged = new Consumer<String>() {
         public void accept(String text) {
            ConfigsPart.this.handleImport(text, new ConfigsPart.ToolbarPlateInputRef());
         }
      };
      this.boardToolbar.onClose = new Runnable() {
         @Override
         public void run() {
            ConfigsPart.this.handleCreate();
         }
      };
      this.addTile.onSubmitText = new Consumer<String>() {
         public void accept(String text) {
            ConfigsPart.this.handleImport(text, ConfigsPart.this.new AddTilePlateInputRef());
         }
      };
      this.addTile.onSubmitEmpty = new Runnable() {
         @Override
         public void run() {
            ConfigsPart.this.handleCreate();
         }
      };
      this.refreshFromServer();
   }

   public String[][] tabSpec() {
      return new String[][]{{"Сонфигз", "Привате"}, {"Сонфигз", "Публис"}, {"Сонфигз", "Привате"}};
   }

   public int[] tabPredicate() {
      return new int[]{1, 2, 1};
   }

   private void beginDeferredLayout(Runnable action) {
      this.pendingTransition = action;
      this.overlayBlocked = true;
      this.easePow = 0.16F;
      this.layoutEase = 1;
      if (this.layoutFade != 0.0F) {
         long time = this.now();
         this.layoutAlphaB = this.layoutAlphaA;
         this.layoutFade = 0.0F;
         this.lastTime = time;
         this.suppressClick = true;
      }
   }

   public void runPendingTransition() {
      Runnable action = this.pendingTransition;
      this.pendingTransition = null;
      if (action != null) {
         action.run();
      }
   }

   public ConfigsPart.ConfigCard buildCard(ConfigsPart.ConfigInfo info) {
      if (info == null) {
         return null;
      } else {
         boolean isNew = !this.containsName(info.name);
         final ConfigsPart.ConfigCard card = new ConfigsPart.ConfigCard(info, isNew);
         card.onActivate = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.handleActivate(item);
            }
         };
         card.onSaveCurrent = new Runnable() {
            @Override
            public void run() {
               ConfigsPart.this.saveCurrent();
            }
         };
         card.onShare = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.handleShare(item);
            }
         };
         card.onDelete = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.handleDelete(item);
            }
         };
         card.onRename = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.handleRename(item, card.pendingName);
            }
         };
         card.onDescribe = new ConfigsPart.CardDescribeCallback() {
            @Override
            public void accept(ConfigsPart.ConfigInfo item, String text) {
               ConfigsPart.this.handleDescribe(item, text);
            }
         };
         card.onTogglePrivate = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.togglePrivate(item);
            }
         };
         card.onUpdate = new ConfigsPart.CardUpdateCallback() {
            @Override
            public void accept(ConfigsPart.ConfigInfo item, boolean visible) {
               ConfigsPart.this.applyUpdate(item, visible);
            }
         };
         card.onOpenSettings = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.openSettingsFor(card, item);
            }
         };
         return card;
      }
   }

   public void openSettingsFor(final ConfigsPart.ConfigCard card, ConfigsPart.ConfigInfo info) {
      if (info != null) {
         if (this.details != null) {
            this.dismissDetails();
         }

         this.closeDetails();
         ConfigsPart.ConfigDetailsCard view = new ConfigsPart.ConfigDetailsCard(info);
         view.onActivate = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.handleActivate(item);
            }
         };
         view.onRefresh = new Runnable() {
            @Override
            public void run() {
               ConfigsPart.this.refreshFromServer();
            }
         };
         view.onTogglePrivate = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.togglePrivate(item);
            }
         };
         view.onClose = new Consumer<ConfigsPart.ConfigInfo>() {
            public void accept(ConfigsPart.ConfigInfo item) {
               ConfigsPart.this.closeDetails();
            }
         };
         view.onAnchor = new ConfigsPart.AnchorProvider() {
            @Override
            public float[] anchor() {
               return ConfigsPart.this.computeDetailsAnchor(card);
            }
         };
         ConfigsPart.ConfigDetailsCard previous = this.detailsPrev;
         this.detailsPrev = view;
         if (previous != null) {
            previous.dispose();
         }

         this.placeDetails(view);
      }
   }

   private float[] computeDetailsAnchor(ConfigsPart.ConfigCard card) {
      float right = card.x + card.width;
      float left;
      float top;
      if (card.columnIndex == 1) {
         top = card.y;
         left = right + 16.0F;
      } else {
         left = right - 250.0F;
         top = card.height + card.y + 1.75F;
      }

      if (this.toolsRightEdge() + 250.0F > left) {
         left = card.x - 16.0F - 250.0F;
      }

      return new float[]{left, top};
   }

   private float toolsRightEdge() {
      return this.boardToolbar.x + this.boardToolbar.width;
   }

   private void placeDetails(ConfigsPart.ConfigDetailsCard view) {
      float[] point = view.onAnchor != null ? view.onAnchor.anchor() : new float[]{0.0F, 0.0F};
      view.setPosition(point[0], point[1]);
      view.setSize(view.width, view.height);
   }

   private void closeDetails() {
      ConfigsPart.ConfigDetailsCard card = this.details;
      if (card != null) {
         this.details = null;
         this.detailsPrev = card;
         if (this.detailsPrev != null) {
            this.detailsPrev.dispose();
         }
      }
   }

   private void dismissDetails() {
      if (this.details != null) {
         this.details.dismiss();
      }
   }

   public void refreshFromServer() {
      ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
      if (service.hasRefreshHandler()) {
         service.refresh(new Runnable() {
            @Override
            public void run() {
            }
         });
      }
   }

   public void handleCreate() {
      ConfigsPart.CardConsumer callback = new ConfigsPart.CardConsumer() {
         @Override
         public void accept(ConfigsPart.ConfigInfo info) {
            if (info != null) {
               ConfigsPart.this.addName(info.name);
               ConfigsPart.this.syncRows();
            }
         }
      };
      String note = this.generateNote();
      String name = this.generateName();
      ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
      if (!service.hasCreateHandler()) {
         if (callback != null) {
            callback.accept(new ConfigsPart.ConfigInfo());
         }
      } else {
         service.create(name, note, callback);
      }
   }

   public void handleImport(String text, ConfigsPart.PlateInputRef input) {
      final ConfigsPart.PlateInputRef field = input;
      ConfigsPart.CardConsumer callback = new ConfigsPart.CardConsumer() {
         @Override
         public void accept(ConfigsPart.ConfigInfo info) {
            if (info != null) {
               if (field != null) {
                  field.clearText();
               }

               ConfigsPart.this.addName(info.name);
               ConfigsPart.this.syncRows();
            }
         }
      };
      ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
      if (!service.hasImportHandler()) {
         if (callback != null) {
            callback.accept(new ConfigsPart.ConfigInfo());
         }
      } else {
         service.importByKey(text, callback);
      }
   }

   public void handleRename(ConfigsPart.ConfigInfo info, String newName) {
      if (info != null) {
         ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
         if (!service.hasRenameHandler()) {
            info.name = newName;
         } else {
            if (newName != null && !this.containsName(newName)) {
               int index = this.indexOfName(info.name);
               if (index >= 0) {
                  this.names.set(index, newName);
               }
            }

            service.rename(info.name, newName, new ConfigsPart.CardConsumer() {
               @Override
               public void accept(ConfigsPart.ConfigInfo item) {
                  ConfigsPart.this.syncRows();
               }
            });
         }
      }
   }

   public void handleActivate(ConfigsPart.ConfigInfo info) {
      if (info != null) {
         ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
         if (!service.hasActivateHandler()) {
            info.active = true;
         } else {
            service.setActive(info.name, new ConfigsPart.CardConsumer() {
               @Override
               public void accept(ConfigsPart.ConfigInfo item) {
                  ConfigsPart.this.syncRows();
               }
            });
         }
      }
   }

   public void handleDelete(ConfigsPart.ConfigInfo info) {
      if (info != null) {
         this.dropName(info.name);
         ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
         if (!service.hasDeleteHandler()) {
            this.syncRows();
         } else {
            service.deleteConfig(info.name, new ConfigsPart.CardConsumer() {
               @Override
               public void accept(ConfigsPart.ConfigInfo item) {
                  ConfigsPart.this.syncRows();
               }
            });
         }
      }
   }

   public void handleDescribe(ConfigsPart.ConfigInfo info, String text) {
      if (info != null) {
         ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
         if (!service.hasDescribeHandler()) {
            if (this.details != null) {
               this.details.refresh();
            }
         } else {
            service.setDescription(info.name, text, new ConfigsPart.CardConsumer() {
               @Override
               public void accept(ConfigsPart.ConfigInfo item) {
                  if (ConfigsPart.this.details != null) {
                     ConfigsPart.this.details.refresh();
                  }

                  ConfigsPart.this.syncRows();
               }
            });
         }
      }
   }

   public void handleShare(ConfigsPart.ConfigInfo info) {
      if (info != null) {
         ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
         if (service.hasShareHandler()) {
            service.share(info.name, new ConfigsPart.CardConsumer() {
               @Override
               public void accept(ConfigsPart.ConfigInfo item) {
               }
            });
         }
      }
   }

   public void saveCurrent() {
      ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
      if (service.hasSaveHandler()) {
         service.saveCurrent(new Runnable() {
            @Override
            public void run() {
               ConfigsPart.this.syncRows();
            }
         });
      }
   }

   public void togglePrivate(ConfigsPart.ConfigInfo info) {
      if (info != null) {
         boolean value = !info.privateFlag;
         info.privateFlag = value;
         ConfigsPart.ConfigsService service = ConfigsPart.ConfigsService.instance();
         if (!service.hasPrivateHandler()) {
            if (this.tabFilter != 0) {
               this.syncRows();
            }
         } else {
            service.setPrivate(info.name, value, new ConfigsPart.CardConsumer() {
               @Override
               public void accept(ConfigsPart.ConfigInfo item) {
                  if (ConfigsPart.this.tabFilter != 0) {
                     ConfigsPart.this.syncRows();
                  }
               }
            });
         }
      }
   }

   public void applyUpdate(ConfigsPart.ConfigInfo info, boolean visible) {
      if (info != null) {
         if (visible) {
            this.addName(info.name);
         } else {
            this.dropName(info.name);
         }

         this.syncRows();
      }
   }

   public int countByFlag(boolean privateValue) {
      int count = 0;
      List<ConfigsPart.ConfigInfo> all = ConfigsPart.ConfigsService.instance().list();

      for (int i = 0; i < all.size(); i++) {
         ConfigsPart.ConfigInfo info = all.get(i);
         if (info != null && info.privateFlag == privateValue) {
            count++;
         }
      }

      return count;
   }

   @Override
   public void syncRows() {
      List<String> source = ConfigsPart.ConfigsService.instance().listNames();
      this.entries.clear();

      for (int i = 0; i < source.size(); i++) {
         String name = source.get(i);
         ConfigsPart.ConfigInfo info = ConfigsPart.ConfigsService.instance().find(name);
         if (info != null && (this.tabFilter != 1 || info.privateFlag) && (this.tabFilter != 2 || !info.privateFlag)) {
            ConfigsPart.ConfigInfo existing = null;

            for (int k = 0; k < this.entries.size(); k++) {
               if (name.equals(this.entries.get(k).name)) {
                  existing = this.entries.get(k);
                  break;
               }
            }

            if (existing != null) {
               existing.copyFrom(info);
            } else {
               this.entries.add(info);
            }
         }
      }

      if (this.entries.size() > 33) {
         this.sortEntriesLarge(this.entries);
      } else {
         this.sortEntriesSmall(this.entries);
      }

      List<Component> fresh = new ArrayList<>();

      for (int ix = 0; ix < this.entries.size(); ix++) {
         ConfigsPart.ConfigInfo info = this.entries.get(ix);
         ConfigsPart.ConfigCard found = this.findRow(info.name);
         if (found == null) {
            ConfigsPart.ConfigCard card = this.buildCard(info);
            if (card != null) {
               fresh.add(card);
            }
         } else {
            found.active = this.containsName(found.configName);
            fresh.add(found);
         }
      }

      for (int ixx = 0; ixx < this.rows.size(); ixx++) {
         Component row = this.rows.get(ixx);
         if (row instanceof ConfigsPart.ConfigCard card && !card.hidden && !fresh.contains(card)) {
            card.hidden = true;
            card.anim.setTarget(0.0F, this.now());
         }
      }

      this.rows.clear();
      this.rows.addAll(fresh);

      for (int ixxx = 0; ixxx < this.rows.size(); ixxx++) {
         Component row = this.rows.get(ixxx);
         if (row instanceof ConfigsPart.ConfigCard) {
            ((ConfigsPart.ConfigCard)row).hidden = false;
         }
      }

      if (this.details != null && this.details.selectedName != null) {
         for (int ixxxx = 0; ixxxx < this.entries.size(); ixxxx++) {
            if (this.details.selectedName.equals(this.entries.get(ixxxx).name)) {
               this.details.select(this.entries.get(ixxxx));
               break;
            }
         }
      }
   }

   private ConfigsPart.ConfigCard findRow(String name) {
      if (name == null) {
         return null;
      } else {
         for (int i = 0; i < this.rows.size(); i++) {
            Component row = this.rows.get(i);
            if (row instanceof ConfigsPart.ConfigCard && name.equals(((ConfigsPart.ConfigCard)row).configName)) {
               return (ConfigsPart.ConfigCard)row;
            }
         }

         return null;
      }
   }

   private void sortEntriesSmall(List<ConfigsPart.ConfigInfo> list) {
      for (int i = 1; i < list.size(); i++) {
         ConfigsPart.ConfigInfo key = list.get(i);

         int j;
         for (j = i - 1; j >= 0 && this.compareEntries(list.get(j), key) > 0; j--) {
            list.set(j + 1, list.get(j));
         }

         list.set(j + 1, key);
      }
   }

   private void sortEntriesLarge(List<ConfigsPart.ConfigInfo> list) {
      this.mergeSort(list, new ConfigsPart.ConfigInfo[list.size()], 0, list.size() - 1);
   }

   private void mergeSort(List<ConfigsPart.ConfigInfo> list, ConfigsPart.ConfigInfo[] buffer, int lo, int hi) {
      if (lo < hi) {
         int mid = lo + hi >>> 1;
         this.mergeSort(list, buffer, lo, mid);
         this.mergeSort(list, buffer, mid + 1, hi);
         int i = lo;
         int j = mid + 1;
         int k = lo;

         while (i <= mid && j <= hi) {
            buffer[k++] = this.compareEntries(list.get(j), list.get(i)) < 0 ? list.get(j++) : list.get(i++);
         }

         while (i <= mid) {
            buffer[k++] = list.get(i++);
         }

         while (j <= hi) {
            buffer[k++] = list.get(j++);
         }

         for (int t = lo; t <= hi; t++) {
            list.set(t, buffer[t]);
         }
      }
   }

   private int compareEntries(ConfigsPart.ConfigInfo a, ConfigsPart.ConfigInfo b) {
      if (a == b) {
         return 0;
      } else if (a == null) {
         return -1;
      } else {
         return b == null ? 1 : a.name.compareTo(b.name);
      }
   }

   private String generateNote() {
      int number = ConfigsPart.ConfigsService.random(9000) + 1000;
      String word = NOTE_WORDS[ConfigsPart.ConfigsService.random(NOTE_WORDS.length)];
      return word + "-" + number;
   }

   private String generateName() {
      List<String> existing = ConfigsPart.ConfigsService.instance().listNames();

      for (int attempt = 0; attempt < 33; attempt++) {
         int number = ConfigsPart.ConfigsService.random(9000) + 1000;
         String word = NAME_WORDS[ConfigsPart.ConfigsService.random(NAME_WORDS.length)];
         String candidate = word + "-" + number;
         if (!existing.contains(candidate)) {
            return candidate;
         }
      }

      return ConfigsPart.ConfigsService.base36(System.currentTimeMillis() / 1000L);
   }

   private boolean containsName(String name) {
      if (name == null) {
         return false;
      } else {
         for (int i = 0; i < this.names.size(); i++) {
            if (name.equals(this.names.get(i))) {
               return true;
            }
         }

         return false;
      }
   }

   private int indexOfName(String name) {
      if (name == null) {
         return -1;
      } else {
         for (int i = 0; i < this.names.size(); i++) {
            if (name.equals(this.names.get(i))) {
               return i;
            }
         }

         return -1;
      }
   }

   private void addName(String name) {
      if (name != null) {
         if (!this.containsName(name)) {
            this.names.add(name);
         }
      }
   }

   private void dropName(String name) {
      int index = this.indexOfName(name);
      if (index >= 0) {
         this.names.remove(index);
      }
   }

   public String displayText(int index) {
      return index >= 0 && index < this.entries.size() ? this.entries.get(index).name : null;
   }

   public ConfigsPart.ConfigCard cardAt(int index) {
      if (index >= 0 && index < this.rows.size()) {
         Component row = this.rows.get(index);
         return row instanceof ConfigsPart.ConfigCard ? (ConfigsPart.ConfigCard)row : null;
      } else {
         return null;
      }
   }

   public ConfigsPart.ConfigInfo infoAt(int index) {
      return index >= 0 && index < this.entries.size() ? this.entries.get(index) : null;
   }

   public int entryCount() {
      return this.entries.size();
   }

   public int nameCount() {
      return this.names.size();
   }

   public int tabFilter() {
      return this.tabFilter;
   }

   public void setTabFilter(int value) {
      if (this.tabFilter != value) {
         this.tabFilter = value;
         this.syncRows();
      }
   }

   public ConfigsPart.ConfigDetailsCard detailsCard() {
      return this.details;
   }

   public float slot12() {
      return 174.0F;
   }

   @Override
   public void dispose() {
      this.names.clear();
      this.entries.clear();
      this.pendingTransition = null;
      this.details = null;
      this.detailsPrev = null;
      super.dispose();
   }

   public class AddTilePlateInputRef implements ConfigsPart.PlateInputRef {
      @Override
      public void clearText() {
         ConfigsPart.this.addTile.clearText();
      }

      @Override
      public String text() {
         return ConfigsPart.this.addTile.text;
      }
   }

   public interface AnchorProvider {
      float[] anchor();
   }

   public static class CardAnim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int ease;
      public long start;
      public boolean running;

      public CardAnim(float initial, float duration) {
         this.from = initial;
         this.current = initial;
         this.target = initial;
         this.duration = duration;
         this.ease = 0;
         this.start = System.nanoTime();
         this.running = false;
      }

      public void setTarget(float value, long time) {
         if (this.target != value) {
            this.from = this.current;
            this.start = time;
            this.target = value;
            this.running = true;
         }
      }

      public float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float t = (float)((time - this.start) / 1.0E9) / this.duration;
            if (t <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (t >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               float k = this.ease == 1 ? Component.easeInCubic(t) : Component.easeOutCubic(t);
               this.current = k * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.running = false;
            this.current = this.target;
            return this.current;
         }
      }

      public float value() {
         return this.current;
      }
   }

   public interface CardConsumer {
      void accept(ConfigsPart.ConfigInfo var1);
   }

   public interface CardDescribeCallback {
      void accept(ConfigsPart.ConfigInfo var1, String var2);
   }

   public interface CardUpdateCallback {
      void accept(ConfigsPart.ConfigInfo var1, boolean var2);
   }

   public static class ConfigCard extends Component {
      public ConfigsPart.ConfigInfo info;
      public boolean isNew;
      public String configName;
      public String pendingName;
      public boolean active;
      public boolean hidden;
      public int columnIndex;
      public final ConfigsPart.CardAnim anim = new ConfigsPart.CardAnim(1.0F, 0.28F);
      public Consumer<ConfigsPart.ConfigInfo> onActivate;
      public Runnable onSaveCurrent;
      public Consumer<ConfigsPart.ConfigInfo> onShare;
      public Consumer<ConfigsPart.ConfigInfo> onDelete;
      public Consumer<ConfigsPart.ConfigInfo> onRename;
      public ConfigsPart.CardDescribeCallback onDescribe;
      public Consumer<ConfigsPart.ConfigInfo> onTogglePrivate;
      public ConfigsPart.CardUpdateCallback onUpdate;
      public Consumer<ConfigsPart.ConfigInfo> onOpenSettings;

      public ConfigCard(ConfigsPart.ConfigInfo info, boolean isNew) {
         this.info = info;
         this.isNew = isNew;
         this.configName = info != null ? info.name : "";
         this.pendingName = this.configName;
         this.active = info != null && info.active;
         this.hidden = false;
         this.columnIndex = 0;
      }

      public boolean applyUpdate(boolean visible) {
         this.hidden = !visible;
         return this.hidden;
      }

      @Override
      public void tick() {
         this.anim.advance(this.now());
      }
   }

   public static class ConfigDetailsCard extends Component {
      public ConfigsPart.ConfigInfo info;
      public String selectedName;
      public Consumer<ConfigsPart.ConfigInfo> onActivate;
      public Runnable onRefresh;
      public Consumer<ConfigsPart.ConfigInfo> onTogglePrivate;
      public Consumer<ConfigsPart.ConfigInfo> onClose;
      public ConfigsPart.AnchorProvider onAnchor;

      public ConfigDetailsCard(ConfigsPart.ConfigInfo info) {
         this.info = info;
         this.selectedName = info != null ? info.name : null;
      }

      public void select(ConfigsPart.ConfigInfo value) {
         this.info = value;
         this.selectedName = value != null ? value.name : null;
      }

      public void refresh() {
      }

      public void dismiss() {
      }
   }

   public static class ConfigInfo {
      public String name;
      public String description;
      public boolean active;
      public boolean privateFlag;

      public ConfigInfo() {
         this.name = "";
         this.description = "";
         this.active = false;
         this.privateFlag = false;
      }

      public ConfigInfo(String name, String description, boolean active, boolean privateFlag) {
         this.name = name;
         this.description = description;
         this.active = active;
         this.privateFlag = privateFlag;
      }

      public ConfigsPart.ConfigInfo copyFrom(ConfigsPart.ConfigInfo other) {
         this.name = other.name;
         this.description = other.description;
         this.active = other.active;
         this.privateFlag = other.privateFlag;
         return this;
      }
   }

   public static class ConfigsService {
      public static final int MT_N = 624;
      public static final int MT_M = 397;
      public static final int MT_MATRIX_A = -1727483681;
      public static final int MT_UPPER_MASK = Integer.MIN_VALUE;
      public static final int MT_LOWER_MASK = Integer.MAX_VALUE;
      public static final int MT_INIT_MUL = 1812433253;
      public static final int MT_SEED = -1;
      private static final ConfigsPart.ConfigsService INSTANCE = new ConfigsPart.ConfigsService();
      private final List<String> keys = new ArrayList<>();
      private final List<ConfigsPart.ConfigInfo> items = new ArrayList<>();
      private final int[] state = new int[624];
      private int index = 624;

      public ConfigsService() {
         this.state[0] = -1;

         for (int i = 1; i < 624; i++) {
            this.state[i] = 1812433253 * (this.state[i - 1] ^ this.state[i - 1] >>> 30) + i;
         }

         this.index = 624;
      }

      public static ConfigsPart.ConfigsService instance() {
         return INSTANCE;
      }

      public int nextInt() {
         if (this.index >= 624) {
            this.twist();
         }

         int y = this.state[this.index++];
         y ^= y >>> 11;
         y ^= y << 7 & -1658038656;
         y ^= y << 15 & -272236544;
         return y ^ y >>> 18;
      }

      private void twist() {
         for (int i = 0; i < 624; i++) {
            int x = this.state[i] & -2147483648 | this.state[(i + 1) % 624] & 2147483647;
            int xa = x >>> 1;
            if ((x & 1) != 0) {
               xa ^= -1727483681;
            }

            this.state[i] = this.state[(i + 397) % 624] ^ xa;
         }

         this.index = 0;
      }

      public static int random(int bound) {
         if (bound <= 0) {
            return 0;
         } else {
            long range = bound - 1L & 4294967295L;
            long u = range ^ 2147483648L;
            if (u == 2147483647L) {
               return INSTANCE.nextInt();
            } else {
               u = u + 2147483649L & 4294967295L;
               long g = INSTANCE.nextInt() & 4294967295L;
               long product = g * u;
               long low = product & 4294967295L;
               if (low < u) {
                  for (long threshold = (4294967296L - u) % u & 4294967295L; low < threshold; low = product & 4294967295L) {
                     g = INSTANCE.nextInt() & 4294967295L;
                     product = g * u;
                  }
               }

               return (int)(product >>> 32);
            }
         }
      }

      public static String base36(long value) {
         if (value <= 0L) {
            return "0";
         } else {
            StringBuffer out = new StringBuffer();

            for (long rest = value; rest > 0L; rest /= 36L) {
               out.append("0123456789abcdefghijklmnopqrstuvwxyz".charAt((int)(rest % 36L)));
            }

            return out.reverse().toString();
         }
      }

      public List<String> listNames() {
         return new ArrayList<>(this.keys);
      }

      public List<ConfigsPart.ConfigInfo> list() {
         return new ArrayList<>(this.items);
      }

      public void put(ConfigsPart.ConfigInfo info) {
         if (info != null) {
            if (!this.keys.contains(info.name)) {
               this.keys.add(info.name);
            }

            for (int i = 0; i < this.items.size(); i++) {
               if (info.name.equals(this.items.get(i).name)) {
                  this.items.get(i).copyFrom(info);
                  return;
               }
            }

            this.items.add(info);
         }
      }

      public void remove(String name) {
         this.keys.remove(name);

         for (int i = this.items.size() - 1; i >= 0; i--) {
            if (name.equals(this.items.get(i).name)) {
               this.items.remove(i);
               return;
            }
         }
      }

      public ConfigsPart.ConfigInfo find(String name) {
         for (int i = 0; i < this.items.size(); i++) {
            if (name != null && name.equals(this.items.get(i).name)) {
               return this.items.get(i);
            }
         }

         return null;
      }

      public boolean hasRefreshHandler() {
         return true;
      }

      public boolean hasCreateHandler() {
         return true;
      }

      public boolean hasImportHandler() {
         return true;
      }

      public boolean hasRenameHandler() {
         return true;
      }

      public boolean hasActivateHandler() {
         return true;
      }

      public boolean hasDeleteHandler() {
         return true;
      }

      public boolean hasDescribeHandler() {
         return true;
      }

      public boolean hasShareHandler() {
         return true;
      }

      public boolean hasPrivateHandler() {
         return true;
      }

      public boolean hasSaveHandler() {
         return true;
      }

      public void refresh(Runnable callback) {
         if (callback != null) {
            callback.run();
         }
      }

      public void create(String name, String note, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = new ConfigsPart.ConfigInfo(name, note, false, false);
         this.put(info);
         if (callback != null) {
            callback.accept(info);
         }
      }

      public void importByKey(String key, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = new ConfigsPart.ConfigInfo(key, "", false, false);
         this.put(info);
         if (callback != null) {
            callback.accept(info);
         }
      }

      public void rename(String name, String newName, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = this.find(name);
         if (info != null && newName != null) {
            this.keys.remove(info.name);
            info.name = newName;
            this.keys.add(newName);
         }

         if (callback != null) {
            callback.accept(info);
         }
      }

      public void setActive(String name, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = this.find(name);
         if (info != null) {
            for (int i = 0; i < this.items.size(); i++) {
               this.items.get(i).active = false;
            }

            info.active = true;
         }

         if (callback != null) {
            callback.accept(info);
         }
      }

      public void deleteConfig(String name, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = this.find(name);
         this.remove(name);
         if (callback != null) {
            callback.accept(info);
         }
      }

      public void setDescription(String name, String text, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = this.find(name);
         if (info != null) {
            info.description = text;
         }

         if (callback != null) {
            callback.accept(info);
         }
      }

      public void share(String name, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = this.find(name);
         if (callback != null) {
            callback.accept(info);
         }
      }

      public void setPrivate(String name, boolean value, ConfigsPart.CardConsumer callback) {
         ConfigsPart.ConfigInfo info = this.find(name);
         if (info != null) {
            info.privateFlag = value;
         }

         if (callback != null) {
            callback.accept(info);
         }
      }

      public void saveCurrent(Runnable callback) {
         if (callback != null) {
            callback.run();
         }
      }
   }

   public interface PlateInputRef {
      void clearText();

      String text();
   }

   public static class ToolbarPlateInputRef implements ConfigsPart.PlateInputRef {
      @Override
      public void clearText() {
      }

      @Override
      public String text() {
         return null;
      }
   }
}

