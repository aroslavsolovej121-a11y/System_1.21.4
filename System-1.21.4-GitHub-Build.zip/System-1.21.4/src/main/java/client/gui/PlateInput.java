package client.gui;

public class PlateInput extends Component {
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int TEXT_OFFSET = 96;
   public static final int TEXT_SIZE_OFFSET = 112;
   public static final int TEXT_CAPACITY_OFFSET = 120;
   public static final int FONT_SIZE_OFFSET = 128;
   public static final int FLAG_84_OFFSET = 132;
   public static final int FLAG_85_OFFSET = 133;
   public static final int FLAG_86_OFFSET = 134;
   public static final int CURSOR_OFFSET = 136;
   public static final int SELECTION_OFFSET = 144;
   public static final int VIEW_TEXT_OFFSET = 152;
   public static final int SUBJECT_OFFSET = 240;
   public static final int RESERVED_130_OFFSET = 304;
   public static final int LABEL_OFFSET = 312;
   public static final int ICON_OFFSET = 344;
   public static final int PANEL_STYLE_OFFSET = 348;
   public static final int FOCUSED_OFFSET = 352;
   public static final int FOCUS_ANIM_OFFSET = 360;
   public static final int REVEAL_ANIM_OFFSET = 400;
   public static final int GHOST_ANIM_OFFSET = 440;
   public static final int STAGING_OFFSET = 480;
   public static final int PENDING_CLEAR_OFFSET = 512;
   public static final int COLOR_ANIM_OFFSET = 520;
   public static final int FLASH_ALPHA_OFFSET = 568;
   public static final int FLASH_ANIM_OFFSET = 576;
   public static final int CALLBACK_STORAGE_OFFSET = 616;
   public static final int CALLBACK_OFFSET = 672;
   public static final int CHAR_FILTER_STORAGE_OFFSET = 680;
   public static final int CHAR_FILTER_OFFSET = 736;
   public static final float DEFAULT_WIDTH = 230.0F;
   public static final float HEIGHT = 42.0F;
   public static final float FONT_SIZE = 14.0F;
   public static final float VIEW_HEIGHT = 36.0F;
   public static final float VIEW_RADIUS = 12.0F;
   public static final float PANEL_RADIUS = 14.0F;
   public static final float PANEL_INSET = 3.0F;
   public static final float PANEL_GAP = 6.0F;
   public static final float ICON_SIZE = 12.0F;
   public static final float ICON_LABEL_INSET = 18.0F;
   public static final float ICON_TOP_INSET = 6.0F;
   public static final float SEPARATOR_SIZE = 20.0F;
   public static final float SEPARATOR_INSET = 10.0F;
   public static final float TEXT_TOP_INSET = 7.0F;
   public static final float FLASH_SCALE = 0.35F;
   public static final float HOVER_SCALE = 0.5F;
   public static final float FOCUS_DURATION = 0.15F;
   public static final float REVEAL_DURATION = 0.15F;
   public static final float GHOST_DURATION = 0.15F;
   public static final float FLASH_DURATION = 0.32F;
   public static final float REVEAL_EXPONENT = 1.7F;
   public static final float EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final int HOVER_INPUT = 2;
   public static final int SEPARATOR_ICON = 80;
   public static final int TEXT_ALIGNMENT = 2;
   public static final int KEY_ENTER = 13;
   public static final int KEY_ESCAPE = 27;
   public static final int SPACE_LIMIT = 32;
   protected final PlateInput.Anim rectAnim = new PlateInput.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected String text = "";
   protected float fontSize = 14.0F;
   protected byte flag84;
   protected byte flag85;
   protected byte flag86;
   protected long cursor;
   protected long selection;
   protected String viewText = "";
   protected Object subject;
   protected long reserved130;
   protected String label = "";
   protected int icon;
   protected float panelStyle;
   protected boolean focused;
   protected final PlateInput.Anim focusAnim = new PlateInput.Anim();
   protected final PlateInput.Anim revealAnim = new PlateInput.Anim();
   protected final PlateInput.Anim ghostAnim = new PlateInput.Anim();
   protected String staging = "";
   protected boolean pendingClear;
   protected final PlateInput.ColorAnim colorAnim = new PlateInput.ColorAnim();
   protected float flashAlpha;
   protected final PlateInput.Anim flashAnim = new PlateInput.Anim();
   protected Object callback;
   protected final byte[] callbackStorage = new byte[56];
   protected Object charFilter;
   protected final byte[] charFilterStorage = new byte[56];
   private static final float ONE = 1.0F;

   public PlateInput(float width, String label, int icon) {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.text = "";
      this.cursor = 0L;
      this.selection = 0L;
      this.viewText = "";
      this.fontSize = 14.0F;
      this.flag84 = 0;
      this.flag85 = 0;
      this.flag86 = 0;
      this.subject = null;
      this.reserved130 = 0L;
      this.label = "";
      this.label = label != null ? label : "";
      releaseSourceString();
      this.icon = icon;
      this.panelStyle = 0.0F;
      this.focused = false;
      this.focusAnim.set(0.0F, 0.15F);
      this.revealAnim.set(1.0F, 0.15F);
      this.ghostAnim.set(1.0F, 0.15F);
      this.staging = "";
      this.pendingClear = false;
      this.colorAnim.set(themeColor(0), 0.15F);
      this.flashAlpha = 0.0F;
      this.flashAnim.set(0.0F, 0.32F);
      this.callback = null;
      this.charFilter = null;
      this.width = width;
      this.height = 42.0F;
      this.flag85 = 1;
   }

   @Override
   public void dispose() {
      releaseGlobalTextOwner(this);
      resetString(312);
      resetString(480);
      if (this.callback != null) {
         releaseCallback(this.callback, this.callback != this.callbackStorage);
         this.callback = null;
      }

      if (this.charFilter != null) {
         releaseCallback(this.charFilter, this.charFilter != this.charFilterStorage);
         this.charFilter = null;
      }

      freeString(480);
      freeString(312);
      freeString(96);
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      if (this.focused) {
         Screen.textInputActive = true;
      }

      float hover = this.updateHover(mouseX, mouseY);
      if ((this.flags & 0xFF) != 0) {
         Screen.hoveredWidget = 2;
      }

      float focus = this.focusAnim.advance(PlateInput.Anim.now());
      if (focus <= hover) {
         focus = hover;
      }

      float panelAlpha = (focus * 0.5F + 0.5F) * alpha;
      drawPanel(mat, this.x, this.y, this.width, this.height, 14.0F, panelAlpha, this.panelStyle);
      float innerX = this.x + 3.0F;
      float innerY = this.y + 3.0F;
      float innerWidth = this.width - 6.0F;
      int frameColor = themeBorderColor();
      float iconSize = 12.0F;
      drawInnerPlate(mat, innerX, innerY, innerWidth, 36.0F, 12.0F, frameColor, panelAlpha);
      float flash = this.flashAnim.advance(PlateInput.Anim.now());
      this.flashAlpha = flash;
      if (0.001F < flash) {
         float tint = this.colorAnim.advance(PlateInput.Anim.now());
         float value = flash * alpha * 0.35F;
         int color = mixColor(this.colorAnim.colorFrom, this.colorAnim.colorTo, tint);
         drawAccentPlate(mat, innerX, innerY, innerWidth, 36.0F, 12.0F, color, value);
      }

      float iconY = innerY + 18.0F;
      float iconX = innerX + iconSize;
      drawIcon(mat, this.icon, iconX, iconY - 6.0F, iconSize, iconSize, themeColor(24), panelAlpha);
      float separatorSize = 20.0F;
      float separatorY = iconY - 10.0F;
      float separatorX = innerX + innerWidth - iconSize - 20.0F;
      drawSeparator(mat, separatorX, separatorY, separatorSize, separatorSize, themeColor(8), panelAlpha);
      float[] metrics = iconMetrics(80);
      drawIcon(
         mat,
         80,
         (separatorSize - metrics[0]) * 0.5F + separatorX,
         (separatorSize - metrics[1]) * 0.5F + separatorY,
         metrics[0],
         metrics[1],
         themeColor(24),
         panelAlpha
      );
      float textY = iconY - 7.0F;
      float ghostTarget = 0.0F;
      float textX = innerX + iconSize + iconSize + 6.0F;
      float textWidth = separatorX - 6.0F - textX;
      if (textWidth <= 0.0F) {
         textWidth = 0.0F;
      }

      float reveal = this.revealAnim.advance(PlateInput.Anim.now());
      if (this.pendingClear && reveal <= 0.001F) {
         this.resetInput();
      }

      if (!this.staging.isEmpty() && this.ghostAnim.current <= 0.001F) {
         resetString(312);
         this.label = this.staging;
         this.staging = "";
      }

      if (this.text.isEmpty() && !this.focused && this.staging.isEmpty()) {
         ghostTarget = 1.0F;
      }

      if (this.ghostAnim.target != ghostTarget) {
         long time = PlateInput.Anim.now();
         float value = this.ghostAnim.advance(time);
         this.ghostAnim.from = value;
         this.ghostAnim.target = ghostTarget;
         this.ghostAnim.start = time;
         this.ghostAnim.running = true;
      }

      float ghost = this.ghostAnim.advance(PlateInput.Anim.now());
      pushScissor(textX, innerY, textWidth, 36.0F);
      if (0.001F < ghost) {
         float fade = clamp01(ghost);
         fade = (float)Math.pow(fade, 1.7F);
         drawText(2, mat, this.label, textX, textY, 14.0F, themeColor(24), fade * panelAlpha);
      }

      if (ghost < 0.999F) {
         drawTextField(mat, this.text, textX, textY, textWidth, themeColor(24), reveal * alpha * (1.0F - ghost), this.focused);
      }

      popScissor();
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (this.x <= (float)mx && mx <= this.x + this.width && this.y <= (float)my && my <= this.y + this.height) {
         this.setFocused(true);
         return true;
      } else {
         this.setFocused(false);
         return false;
      }
   }

   public boolean keyPressed(int keyCode) {
      if (!this.focused) {
         return false;
      } else if (keyCode == 27) {
         this.focused = false;
         this.focusAnim.retarget(0.0F);
         clearGlobalFocus(this);
         return true;
      } else {
         return keyCode == 13 ? this.submit() : textKey(this.text, keyCode);
      }
   }

   @Override
   public boolean charTyped(char ch) {
      if (!this.focused) {
         return false;
      } else {
         return this.charFilter != null && !acceptChar(this.charFilter, ch) ? false : textChar(this.text, ch);
      }
   }

   public void setFocused(boolean value) {
      if (this.focused != value) {
         this.focused = value;
         this.focusAnim.retarget(value ? 1.0F : 0.0F);
         if (value) {
            installGlobalFocus(this);
         } else {
            clearGlobalFocus(this);
         }
      }
   }

   public boolean isFocused() {
      return this.focused;
   }

   public String text() {
      return this.text;
   }

   public void setText(String value) {
      String next = value != null ? value : "";
      if (next.length() == this.label.length()) {
         boolean sameAsLabel = next.length() == 0 || next.equals(this.label);
         if (sameAsLabel) {
            this.staging = "";
            return;
         }
      }

      if (next.length() == this.staging.length()) {
         if (next.length() == 0) {
            return;
         }

         if (next.equals(this.staging)) {
            return;
         }
      }

      if (0.001F < this.ghostAnim.current) {
         resetString(480);
         this.staging = next;
      } else {
         resetString(312);
         this.label = next;
      }
   }

   public void setLabel(String value) {
      this.staging = "";
      this.label = value != null ? value : "";
      float target = !this.text.isEmpty() && !this.focused ? 1.0F : 0.0F;
      this.ghostAnim.from = target;
      this.ghostAnim.current = target;
      this.ghostAnim.target = target;
      this.ghostAnim.running = false;
   }

   public String label() {
      return this.label;
   }

   public int icon() {
      return this.icon;
   }

   public boolean hasText() {
      int start = 0;
      int remaining = this.text.length();
      boolean blank = remaining == 0;
      if (!blank) {
         while (this.text.charAt(start) < '!') {
            remaining--;
            start++;
            if (remaining == 0) {
               return false;
            }
         }

         while (' ' >= this.text.charAt(start + remaining - 1)) {
            if (--remaining == 0) {
               break;
            }
         }

         blank = remaining == 0;
      }

      return !blank;
   }

   public boolean submit() {
      int start = 0;

      while (start < this.text.length() && this.text.charAt(start) <= ' ') {
         start++;
      }

      int end = this.text.length();

      while (end > start && this.text.charAt(end - 1) <= ' ') {
         end--;
      }

      String trimmed = this.text.substring(start, end);
      if (trimmed.isEmpty()) {
         return false;
      } else {
         if (this.callback != null) {
            invokeCallback(this.callback, trimmed);
         }

         this.resetInput();
         if (this.focused) {
            this.focused = false;
            this.focusAnim.retarget(0.0F);
            clearGlobalFocus(this);
         }

         return true;
      }
   }

   public void resetInput() {
      this.text = "";
      this.cursor = 0L;
      this.selection = 0L;
      if (this.subject != null) {
         notifySubject(this.subject);
      }

      this.pendingClear = false;
      this.revealAnim.from = 1.0F;
      this.revealAnim.current = 1.0F;
      this.revealAnim.target = 1.0F;
      this.revealAnim.running = false;
   }

   public void takeOverFrom(PlateInput other) {
      if (other != this && other.hasText()) {
         this.text = other.text;
         this.cursor = this.text.length();
         this.selection = this.text.length();
         if (this.subject != null) {
            notifySubjectText(this.subject, this.text);
         }

         this.revealAnim.from = 0.0F;
         this.revealAnim.current = 0.0F;
         this.revealAnim.target = 0.0F;
         this.revealAnim.running = false;
         this.revealAnim.retarget(1.0F);
         if (!this.focused) {
            this.focused = true;
            this.focusAnim.retarget(1.0F);
            installGlobalFocus(this);
         }

         other.pendingClear = true;
         other.revealAnim.retarget(0.0F);
         if (other.focused) {
            other.focused = false;
            other.focusAnim.retarget(0.0F);
            clearGlobalFocus(other);
         }
      } else {
         if (!this.focused) {
            this.focused = true;
            this.focusAnim.retarget(1.0F);
            installGlobalFocus(this);
         }
      }
   }

   public void setColor(int color) {
      this.colorAnim.colorFrom = color;
      this.colorAnim.colorTo = color;
      this.colorAnim.from = 1.0F;
      this.colorAnim.current = 1.0F;
      this.colorAnim.target = 1.0F;
      this.colorAnim.running = false;
      this.flashAnim.from = 1.0F;
      this.flashAnim.current = 1.0F;
      this.flashAnim.target = 1.0F;
      this.flashAnim.running = false;
      long time = PlateInput.Anim.now();
      float value = this.flashAnim.advance(time);
      this.flashAnim.current = value;
      this.flashAnim.start = time;
      this.flashAnim.from = value;
      this.flashAnim.target = 0.0F;
      this.flashAnim.running = true;
   }

   public float flashAlpha() {
      return this.flashAlpha;
   }

   public void setSubject(Object value) {
      this.subject = value;
   }

   public void setCallback(Object value) {
      this.callback = value;
   }

   public void setCharFilter(Object value) {
      this.charFilter = value;
   }

   public static boolean releaseFocus(Object lambda) {
      PlateInput widget = (PlateInput)lambdaOwner(lambda);
      if (widget != null && widget.focused) {
         widget.focused = false;
         widget.focusAnim.retarget(0.0F);
         clearGlobalFocus(widget);
         return true;
      } else {
         return false;
      }
   }

   private float updateHover(float mouseX, float mouseY) {
      float target;
      if (!(mouseX < this.x)
         && !(this.x + this.width < mouseX)
         && !(mouseY < this.y)
         && !(this.y + this.height < mouseY)
         && (Screen.focusedInput == null || Screen.allowHover)) {
         this.flags = this.flags & 0xFF00 | 1;
         target = 1.0F;
      } else {
         this.flags &= 65280;
         target = 0.0F;
      }

      if (this.rectAnim.target != target) {
         long time = PlateInput.Anim.now();
         float value = this.rectAnim.advance(time);
         this.rectAnim.start = time;
         this.rectAnim.from = value;
         this.rectAnim.target = target;
         this.rectAnim.running = true;
      }

      return this.rectAnim.advance(PlateInput.Anim.now());
   }

   private static float clamp01(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private static void installGlobalFocus(PlateInput widget) {
   }

   private static void clearGlobalFocus(PlateInput widget) {
   }

   private static void releaseGlobalTextOwner(PlateInput widget) {
   }

   private static Object lambdaOwner(Object lambda) {
      return null;
   }

   private static void releaseSourceString() {
   }

   private static void resetString(int offset) {
   }

   private static void freeString(int offset) {
   }

   private static void releaseCallback(Object sub, boolean heap) {
   }

   private static void invokeCallback(Object sub, String value) {
   }

   private static void notifySubject(Object sub) {
   }

   private static void notifySubjectText(Object sub, String value) {
   }

   private static boolean acceptChar(Object filter, char ch) {
      return true;
   }

   private static boolean textKey(String value, int keyCode) {
      return true;
   }

   private static boolean textChar(String value, char ch) {
      return true;
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static int themeBorderColor() {
      return 0;
   }

   private static int mixColor(int from, int to, float t) {
      return 0;
   }

   private static float[] iconMetrics(int icon) {
      return new float[2];
   }

   private static void drawPanel(Object mat, float x, float y, float width, float height, float radius, float alpha, float style) {
   }

   private static void drawInnerPlate(Object mat, float x, float y, float width, float height, float radius, int color, float alpha) {
   }

   private static void drawAccentPlate(Object mat, float x, float y, float width, float height, float radius, int color, float alpha) {
   }

   private static void drawSeparator(Object mat, float x, float y, float width, float height, int color, float alpha) {
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float width, float height, int color, float alpha) {
   }

   private static void drawText(int alignment, Object mat, String text, float x, float y, float size, int color, float alpha) {
   }

   private static void drawTextField(Object mat, String value, float x, float y, float width, int color, float alpha, boolean focusedNow) {
   }

   private static void pushScissor(float x, float y, float width, float height) {
   }

   private static void popScissor() {
   }

   private static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }

   private static final class ColorAnim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int ANIM_COLOR_FROM = 40;
      public static final int ANIM_COLOR_TO = 44;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;
      int colorFrom;
      int colorTo;

      void set(int color, float duration) {
         this.duration = duration;
         this.easing = 0;
         this.from = 1.0F;
         this.current = 1.0F;
         this.target = 1.0F;
         this.start = PlateInput.Anim.now();
         this.colorFrom = color;
         this.colorTo = color;
         this.running = false;
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = PlateInput.Anim.easeOutCubic(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }
   }
}

