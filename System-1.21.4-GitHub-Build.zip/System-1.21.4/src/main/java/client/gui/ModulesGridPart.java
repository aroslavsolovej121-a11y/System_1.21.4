package client.gui;

import java.util.ArrayList;
import java.util.List;

public class ModulesGridPart extends Component {
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int CARDS_OFFSET = 96;
   public static final int COLUMNS_OFFSET = 120;
   public static final int SCROLL_ANIM_OFFSET = 144;
   public static final int SCROLL_OFFSET = 184;
   public static final int CONTENT_HEIGHT_OFFSET = 188;
   public static final int COLUMN_WIDTH_OFFSET = 192;
   public static final int DRAGGING_OFFSET = 196;
   public static final int DRAG_ANCHOR_OFFSET = 200;
   public static final int BAND_TOP_OFFSET = 204;
   public static final int BAND_BOTTOM_OFFSET = 208;
   public static final int CATEGORY_OFFSET = 296;
   public static final int FAVORITES_OFFSET = 304;
   public static final int FAVORITES_SCROLL_OFFSET = 308;
   public static final int CARD_HEIGHT_OFFSET = 16;
   public static final int CARD_ANIM_OFFSET = 920;
   public static final int CARD_VISIBLE_OFFSET = 118;
   public static final float DEFAULT_WIDTH = 964.0F;
   public static final float COLUMN_WIDTH = 305.0F;
   public static final float COLUMN_GAP = 8.0F;
   public static final float GRID_PADDING = 16.0F;
   public static final float BAND_INSET = 2.0F;
   public static final float SCROLL_STEP = 48.0F;
   public static final float SCROLLBAR_MIN_HEIGHT = 59.0F;
   public static final float SCROLLBAR_INSET = 4.0F;
   public static final float SCROLLBAR_GAP = 6.0F;
   public static final float SCROLLBAR_WIDTH = 3.0F;
   public static final float SCROLLBAR_PADDING = 64.0F;
   public static final float VIEWPORT_RATIO = 0.0625F;
   public static final float EPSILON = 0.001F;
   public static final float FADE_DURATION = 0.28F;
   public static final float HALF = 0.5F;
   public static final int COLUMN_COUNT = 3;
   public static final int HOVER_GRID = 1;
   public static final int HOVER_SCROLLBAR = 4;
   protected final ModulesGridPart.Anim rectAnim = new ModulesGridPart.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected final List<ModuleCard> cards = new ArrayList<>();
   protected final List<Integer> columns = new ArrayList<>();
   protected final ModulesGridPart.Anim scrollAnim = new ModulesGridPart.Anim();
   protected float scroll;
   protected float contentHeight;
   protected float columnWidth = 305.0F;
   protected boolean dragging;
   protected float dragAnchor;
   protected float bandTop;
   protected float bandBottom;
   protected Object category;
   protected boolean favorites;
   protected float favoritesScroll;
   private static final float RECT_ANIM_DURATION = 0.15F;

   public ModulesGridPart() {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.scrollAnim.from = 0.0F;
      this.scrollAnim.current = 0.0F;
      this.scrollAnim.target = 0.0F;
      this.scrollAnim.duration = 0.28F;
      this.scrollAnim.easing = 1;
      this.scrollAnim.start = ModulesGridPart.Anim.now();
      this.scrollAnim.running = false;
      this.scroll = 0.0F;
      this.columnWidth = 305.0F;
      this.dragging = false;
      this.category = null;
      this.favorites = false;
      this.favoritesScroll = 0.0F;
      this.width = 964.0F;
   }

   @Override
   public void dispose() {
      clearCards();
      clearColumns();
      super.dispose();
   }

   public void setModules(List<?> modules) {
      if (!this.cards.isEmpty()) {
         destroyCards();
      }

      for (Object module : modules) {
         ModuleCard card = new ModuleCard(module);
         if (0.001F < Math.abs(card.width - this.columnWidth)) {
            card.width = this.columnWidth;
            cardRemeasure(card);
         }

         setModuleEnabled(card.feature, moduleEnabled(module));
         float target;
         if (cardAvailable(card) && featureEnabled(card.feature)) {
            target = 1.0F;
         } else {
            target = 0.0F;
         }

         cardSnapReveal(card, target);
         this.cards.add(card);
      }

      this.syncColumns();
      this.scroll = 0.0F;
      this.scrollAnim.target = 0.0F;
      this.contentHeight = 0.0F;
      this.dragging = false;
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      for (ModuleCard card : this.cards) {
         float target;
         if (cardAvailable(card) && featureEnabled(card.feature)) {
            target = 1.0F;
         } else {
            target = 0.0F;
         }

         cardDriveReveal(card, target);
      }

      this.syncColumns();
      float offset = this.scrollAnim.advance(ModulesGridPart.Anim.now());
      float pad = 8.0F;
      float originX = this.x + 16.0F;
      float originY = this.y - offset;
      float bandH = this.height - 2.0F;
      this.bandTop = this.y;
      if (bandH <= 0.0F) {
         bandH = 0.0F;
      }

      float columnPitch = this.columnWidth + pad;
      this.bandBottom = this.y + bandH;
      float scrolled = -1.0E9F;
      if (this.y <= mouseY && mouseY <= this.y + bandH) {
         scrolled = mouseY;
      }

      float viewTop = clamp01(offset * 0.0625F);
      float maxScroll = this.contentHeight - this.height;
      if (maxScroll <= 0.0F) {
         maxScroll = 0.0F;
      }

      float viewBottom = clamp01((maxScroll - offset) * 0.0625F);
      boolean clip = viewTop > 0.001F || viewBottom > 0.001F;
      if (clip) {
         drawScrollHint();
      }

      float clipHeight = bandH + 6.0F;
      pushScissor(this.x, this.y - 6.0F, this.width, clipHeight);
      float[] columnHeights = new float[3];

      for (int i = 0; i < this.cards.size(); i++) {
         ModuleCard card = this.cards.get(i);
         int column = i < this.columns.size() ? this.columns.get(i) : 0;
         float cardHeight = cardPreferredHeight(card);
         float columnY = columnHeights[column] + originY;
         card.y = columnY;
         card.x = column * columnPitch + originX;
         cardArrange(card);
         if (this.y < columnY + cardHeight && columnY < this.y + bandH) {
            card.render(mat, mouseX, scrolled, alpha);
         }

         columnHeights[column] += cardHeight + pad;
      }

      popScissor();
      pushScissor(this.x, this.y - 6.0F, this.width, clipHeight);

      for (ModuleCard card : this.cards) {
         card.layout(mat, mouseX, mouseY, alpha);
      }

      popScissor();
      if (clip) {
         drawScrollbarTrack(mouseY, viewTop, viewBottom, originX, this.bandTop, this.bandBottom);
      }

      float content = 0.0F;

      for (int i = 0; i < 3; i++) {
         if (content < columnHeights[i]) {
            content = columnHeights[i];
         }
      }

      this.contentHeight = content;
      layoutScrollbar();
      if (this.dragging) {
         Screen.hoveredWidget = 4;
      } else if (scrollbarContains(mouseX, mouseY) && (Screen.focusedInput == null || Screen.allowHover)) {
         Screen.hoveredWidget = 1;
      }

      float overflow = this.contentHeight - this.height;
      if (overflow <= 0.0F) {
         overflow = 0.0F;
      }

      if (0.001F < overflow) {
         float track = this.height - 2.0F - 16.0F;
         if (track <= 0.0F) {
            track = 0.0F;
         }

         if (59.0F < track) {
            Object thumb = scrollbarThumb(this.y + pad, track, 59.0F, offset);
            drawScrollbar(mat, this.x + this.width - 4.0F - 6.0F, thumb, alpha);
         }
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      for (ModuleCard card : this.cards) {
         if (cardAcceptsInput(card)) {
            if (card.mouseClicked(mx, my, button)) {
               return true;
            }

            for (Component child : cardChildren(card)) {
               if (invokeWidgetMouseClicked(child, mx, my, button)) {
                  invokeWidgetMouseReleased(child, mx, my, button);
               }
            }

            return true;
         }
      }

      if (button == 0 && scrollbarContains(mx, my)) {
         this.dragging = true;
         this.dragAnchor = (float)my - scrollbarOffset();
         return true;
      } else {
         if (this.x <= (float)mx && mx <= this.x + this.width && this.bandTop <= (float)my && my <= this.bandBottom) {
            for (ModuleCard cardx : this.cards) {
               if (cardx.mouseClicked(mx, my, button)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.dragging && button == 0) {
         this.dragging = false;
         return true;
      } else {
         for (ModuleCard card : this.cards) {
            if (card.mouseReleased(mx, my, button)) {
               return true;
            }

            for (Component child : cardChildren(card)) {
               if (invokeWidgetMouseReleased(child, mx, my, button)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      return this.mouseDragged(mx, my, button, 0.0, 0.0);
   }

   public boolean mouseDragged(double mx, double my, int buttons, double deltaX, double deltaY) {
      if (this.dragging && buttons == 0) {
         float maxScroll = this.contentHeight - this.height;
         if (maxScroll <= 0.0F) {
            maxScroll = 0.0F;
         }

         float track = this.height - 2.0F - 16.0F;
         if (track <= 0.0F) {
            track = 0.0F;
         }

         float value = 0.0F;
         if (0.0F < track - 59.0F) {
            value = ((float)my - this.dragAnchor - (this.y + 8.0F)) / (track - 59.0F) * maxScroll;
            if (value < 0.0F) {
               value = 0.0F;
            }

            if (value > maxScroll) {
               value = maxScroll;
            }
         }

         this.scroll = value;
         this.scrollAnim.retarget(value);
         return true;
      } else {
         for (ModuleCard card : this.cards) {
            if (card.mouseDragged(mx, my, buttons, deltaX, deltaY)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (this.x <= (float)mx && mx <= this.x + this.width && this.y <= (float)my && my <= this.y + this.height) {
         for (ModuleCard card : this.cards) {
            if (card.mouseScrolled(mx, my, amount)) {
               return true;
            }
         }

         float maxScroll = this.contentHeight - this.height;
         if (maxScroll <= 0.0F) {
            maxScroll = 0.0F;
         }

         float value = clamp(this.scroll - (float)amount * 48.0F, 0.0F, maxScroll);
         this.scroll = value;
         if (this.scrollAnim.target != value) {
            this.scrollAnim.advance(ModulesGridPart.Anim.now());
            this.scrollAnim.target = value;
            this.scrollAnim.start = ModulesGridPart.Anim.now();
            this.scrollAnim.running = true;
         }

         return true;
      } else {
         return true;
      }
   }

   @Override
   public boolean keyPressed(int key, int modifiers) {
      for (ModuleCard card : this.cards) {
         if (card.keyPressed(key)) {
            return true;
         }

         for (Component child : cardChildren(card)) {
            if (invokeWidgetKeyPressed(child, key)) {
               return true;
            }
         }
      }

      return false;
   }

   @Override
   public boolean keyReleased(int key) {
      for (ModuleCard card : this.cards) {
         if (card.keyReleased(key)) {
            return true;
         }

         for (Component child : cardChildren(card)) {
            if (invokeWidgetKeyReleased(child, key)) {
               return true;
            }
         }
      }

      return false;
   }

   @Override
   public boolean charTyped(char codePoint) {
      for (ModuleCard card : this.cards) {
         for (Component child : cardChildren(card)) {
            if (invokeWidgetCharTyped(child, codePoint)) {
               return true;
            }
         }
      }

      return false;
   }

   private void syncColumns() {
      while (this.columns.size() < this.cards.size()) {
         this.columns.add(0);
      }

      while (this.columns.size() > this.cards.size()) {
         this.columns.remove(this.columns.size() - 1);
      }

      float[] heights = new float[3];

      for (int i = 0; i < this.cards.size(); i++) {
         int column = heights[1] < heights[0] ? 1 : 0;
         if (heights[2] < heights[column]) {
            column = 2;
         }

         this.columns.set(i, column);
         heights[column] += cardPreferredHeight(this.cards.get(i)) + 8.0F;
      }
   }

   private static void cardSnapReveal(ModuleCard card, float target) {
   }

   private static void cardDriveReveal(ModuleCard card, float target) {
   }

   private static float cardPreferredHeight(ModuleCard card) {
      return 0.0F;
   }

   private static void cardArrange(ModuleCard card) {
   }

   private static void cardRemeasure(ModuleCard card) {
   }

   private static boolean cardAcceptsInput(ModuleCard card) {
      return false;
   }

   private static boolean cardAvailable(ModuleCard card) {
      return false;
   }

   private static List<Component> cardChildren(ModuleCard card) {
      return new ArrayList<>();
   }

   public List<ModuleCard> cards() {
      return this.cards;
   }

   public boolean favorites() {
      return this.favorites;
   }

   public Object category() {
      return this.category;
   }

   public float contentHeight() {
      return this.contentHeight;
   }

   public void setScroll(float value) {
      this.scroll = value;
   }

   private static boolean moduleEnabled(Object module) {
      return false;
   }

   private static void setModuleEnabled(Object feature, boolean value) {
   }

   private static boolean featureEnabled(Object feature) {
      return false;
   }

   private static float clamp(float value, float min, float max) {
      if (value < min) {
         return min;
      } else {
         return value > max ? max : value;
      }
   }

   private static float clamp01(float value) {
      return clamp(value, 0.0F, 1.0F);
   }

   private static void destroyCards() {
   }

   private static void clearCards() {
   }

   private static void clearColumns() {
   }

   private static void drawScrollHint() {
   }

   private static void drawScrollbarTrack(float mouseY, float viewTop, float viewBottom, float x, float bandTop, float bandBottom) {
   }

   private static Object scrollbarThumb(float y, float track, float minHeight, float offset) {
      return null;
   }

   private static void drawScrollbar(Object mat, float x, Object thumb, float alpha) {
   }

   private static void pushScissor(float x, float y, float width, float height) {
   }

   private static void popScissor() {
   }

   private static boolean scrollbarContains(double mx, double my) {
      return false;
   }

   private static float scrollbarOffset() {
      return 0.0F;
   }

   private static void layoutScrollbar() {
   }

   private static boolean invokeWidgetMouseClicked(Component widget, double mx, double my, int button) {
      return false;
   }

   private static boolean invokeWidgetMouseReleased(Component widget, double mx, double my, int button) {
      return false;
   }

   private static boolean invokeWidgetKeyPressed(Component widget, int key) {
      return false;
   }

   private static boolean invokeWidgetKeyReleased(Component widget, int key) {
      return false;
   }

   private static boolean invokeWidgetCharTyped(Component widget, char codePoint) {
      return false;
   }

   public static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }
}

