package client.gui;

import java.util.ArrayList;
import java.util.List;

public class SafeModeOverlay extends AbstractOverlay {
   public static final float DEFAULT_DURATION = 0.15F;
   public static final float DEFAULT_ALPHA_DURATION = 0.15F;
   public static final int MODE_LIST = 0;
   public static final int MODE_DETAIL = 1;
   public static final int MODE_IMAGE = 2;
   public static final float PANEL_WIDTH = 360.0F;
   public static final float PANEL_HEIGHT = 295.0F;
   public static final float PANEL_RADIUS = 12.0F;
   public static final float PANEL_PADDING = 16.0F;
   public static final float PANEL_INNER_GAP = 8.0F;
   public static final float PANEL_BOTTOM_GAP = 32.0F;
   public static final float BUTTON_HEIGHT = 32.0F;
   public static final float BUTTON_RADIUS = 8.0F;
   public static final float HINT_WIDTH = 248.0F;
   public static final float HINT_HEIGHT = 167.0F;
   public static final float HINT_RADIUS = 8.0F;
   public static final float THUMB_WIDTH = 236.0F;
   public static final float THUMB_HEIGHT = 133.0F;
   public static final float THUMB_PADDING = 2.0F;
   public static final float HEADER_TEXT_SIZE = 16.0F;
   public static final float TITLE_TEXT_SIZE = 12.0F;
   public static final float LABEL_TEXT_SIZE = 14.0F;
   public static final float DETAIL_TEXT_SIZE = 12.0F;
   public static final float LINE_HEIGHT = 14.4F;
   public static final float LINES_BIAS = 44.0F;
   public static final float MEASURE_MAX_WIDTH = 328.0F;
   public static final float OPEN_THRESHOLD = 0.5F;
   public static final float SNAPSHOT_POLL_SECONDS = 1.0F;
   public static final float NANOS_PER_SECOND = 1.0E9F;
   public static final int HOVERED_WIDGET_SAFE_MODE = 1;
   public static final int HOVER_SOUND_IN = 8;
   public static final int HOVER_SOUND_OUT = 9;
   public static final int ICON_WARNING = 51;
   private static final String HEADER_LABEL = "SafeModeOverlay.header";
   private static final String TITLE_LABEL = "SafeModeOverlay.title";
   private static final String TITLE_LABEL_ALT = "SafeModeOverlay.titleAlt";
   private static final String LIST_LABEL = "SafeModeOverlay.list";
   private static final String LIST_LABEL_ALT = "SafeModeOverlay.listAlt";
   private static final String DETAIL_LABEL = "SafeModeOverlay.detail";
   private static final String DETAIL_LABEL_ALT = "SafeModeOverlay.detailAlt";
   private static final String EMPTY_LABEL = "SafeModeOverlay.empty";
   private static final String LOADING_LABEL_A = "SafeModeOverlay.loadingA";
   private static final String LOADING_LABEL_B = "SafeModeOverlay.loadingB";
   private static final String DEFAULT_DETAIL = "SafeModeOverlay.defaultDetail";
   private static final String DEFAULT_ENTRY = "SafeModeOverlay.defaultEntry";
   private static Object dismissHandler;
   private final List<Object> entries = new ArrayList<>();
   private final List<Object> imageA = new ArrayList<>();
   private final List<Object> imageB = new ArrayList<>();
   private Object childSlot;
   private int mode;
   private Object previousSnapshot;
   private Object snapshotHandle;
   private int textureA;
   private int textureB;
   private int textureWidth;
   private int textureHeight;
   private int imageAWidth;
   private int imageAHeight;
   private int imageBWidth;
   private int imageBHeight;
   private float heightSmooth = 295.0F;
   private float panelTop;
   private float buttonX;
   private float panelRight;
   private float panelHalfWidth;
   private float hintX;
   private float hintY;
   private boolean twoColumn;
   private boolean closeRequested;
   private boolean snapshotPending;
   private boolean loadingLabel;
   private long requestTime;
   private final AbstractOverlay.Animator openAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   private final AbstractOverlay.Animator hoverLeftAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   private final AbstractOverlay.Animator hoverRightAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   private final AbstractOverlay.Animator loadAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);

   public SafeModeOverlay() {
      this.initRectAnimator();
      this.animXFrom = 0.0F;
      this.animXCurrent = 0.0F;
      this.animXTarget = 0.0F;
      this.animYFrom = 0.0F;
      this.animYCurrent = 0.0F;
      this.animYTarget = 0.0F;
      this.animatingPosition = false;
      this.animFrom = 0.0F;
      this.alpha = 0.0F;
      this.alphaTarget = 0.0F;
      this.alphaDuration = 0.15F;
      this.alphaEasing = 1;
      this.alphaStart = this.now();
      this.alphaRunning = false;
      this.closed = false;
      this.closeOnOutsideClick = true;
      this.closeOnEscape = true;
      this.detached = false;
      this.child = null;
      this.childSlot = null;
      this.mode = 0;
      resetAnimator(this.openAnim, 0.0F, 0.15F, 0);
      this.heightSmooth = 295.0F;
      this.previousSnapshot = null;
      this.snapshotHandle = null;
      this.textureA = 0;
      this.textureB = 0;
      this.textureWidth = 0;
      this.textureHeight = 0;
      this.imageAWidth = 0;
      this.imageAHeight = 0;
      this.imageBWidth = 0;
      this.imageBHeight = 0;
      this.panelTop = 0.0F;
      this.buttonX = 0.0F;
      this.panelRight = 0.0F;
      this.panelHalfWidth = 0.0F;
      this.hintX = 0.0F;
      this.hintY = 0.0F;
      this.twoColumn = false;
      this.closeRequested = false;
      this.snapshotPending = false;
      this.loadingLabel = false;
      this.requestTime = 0L;
      resetAnimator(this.hoverLeftAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.hoverRightAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.loadAnim, 0.0F, 0.15F, 0);
   }

   public void show() {
      this.closeRequested = true;
      this.mode = 0;
      resetAnimator(this.openAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.hoverLeftAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.hoverRightAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.loadAnim, 0.0F, 0.15F, 0);
      clearLabel(352);
      applySnapshot(collectWindows());
      this.snapshotPending = true;
      this.requestTime = this.now();
      submitSnapshotRequest();
      this.width = 360.0F;
      this.height = 295.0F;
      this.heightSmooth = 295.0F;
      this.centerOnScreen();
      this.activate();
   }

   @Override
   public void dispose() {
      releaseSnapshotState();
      super.dispose();
   }

   @Override
   public void reset() {
      this.closed = false;
      this.animFrom = 0.0F;
      this.alpha = 0.0F;
      this.alphaTarget = 0.0F;
      this.alphaRunning = false;
      this.onDisposed();
   }

   @Override
   public void onDisposed() {
      if (this.closeRequested) {
         this.closeRequested = false;
         if (dismissHandler != null) {
            releaseDismissHandler(dismissHandler);
         }
      }

      this.mode = 0;
      this.openAnim.from = 0.0F;
      this.openAnim.current = 0.0F;
      this.openAnim.target = 0.0F;
      this.openAnim.running = false;
      releaseEntries();
      this.entries.clear();
      clearLabel(288);
      clearLabel(320);
      releaseTextures();
      this.previousSnapshot = null;
      this.snapshotHandle = null;
      releaseImageList(this.imageA);
      this.imageA.clear();
      this.imageAWidth = 0;
      this.imageAHeight = 0;
      releaseImageList(this.imageB);
      this.imageB.clear();
      this.imageBWidth = 0;
      this.imageBHeight = 0;
   }

   @Override
   public boolean isActive() {
      return true;
   }

   @Override
   public void renderBody(Object renderer, float mouseX, float mouseY, float alpha) {
      if (this.mode == 0 && !this.snapshotPending && 1.0F <= (float)((this.now() - this.requestTime) / 1.0E9)) {
         this.requestSnapshot();
      }

      refresh();
      float open = advance(this.openAnim, this.now());
      float height = this.heightSmooth;
      float magnitude = Math.abs(open);
      if (!Float.isNaN(magnitude) && !Float.isInfinite(magnitude) && !Float.isNaN(height) && !Float.isInfinite(height)) {
         if (0.0F < height) {
            if (open != 1.0F) {
               float scaled = magnitude * (height - 295.0F) + 295.0F;
               boolean keep;
               if (1.0F < open == 295.0F < height) {
                  keep = scaled < height;
               } else {
                  keep = height < scaled;
               }

               if (!keep) {
                  height = scaled;
               }
            }
         } else {
            height = height * open + (1.0F - open) * 295.0F;
         }
      } else if (!Float.isNaN(height)) {
         if (!Float.isNaN(open)) {
            if (Float.isInfinite(magnitude)) {
               height = (height - 295.0F) * open;
            } else if (open < 0.0F) {
               height = 295.0F - height;
            } else if (1.0F < open) {
               height -= 295.0F;
            } else {
               height = height * open + (1.0F - open) * 295.0F;
            }
         } else {
            height = open + open;
         }
      } else {
         height = height + 295.0F + open;
      }

      this.heightSmooth = height;
      this.height = height;
      this.renderPanels(renderer, mouseX, mouseY, alpha, open);
   }

   private void renderPanels(Object renderer, float mouseX, float mouseY, float alpha, float open) {
      this.centerOnScreen();
      float top = this.y;
      float alphaClamped = alpha;
      if (alpha < 0.0F) {
         alphaClamped = 0.0F;
      }

      if (alphaClamped > 1.0F) {
         alphaClamped = 1.0F;
      }

      float rectTop = (1.0F - alphaClamped) * 16.0F + top;
      Object rect = makeRect(renderer, alpha, this.width * 0.5F + this.x, this.height * 0.5F + rectTop);
      int panelColor = uiThemeColor(uiTheme(), 8);
      drawPanel(
         rect,
         this.x,
         rectTop,
         this.width,
         this.height,
         12.0F,
         12.0F,
         12.0F,
         12.0F,
         panelColor,
         uiThemeColor(uiTheme(), 12),
         1.0F,
         0.0F,
         0,
         0.0F,
         0.0F,
         alpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      float innerWidth = this.width - 32.0F;
      float headerTop = rectTop + 16.0F;
      float left = this.x + 16.0F;
      float halfWidth = innerWidth - 8.0F;
      this.panelTop = rectTop + this.height - 16.0F - 32.0F;
      halfWidth *= 0.5F;
      this.panelHalfWidth = halfWidth;
      float buttonLeft;
      if (this.mode == 0 && this.entries.isEmpty()) {
         this.twoColumn = false;
         buttonLeft = (innerWidth - halfWidth) * 0.5F + left;
      } else {
         this.twoColumn = true;
         buttonLeft = left;
      }

      this.buttonX = buttonLeft;
      float value = (1.0F - open) * alpha;
      this.panelRight = halfWidth + left + 8.0F;
      if (0.001F < value) {
         drawText(4, renderer, "SafeModeOverlay.header", left, headerTop, 16.0F, uiThemeColor(uiTheme(), 24), value);
         float titleTop = headerTop + 16.0F + 8.0F;
         String titleLabel = this.entries.isEmpty() ? "SafeModeOverlay.title" : "SafeModeOverlay.titleAlt";
         drawText(0, renderer, titleLabel, left, titleTop, 12.0F, uiThemeColor(uiTheme(), 16), value);
         float hintW = Math.round((this.width - 248.0F) * 0.5F);
         this.hintX = hintW + this.x;
         this.hintY = titleTop + 12.0F + 12.0F;
         this.renderHeader(renderer, mouseX, mouseY, value);
      }

      float bodyValue = open * alpha;
      if (0.001F < bodyValue) {
         String label;
         int labelColor;
         if (this.mode == 1) {
            label = "SafeModeOverlay.listAlt";
            labelColor = uiThemeColor(uiTheme(), 24);
         } else {
            label = "SafeModeOverlay.list";
            labelColor = uiThemeColor(uiTheme(), 40);
         }

         drawText(4, renderer, label, left, headerTop, 16.0F, labelColor, bodyValue);
         if (this.mode == 1) {
            String detail = "SafeModeOverlay.loadingA";
            int detailColor = uiThemeColor(uiTheme(), 24);
            drawTextClipped(0, renderer, detail, left, headerTop + 16.0F + 12.0F, 12.0F, innerWidth, detailColor, bodyValue);
         } else {
            String detail = this.statusText();
            int detailColor = uiThemeColor(uiTheme(), 16);
            drawTextClipped(0, renderer, detail, left, headerTop + 16.0F + 12.0F, 12.0F, innerWidth, detailColor, bodyValue);
         }
      }

      float panelTop = this.panelTop;
      boolean leftHovered;
      if (!(this.buttonX <= mouseX)
         || !(mouseX <= this.buttonX + this.panelHalfWidth)
         || !(panelTop <= mouseY)
         || !(mouseY <= panelTop + 32.0F)
         || activeOverlay != null && !Screen.allowHover) {
         leftHovered = false;
      } else {
         leftHovered = true;
      }

      boolean rightHovered;
      if (!this.twoColumn
         || !(this.panelRight <= mouseX)
         || !(mouseX <= this.panelRight + this.panelHalfWidth)
         || !(panelTop <= mouseY)
         || !(mouseY <= panelTop + 32.0F)
         || activeOverlay != null && !Screen.allowHover) {
         rightHovered = false;
      } else {
         rightHovered = true;
      }

      if (leftHovered || rightHovered) {
         Screen.hoveredWidget = 1;
      }

      float leftTarget = leftHovered ? 1.0F : 0.0F;
      if (this.hoverLeftAnim.target != leftTarget) {
         animate(this.hoverLeftAnim, leftTarget);
      }

      float rightTarget = rightHovered ? 1.0F : 0.0F;
      if (this.hoverRightAnim.target != rightTarget) {
         animate(this.hoverRightAnim, rightTarget);
      }

      int leftColor = uiLerpColor(uiThemeColor(uiTheme(), 0), uiThemeColor(uiTheme(), 8), 0.85F);
      leftColor = uiLerpColor(uiThemeColor(uiTheme(), 4), leftColor, this.hoverLeftAnim.current);
      drawPanel(
         rect,
         this.buttonX,
         panelTop,
         this.panelHalfWidth,
         32.0F,
         8.0F,
         8.0F,
         8.0F,
         8.0F,
         leftColor,
         uiThemeColor(uiTheme(), 12),
         1.0F,
         4.362076E8F,
         0,
         1.0F,
         1.0F,
         alpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      float rightHover = advance(this.hoverRightAnim, this.now());
      if (this.twoColumn) {
         int rightColor = uiLerpColor(uiThemeColor(uiTheme(), 20), uiThemeColor(uiTheme(), 24), rightHover * 0.15F);
         drawPanel(
            rect,
            this.panelRight,
            panelTop,
            this.panelHalfWidth,
            32.0F,
            8.0F,
            8.0F,
            8.0F,
            8.0F,
            rightColor,
            0,
            0.0F,
            4.362076E8F,
            0,
            1.0F,
            1.0F,
            alpha,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0
         );
      }

      String secondaryLabel;
      String primaryLabel;
      if (0.5F < open) {
         if (this.mode == 1) {
            primaryLabel = "SafeModeOverlay.listAlt";
            secondaryLabel = "SafeModeOverlay.detailAlt";
         } else {
            primaryLabel = "SafeModeOverlay.list";
            secondaryLabel = "SafeModeOverlay.detail";
         }
      } else {
         primaryLabel = "SafeModeOverlay.empty";
         secondaryLabel = "SafeModeOverlay.empty";
      }

      float labelTop = panelTop + 9.0F;
      float primaryWidth = measureText(0, primaryLabel, 14.0F);
      drawText(2, renderer, primaryLabel, (this.panelHalfWidth - primaryWidth) * 0.5F + this.buttonX, labelTop, 14.0F, uiThemeColor(uiTheme(), 24), alpha);
      if (this.twoColumn) {
         float secondaryWidth = measureText(0, secondaryLabel, 14.0F);
         drawText(
            2, renderer, secondaryLabel, (this.panelHalfWidth - secondaryWidth) * 0.5F + this.panelRight, labelTop, 14.0F, uiThemeColor(uiTheme(), 24), alpha
         );
      }
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         float panelTop = this.panelTop;
         if (!(this.buttonX <= mx) || !(mx <= this.buttonX + this.panelHalfWidth) || !(panelTop <= my) || !(my <= panelTop + 32.0F)) {
            if (this.twoColumn && !(mx < this.panelRight) && !(this.panelRight + this.panelHalfWidth < mx) && !(my < panelTop) && !(panelTop + 32.0F < my)) {
               if (this.mode == 0) {
                  this.openSelected();
               } else {
                  if (this.mode == 1) {
                     this.close();
                     return true;
                  }

                  if (this.mode == 2) {
                     this.closeAndRefresh();
                     return true;
                  }
               }
            } else if (this.mode != 0 || mx < this.hintX || this.hintX + 248.0F < mx || my < this.hintY || this.hintY + 167.0F < my) {
               return false;
            }

            return true;
         } else if (this.mode == 2) {
            this.closeAndRefresh();
            return true;
         } else {
            this.close();
            return true;
         }
      }
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      if (keyCode == 13) {
         if (this.mode == 1) {
            this.close();
            return true;
         }

         if (this.mode == 0 && !this.entries.isEmpty()) {
            this.openSelected();
            return true;
         }
      }

      return false;
   }

   private void requestSnapshot() {
      this.snapshotPending = true;
      this.requestTime = this.now();
      submitSnapshotRequest();
   }

   private void openSelected() {
      if (!this.entries.isEmpty()) {
         Object id = firstEntryId();
         if (lookupSnapshotEntry(id) != null) {
            applySnapshotDetail(id);
         } else {
            applySnapshotDetail("SafeModeOverlay.defaultDetail");
         }

         this.setMode(2);
      }
   }

   private void setMode(int value) {
      this.mode = value;
      String text;
      if (value == 1) {
         text = "SafeModeOverlay.loadingB";
      } else {
         text = this.statusText();
      }

      int lines = measureLines(0, text, 12.0F, 328.0F);
      this.heightSmooth = lines * 14.4F + 44.0F + 16.0F + 32.0F + 16.0F;
      if (this.openAnim.target != 1.0F) {
         animate(this.openAnim, 1.0F);
      }
   }

   private void closeAndRefresh() {
      this.mode = 0;
      if (this.openAnim.target != 0.0F) {
         animate(this.openAnim, 0.0F);
      }

      Object snapshot = collectWindows();
      applySnapshot(snapshot);
      if (!this.snapshotPending) {
         this.requestSnapshot();
      }
   }

   private void renderHeader(Object renderer, float mouseX, float mouseY, float alpha) {
      boolean populated = !this.entries.isEmpty();
      float hoverTarget;
      if (populated && this.hintX <= mouseX && mouseX <= this.hintX + 248.0F && this.hintY <= mouseY && mouseY <= this.hintY + 167.0F) {
         hoverTarget = 1.0F;
      } else {
         hoverTarget = 0.0F;
      }

      if (this.loadAnim.target != hoverTarget) {
         animate(this.loadAnim, hoverTarget);
      }

      float hover = advance(this.loadAnim, this.now());
      int fill = uiLerpColor(uiThemeColor(uiTheme(), 4), uiThemeColor(uiTheme(), 8), hover);
      float borderMix;
      if (populated) {
         borderMix = hover * 0.5F + 0.5F;
      } else {
         borderMix = 0.0F;
      }

      int border = uiLerpColor(uiThemeColor(uiTheme(), 12), uiThemeColor(uiTheme(), 20), borderMix);
      drawPanel(
         renderer,
         this.hintX,
         this.hintY,
         248.0F,
         167.0F,
         8.0F,
         8.0F,
         8.0F,
         8.0F,
         fill,
         border,
         1.0F,
         4.362076E8F,
         0,
         2.0F,
         8.0F,
         alpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      if (populated) {
         if (this.textureB == 0) {
            float iconX = this.hintX + 8.0F;
            float iconY = this.hintY + 6.0F;
            drawIcon(renderer, 51, iconX, iconY, 16.0F, 16.0F, uiThemeColor(uiTheme(), 16), alpha);
         } else {
            drawSurface(renderer, this.textureB, this.hintX + 8.0F, this.hintY + 6.0F, 16.0F, 16.0F, 0.0F, -1, alpha);
         }

         float labelLeft = this.hintX + 8.0F;
         float labelTop = this.hintY + 8.0F;
         drawText(2, renderer, this.labelPrimary(), labelLeft + 16.0F + 2.0F, labelTop, 12.0F, uiThemeColor(uiTheme(), 24), alpha);
         float detailWidth = measureText(0, this.labelDetail(), 12.0F);
         drawText(0, renderer, this.labelDetail(), this.hintX + 248.0F - 8.0F - detailWidth, labelTop, 12.0F, uiThemeColor(uiTheme(), 16), alpha);
         float imageLeft = this.hintX + 8.0F;
         float imageTop = this.hintY + 28.0F;
         drawBox(
            renderer, imageLeft, imageTop, 236.0F, 133.0F, 4.0F, 4.0F, 4.0F, 4.0F, uiThemeColor(uiTheme(), 12), 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, alpha, 0
         );
         if (this.textureA == 0) {
            float titleWidth = measureText(0, this.labelPrimary(), 14.0F);
            drawText(
               0,
               renderer,
               this.labelPrimary(),
               (236.0F / this.textureWidth - titleWidth) * 0.5F + imageLeft,
               imageTop + 60.5F,
               14.0F,
               uiThemeColor(uiTheme(), 24),
               alpha
            );
         } else {
            float scaleX = 236.0F / this.textureWidth;
            float scaleY = 133.0F / this.textureHeight;
            if (scaleY <= scaleX) {
               scaleX = scaleY;
            }

            float drawWidth = Math.round(this.textureWidth * scaleX);
            float drawHeight = Math.round(this.textureHeight * scaleX);
            float offsetX = Math.round((236.0F - drawWidth) * 0.5F);
            float offsetY = Math.round((133.0F - drawHeight) * 0.5F);
            drawSurface(renderer, this.textureA, offsetX + imageLeft, offsetY + imageTop, drawWidth, drawHeight, 4.0F, -1, alpha);
         }
      } else {
         float iconX = this.hintX + 124.0F;
         float iconY = this.hintY + 83.5F;
         drawIcon(renderer, 51, iconX - 10.0F, iconY - 20.0F - 4.0F, 20.0F, 20.0F, uiThemeColor(uiTheme(), 16), alpha * 0.5F);
         float titleWidth = measureText(0, "SafeModeOverlay.empty", 12.0F);
         drawText(0, renderer, "SafeModeOverlay.empty", iconX - titleWidth * 0.5F, iconY + 8.0F, 12.0F, uiThemeColor(uiTheme(), 16), alpha);
      }
   }

   private void centerOnScreen() {
      initGuiMetrics();
      float scale = guiScale();
      float width = screenWidth() / scale - this.width;
      if (width <= 0.0F) {
         width = 0.0F;
      }

      this.x = Math.round(width * 0.5F);
      float height = screenHeight() / scale - this.height;
      if (height <= 0.0F) {
         height = 0.0F;
      }

      this.y = Math.round(height * 0.5F);
   }

   private String labelPrimary() {
      return labelAt(288);
   }

   private String labelDetail() {
      return labelAt(320);
   }

   private String statusText() {
      return labelAt(352);
   }

   private static String labelAt(int offset) {
      return "";
   }

   private static void clearLabel(int offset) {
   }

   private static void releaseEntries() {
   }

   private static void releaseImageList(List<Object> images) {
   }

   private static void releaseTextures() {
   }

   private static void releaseOneTexture(int id) {
   }

   private static void releaseDismissHandler(Object handler) {
   }

   private static void submitSnapshotRequest() {
   }

   private static Object collectWindows() {
      return null;
   }

   private static Object firstEntryId() {
      return null;
   }

   private static Object lookupSnapshotEntry(Object id) {
      return null;
   }

   private static void applySnapshotDetail(Object value) {
   }

   private static void applySnapshot(Object snapshot) {
   }

   private static void refresh() {
   }

   private static void releaseSnapshotState() {
   }

   private static void initGuiMetrics() {
   }

   private static float guiScale() {
      return 1.0F;
   }

   private static int screenWidth() {
      return 0;
   }

   private static int screenHeight() {
      return 0;
   }

   private static Object makeRect(Object renderer, float alpha, float right, float bottom) {
      return new float[8];
   }

   private static void drawPanel(
      Object rect,
      float x,
      float y,
      float w,
      float h,
      float r0,
      float r1,
      float r2,
      float r3,
      int fill,
      int border,
      float borderWidth,
      float shadowColor,
      int shadowFlag,
      float shadowAlpha,
      float scale,
      float alpha,
      Object... tail
   ) {
   }

   private static void drawBox(
      Object renderer,
      float x,
      float y,
      float w,
      float h,
      float r0,
      float r1,
      float r2,
      float r3,
      int color,
      float a1,
      float a2,
      float a3,
      float a4,
      float a5,
      float a6,
      float alpha,
      Object... tail
   ) {
   }

   private static void drawText(int style, Object renderer, String text, float x, float y, float size, int color, float alpha) {
   }

   private static void drawTextClipped(int style, Object renderer, String text, float x, float y, float size, float maxWidth, int color, float alpha) {
   }

   private static void drawIcon(Object renderer, int icon, float x, float y, float w, float h, int color, float alpha) {
   }

   private static void drawSurface(Object renderer, int texture, float x, float y, float w, float h, float inset, int mode, float alpha) {
   }

   private static float measureText(int style, String text, float size) {
      return 0.0F;
   }

   private static int measureLines(int style, String text, float size, float maxWidth) {
      return 0;
   }

   public static int uiThemeColor(Object theme, int offset) {
      return 0;
   }

   public static Object uiTheme() {
      return null;
   }
}

