package client.gui;

import client.Setting;

public class AlignmentWidget extends AbstractTrackChoiceWidget {
   public static final float VALUE_PAD = 12.0F;
   public static final float VALUE_MIN = 8.0F;
   public static final float TRACK_TOP_OFFSET = 11.5F;
   public static final float ICON_WIDTH = 14.0F;
   public static final float ICON_HEIGHT = 9.0F;
   public static final String LABEL_LEFT = "Лево";
   public static final String LABEL_CENTER = "Центр";
   public static final String LABEL_RIGHT = "Право";
   public static final int TRACK_COUNT = 3;
   public static final int ANIM_FALLBACK_INDEX = 1;

   public AlignmentWidget() {
   }

   public AlignmentWidget(Setting setting) {
      super(setting);
      this.trackSetting = setting;
      float index = this.alignmentIndex();
      this.animFrom = index;
      this.animCurrent = index;
      this.animTarget = index;
      this.animRunning = false;
   }

   @Override
   protected int getTypeId() {
      return 66;
   }

   @Override
   protected float getValuePad() {
      return 12.0F;
   }

   @Override
   protected float getValueMin() {
      return 8.0F;
   }

   @Override
   protected int getTrackCount() {
      return 3;
   }

   @Override
   protected String getTrackLabel() {
      int value = this.alignmentValue();
      if (value == 0) {
         return "Лево";
      } else if (value == 1) {
         return "Центр";
      } else {
         return value == 2 ? "Право" : "";
      }
   }

   protected int alignmentValue() {
      Setting s = this.trackSetting;
      return s == null ? 0 : alignmentIndexOf(s.getMode());
   }

   protected float alignmentIndex() {
      int value = this.alignmentValue();

      for (int i = 0; i < ALIGNMENT_VALUES.length; i++) {
         if (ALIGNMENT_VALUES[i] == value) {
            return i;
         }
      }

      return 1.0F;
   }

   protected static int alignmentIndexOf(String mode) {
      if (mode == null) {
         return 0;
      } else if (mode.equals("Центр")) {
         return 1;
      } else {
         return mode.equals("Право") ? 2 : 0;
      }
   }

   public static String alignmentMode(int value) {
      for (int i = 0; i < ALIGNMENT_VALUES.length; i++) {
         if (ALIGNMENT_VALUES[i] == value) {
            if (value == 0) {
               return "Лево";
            }

            if (value == 1) {
               return "Центр";
            }

            if (value == 2) {
               return "Право";
            }
         }
      }

      return "";
   }

   @Override
   protected float getTrackAnimTarget() {
      int value = this.alignmentValue();

      for (int i = 0; i < ALIGNMENT_VALUES.length; i++) {
         if (ALIGNMENT_VALUES[i] == value) {
            return i;
         }
      }

      return 1.0F;
   }

   @Override
   protected void setTrackIndex(int index) {
      if (index >= 0 && index < ALIGNMENT_VALUES.length) {
         Setting s = this.trackSetting;
         if (s != null) {
            int target = ALIGNMENT_VALUES[index];
            if (alignmentIndexOf(s.getMode()) != target) {
               s.setMode(alignmentMode(target));
               this.notifyChanged();
            }
         }
      }
   }

   protected void notifyChanged() {
   }

   @Override
   protected void renderTrack(Object mat, float top, float alpha) {
      float ty = top + 11.5F;
      int value = this.alignmentValue();

      for (int i = 0; i < 3; i++) {
         int color;
         if (ALIGNMENT_VALUES[i] == value) {
            color = rendererSecondaryColor();
         } else {
            color = rendererColor();
         }

         float cellsA = this.cellWidth();
         float baseX = this.x;
         float cellsB = this.cellWidth();
         int kind = ALIGNMENT_VALUES[i];
         int icon;
         if (kind == 0) {
            icon = 42;
         } else if (kind == 1) {
            icon = 43;
         } else if (kind == 2) {
            icon = 44;
         } else {
            icon = 42;
         }

         drawText(mat, icon, cellsB * 0.5F + baseX + 3.0F + (cellsA + 2.0F) * i - 7.0F, ty, 14.0F, 9.0F, color, alpha);
      }
   }
}

