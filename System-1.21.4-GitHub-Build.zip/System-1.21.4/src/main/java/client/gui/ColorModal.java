package client.gui;

import java.util.ArrayList;
import java.util.List;

public class ColorModal extends AbstractOverlay {
   public static final int SETTING_VALUE = 232;
   public static final int SETTING_ALPHA_FLAG = 240;
   public static final int SETTING_CHANGE_CALLBACK = 224;
   public static final int GRADIENT_STOPS_BEGIN = 488;
   public static final int GRADIENT_STOPS_END = 496;
   public static final int GRADIENT_ENABLED = 480;
   public static final int GRADIENT_ALPHA_FLAG = 464;
   public static final int STOP_STRIDE = 12;
   public static final float WIDTH = 292.0F;
   public static final float HEIGHT = 383.0F;
   public static final float STOP_FIELD_WIDTH = 267.0F;
   public static final float FIELD_DURATION = 0.15F;
   public static final float COLOR_DURATION = 0.22F;
   public static final float STOP_ANIM_DURATION = 0.18F;
   public static final float STOP_ANIM_START = 1.0F;
   public static final float ACTION_FIELD_STEP = 12.0F;
   public static final float ROW_SPACING_VALUE = 4.0F;
   public static final float ALPHA_MAX = 255.0F;
   public static final float PAD = 16.0F;
   public static final float GAP = 8.0F;
   public static final float INNER = 12.0F;
   public static final float HALF = 0.5F;
   public static final float SQUARE_SIZE = 269.0F;
   public static final float ALPHA_BAR_WIDTH = 269.0F;
   public static final float ALPHA_BAR_HEIGHT = 140.0F;
   public static final float ALPHA_BAR_SLOT = 148.0F;
   public static final float BAR_SPAN = 240.0F;
   public static final float ACTION_BUTTON_SIZE = 18.0F;
   public static final float TEXT_FIELD_WIDTH = 60.0F;
   public static final float BODY_GAP = 10.0F;
   public static final float ERROR_GAP = 4.0F;
   public static final float BAR_THICKNESS = 8.0F;
   public static final float STRIP_WIDTH = 60.0F;
   public static final float STRIP_HEIGHT = 26.0F;
   public static final float STOP_ROW_STEP = 48.0F;
   public static final float STOP_ROW_HEIGHT = 28.0F;
   public static final float LIST_ROW_STEP = 137.0F;
   public static final float LIST_ROW_WIDTH = 150.0F;
   public static final float PRESET_STEP = 46.0F;
   public static final float PRESET_SIZE = 32.0F;
   public static final float PRESET_ROW_OFFSET = 6.0F;
   public static final float PRESET_ROW_HEIGHT = 28.0F;
   public static final float PRESET_ROW_WIDTH = 150.0F;
   public static final float PRESET_TEXT_OFFSET = 240.0F;
   public static final float PRESET_TEXT_ADVANCE = 240.0F;
   public static final float LIST_TEXT_OFFSET = 240.0F;
   public static final float HEADER_OFFSET = 293.0F;
   public static final float HEADER_WIDTH = 150.0F;
   public static final float HEADER_HEIGHT = 155.5F;
   public static final float STOP_TEXT_SIZE = 12.0F;
   public static final float HOVER_EPSILON = 0.001F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float SMOOTH_EPSILON = 0.01F;
   public static final float SMOOTH_FACTOR = -6.931472F;
   public static final float SMOOTH_DIVISOR = 0.05F;
   public static final float HEIGHT_SMOOTH_DIVISOR = 0.03F;
   public static final float DISABLED_HEIGHT = 38.0F;
   public static final float ROUND_TRIP = 2.0F;
   public static final String DEFAULT_STOP_NAME = "Выбор цвета";
   public static final int PALETTE_SIZE = 7;
   protected ColorModal.ColorSetting color;
   protected ColorModal.GradientSetting gradient;
   protected String stopName = "Выбор цвета";
   protected Object setting;
   protected int packedColor;
   protected boolean alphaEnabled;
   protected int selectedStop;
   protected ColorModal child;
   protected final AbstractOverlay.Animator gradientReadyAnim = new AbstractOverlay.Animator();
   protected final List<ColorModal.Row> rows = new ArrayList<>();
   protected float rowSpacing = 4.0F;
   protected int presetPicked = -1;
   protected boolean hoverLock;
   protected int dragStop;
   protected final AbstractOverlay.Animator heightAnim = new AbstractOverlay.Animator();
   protected float lastHeight;
   protected boolean heightReady;
   protected int gradientReady;
   protected final AbstractOverlay.Animator visibleAnim = new AbstractOverlay.Animator();
   protected float hue;
   protected float saturation;
   protected float value;
   protected float alphaValue = 1.0F;
   protected boolean squareHover;
   protected boolean hueHover;
   protected boolean alphaHover;
   protected float dragOffset;
   protected float smoothHue;
   protected float smoothSaturation;
   protected float smoothValue;
   protected float smoothAlpha;
   protected boolean smoothReady;
   protected int presetIndex = -1;
   protected final AbstractOverlay.Animator previewFieldAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator stopPickAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.ColorAnim colorAnim = new AbstractOverlay.ColorAnim();
   protected boolean picking;
   protected int pickedRgb = -16777216;
   protected float screenPickX;
   protected boolean screenPickReady;
   protected int lastHoverState;
   protected boolean squareActive;
   protected final AbstractOverlay.Animator modeAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator stopAnim = new AbstractOverlay.Animator();
   protected int stopAnimDirection = 1;
   protected int actionIndex = -1;
   protected int tab = 0;
   protected String actionField = "";

   public ColorModal(ColorModal.ColorSetting colorSetting, ColorModal.GradientSetting gradientSetting) {
      this.color = colorSetting;
      this.gradient = gradientSetting;
      this.stopName = "Выбор цвета";
      this.selectedStop = 0;
      this.child = null;
      resetAnimator(this.gradientReadyAnim, gradientSetting != null && gradientSetting.enabled ? 1.0F : 0.0F, 0.15F, 2);
      this.rows.clear();
      this.rowSpacing = 4.0F;
      this.presetPicked = -1;
      this.hoverLock = false;
      this.dragStop = 0;
      resetAnimator(this.heightAnim, 0.0F, 0.15F, 0);
      this.lastHeight = 0.0F;
      this.heightReady = false;
      this.gradientReady = 0;
      resetAnimator(this.visibleAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.previewFieldAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.stopPickAnim, 0.0F, 0.15F, 2);
      resetColorAnimator(this.colorAnim, colorSetting == null ? 0 : colorSetting.value | 0xFF000000, 0.22F);
      this.picking = false;
      this.pickedRgb = -16777216;
      this.screenPickX = 0.0F;
      this.screenPickReady = false;
      this.lastHoverState = 0;
      this.squareActive = false;
      resetAnimator(this.modeAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.stopAnim, 1.0F, 0.18F, 2);
      this.stopAnimDirection = 1;
      this.actionIndex = -1;
      this.tab = 0;
      this.actionField = "";
      this.width = 292.0F;
      this.height = 383.0F;
      this.setupRows();
      this.syncRows();
   }

   protected void setupRows() {
   }

   public void closeChild() {
      this.child = null;
      this.selectedStop = 0;
   }

   @Override
   public void syncRows() {
      if (this.color != null) {
         int packed = this.color.value;
         ColorModal.Hsv hsv = unpackHsv(packed);
         this.hue = hsv.hue;
         this.saturation = hsv.saturation;
         this.value = hsv.value;
         this.alphaValue = (packed >>> 24 & 0xFF) / 255.0F;
      }
   }

   public void applyColor() {
      if (this.color != null) {
         int packed = packRgb(this.hue, this.saturation, this.value);
         int alpha = (int)(clamp01(this.alphaValue) * 255.0F) & 0xFF;
         int out = packed & 16777215 | alpha << 24;
         if (this.color.value != out) {
            this.color.value = out;
            this.color.notifyChanged();
         }
      }
   }

   public void openStopModal(int stopIndex) {
      if (this.gradient != null) {
         int found = -1;

         for (int i = 0; i < this.gradient.stops.size(); i++) {
            if (this.gradient.stops.get(i).position == stopIndex) {
               found = i;
               break;
            }
         }

         if (found >= 0) {
            this.dragStop = 0;
            int raw = this.gradient.stops.get(found).color;
            int packed = raw | 0xFF000000;
            if (this.alphaEnabled) {
               packed = raw;
            }

            if (this.packedColor != packed) {
               this.packedColor = packed;
               if (this.setting != null) {
                  notifySettingChanged(this.setting);
               }
            }

            this.selectedStop = stopIndex;
            if (this.child == null) {
               this.child = new ColorModal(null, this.gradient);
               this.child.detached = true;
            }

            ColorModal target = this.child;
            target.stopName = stopLabel(found + 1);
            target.applyStop(this.gradient.stops.get(found));
            if (target.alphaCurrent() <= 0.001F && target.alphaTarget <= 0.001F) {
               target.gradientReadyStep();
            } else {
               target.animateAlphaTo(1.0F);
            }
         }
      }
   }

   protected void applyStop(ColorModal.ColorStop stop) {
   }

   public void gradientReadyStep() {
      this.animateAlphaTo(1.0F);
   }

   private static void notifySettingChanged(Object target) {
   }

   private static String stopLabel(int index) {
      return String.valueOf(index);
   }

   public static ColorModal.Hsv unpackHsv(int packed) {
      return new ColorModal.Hsv(0.0F, 0.0F, 0.0F);
   }

   public static int packRgb(float hue, float saturation, float value) {
      return 0;
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      this.smoothHsv();
      int ready = this.gradient != null && this.gradient.enabled ? 1 : 0;
      if (ready != this.gradientReady) {
         this.gradientReady = ready;
         this.visibleAnim.from = 0.0F;
         this.visibleAnim.current = 0.0F;
         this.visibleAnim.target = 0.0F;
         this.visibleAnim.running = false;
         long time = this.now();
         float current;
         if (this.visibleAnim.running && !(this.visibleAnim.duration <= 0.0F)) {
            float t = (float)((time - this.visibleAnim.start) / 1.0E9) / this.visibleAnim.duration;
            if (t <= 0.0F) {
               current = this.visibleAnim.from;
            } else if (t >= 1.0F) {
               this.visibleAnim.running = false;
               current = this.visibleAnim.target;
            } else {
               current = applyEasing(this.visibleAnim.easing, t) * (this.visibleAnim.target - this.visibleAnim.from) + this.visibleAnim.from;
            }
         } else {
            current = this.visibleAnim.target;
         }

         this.visibleAnim.current = current;
         this.visibleAnim.from = current;
         this.visibleAnim.target = 1.0F;
         this.visibleAnim.start = time;
         this.visibleAnim.running = true;
         if (ready != 1) {
            rowHeightReset(this.rows);
            this.hoverLock = false;
            this.dragStop = 0;
         }
      }

      long timex = this.now();
      float visible = advance(this.visibleAnim, timex);
      float weight = clamp01(parentAlpha);
      float top = (1.0F - weight) * 16.0F + this.y;
      ColorModal.Rect rect = new ColorModal.Rect();
      this.layout(target, rect, top);
      if (ready == 1) {
         syncRowRows(this);
         if (this.selectedStop != 0) {
            boolean exists = false;

            for (int i = 0; i < this.gradient.stops.size(); i++) {
               if (this.gradient.stops.get(i).position == this.selectedStop) {
                  exists = true;
                  break;
               }
            }

            if (!exists) {
               this.selectedStop = 0;
               if (this.child != null && (0.001F < this.child.alphaCurrent() || 0.001F < this.child.alphaTarget)) {
                  this.child.close();
               }
            }
         }
      }

      float targetHeight = this.height(this, rect);
      float coeff = frameDelta();
      if (this.heightReady) {
         float diff = targetHeight - this.lastHeight;
         if (Math.abs(diff) >= 0.01F) {
            coeff = (float)Math.exp(coeff * -6.931472F / 0.03F);
            targetHeight -= coeff * diff;
         }
      }

      this.lastHeight = targetHeight;
      this.heightReady = true;
      this.height = targetHeight;
      this.renderContent(target, rect, top, targetHeight, visible, parentAlpha, rx, ry, ready);
      if (this.child != null && (0.001F < this.child.alphaCurrent() || 0.001F < this.child.alphaTarget)) {
         this.child.renderOverlay(target, rx, ry, parentAlpha);
      }
   }

   protected void renderContent(
      Object target, ColorModal.Rect rect, float top, float modalHeight, float visible, float parentAlpha, float rx, float ry, int ready
   ) {
      if (ready == 1) {
         this.renderGradientMode(target, rect, top, modalHeight, visible, parentAlpha, rx, ry);
      } else {
         this.renderSolidMode(target, rect, top, modalHeight, visible, parentAlpha, rx, ry);
      }

      updateCursor(this);
   }

   protected void renderGradientMode(Object target, ColorModal.Rect rect, float top, float modalHeight, float visible, float parentAlpha, float rx, float ry) {
   }

   protected void renderSolidMode(Object target, ColorModal.Rect rect, float top, float modalHeight, float visible, float parentAlpha, float rx, float ry) {
   }

   protected float height(ColorModal modal, ColorModal.Rect rect) {
      if (this.gradient == null) {
         return 383.0F;
      } else if (!this.gradient.enabled) {
         return 421.0F;
      } else {
         float extra = 0.0F;
         return this.selectedStop == 0 ? rect.height + extra + 8.0F : rect.height + extra + 8.0F;
      }
   }

   protected void smoothHsv() {
      float step = (float)Math.exp(960.90607F);
      if (!this.smoothReady) {
         this.smoothAlpha = this.alphaValue;
         this.smoothValue = this.value;
         this.smoothSaturation = this.saturation;
         this.smoothHue = this.hue;
         this.smoothReady = true;
      } else {
         float delta = this.saturation - this.smoothSaturation;
         if (Math.abs(delta) >= 0.01F) {
            this.smoothSaturation = this.saturation - step * delta;
         }

         delta = this.value - this.smoothValue;
         if (Math.abs(delta) >= 0.01F) {
            this.smoothValue = this.value - step * delta;
         }

         delta = this.hue - this.smoothHue;
         if (Math.abs(delta) >= 0.01F) {
            this.smoothHue = this.hue - step * delta;
         }

         delta = this.alphaValue - this.smoothAlpha;
         if (Math.abs(delta) >= 0.01F) {
            this.smoothAlpha = this.alphaValue - step * delta;
         }
      }
   }

   public void layout(Object target, ColorModal.Rect out, float top) {
      out.clear();
      out.set(0.0F, top + 267.0F, 1.0F);
      out.height = this.rectHeight();
   }

   protected float rectHeight() {
      return 0.0F;
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      ColorModal node = this;

      do {
         ColorModal current = node;
         node = node.child;
         if (node == null) {
            return this.mouseBody(current, mx, my, button);
         }

         boolean faded = node.alphaCurrent() <= 0.001F && node.alphaTarget <= 0.001F;
         if (faded) {
            return this.mouseBody(current, mx, my, button);
         }
      } while (!(mx < node.x) && !(node.x + node.width < mx) && !(my < node.y) && !(node.y + node.height < my));

      this.selectedStop = 0;
      if (0.001F < node.alphaCurrent() || 0.001F < node.alphaTarget) {
         node.close();
      }

      return true;
   }

   protected boolean mouseBody(ColorModal modal, double mx, double my, int button) {
      if (modal.picking) {
         if (button != 1) {
            if (button != 0) {
               return true;
            } else {
               int rgb = modal.pickedRgb;
               ColorModal.ColorSetting cs = modal.color;
               int alpha;
               if (cs != null && cs.alphaFlag) {
                  alpha = Math.round(modal.alphaValue * 255.0F);
               } else {
                  alpha = 255;
               }

               int packed = alpha << 24 | rgb & 16777215;
               int out = packed | 0xFF000000;
               if (cs != null && cs.alphaFlag) {
                  out = packed;
               }

               if (cs != null && cs.value != out) {
                  cs.value = out;
                  cs.notifyChanged();
               }

               modal.syncRows();
               int index = modal.presetIndex;
               if (index >= 0 && index < 7 && modal.color != null) {
                  setPaletteEntry(index, modal.color.value);
               }

               return true;
            }
         } else {
            modal.picking = false;
            return true;
         }
      } else if (!modal.squareActive
         || button != 0
         || modal.hitsSquare(mx, my)
         || (modal.gradient == null || !modal.gradient.enabled) && !modal.outsideBody(mx, my)) {
         return super.mouseClicked(mx, my, button);
      } else {
         modal.squareActive = false;
         return true;
      }
   }

   protected boolean hitsSquare(double mx, double my) {
      return false;
   }

   protected boolean outsideBody(double mx, double my) {
      ColorModal.Rect rect = new ColorModal.Rect();
      this.layout(null, rect, this.y);
      return mx < rect.x || rect.x + 60.0F < mx || my < rect.y || rect.y + 26.0F < my;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      ColorModal current = this.topmostVisible();
      if (current.dragStop != 0) {
         current.dragStop = 0;
         return true;
      } else if (!current.squareHover && !current.alphaHover && !current.hueHover) {
         return false;
      } else {
         current.hueHover = false;
         current.alphaHover = false;
         current.squareHover = false;
         return true;
      }
   }

   public boolean mouseDragged(double mx, double my) {
      ColorModal current = this.topmostVisible();
      if (current.dragStop == 0) {
         if (current.squareHover) {
            dragSquare(current, mx, my);
            return true;
         } else if (current.hueHover) {
            dragHue(current, mx);
            return true;
         } else if (current.alphaHover) {
            dragAlpha(current, mx);
            return true;
         } else {
            return false;
         }
      } else if (current.gradient == null) {
         return true;
      } else {
         for (int i = 0; i < current.gradient.stops.size(); i++) {
            ColorModal.ColorStop stop = current.gradient.stops.get(i);
            if (stop.position == current.dragStop) {
               if (i >= 0) {
                  ColorModal.Rect rect = new ColorModal.Rect();
                  this.layout(null, rect, current.y);
                  float delta = clamp01((float)((mx - current.screenPickX - current.dragOffset) / 269.0));
                  moveStop(current.gradient, i, delta);
                  return true;
               }
               break;
            }
         }

         current.dragStop = 0;
         return true;
      }
   }

   protected static void dragSquare(ColorModal modal, double mx, double my) {
      ColorModal.Rect rect = new ColorModal.Rect();
      modal.layout(null, rect, modal.y);
      float xr = clamp01((float)((mx - rect.slots[2]) / 269.0));
      float yr = clamp01((float)((my - rect.slots[3]) / 140.0));
      modal.saturation = xr;
      modal.value = 1.0F - yr;
      modal.applyColor();
   }

   protected static void dragHue(ColorModal modal, double mx) {
      ColorModal.Rect rect = new ColorModal.Rect();
      modal.layout(null, rect, modal.y);
      modal.hue = clamp01((float)((mx - rect.slots[4]) / 240.0));
      modal.applyColor();
   }

   protected static void dragAlpha(ColorModal modal, double mx) {
      ColorModal.Rect rect = new ColorModal.Rect();
      modal.layout(null, rect, modal.y);
      modal.alphaValue = clamp01((float)((mx - rect.slots[4]) / 240.0));
      modal.applyColor();
   }

   protected static void moveStop(ColorModal.GradientSetting gradient, int index, float delta) {
      gradient.setStopPosition(index, delta);
   }

   protected ColorModal topmostVisible() {
      ColorModal node = this;

      ColorModal current;
      do {
         current = node;
         node = node.child;
      } while (node != null && (0.001F < node.alphaCurrent() || 0.001F < node.alphaTarget));

      return current;
   }

   public static void setPaletteEntry(int index, int color) {
   }

   public static int paletteEntry(int index) {
      return 0;
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      if (this.child != null && this.child.keyPressed(keyCode, modifiers)) {
         return true;
      } else if (this.hoverLock && keyCode == 27) {
         this.hoverLock = false;
         return true;
      } else if (this.actionFieldActive()) {
         return this.actionFieldKey(keyCode, modifiers);
      } else if (this.closeOnEscape && keyCode == 27) {
         this.close();
         return true;
      } else {
         return super.onKeyPressed(keyCode, modifiers);
      }
   }

   protected boolean actionFieldActive() {
      return false;
   }

   protected boolean actionFieldKey(int keyCode, int modifiers) {
      return false;
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      ColorModal current = this.topmostVisible();
      if (delta != 0.0) {
         current.close();
         return true;
      } else {
         ColorModal.Rect rect = new ColorModal.Rect();
         this.layout(null, rect, current.y);
         float actionRight = current.x + 293.0F - 16.0F - 10.0F - 4.0F;
         if (inRect(mx, my, actionRight, rect.slots[1], 18.0F, 18.0F)) {
            current.picking = true;
            return true;
         } else if (current.squareActive && current.presetIndexHit(mx, my, rect)) {
            current.squareActive = false;
            return true;
         } else {
            float stripX = rect.slots[10];
            float stripY = rect.slots[11];
            if (inRect(mx, my, stripX, stripY, 60.0F, 26.0F)) {
               current.picking = false;
               return true;
            } else {
               float squareX = rect.slots[2];
               float squareY = rect.slots[3];
               if (inRect(mx, my, squareX, squareY, 269.0F, 269.0F)) {
                  current.squareHover = true;
                  current.hueHover = false;
                  current.alphaHover = false;
                  dragSquare(current, mx, my);
                  return true;
               } else {
                  float barX = rect.slots[4];
                  float hueY = squareY + 269.0F + 8.0F;
                  if (inRect(mx, my, barX, hueY, 240.0F, 8.0F)) {
                     current.squareHover = false;
                     current.hueHover = true;
                     current.alphaHover = false;
                     dragHue(current, mx);
                     return true;
                  } else {
                     float alphaY = hueY + 8.0F + 8.0F + 8.0F;
                     if (inRect(mx, my, barX, alphaY, 240.0F, 8.0F)) {
                        current.squareHover = false;
                        current.hueHover = false;
                        current.alphaHover = true;
                        dragAlpha(current, mx);
                        return true;
                     } else {
                        if (current.squareHover && !inRect(mx, my, squareX, squareY, 269.0F, 269.0F)) {
                           current.squareHover = false;
                           current.dragStop = 0;
                        }

                        if (current.actionIndex >= 0) {
                           current.cancelEdit();
                        }

                        float fieldLeft = current.x + 16.0F - 8.0F;
                        float fieldTop = (rect.slots[8] - 16.0F) * 0.5F + rect.slots[9] - 8.0F;
                        if (!inRect(mx, my, fieldLeft, fieldTop, 12.0F, 12.0F)) {
                           if (!inRect(mx, my, rect.slots[5], rect.slots[5], 60.0F, 12.0F)) {
                              if (!inRect(mx, my, rect.slots[5], rect.slots[5] - 8.0F, 60.0F, 12.0F)) {
                                 if (!inRect(mx, my, rect.slots[5], rect.slots[5] - 8.0F, 60.0F, 12.0F)) {
                                    return true;
                                 } else {
                                    current.alphaHover = true;
                                    dragAlpha(current, mx);
                                    return true;
                                 }
                              } else {
                                 current.hueHover = true;
                                 dragHue(current, mx);
                                 return true;
                              }
                           } else {
                              current.squareHover = true;
                              dragSquare(current, mx, my);
                              return true;
                           }
                        } else {
                           current.picking = true;
                           return true;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   protected boolean presetIndexHit(double mx, double my, ColorModal.Rect rect) {
      return false;
   }

   private static boolean inRect(double mx, double my, float x, float y, float width, float height) {
      return mx >= x && mx <= x + width && my >= y && my <= y + height;
   }

   public boolean hasDragPreview() {
      ColorModal current = this.topmostVisible();
      if (!current.listFlag()) {
         return false;
      } else {
         current.cancelEdit();
         return true;
      }
   }

   public boolean listFlag() {
      return false;
   }

   @Override
   public void onClosed() {
      this.resetDrag();
   }

   public void resetDrag() {
      this.squareHover = false;
      this.hueHover = false;
      this.selectedStop = 0;
      this.dragStop = 0;
      this.squareActive = false;
      if (this.child != null && (0.001F < this.child.alphaCurrent() || 0.001F < this.child.alphaTarget)) {
         this.child.close();
      }

      if (this.actionFieldActive()) {
         this.cancelEdit();
      }
   }

   protected void cancelEdit() {
   }

   protected static void updateCursor(ColorModal modal) {
   }

   protected static void syncRowRows(ColorModal modal) {
   }

   protected static void rowHeightReset(List<ColorModal.Row> rows) {
   }

   protected static float frameDelta() {
      return 0.0F;
   }

   public static final class ColorSetting {
      public int value;
      public boolean alphaFlag;

      public void notifyChanged() {
      }
   }

   public static final class ColorStop {
      public String name = "";
      public int color;
      public int position;
   }

   public static final class GradientSetting {
      public boolean enabled;
      public boolean alphaFlag;
      public final List<ColorModal.ColorStop> stops = new ArrayList<>();

      public void setStopPosition(int index, float ratio) {
         if (index >= 0 && index < this.stops.size()) {
            this.stops.get(index).color = AbstractOverlay.mixColor(this.stops.get(index).color, this.stops.get(index).color, ratio);
         }
      }
   }

   public static final class Hsv {
      public final float hue;
      public final float saturation;
      public final float value;

      public Hsv(float hue, float saturation, float value) {
         this.hue = hue;
         this.saturation = saturation;
         this.value = value;
      }
   }

   public static final class Rect {
      public static final int SIZE = 88;
      public float x;
      public float y;
      public float width;
      public float height;
      public final float[] slots = new float[21];

      public void clear() {
         this.x = 0.0F;
         this.y = 0.0F;
         this.width = 0.0F;
         this.height = 0.0F;

         for (int i = 0; i < this.slots.length; i++) {
            this.slots[i] = 0.0F;
         }
      }

      public void set(float sx, float sy, float sw) {
         this.x = sx;
         this.y = sy;
         this.width = sw;
      }
   }

   public static final class Row {
      public String name = "";
      public float progress;
      public float animFrom;
      public float animCurrent;
      public float animTarget;
      public float animDuration = 0.18F;
      public long animStart;
      public boolean animRunning;
      public boolean marked;

      public Row() {
      }

      public Row(String name, boolean marked) {
         this.name = name == null ? "" : name;
         this.marked = marked;
      }
   }
}

