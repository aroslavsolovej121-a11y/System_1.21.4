package client.gui;

import client.Setting;
import java.util.List;

public class ChoiceWidget extends AbstractTrackChoiceWidget {
   public static final float OPTION_TEXT_TOP = 10.0F;
   public static final float OPTION_ICON_TOP = 11.5F;
   public static final float OPTION_ICON_WIDTH = 14.0F;
   public static final float OPTION_ICON_HEIGHT = 9.0F;
   public static final int TRACK_COUNT = 2;
   public static final int OPTION_ICON_TEXT = 89;
   public static final int SOUND_TOGGLE_ON = 7;
   public static final int SOUND_TOGGLE_OFF = 6;
   protected final ChoiceWidget.TrackOption[] options = new ChoiceWidget.TrackOption[2];

   public ChoiceWidget() {
      this.initSettingWidget(null);
      this.trackSetting = null;
      this.options[0] = new ChoiceWidget.TrackOption("", 89);
      this.options[1] = new ChoiceWidget.TrackOption("", 89);
      float flag = 0.0F;
      this.animFrom = flag;
      this.animCurrent = flag;
      this.animTarget = flag;
      this.animRunning = false;
   }

   public ChoiceWidget(Setting setting) {
      super(setting);
      this.trackSetting = setting;
      this.options[0] = new ChoiceWidget.TrackOption(this.optionText(0), 89);
      this.options[1] = new ChoiceWidget.TrackOption(this.optionText(1), 89);
      float flag = this.choiceValue() ? 1.0F : 0.0F;
      this.animFrom = flag;
      this.animCurrent = flag;
      this.animTarget = flag;
      this.animRunning = false;
   }

   @Override
   protected int getTypeId() {
      return 73;
   }

   @Override
   protected int getTrackCount() {
      return 2;
   }

   protected boolean choiceValue() {
      Setting s = this.trackSetting;
      return s == null ? false : s.getModes().indexOf(s.getMode()) == 1;
   }

   protected String optionText(int index) {
      Setting s = this.trackSetting;
      if (s == null) {
         return "";
      } else {
         List<String> modes = s.getModes();
         return index >= 0 && index < modes.size() ? modes.get(index) : "";
      }
   }

   @Override
   protected String getTrackLabel() {
      return this.optionText(this.choiceValue() ? 1 : 0);
   }

   @Override
   protected String settingValue() {
      return this.getTrackLabel();
   }

   @Override
   protected float getTrackAnimTarget() {
      return this.choiceValue() ? 1.0F : 0.0F;
   }

   @Override
   protected void setTrackIndex(int index) {
      Setting s = this.trackSetting;
      if (s != null) {
         boolean target = index == 1;
         if (target != this.choiceValue()) {
            playSound(target ? 7 : 6);
         }

         if (this.choiceValue() != target) {
            s.setMode(this.optionText(target ? 1 : 0));
            this.notifyChanged();
         }
      }
   }

   protected void notifyChanged() {
   }

   protected static void playSound(int id) {
   }

   protected void drawOptionText(Object mat, String text, float px, float py, float size, int color, float alpha) {
   }

   @Override
   protected void renderTrack(Object mat, float top, float alpha) {
      boolean checked = this.choiceValue();

      for (int i = 0; i < 2; i++) {
         ChoiceWidget.TrackOption option = this.options[i];
         int color;
         if (i == 1 == checked) {
            color = rendererSecondaryColor();
         } else {
            color = rendererColor();
         }

         if (option.icon == 89) {
            float width = textWidth(option.text, 12.0F);
            float baseX = this.x;
            float offset = top + 10.0F;
            float cellsA = this.cellWidth();
            float cellsB = this.cellWidth();
            this.drawOptionText(mat, option.text, cellsB * 0.5F + (cellsA + 2.0F) * i + baseX + 3.0F - width * 0.5F, offset, 12.0F, color, alpha);
         } else {
            float cellsA = this.cellWidth();
            float baseX = this.x;
            float cellsB = this.cellWidth();
            drawText(mat, option.icon, cellsB * 0.5F + baseX + 3.0F + (cellsA + 2.0F) * i - 7.0F, top + 11.5F, 14.0F, 9.0F, color, alpha);
         }
      }
   }

   public static final class TrackOption {
      public final String text;
      public final int icon;

      public TrackOption(String text, int icon) {
         this.text = text;
         this.icon = icon;
      }
   }
}

