package client.gui;

import java.util.function.Consumer;

public class FriendCard extends Component {
   public static final float CARD_WIDTH = 930.0F;
   public static final float CARD_HEIGHT = 62.0F;
   public static final float CARD_HEIGHT_SELECTED = 112.0F;
   public static final float PLATE_BUTTON_SIZE = 42.0F;
   public static final float NAME_INPUT_SIZE = 12.0F;
   public static final float AVATAR_MIN_SIZE = 30.0F;
   public static final float AVATAR_HEIGHT = 16.0F;
   public static final float PANEL_RADIUS = 18.0F;
   public static final float FADE_FLAG_THRESHOLD = 0.001F;
   public static final float ROW_GAP = 4.0F;
   public static final float TEXT_PADDING = 6.0F;
   public static final float ALPHA_CAP = 127.5F;
   public static final int COLOR_INVITE = -10571281;
   public static final int COLOR_FRIEND = -10569333;
   public static final int COLOR_REQUEST = -17896;
   public static final int COLOR_ENEMY = -2276315;
   public static final int COLOR_DEFAULT = -8158333;
   public static final int ICON_ALIAS = 81;
   public static final int ICON_REMOVE = 82;
   public static final int TEXT_ID_INVITE = 76;
   public static final int TEXT_ID_KICK = 77;
   public static final int TEXT_ID_OWNER = 75;
   public static final int TEXT_ID_ACCEPT = 20;
   public static final int TEXT_ID_DECLINE = 22;
   public static final int SOUND_ENABLE = 8;
   public static final String TEXT_INVITE_SHORT = "Киск";
   public static final String TEXT_INVITE_LONG = "Киск Фром Партй";
   public static final String TEXT_OWNER_SHORT = "Ошнер";
   public static final String TEXT_OWNER_LONG = "Гиве Ошнер";
   public static final String LABEL_INVITE = "Инвите";
   public static final String LABEL_ACCEPT = "Ассепт";
   public static final String LABEL_DECLINE = "Деслине";
   public static final String LABEL_ALIAS = "Изменить алиас";
   public static final String LABEL_REMOVE = "Удалить из друзей";
   public static final String LABEL_INVITE_PARTY = "Позвать в пати";
   public static final String LABEL_KICK_PARTY = "Выгнать из пати";
   public static final String LABEL_GIVE_OWNER = "Передать лидерство";
   public static int hoverState;
   protected FriendCard.Info info;
   protected final FriendCard.PlateIconButton aliasButton = new FriendCard.PlateIconButton(81, "Изменить алиас");
   protected final FriendCard.PlateIconButton removeButton = new FriendCard.PlateIconButton(82, "Удалить из друзей");
   protected final FriendCard.TextButton inviteButton = new FriendCard.TextButton(76, "Инвите");
   protected final FriendCard.TextButton kickButton = new FriendCard.TextButton(77, "Киск Фром Партй");
   protected final FriendCard.TextButton ownerButton = new FriendCard.TextButton(75, "Гиве Ошнер");
   protected final FriendCard.TextButton acceptButton = new FriendCard.TextButton(20, "Ассепт");
   protected final FriendCard.TextButton declineButton = new FriendCard.TextButton(22, "Деслине");
   protected final FriendCard.PlateIconButton[] iconButtons = new FriendCard.PlateIconButton[]{this.aliasButton, this.removeButton};
   protected final FriendCard.PlateIconButton[] iconLayoutOrder = new FriendCard.PlateIconButton[]{this.removeButton, this.aliasButton};
   protected final FriendCard.TextButton[] textButtons = new FriendCard.TextButton[]{
      this.inviteButton, this.kickButton, this.ownerButton, this.acceptButton, this.declineButton
   };
   protected final FriendCard.TextButton[] textLayoutOrder = new FriendCard.TextButton[]{
      this.inviteButton, this.ownerButton, this.kickButton, this.declineButton, this.acceptButton
   };
   protected final FriendCard.IconInputButton nameInput = new FriendCard.IconInputButton(12.0F);
   protected final FriendCard.ColorAnim colorAnim = new FriendCard.ColorAnim();
   protected final FriendCard.Rect avatarRect = new FriendCard.Rect(0.0F, 0.0F, 0.0F, 0.0F);
   protected Consumer<FriendCard.Info> onAlias;
   protected Runnable onRemove;
   protected Consumer<FriendCard.Info> onInvite;
   protected Consumer<FriendCard.Info> onKick;
   protected Consumer<FriendCard.Info> onGiveOwner;
   protected Consumer<FriendCard.Info> onAccept;
   protected Consumer<FriendCard.Info> onDecline;
   protected final FriendCard.ButtonTemplate[] templates = new FriendCard.ButtonTemplate[3];
   protected int state;
   protected AbstractCard.Anim animX;
   protected AbstractCard.Anim animY;
   protected boolean animatingPosition;

   public FriendCard(FriendCard.Info friendInfo) {
      this.info = friendInfo;
      this.add(this.aliasButton);
      this.add(this.removeButton);
      this.add(this.inviteButton);
      this.add(this.kickButton);
      this.add(this.ownerButton);
      this.add(this.acceptButton);
      this.add(this.declineButton);
      this.add(this.nameInput);
      this.aliasButton.onAction = this::onAliasClicked;
      this.removeButton.onAction = this::onRemoveClicked;
      this.inviteButton.onClick = this::onInviteClicked;
      this.kickButton.onClick = this::onKickClicked;
      this.ownerButton.onClick = this::onGiveOwnerClicked;
      this.acceptButton.onClick = this::onAcceptClicked;
      this.declineButton.onClick = this::onDeclineClicked;
      this.nameInput.onAction = this::onNameCommitted;
      this.colorAnim.reset(this.nameColor());
      if (friendInfo == null) {
         String var10000 = "";
      }

      this.inviteButton.setTooltip("Позвать в пати");
      this.kickButton.setTooltip("Выгнать из пати");
      this.ownerButton.setTooltip("Передать лидерство");
      if (this.state != 0) {
         this.kickButton.setLabel("Киск Фром Партй");
         this.ownerButton.setLabel("Гиве Ошнер");
      }

      this.state = 0;
      this.width = 930.0F;
      this.height = 62.0F;
      this.refreshButtons(true);
   }

   private void onAliasClicked(String value) {
   }

   private void onRemoveClicked(String value) {
   }

   private void onInviteClicked() {
   }

   private void onKickClicked() {
   }

   private void onGiveOwnerClicked() {
   }

   private void onAcceptClicked() {
   }

   private void onDeclineClicked() {
   }

   private void onNameCommitted(String value) {
   }

   public void setState(int newState, float newWidth) {
      if (newState != this.state) {
         this.kickButton.setLabel(newState == 1 ? "Киск" : "Киск Фром Партй");
         this.ownerButton.setLabel(newState == 1 ? "Ошнер" : "Гиве Ошнер");
      }

      this.width = newWidth;
      this.state = newState;
      this.height = newState == 1 ? 112.0F : 62.0F;
   }

   public void applyPositionAnimation(long time) {
      if (this.animatingPosition && this.animX != null && this.animY != null) {
         this.x = this.animX.update(time);
         this.y = this.animY.update(time);
      }
   }

   public void setPositionAnimated(float px, float py) {
      if (this.animX == null) {
         this.animX = new AbstractCard.Anim(px, 0.0F, 1);
         this.animY = new AbstractCard.Anim(py, 0.0F, 1);
      }

      if (!this.animatingPosition) {
         this.animX.snap(px);
         this.animY.snap(py);
         this.x = px;
         this.y = py;
         this.animatingPosition = true;
      } else {
         this.animX.setTarget(px);
         this.animY.setTarget(py);
      }
   }

   @Override
   public void setPosition(float px, float py) {
      this.setPositionAnimated(px, py);
   }

   public void refreshButtons(boolean instant) {
      String display = displayName(this.info == null ? "" : this.info.name);
      this.aliasButton.enabled = this.info != null && this.info.mode == 1 && this.info.flagB2;
      this.removeButton.enabled = this.info != null && this.info.mode == 1 && this.info.flagB1;
      this.inviteButton.enabled = this.info != null && this.info.mode == 1 && !this.info.flagAD && this.info.groupMode == 2;
      this.kickButton.enabled = this.info != null && this.info.mode == 2 && this.info.flagB3;
      this.ownerButton.enabled = this.info != null && this.info.mode == 2 && this.info.flagB3;
      this.acceptButton.enabled = this.info != null && this.info.mode == 3;
      this.declineButton.enabled = this.info != null && this.info.mode == 3;
      if (instant) {
         this.aliasButton.enabledAnim.snap(this.aliasButton.enabled ? 1.0F : 0.0F);
         this.removeButton.enabledAnim.snap(this.removeButton.enabled ? 1.0F : 0.0F);
         applyEnabledInstant(this.inviteButton);
         applyEnabledInstant(this.kickButton);
         applyEnabledInstant(this.ownerButton);
         applyEnabledInstant(this.acceptButton);
         applyEnabledInstant(this.declineButton);
      } else {
         this.aliasButton.enabledAnim.setTarget(this.aliasButton.enabled ? 1.0F : 0.0F);
         this.removeButton.enabledAnim.setTarget(this.removeButton.enabled ? 1.0F : 0.0F);
         applyEnabledAnimated(this.inviteButton);
         applyEnabledAnimated(this.kickButton);
         applyEnabledAnimated(this.ownerButton);
         applyEnabledAnimated(this.acceptButton);
         applyEnabledAnimated(this.declineButton);
      }

      boolean hasName = this.info != null && this.info.name != null && !this.info.name.isEmpty();
      this.inviteButton.tooltipVisible = hasName;
      float target = hasName ? 1.0F : 0.0F;
      if (this.inviteButton.tooltipAnim.target != target) {
         this.inviteButton.tooltipAnim.from = this.inviteButton.tooltipAnim.update(this.now());
         this.inviteButton.tooltipAnim.target = target;
         this.inviteButton.tooltipAnim.start = this.now();
         this.inviteButton.tooltipAnim.running = true;
      }

      this.inviteButton.setLabel(display);
      this.nameInput.setText(display);
   }

   private static void applyEnabledInstant(FriendCard.TextButton button) {
      float value = button.enabled ? 1.0F : 0.0F;
      button.animFrom = value;
      button.animCurrent = value;
      button.animTarget = value;
      button.animRunning = false;
   }

   private static void applyEnabledAnimated(FriendCard.TextButton button) {
      button.animTarget = button.enabled ? 1.0F : 0.0F;
   }

   @Override
   public void render(Object renderer, float mouseX, float mouseY, float alpha) {
      this.applyPositionAnimation(this.now());
      drawPanel(renderer, this.x, this.y, this.width, this.height, 18.0F, alpha);
      if (0.0F < this.avatarRect.w
         && mouseX >= this.avatarRect.x
         && mouseX <= this.avatarRect.x + this.avatarRect.w
         && mouseY >= this.avatarRect.y
         && mouseY <= this.avatarRect.y + this.avatarRect.h) {
         hoverState = 2;
      }

      int currentState = this.state;
      float rowY = currentState == 1 ? this.y + 11.0F : (this.height - 42.0F) * 0.5F + this.y;
      int color = this.nameColor();
      drawNameText(renderer, this.x + 12.0F, rowY, 34, color, alpha);
      float right = this.x + this.width - 12.0F;
      float used;
      if (currentState == 1) {
         used = this.renderRow(renderer, right, rowY, mouseX, mouseY, alpha, 1);
         this.renderRow(renderer, right, rowY + 42.0F + 6.0F, mouseX, mouseY, alpha, 2);
      } else {
         used = this.renderRow(renderer, right, rowY, mouseX, mouseY, alpha, 0);
      }

      float start = this.x + 12.0F + 42.0F + 6.0F;
      float width2 = right - start - used;
      if (width2 <= 0.0F) {
         width2 = 0.0F;
      }

      this.renderFooter(renderer, start, rowY - 1.0F, width2, alpha);
   }

   public float renderRow(Object renderer, float right, float rowY, float mouseX, float mouseY, float alpha, int mode) {
      float cursor = right;
      if (mode == 2) {
         this.layoutTextButtons(right, rowY);
         this.drawTextButtons(renderer, mouseX, mouseY, alpha);
         return right - right;
      } else {
         for (int i = 0; i < this.iconLayoutOrder.length; i++) {
            FriendCard.PlateIconButton button = this.iconLayoutOrder[i];
            float size = button.enabledAnim.update(this.now()) * 42.0F;
            button.setPosition(cursor - size, rowY);
            button.setSize(size, size);
            if (0.001F < size) {
               cursor -= size + 4.0F;
            }
         }

         if (mode != 1) {
            this.layoutTextButtons(cursor, rowY);
            this.drawTextButtons(renderer, mouseX, mouseY, alpha);
         }

         for (int ix = 0; ix < this.iconButtons.length; ix++) {
            drawIconButton(renderer, this.iconButtons[ix], mouseX, mouseY, alpha);
         }

         return right - cursor;
      }
   }

   protected void layoutTextButtons(float right, float rowY) {
      float cursor = right;

      for (int i = 0; i < this.textLayoutOrder.length; i++) {
         FriendCard.TextButton button = this.textLayoutOrder[i];
         float width = button.textWidth();
         button.setPosition(cursor - width, rowY);
         if (0.001F < button.getWidth()) {
            cursor -= button.getWidth() + 4.0F;
         }
      }
   }

   protected void drawTextButtons(Object renderer, float mouseX, float mouseY, float alpha) {
      drawTextButton(renderer, this.acceptButton, mouseX, mouseY, alpha);
      drawTextButton(renderer, this.declineButton, mouseX, mouseY, alpha);
      drawTextButton(renderer, this.kickButton, mouseX, mouseY, alpha);
      drawTextButton(renderer, this.ownerButton, mouseX, mouseY, alpha);
      drawTextButton(renderer, this.inviteButton, mouseX, mouseY, alpha);
   }

   public void renderFooter(Object renderer, float px, float py, float width, float alpha) {
      String alias = this.info == null ? "" : this.info.alias;
      float textWidth = measureText(alias, Math.min(alpha, 127.5F), 16.0F);
      drawTextAt2(renderer, 4, px, alias, alpha);
      this.avatarRect.w = 0.0F;
      float inputX = px + textWidth + 6.0F;
      boolean showInput = (alias.isEmpty() || this.nameInput.focused || this.info != null && this.info.flagB2) && this.info != null && this.info.flagB2;
      if (0.0F < alpha - (inputX - px) && (!alias.isEmpty() || this.nameInput.focused || showInput)) {
         float inputY = py + 6.0F;
         textColor(renderer, 63, showInput);
         float inputWidth = renderNameInput(renderer, this.nameInput, alias, inputX);
         if (this.info != null && this.info.flagB2) {
            this.avatarRect.x = inputX - 2.0F;
            this.avatarRect.y = inputY - 2.0F;
            this.avatarRect.w = Math.max(30.0F, inputWidth + 4.0F);
            this.avatarRect.h = 16.0F;
         }
      }

      drawAvatar(renderer, px, py + 24.0F);
   }

   protected int nameColor() {
      if (this.info == null) {
         return -10571281;
      } else {
         switch (this.info.status) {
            case 1:
               return -10569333;
            case 2:
               return -17896;
            case 3:
               return -2276315;
            default:
               return -8158333;
         }
      }
   }

   public boolean onMouse(double mx, double my, int button) {
      for (int i = 0; i < this.iconButtons.length; i++) {
         FriendCard.PlateIconButton current = this.iconButtons[i];
         if (current.mousePressed(mx, my, button)) {
            AbstractCard.blurFocusedChildren(this);
            return true;
         }
      }

      for (int ix = 0; ix < this.textButtons.length; ix++) {
         FriendCard.TextButton current = this.textButtons[ix];
         if (current.mousePressed(mx, my, button)) {
            AbstractCard.blurFocusedChildren(this);
            return true;
         }
      }

      if (button == 0
         && 0.0F < this.avatarRect.w
         && mx >= this.avatarRect.x
         && mx <= this.avatarRect.x + this.avatarRect.w
         && my >= this.avatarRect.y
         && my <= this.avatarRect.y + this.avatarRect.h) {
         AbstractCard.focusChildWithText(this, this.nameInput, this.info == null ? "" : this.info.name);
         return true;
      } else {
         return false;
      }
   }

   public static void playClickSound(int sound) {
      uiSound(sound);
   }

   public static String displayName(String value) {
      return value;
   }

   public static void drawPanel(Object renderer, float x, float y, float width, float height, float radius, float alpha) {
   }

   public static void drawNameText(Object renderer, float x, float y, int id, int color, float alpha) {
   }

   public static void drawIconButton(Object renderer, Component button, float mouseX, float mouseY, float alpha) {
   }

   public static void drawTextButton(Object renderer, Component button, float mouseX, float mouseY, float alpha) {
   }

   public static void drawAvatar(Object renderer, float x, float y) {
   }

   public static void drawTextAt2(Object renderer, int mode, float x, String text, float alpha) {
   }

   public static float measureText(String text, float alpha, float size) {
      return 0.0F;
   }

   public static void textColor(Object renderer, int alpha, boolean highlight) {
   }

   public static float renderNameInput(Object renderer, Component input, String value, float x) {
      return 0.0F;
   }

   public static float formatText(String value, float alpha, float size) {
      return 0.0F;
   }

   public static final class ButtonTemplate {
      public String label = "";
      public int icon;
      public float width;
      public float height;
      public boolean flag;
   }

   public static final class ColorAnim {
      public static final int EASING = 0;
      public float alphaFrom = 1.0F;
      public float alphaCurrent = 1.0F;
      public float alphaTarget = 1.0F;
      public float duration = 0.22F;
      public int colorFrom;
      public int colorTo;
      public long start = System.nanoTime();
      public boolean running;

      public void reset(int color) {
         this.colorFrom = color;
         this.colorTo = color;
         this.alphaFrom = 1.0F;
         this.alphaCurrent = 1.0F;
         this.alphaTarget = 1.0F;
         this.start = System.nanoTime();
         this.running = false;
      }

      public void setColor(int color) {
         if (this.colorTo != color) {
            this.colorFrom = this.colorTo;
            this.colorTo = color;
            this.start = System.nanoTime();
            this.running = true;
         }
      }
   }

   public static class IconInputButton extends Component implements AbstractCard.InputChild {
      public int icon;
      public int variant = 89;
      public float iconSize;
      public boolean flagD9;
      public String text = "";
      public Consumer<String> onAction;
      public Consumer<String> onCommit;
      public final AbstractCard.Anim anim = new AbstractCard.Anim(0.0F, 0.15F, 0);

      public IconInputButton(float size) {
         this.iconSize = size;
         this.setSize(size, size);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }

      @Override
      public String getText() {
         return this.text;
      }

      @Override
      public void setText(String value) {
         this.text = value == null ? "" : value;
      }

      @Override
      public boolean isShiftCommit() {
         return this.flagD9;
      }

      @Override
      public void commit() {
         if (this.onAction != null) {
            this.onAction.accept(this.text);
         }

         this.focused = false;
      }

      @Override
      public void cancel() {
         this.focused = false;
      }

      @Override
      public void blur(String value) {
         if (this.onCommit != null) {
            this.onCommit.accept(value);
         }
      }
   }

   public static final class Info {
      public String name = "";
      public String alias = "";
      public int mode;
      public int groupMode;
      public int status;
      public boolean flagAD;
      public boolean flagAE;
      public boolean flagAF;
      public boolean flagB0;
      public boolean flagB1;
      public boolean flagB2;
      public boolean flagB3;
   }

   public static class PlateIconButton extends Component {
      public static final float DEFAULT_SIZE = 42.0F;
      public int icon;
      public int variant;
      public boolean enabled = true;
      public final AbstractCard.Anim enabledAnim = new AbstractCard.Anim(1.0F, 0.22F, 0);
      public final AbstractCard.Anim hoverAnim = new AbstractCard.Anim(0.0F, 0.15F, 0);
      public String label;
      public Consumer<String> onAction;

      public PlateIconButton(int icon, String label) {
         this.icon = icon;
         this.label = label;
         this.setSize(42.0F, 42.0F);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return this.enabled && button == 0 && this.contains(mx, my);
      }
   }

   public static final class Rect {
      public float x;
      public float y;
      public float w;
      public float h;

      public Rect(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }
   }

   public static class TextButton extends Component {
      public int id;
      public boolean enabled = true;
      public String label = "";
      public String oldLabel = "";
      public String tooltip = "";
      public String extra = "";
      public Runnable onClick;
      public float animFrom;
      public float animCurrent;
      public float animTarget;
      public boolean animRunning;
      public boolean tooltipVisible;
      public boolean fadeFlag;
      public final AbstractCard.Anim tooltipAnim = new AbstractCard.Anim(0.0F, 0.22F, 0);

      public TextButton(int id, String label) {
         this.id = id;
         this.label = label;
      }

      public boolean mousePressed(double mx, double my, int button) {
         return this.enabled && button == 0 && this.contains(mx, my);
      }

      public float textWidth() {
         return 0.0F;
      }

      public void setLabel(String value) {
         String next = value == null ? "" : value;
         if (!this.label.equals(next)) {
            if (this.fadeFlag && 0.001F < this.alpha) {
               this.oldLabel = this.label;
            }

            this.label = next;
         }
      }

      public void setTooltip(String value) {
         this.tooltip = value == null ? "" : value;
      }
   }
}

