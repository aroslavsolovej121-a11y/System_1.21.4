package client.gui;

import client.Setting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class ModuleCard extends Component {
   public static final int FEATURE_OFFSET = 96;
   public static final int SWITCHER_CALLBACK_STORAGE_OFFSET = 208;
   public static final int SWITCHER_CALLBACK_OFFSET = 264;
   public static final int FAVOURITE_CALLBACK_STORAGE_OFFSET = 200;
   public static final int FAVOURITE_CALLBACK_OFFSET = 456;
   public static final int OWNED_CHILDREN_OFFSET = 792;
   public static final int OWNED_CHILDREN_END_OFFSET = 800;
   public static final int OWNED_CHILDREN_CAPACITY_OFFSET = 808;
   public static final int CHILD_FADES_OFFSET = 816;
   public static final int CHILDREN_COLLAPSED_OFFSET = 880;
   public static final int VERSION_LABEL_OFFSET = 888;
   public static final int REVEAL_ANIM_OFFSET = 920;
   public static final int OPEN_ANIM_OFFSET = 960;
   public static final int GLOW_ANIM_OFFSET = 1000;
   public static final int CHILD_PRESS_ANIM_OFFSET = 1040;
   public static final int HIGHLIGHTED_CHILD_OFFSET = 1080;
   public static final int CHILD_WIDTH_OFFSET = 1088;
   public static final int SWITCHER_OFFSET = 104;
   public static final int FAVOURITE_OFFSET = 296;
   public static final int BIND_OFFSET = 504;
   public static final int CHILD_SOURCE_OFFSET = 96;
   public static final int CHILD_TAB_OFFSET = 160;
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final float CARD_WIDTH = 305.0F;
   public static final float CLOSED_HEIGHT = 60.0F;
   public static final float HEADER_HEIGHT = 58.0F;
   public static final float HEADER_PAD = 18.0F;
   public static final float HEADER_Y_INSET = 4.0F;
   public static final float HEADER_X_INSET = 6.0F;
   public static final float CHILD_INSET = 36.0F;
   public static final float ROW_GAP = 24.0F;
   public static final float LINK_STEP = 16.0F;
   public static final float LABEL_STEP = 12.0F;
   public static final float ROW_INCREMENT = 22.0F;
   public static final float TEXT_INSET = 8.0F;
   public static final float SWITCHER_GAP = 28.0F;
   public static final float SWITCHER_X_INSET = 4.0F;
   public static final float FAVOURITE_SIZE = 12.0F;
   public static final float BIND_MIN_WIDTH = 46.0F;
   public static final float CHILD_RADIUS = 8.0F;
   public static final float CHILD_HIGHLIGHT_INSET = 6.0F;
   public static final float PANEL_RADIUS = 14.0F;
   public static final float GLOW_RADIUS = 14.0F;
   public static final float GLOW_WIDTH = 2.0F;
   public static final float GLOW_ALPHA = 0.08F;
   public static final float RECT_ANIM_DURATION = 0.15F;
   public static final float REVEAL_DURATION = 0.32F;
   public static final float OPEN_DURATION = 0.22F;
   public static final float FADE_DURATION = 0.5F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float HALF = 0.5F;
   public static final float NEAR_ONE = 0.999F;
   public static final float EPSILON = 0.001F;
   public static final int HOVER_MODULE_NAME = 7;
   public static final int SOUND_TOGGLE = 14;
   public static final int ICON_BADGE = 56;
   public static final int ICON_METRICS = 75;
   public static final int TEXT_STYLE_NAME = 5;
   public static final int HEADER_TOGGLE_BUTTON = 1;
   public static final int VERSION_1_21_4 = 1;
   public static final int VERSION_1_21_11 = 2;
   public static final int VERSION_26_2 = 3;
   public static final String VERSION_1_21_4_LABEL = "1.21.4";
   public static final String VERSION_1_21_11_LABEL = "1.21.11";
   public static final String VERSION_26_2_LABEL = "26.2";
   public static final String VERSION_UNKNOWN_LABEL = "unknown";
   public static final String BETA_TOOLTIP = "Только для бета-тестеров";
   public static final String VERSION_TOOLTIP_PREFIX = "Только с ";
   protected final ModuleCard.Anim rectAnim = new ModuleCard.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected Object feature;
   protected SwitcherButton switcher;
   protected FavouriteButton favourite;
   protected BindButton bind;
   protected Object switcherCallback;
   protected Object favouriteCallback;
   protected final byte[] switcherCallbackStorage = new byte[56];
   protected final byte[] favouriteCallbackStorage = new byte[56];
   protected final List<Component> ownedChildren = new ArrayList<>();
   protected final Map<Component, ModuleCard.Anim> childFades = new HashMap<>();
   protected boolean childrenCollapsed;
   protected String versionLabel = "";
   protected final ModuleCard.Anim revealAnim = new ModuleCard.Anim();
   protected final ModuleCard.Anim openAnim = new ModuleCard.Anim();
   protected final ModuleCard.Anim glowAnim = new ModuleCard.Anim();
   protected final ModuleCard.Anim childPressAnim = new ModuleCard.Anim();
   protected Component highlightedChild;
   protected float cachedChildWidth;

   public ModuleCard(Object feature) {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.feature = feature;
      this.switcher = new SwitcherButton(featureToggled(feature));
      this.favourite = new FavouriteButton(featureFavourite(feature));
      this.bind = new BindButton((Setting)featureBindTarget(feature));
      this.releaseOwnedChildren();
      this.releaseChildFades();
      this.childrenCollapsed = false;
      this.versionLabel = "";
      this.revealAnim.set(0.0F, 0.32F);
      this.openAnim.set(1.0F, 0.22F);
      this.glowAnim.set(0.0F, 0.5F);
      this.childPressAnim.set(0.0F, 0.5F);
      this.highlightedChild = null;
      this.cachedChildWidth = Float.NaN;
      this.width = 305.0F;
      this.switcher.locked = 1;
      this.switcherCallback = this.createToggleCallback();
      this.favouriteCallback = this.createFavouriteCallback();
      if (moduleVersionFloor() < featureVersion(feature)) {
         int version = featureVersion(feature);
         if (version == 1) {
            this.versionLabel = "1.21.4";
         } else if (version == 2) {
            this.versionLabel = "1.21.11";
         } else if (version == 3) {
            this.versionLabel = "26.2";
         } else {
            this.versionLabel = "unknown";
         }
      }

      this.highlightedChild = null;
      this.releaseOwnedChildren();

      for (Object setting : featureSettings(feature)) {
         Component widget = createSettingWidget(setting);
         if (widget != null) {
            this.ownedChildren.add(widget);
         }
      }

      this.syncChildFades();
      this.cachedChildWidth = Float.NaN;
      float collapsedWidth = this.width - 36.0F;
      if (0.001F < Math.abs(collapsedWidth - Float.NaN)) {
         this.cachedChildWidth = collapsedWidth;

         for (Component child : this.ownedChildren) {
            child.width = collapsedWidth;
         }
      }

      float revealInitial = 0.0F;
      if (!featureIsOn(feature) || modulesDimmed()) {
         for (Component child : this.ownedChildren) {
            if (this.childShown(child)) {
               if (featureExpandable(feature)) {
                  revealInitial = 1.0F;
               }
               break;
            }
         }
      }

      this.revealAnim.from = revealInitial;
      this.revealAnim.current = revealInitial;
      this.revealAnim.target = revealInitial;
      this.revealAnim.running = false;
      float openInitial = this.featureAlphaTarget();
      this.openAnim.from = openInitial;
      this.openAnim.current = openInitial;
      this.openAnim.target = openInitial;
      this.openAnim.running = false;
   }

   @Override
   public void dispose() {
      this.versionLabel = "";
      this.releaseChildFades();
      this.releaseOwnedChildren();
      this.bind.dispose();
      if (this.favouriteCallback != null) {
         releaseCallback(this.favouriteCallback, this.favouriteCallback != this.favouriteCallbackStorage);
         this.favouriteCallback = null;
      }

      this.favourite.dispose();
      if (this.switcherCallback != null) {
         releaseCallback(this.switcherCallback, this.switcherCallback != this.switcherCallbackStorage);
         this.switcherCallback = null;
      }

      this.switcher.dispose();
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      float revealTarget = 1.0F;
      boolean toggled = featureToggled(this.feature);
      if (this.switcher.on != toggled) {
         this.switcher.on = toggled;
         this.switcher.target = toggled ? 1.0F : 0.0F;
      }

      this.favourite.selected = featureFavourite(this.feature);
      this.syncChildWidths();
      this.refreshChildFades();
      float openTarget = this.featureAlphaTarget();
      if (this.openAnim.target != openTarget) {
         this.openAnim.retarget(openTarget);
      }

      float open = this.openAnim.advance(ModuleCard.Anim.now()) * alpha;
      if (this.anyChildShown() && featureExpandable(this.feature)) {
         this.childrenCollapsed = false;
      } else {
         if (!this.childrenCollapsed) {
            for (Component child : this.ownedChildren) {
               detachChild(child);
            }
         }

         this.childrenCollapsed = true;
         revealTarget = 0.0F;
      }

      if (this.revealAnim.target != revealTarget) {
         this.revealAnim.retarget(revealTarget);
      }

      float reveal = this.revealAnim.advance(ModuleCard.Anim.now());
      float preferred = this.measureHeight();
      drawPanel(mat, this.x, this.y, this.width, preferred, 14.0F, open);
      float glow = this.glowAnim.advance(ModuleCard.Anim.now());
      if (0.001F < glow) {
         drawRoundedBox(mat, this.x, this.y, this.width, preferred, 14.0F, 14.0F, 14.0F, 14.0F, 0, themeColor(20), 2.0F, 0, 0.0F, 0.0F, 0.0F, glow * alpha, 0);
      }

      float headerY = this.y + 18.0F;
      float headerX = this.x + 18.0F;
      this.renderHeader(mat, mouseX, mouseY, alpha, headerX, headerY);
      if (0.001F < reveal) {
         headerY += 24.0F;
         this.layoutChildRow(headerX, headerY + 16.0F);
         if (0.999F <= reveal) {
            this.renderChildren(mat, mouseX, mouseY, reveal * open);
         } else {
            float clipHeight = preferred + this.y - 18.0F - headerY;
            if (clipHeight <= 0.0F) {
               clipHeight = 0.0F;
            }

            pushScissor(headerX, headerY, this.width - 36.0F, clipHeight);
            this.renderChildren(mat, mouseX, mouseY, reveal * open);
            popScissor();
         }
      }
   }

   public void layout(Object mat, float mouseX, float mouseY, float alpha) {
      if (0.001F < this.revealAnim.current) {
         float expand = this.openAnim.current;

         for (Component child : this.ownedChildren) {
            float weight = this.childWeight(child);
            if (0.001F < weight) {
               invokeChildLayout(child, mat, mouseX, mouseY, weight * alpha * expand);
            }
         }
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (0.5F <= this.revealAnim.current) {
         for (Component child : this.collectActiveChildren()) {
            if (childAcceptsMouse(child, mx, my) && child.mouseClicked(mx, my, button)) {
               return true;
            }
         }
      }

      if (this.bind.listening && this.bind.mouseClicked(mx, my, button)) {
         return true;
      } else {
         if (button == 1) {
            float switchY = this.y + 18.0F;
            if (this.x <= mx && mx <= this.x + this.width && switchY <= my && my <= switchY + 24.0F && this.anyChildShown()) {
               boolean previous = featureExpandable(this.feature);
               if (this.anyChildShown()) {
                  setFeatureExpandable(this.feature, !previous);
               }

               playSound(14);
               return true;
            }
         }

         if (featureIsOn(this.feature) && !modulesDimmed()) {
            return false;
         } else {
            if (moduleVersionFloor() >= featureVersion(this.feature) && button == 0) {
               if (mx < this.switcher.x || mx > this.switcher.x + this.switcher.width || my < this.switcher.y || my > this.switcher.y + this.switcher.height) {
                  return this.mouseClickedTail(mx, my, button);
               }

               if (this.switcher.press(mx)) {
                  return true;
               }
            } else if (button != 0) {
               return this.mouseClickedTail(mx, my, button);
            }

            return this.favourite.x <= mx
                  && mx <= this.favourite.x + this.favourite.width
                  && this.favourite.y <= my
                  && my <= this.favourite.y + this.favourite.height
                  && this.favourite.onClick(mx, my)
               ? true
               : this.mouseClickedTail(mx, my, button);
         }
      }
   }

   private boolean mouseClickedTail(double mx, double my, int button) {
      if (this.bind.mouseClicked(mx, my, button)) {
         return true;
      } else {
         if (0.5F >= this.revealAnim.current) {
            for (Component child : this.collectActiveChildren()) {
               if (child.mouseClicked(mx, my, button)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.switcher.mouseReleased(mx, my, button)) {
         return true;
      } else {
         for (Component child : this.collectActiveChildren()) {
            if (child.mouseReleased(mx, my, button)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean mouseDragged(double mx, double my, int buttons, double deltaX, double deltaY) {
      if (this.switcher.mouseDragged(mx, my, buttons)) {
         return true;
      } else {
         for (Component child : this.collectActiveChildren()) {
            if (child.mouseDragged(mx, my, buttons)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (0.5F <= this.revealAnim.current) {
         for (Component child : this.collectActiveChildren()) {
            if (child.mouseScrolled(mx, my, amount)) {
               return true;
            }
         }
      }

      return false;
   }

   public boolean keyPressed(int keyCode) {
      if (this.bind.keyPressed(keyCode, 0)) {
         return true;
      } else {
         for (Component child : this.collectActiveChildren()) {
            if (invokeChildKeyPressed(child, keyCode)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (this.bind.keyReleased(keyCode)) {
         return true;
      } else {
         for (Component child : this.collectActiveChildren()) {
            if (child.keyReleased(keyCode)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean charTyped(char ch) {
      for (Component child : this.collectActiveChildren()) {
         if (child.charTyped(ch)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public void setPosition(float px, float py) {
      this.x = px;
      this.y = py;
   }

   private float updateHover(float mouseX, float mouseY) {
      float target;
      if (!(mouseX < this.x)
         && !(this.x + this.width < mouseX)
         && !(mouseY < this.y)
         && !(this.y + this.height < mouseY)
         && (Screen.focusedInput == null || Screen.allowHover)) {
         this.flags = this.flags & 0xFF00 | 1;
         target = 1.0F;
      } else {
         this.flags &= 65280;
         target = 0.0F;
      }

      if (this.rectAnim.target != target) {
         long time = ModuleCard.Anim.now();
         float value = this.rectAnim.advance(time);
         this.rectAnim.start = time;
         this.rectAnim.from = value;
         this.rectAnim.target = target;
         this.rectAnim.running = true;
      }

      return this.rectAnim.advance(ModuleCard.Anim.now());
   }

   private float featureAlphaTarget() {
      return !featureToggled(this.feature) || featureIsOn(this.feature) && !modulesDimmed() ? 1.0F : 0.5F;
   }

   private void syncChildWidths() {
      float value = this.width - 36.0F;
      if (0.001F < Math.abs(value - this.cachedChildWidth)) {
         this.cachedChildWidth = value;

         for (Component child : this.ownedChildren) {
            child.width = value;
         }
      }
   }

   private void syncChildFades() {
      Iterator<Component> keys = this.childFades.keySet().iterator();

      while (keys.hasNext()) {
         if (!this.ownedChildren.contains(keys.next())) {
            keys.remove();
         }
      }

      for (Component child : this.ownedChildren) {
         ModuleCard.Anim anim = this.childFades.get(child);
         if (anim == null) {
            anim = new ModuleCard.Anim();
            this.childFades.put(child, anim);
         }

         float value = childTabVisible(child) ? 1.0F : 0.0F;
         anim.from = value;
         anim.current = value;
         anim.target = value;
         anim.duration = 0.22F;
         anim.easing = 0;
         anim.start = ModuleCard.Anim.now();
         anim.running = false;
      }
   }

   private void refreshChildFades() {
      for (Entry<Component, ModuleCard.Anim> entry : this.childFades.entrySet()) {
         if (this.ownedChildren.contains(entry.getKey())) {
            ModuleCard.Anim anim = entry.getValue();
            float value = childTabVisible(entry.getKey()) ? 1.0F : 0.0F;
            if (anim.target != value) {
               long time = ModuleCard.Anim.now();
               float current = anim.advance(time);
               anim.from = current;
               anim.target = value;
               anim.start = time;
               anim.running = true;
            }

            anim.advance(ModuleCard.Anim.now());
         }
      }
   }

   private float childWeight(Component child) {
      ModuleCard.Anim anim = this.childFades.get(child);
      if (anim == null) {
         return childTabVisible(child) ? 1.0F : 0.0F;
      } else {
         return anim.current;
      }
   }

   private boolean anyChildShown() {
      if (!featureIsOn(this.feature) || modulesDimmed()) {
         for (Component child : this.ownedChildren) {
            if (childTabVisible(child) || 0.001F < this.childWeight(child)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean childShown(Component child) {
      return childTabVisible(child) || 0.001F < this.childWeight(child);
   }

   private List<Component> collectActiveChildren() {
      List<Component> active = new ArrayList<>();

      for (Component child : this.ownedChildren) {
         if (0.5F < this.childWeight(child)) {
            active.add(child);
         }
      }

      return active;
   }

   public float measureHeight() {
      float value = this.revealAnim.current;
      if (!(value <= 0.001F) && this.anyChildShown()) {
         this.syncChildWidths();
         float gap = 12.0F;
         float total = 0.0F;
         float sum = 58.0F;

         for (Component child : this.ownedChildren) {
            float weight = this.childWeight(child);
            if (0.001F < weight) {
               float childHeight = child.preferredHeight();
               float scaledGap = weight * gap;
               if (total <= 0.0F) {
                  scaledGap = 0.0F;
               }

               sum = sum + scaledGap + childHeight * weight;
               total = total + weight * gap + childHeight * weight;
            }
         }

         value = (sum + 18.0F - 60.0F) * value + 60.0F;
         this.height = value;
      } else {
         value = 60.0F;
         this.height = 60.0F;
      }

      return value;
   }

   private float headerLayout(float headerX, float headerY) {
      float value;
      if (featureIsOn(this.feature) && !modulesDimmed()) {
         float headerWidth = this.width - 36.0F;
         float measured = measureHeaderText();
         value = headerWidth + headerX - measured;
      } else {
         float switcherX = this.width - 36.0F + headerX - 28.0F;
         this.switcher.y = headerY + 4.0F;
         float favouriteY = headerY + 6.0F;
         this.switcher.x = switcherX;
         this.favourite.y = favouriteY;
         float favouriteX = switcherX - 4.0F - 12.0F;
         this.favourite.x = favouriteX;
         float bindWidth;
         if (this.bind.bindTarget == null) {
            bindWidth = 0.0F;
         } else {
            this.bind.preferredWidth();
            bindWidth = this.bind.field0xE0 + 22.0F + 8.0F + 8.0F;
            if (bindWidth <= 46.0F) {
               bindWidth = 46.0F;
            }
         }

         this.bind.width = bindWidth;
         float bindX = favouriteX - 4.0F - bindWidth;
         this.bind.y = headerY + 0.0F;
         this.bind.x = bindX;
         if (featureIsOn(this.feature)) {
            if (0.0F < bindWidth) {
               bindX -= 4.0F;
            }

            float[] metrics = iconMetrics(75);
            bindX -= metrics[0] + 16.0F;
         }

         value = bindX;
      }

      return value;
   }

   private void renderHeader(Object mat, float mouseX, float mouseY, float alpha, float headerX, float headerY) {
      theme();
      int style = textStyleIndex(featureStyleKind(this.feature));
      setTextStyle(mat, style);
      float labelX = this.headerLayout(headerX, headerY);
      if (featureIsOn(this.feature) && !modulesDimmed()) {
         float labelY = headerY + 0.0F;
         float measured = measureHeaderText();
         drawLabel(mat, labelX, labelY, alpha);
         if (labelX <= mouseX
            && mouseX <= measured + labelX
            && labelY <= mouseY
            && mouseY <= labelY + 24.0F
            && (Screen.focusedInput == null || Screen.allowHover)) {
            Screen.hoveredWidget = 7;
            if (Screen.focusedInput == null || Screen.allowHover) {
               showTooltip("Только для бета-тестеров", 0.0F, labelY, measured, 0.0F, labelX);
            }
         }
      } else {
         if (moduleVersionFloor() < featureVersion(this.feature)) {
            this.renderVersionBadge(mat, mouseX, mouseY);
         } else {
            this.switcher.render(mat, mouseX, mouseY);
         }

         this.favourite.render(mat, mouseX, mouseY, alpha);
         this.bind.render(mat, mouseX, mouseY, alpha);
         if (featureIsOn(this.feature)) {
            drawBadgeIcon(mat, labelX, headerY + 0.0F, alpha);
         }
      }

      float textX = headerX + 12.0F + 6.0F;
      float available = labelX - 8.0F - textX;
      if (available <= 0.0F) {
         available = 0.0F;
      }

      theme();
      String name = ellipsize(featureName(this.feature), available, 16.0F);
      drawTextStyle(5, mat, name, textX);
   }

   private void renderVersionBadge(Object mat, float mouseX, float mouseY) {
      float badgeX = this.switcher.x + 6.0F;
      float badgeY = this.switcher.y + 0.0F;
      drawTextStyle(mat, 56, badgeX, badgeY);
      if (badgeX <= mouseX && mouseX <= badgeX + 16.0F && badgeY <= mouseY && mouseY <= badgeY + 16.0F && (Screen.focusedInput == null || Screen.allowHover)) {
         Screen.hoveredWidget = 7;
         showTooltip("Только с " + this.versionLabel, 0.0F, badgeY, 16.0F, 0.0F, badgeX);
      }
   }

   private void layoutChildRow(float childX, float rowY) {
      float total = 0.0F;

      for (Component child : this.ownedChildren) {
         float weight = this.childWeight(child);
         if (0.001F < weight) {
            if (0.0F < total) {
               rowY += weight * 12.0F;
            }

            child.setPosition(childX, rowY);
            float childHeight = child.preferredHeight();
            rowY += childHeight * weight;
            total = total + childHeight * weight + weight * 12.0F;
         }
      }
   }

   private void renderChildren(Object mat, float mouseX, float mouseY, float alpha) {
      float press;
      if (this.highlightedChild == null) {
         press = 0.0F;
      } else {
         press = this.childPressAnim.advance(ModuleCard.Anim.now());
      }

      if (this.highlightedChild != null && press <= 0.001F && this.childPressAnim.target <= 0.001F) {
         this.highlightedChild = null;
      }

      if (press <= 0.001F) {
         for (Component child : this.ownedChildren) {
            float weight = this.childWeight(child);
            if (0.001F < weight) {
               child.render(mat, mouseX, mouseY, weight * alpha);
            }
         }
      } else {
         for (Component childx : this.ownedChildren) {
            float weight = this.childWeight(childx);
            if (0.001F < weight) {
               if (childx == this.highlightedChild) {
                  float childHeight = childx.preferredHeight();
                  drawBox(
                     mat,
                     childx.x - 6.0F,
                     childx.y - 6.0F,
                     childx.width + 12.0F,
                     childHeight + 12.0F,
                     8.0F,
                     dimColor(themeColor(20), 0.08F),
                     weight * alpha * press
                  );
               }

               childx.render(mat, mouseX, mouseY, weight * alpha);
            }
         }
      }
   }

   private static int textStyleIndex(int kind) {
      if (kind == 0) {
         return 3;
      } else if (kind == 1) {
         return 4;
      } else if (kind == 2) {
         return 7;
      } else if (kind == 3) {
         return 8;
      } else if (kind == 4) {
         return 28;
      } else {
         return kind == 5 ? 2 : 1;
      }
   }

   private static void invokeChildLayout(Component child, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static boolean childAcceptsMouse(Component child, double mx, double my) {
      return false;
   }

   private static boolean invokeChildKeyPressed(Component child, int keyCode) {
      return false;
   }

   private static boolean featureToggled(Object feature) {
      return featureEnabled(feature) != 0 && !moduleFilterActive() && moduleFilterCount() >= 1
         ? (moduleFilterTokenA() ^ moduleFilterTokenB()) == -1L && moduleFilterTokenB() != 0L
         : false;
   }

   private static boolean childTabVisible(Component child) {
      Object tab = childTab(child);
      return tab == null || tabVisible(tab);
   }

   private static Object childTab(Component child) {
      return null;
   }

   private static boolean tabVisible(Object tab) {
      return true;
   }

   private static byte featureEnabled(Object feature) {
      return 0;
   }

   private static boolean featureFavourite(Object feature) {
      return false;
   }

   private static boolean featureExpandable(Object feature) {
      return false;
   }

   private static void setFeatureExpandable(Object feature, boolean value) {
   }

   private static boolean featureIsOn(Object feature) {
      return false;
   }

   private static int featureStyleKind(Object feature) {
      return 0;
   }

   private static int featureVersion(Object feature) {
      return 0;
   }

   private static Object featureBindTarget(Object feature) {
      return null;
   }

   private static String featureName(Object feature) {
      return "";
   }

   private static List<Object> featureSettings(Object feature) {
      return new ArrayList<>();
   }

   private static Component createSettingWidget(Object setting) {
      return null;
   }

   private static boolean moduleFilterActive() {
      return false;
   }

   private static int moduleFilterCount() {
      return 0;
   }

   private static long moduleFilterTokenA() {
      return 0L;
   }

   private static long moduleFilterTokenB() {
      return 0L;
   }

   private static boolean modulesDimmed() {
      return false;
   }

   private static int moduleVersionFloor() {
      return 0;
   }

   private Object createToggleCallback() {
      return null;
   }

   private Object createFavouriteCallback() {
      return null;
   }

   private void releaseChildFades() {
      this.childFades.clear();
   }

   private void releaseOwnedChildren() {
      this.ownedChildren.clear();
   }

   private static void detachChild(Component child) {
   }

   private static void releaseCallback(Object sub, boolean heap) {
   }

   private static void playSound(int id) {
   }

   private static void theme() {
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static int dimColor(int color, float factor) {
      return 0;
   }

   private static float[] iconMetrics(int icon) {
      return new float[2];
   }

   private static float measureHeaderText() {
      return 0.0F;
   }

   private static String ellipsize(String text, float maxWidth, float extra) {
      return text;
   }

   private static void setTextStyle(Object mat, int style) {
   }

   private static void drawPanel(Object mat, float x, float y, float width, float height, float radius, float alpha) {
   }

   private static void drawRoundedBox(
      Object mat,
      float x,
      float y,
      float width,
      float height,
      float radiusTL,
      float radiusTR,
      float radiusBR,
      float radiusBL,
      int fillTop,
      int fillBottom,
      float fillAlpha,
      int borderColor,
      float borderWidth,
      float borderAlpha,
      float shadowAlpha,
      float alpha,
      int flags
   ) {
   }

   private static void drawBox(Object mat, float x, float y, float width, float height, float radius, int color, float alpha) {
   }

   private static void drawLabel(Object mat, float x, float y, float alpha) {
   }

   private static void drawBadgeIcon(Object mat, float x, float y, float alpha) {
   }

   private static void drawTextStyle(Object mat, int style, float x, float y) {
   }

   private static void drawTextStyle(int style, Object mat, String text, float x) {
   }

   private static void showTooltip(String text, float arg300, float arg304, float arg308, float arg320, float arg328) {
   }

   private static void pushScissor(float x, float y, float width, float height) {
   }

   private static void popScissor() {
   }

   private static float clamp01(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }
}

