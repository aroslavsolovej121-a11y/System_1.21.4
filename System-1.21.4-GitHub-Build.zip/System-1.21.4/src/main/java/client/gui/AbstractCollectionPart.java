package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class AbstractCollectionPart extends Component {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_DELETING_DTOR = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_MOUSE_RELEASED = 40;
   public static final int SLOT_MOUSE_MOVED = 48;
   public static final int SLOT_MOUSE_SCROLLED = 56;
   public static final int SLOT_KEY_PRESSED = 64;
   public static final int SLOT_CHAR_TYPED = 72;
   public static final int SLOT_KEY_RELEASED = 80;
   public static final int SLOT_SET_POSITION = 88;
   public static final int SLOT_HEADER_HEIGHT = 96;
   public static final int COMPONENT_CHILDREN_BEGIN = 144;
   public static final int COMPONENT_CHILDREN_END = 152;
   public static final int COMPONENT_FOCUSED = 216;
   public static final float DEFAULT_WIDTH = 964.0F;
   public static final float ANIM_DURATION_SCROLL = 0.28F;
   public static final float ANIM_DURATION_TAB = 0.22F;
   public static final float LAYOUT_ALPHA_DURATION = 0.16F;
   public static final float SCROLL_EPSILON = 0.001F;
   public static final float SCROLLBAR_WIDTH = 14.0F;
   public static final float SCROLLBAR_HEIGHT = 59.0F;
   public static final float SCROLL_STEP = 48.0F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float SCROLL_EDGE = 2.0F;
   public static final float LIST_PAD_TOP = 16.0F;
   public static final float LIST_PAD_BOTTOM = 57.0F;
   public static final float TAB_ALPHA_HIDDEN = 1.0F;
   public static final float TAB_ALPHA_SHOWN = 0.0F;
   public static final float EASE_IN_EXPO_RATE = -6.931472F;
   public static final double NANOS = 1.0E9;
   public static final int EASE_OUT_CUBIC = 0;
   public static final int EASE_IN_CUBIC = 1;
   public static final int EASE_OUT_EXPO = 2;
   public static final int KEY_ESCAPE = 27;
   public static final int KEY_ENTER = 13;
   protected BoardToolbar boardToolbar;
   protected AbstractCollectionPart.AddTileBox addTile;
   protected AbstractCollectionPart.LayoutListener layoutListener;
   protected Object layoutCallback;
   protected final List<Component> rows = new ArrayList<>();
   protected boolean layoutDirty;
   protected int boardLayout;
   protected float layoutAlphaA = 1.0F;
   protected float layoutAlphaB = 1.0F;
   protected float layoutFade = 1.0F;
   protected float easePow = 0.16F;
   protected int layoutEase = 0;
   protected long lastTime;
   protected boolean suppressClick;
   protected boolean overlayBlocked;
   protected float layoutCache0;
   protected float hitLimitY;
   protected float contentTop;
   protected boolean dragging;
   protected float dragOffset;
   protected float layoutCache1;
   protected final AbstractCollectionPart.Anim scrollAnim = new AbstractCollectionPart.Anim(0.0F, 0.28F, 2);

   public AbstractCollectionPart() {
   }

   public AbstractCollectionPart(BoardToolbar toolbar, AbstractCollectionPart.AddTileBox tile) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.scroll = 0.0F;
      this.scrollLimit = 0.0F;
      this.boardToolbar = toolbar;
      this.addTile = tile;
      this.layoutListener = null;
      this.rows.clear();
      this.layoutDirty = false;
      this.boardLayout = 0;
      this.layoutAlphaA = 1.0F;
      this.layoutAlphaB = 1.0F;
      this.layoutFade = 1.0F;
      this.easePow = 0.16F;
      this.layoutEase = 0;
      this.lastTime = this.now();
      this.suppressClick = false;
      this.overlayBlocked = false;
      this.layoutCache0 = 0.0F;
      this.layoutCache1 = 0.0F;
      this.hitLimitY = 0.0F;
      this.dragging = false;
      this.dragOffset = 0.0F;
      this.width = 964.0F;
      this.layoutEase = 1;
      if (this.boardToolbar != null) {
         this.boardToolbar.onLayoutRequested = this::onBoardLayoutRequested;
      }
   }

   protected void onBoardLayoutRequested(AbstractCollectionPart.BoardLayout layout) {
      this.setBoardLayout(layout.ordinal(), true);
   }

   public void setBoardLayout(AbstractCollectionPart.BoardLayout layout, boolean animate) {
      this.setBoardLayout(layout.ordinal(), animate);
   }

   public void setBoardLayout(int layout, boolean animate) {
      BoardToolbar toolbar = this.boardToolbar;
      if (toolbar != null && toolbar.tabLayoutIndex != layout) {
         toolbar.tabLayoutIndex = layout;
         float v = 1.0F;
         if (layout == AbstractCollectionPart.BoardLayout.LIST.ordinal()) {
            v = 0.0F;
         }

         toolbar.tabAlphaA = v;
         toolbar.tabAlphaB = v;
         toolbar.tabAlphaTarget = v;
         toolbar.tabAlphaRunning = false;
      }

      if (layout == this.boardLayout) {
         if (!animate) {
            return;
         }
      } else {
         if (!animate) {
            this.boardLayout = layout;
            this.layoutDirty = true;
            return;
         }

         this.animateLayout(layout);
      }

      if (this.layoutListener != null) {
         this.layoutListener.acceptInt(layout);
      }
   }

   public void requestLayout(int layout) {
      this.boardLayout = layout;
      this.layoutDirty = true;
   }

   protected void animateLayout(int layout) {
      this.layoutCallback = new AbstractCollectionPart.LayoutCallback(this, layout);
      this.overlayBlocked = true;
      this.easePow = 0.16F;
      this.layoutEase = 1;
      if (this.layoutFade != 0.0F) {
         float current = advanceAnim(this.layoutEase, this.layoutAlphaA, this.layoutAlphaB, this.layoutFade, this.easePow, this.lastTime, this.suppressClick);
         this.layoutAlphaA = current;
         this.layoutAlphaB = current;
         this.layoutFade = 0.0F;
         this.lastTime = this.now();
         this.suppressClick = true;
      }
   }

   protected static float advanceAnim(int ease, float from, float current, float target, float duration, long start, boolean running) {
      if (running && !(duration <= 0.0F)) {
         float t = (float)((System.nanoTime() - start) / 1.0E9) / duration;
         if (t <= 0.0F) {
            return from;
         } else {
            return t >= 1.0F ? target : easeValue(ease, t) * (target - from) + from;
         }
      } else {
         return target;
      }
   }

   public static float easeValue(int ease, float t) {
      if (ease == 1) {
         return easeInCubic(t);
      } else {
         return ease == 2 ? easeOutExpo(t) : easeOutCubic(t);
      }
   }

   public static float easeOutExpo(float t) {
      return t < 1.0F ? (float)(1.0 - Math.exp(t * -6.931472F)) : 1.0F;
   }

   @Override
   public void updateAlpha(long time) {
      this.scrollAnim.advance(time);
      this.layoutAlphaB = advanceAnim(this.layoutEase, this.layoutAlphaA, this.layoutAlphaB, this.layoutFade, this.easePow, this.lastTime, this.suppressClick);
   }

   public float scrollRange() {
      float v = this.height - 57.0F;
      if (v <= 0.0F) {
         v = 0.0F;
      }

      v -= 2.0F;
      if (v <= 0.0F) {
         v = 0.0F;
      }

      return v;
   }

   public float scrollTrack() {
      float v = this.scrollLimit - this.height + 16.0F;
      if (v <= 0.0F) {
         v = 0.0F;
      }

      return v;
   }

   public float scrollOffset() {
      return this.thumbY();
   }

   public float thumbY() {
      float track = this.scrollTrack();
      if (track <= 0.0F) {
         return this.y + 57.0F;
      } else {
         float range = this.scrollRange();
         float ratio = this.scroll / track;
         if (ratio < 0.0F) {
            ratio = 0.0F;
         }

         if (ratio > 1.0F) {
            ratio = 1.0F;
         }

         return (range - 59.0F) * ratio + (this.y + 57.0F);
      }
   }

   public boolean scrollBarHit(double mx, double my) {
      float track = this.scrollTrack();
      if (!(track > 0.001F)) {
         return false;
      } else {
         float range = this.scrollRange();
         if (!(range > 0.0F)) {
            return false;
         } else {
            float ty = this.thumbY();
            float tx = this.x + this.width - 2.0F - 2.0F - 14.0F;
            return mx >= tx && mx <= tx + 14.0F && my >= ty && my <= ty + 59.0F;
         }
      }
   }

   public boolean selfHit(double mx, double my) {
      return mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.boardToolbar != null && this.boardToolbar.mouseClicked(mx, my, button)) {
         return true;
      } else if (this.hitLimitY > my) {
         return this.selfHit(mx, my);
      } else if (this.overlayBlocked) {
         return true;
      } else if (button == 0 && this.scrollBarHit(mx, my)) {
         this.dragging = true;
         float py = (float)my;
         this.dragOffset = py - this.thumbY();
         return true;
      } else if (this.x > mx) {
         return false;
      } else if (this.x + this.width < mx) {
         return false;
      } else if (this.contentTop < my) {
         return false;
      } else {
         for (Component child : new ArrayList<>(this.children)) {
            if (child.mouseClicked(mx, my, button)) {
               return true;
            }
         }

         AbstractCollectionPart.AddTileBox tile = this.addTile;
         if (tile != null) {
            if (tile.plateClicked(mx, my, button)) {
               return true;
            }

            if (button == 0 && this.selfHit(mx, my)) {
               if (tile.plateHasText()) {
                  tile.plateCommit();
                  return true;
               }

               if (tile.cursor != null) {
                  tile.cursor.mouseClicked(mx, my, button);
                  return true;
               }

               if (!tile.plateFocused) {
                  tile.plateFocused = true;
                  tile.focusAnim.setTarget(1.0F, this.now());
                  tile.notifyTextFocusChanged();
                  return true;
               }

               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.dragging && button == 0) {
         this.dragging = false;
         return true;
      } else {
         for (Component child : this.children) {
            if (child.mouseReleased(mx, my, button)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      return this.mouseMoved(mx, my, (int)delta, 0.0, 0.0);
   }

   public boolean mouseMoved(double mx, double my, int buttons, double unusedA, double unusedB) {
      if (this.dragging && buttons == 0) {
         float range = this.height - 57.0F;
         if (range <= 0.0F) {
            range = 0.0F;
         }

         float track = this.scrollLimit - this.height + 16.0F;
         if (track <= 0.0F) {
            track = 0.0F;
         }

         range -= 2.0F;
         if (range <= 0.0F) {
            range = 0.0F;
         }

         float v = 0.0F;
         if (0.0F < range - 59.0F) {
            float ratio = ((float)my - this.dragOffset - (this.y + 59.0F)) / (range - 59.0F) * track;
            v = ratio;
            if (ratio < 0.0F) {
               v = 0.0F;
            }

            if (v > track) {
               v = track;
            }
         }

         this.scroll = v;
         this.scrollAnim.setTarget(v, this.now());
         return true;
      } else {
         for (Component child : this.children) {
            if (child.mouseMoved(mx, my, buttons)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (this.hitLimitY <= my) {
         if (!this.overlayBlocked) {
            if (this.x > mx) {
               return false;
            }

            if (this.x + this.width < mx) {
               return false;
            }

            if (this.y > my) {
               return false;
            }

            if (this.height + this.y < my) {
               return false;
            }

            float track = this.scrollLimit - this.height + 16.0F;
            if (track <= 0.0F) {
               track = 0.0F;
            }

            float v = this.scroll - (float)amount * 48.0F;
            if (v < 0.0F) {
               v = 0.0F;
            }

            if (v > track) {
               v = track;
            }

            this.scroll = v;
            this.scrollAnim.setTarget(v, this.now());
         }
      } else if (this.x > mx || this.x + this.width < mx || this.y > my || this.y + this.height < my) {
         return false;
      }

      return true;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      for (Component part : this.children) {
         for (Component child : part.children) {
            if (child.focused) {
               return part.keyPressed(keyCode, modifiers);
            }
         }
      }

      if (this.boardToolbar != null && this.boardToolbar.overlayOpen()) {
         return this.boardToolbar.plateKeyPressed(keyCode);
      } else {
         return this.addTile != null && this.addTile.plateFocused ? this.addTile.plateKeyPressed(keyCode) : false;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      return this.keyReleased(keyCode, 0);
   }

   public boolean keyReleased(int keyCode, int mods) {
      for (Component part : this.children) {
         for (Component child : part.children) {
            if (child.focused) {
               return part.keyReleased(keyCode);
            }
         }
      }

      if (this.boardToolbar == null || !this.boardToolbar.overlayOpen()) {
         AbstractCollectionPart.AddTileBox tile = this.addTile;
         return tile == null || !tile.plateFocused || tile.keyFilter != null && !tile.acceptsKey(keyCode) ? false : tile.insertTextChar(keyCode);
      } else {
         return this.boardToolbar.keyFilter != null && !this.boardToolbar.acceptsKey(keyCode) ? false : this.boardToolbar.insertTextChar(keyCode);
      }
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   public float headerHeight() {
      return 0.0F;
   }

   @Override
   public void dispose() {
      this.layoutCallback = null;
      this.layoutListener = null;
      this.rows.clear();
      if (this.boardToolbar != null) {
         this.boardToolbar.dispose();
      }

      if (this.addTile != null) {
         this.addTile.dispose();
      }

      super.dispose();
   }

   public static class AddTileBox extends Component {
      public Consumer<String> onSubmitText;
      public Runnable onSubmitEmpty;
      public Component cursor;
      public Component inputField;
      public Component keyFilter;
      public boolean plateFocused;
      public boolean overlayOpen;
      public String text = "";
      public float hover;
      public float plateX;
      public float plateY;
      public float plateWidth;
      public float plateHeight;
      public final AbstractCollectionPart.Anim focusAnim = new AbstractCollectionPart.Anim(0.0F, 0.28F, 2);

      public boolean plateRectHit(double mx, double my) {
         return mx >= this.plateX && mx <= this.plateX + this.plateWidth && my >= this.plateY && my <= this.plateY + this.plateHeight;
      }

      public boolean hasText() {
         return this.plateHasText();
      }

      public void setText(String value) {
         this.text = value;
      }

      public boolean plateClicked(double mx, double my, int button) {
         if (button != 0) {
            return false;
         } else {
            boolean inside = mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
            this.setHover(inside ? 1.0F : 0.0F);
            return inside;
         }
      }

      public void setHover(float value) {
         this.hover = value;
      }

      public boolean plateHasText() {
         return this.trimmed().length() != 0;
      }

      public String trimmed() {
         int start = 0;
         int end = this.text.length();

         while (start < end && this.text.charAt(start) <= ' ') {
            start++;
         }

         while (end > start && this.text.charAt(end - 1) <= ' ') {
            end--;
         }

         return this.text.substring(start, end);
      }

      public boolean plateCommit() {
         String value = this.trimmed();
         if (value.length() == 0) {
            return false;
         } else {
            if (this.onSubmitText != null) {
               this.onSubmitText.accept(value);
            }

            this.clearText();
            if (this.plateFocused) {
               this.plateFocused = false;
               this.focusAnim.setTarget(0.0F, this.now());
               this.notifyTextFocusChanged();
            }

            return true;
         }
      }

      public void clearText() {
         this.text = "";
      }

      public boolean plateKeyPressed(int keyCode) {
         if (!this.plateFocused) {
            return false;
         } else if (keyCode == 27) {
            this.plateFocused = false;
            this.focusAnim.setTarget(0.0F, this.now());
            this.notifyTextFocusChanged();
            return true;
         } else if (keyCode == 13) {
            this.plateCommit();
            return true;
         } else {
            return this.insertTextChar(keyCode);
         }
      }

      public boolean insertTextChar(int keyCode) {
         if (keyCode >= 32 && keyCode != 127) {
            this.text = this.text + (char)keyCode;
            return true;
         } else {
            return false;
         }
      }

      public void notifyTextFocusChanged() {
      }

      public boolean acceptsKey(int keyCode) {
         return this.keyFilter == null;
      }
   }

   public static class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int ease;
      public long start;
      public boolean running;

      public Anim(float value, float duration, int ease) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.ease = ease;
         this.start = System.nanoTime();
         this.running = false;
      }

      public void setTarget(float value, long now) {
         if (this.target != value) {
            this.advance(now);
            this.from = this.current;
            this.target = value;
            this.start = now;
            this.running = true;
         }
      }

      public void advance(long now) {
         if (this.running && !(this.duration <= 0.0F)) {
            float t = (float)((now - this.start) / 1.0E9) / this.duration;
            if (t <= 0.0F) {
               this.current = this.from;
            } else if (t >= 1.0F) {
               this.running = false;
               this.current = this.target;
            } else {
               this.current = AbstractCollectionPart.easeValue(this.ease, t) * (this.target - this.from) + this.from;
            }
         } else {
            this.current = this.target;
            this.running = false;
         }
      }

      public float value() {
         return this.current;
      }
   }

   public static enum BoardLayout {
      CARD,
      LIST,
      BOARD;
   }

   public static class LayoutCallback implements Runnable {
      private final AbstractCollectionPart owner;
      private final int layout;

      public LayoutCallback(AbstractCollectionPart owner, int layout) {
         this.owner = owner;
         this.layout = layout;
      }

      @Override
      public void run() {
         if (this.owner != null) {
            this.owner.boardLayout = this.layout;
            this.owner.layoutDirty = true;
         }
      }
   }

   public interface LayoutListener {
      void acceptInt(int var1);
   }
}

