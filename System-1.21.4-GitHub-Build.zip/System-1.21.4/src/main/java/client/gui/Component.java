package client.gui;

import java.util.ArrayList;
import java.util.List;

public class Component {
   public static final int FLAG_DEFAULT = 256;
   public static final long NANOS_PER_SECOND = 1000000000L;
   public static final long NANOS_PER_MILLI = 1000000L;
   public static final int ANIM_FROM = 0;
   public static final int ANIM_CURRENT = 4;
   public static final int ANIM_TARGET = 8;
   public static final int ANIM_DURATION = 12;
   public static final int ANIM_EASING = 16;
   public static final int ANIM_START = 24;
   public static final int ANIM_RUNNING = 32;
   protected float x;
   protected float y;
   protected float width;
   protected float height;
   protected int flags = 256;
   protected Component parent;
   protected final List<Component> children = new ArrayList<>();
   protected float animFrom;
   protected float alpha;
   protected float alphaTarget;
   protected float alphaDuration;
   protected long alphaStart;
   protected boolean alphaRunning;
   protected float animXFrom;
   protected float animXCurrent;
   protected float animXTarget;
   protected float animYFrom;
   protected float animYCurrent;
   protected float animYTarget;
   protected long animStart;
   protected float animDuration;
   protected boolean animatingPosition;
   protected float scroll;
   protected float scrollLimit;
   protected boolean mouseOwned;
   protected boolean focused;
   protected long lastInputTime;
   protected Component capture;
   protected boolean hovered;
   protected final Component.Anim hoverAnim = new Component.Anim();
   public static Component hoveredComponent;
   public static boolean cursorSuppressed;
   public static int cursorStyle;
   public static float mouseX;
   public static float mouseY;
   public static final int ICON_INVALID = 89;

   protected long now() {
      return System.nanoTime();
   }

   public float getX() {
      return this.x;
   }

   public float getY() {
      return this.y;
   }

   public float getWidth() {
      return this.width;
   }

   public float getHeight() {
      return this.height;
   }

   public int getFlags() {
      return this.flags;
   }

   public Component getParent() {
      return this.parent;
   }

   public List<Component> getChildren() {
      return this.children;
   }

   public boolean isVisible() {
      return (this.flags & 256) != 0;
   }

   public void setVisible(boolean value) {
      if (value) {
         this.flags |= 256;
      } else {
         this.flags &= -257;
      }
   }

   public void add(Component child) {
      if (child != null) {
         child.parent = this;
         this.children.add(child);
      }
   }

   public void remove(Component child) {
      if (child != null) {
         this.children.remove(child);
      }
   }

   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   public void setSize(float width, float height) {
      this.width = width;
      this.height = height;
   }

   public boolean contains(double mx, double my) {
      return mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
   }

   public float getAlpha() {
      return this.alpha;
   }

   public void setAlpha(float value) {
      this.alpha = value;
   }

   public void animateAlpha(float target, float duration) {
      if (this.alphaTarget != target) {
         this.animFrom = this.alpha;
         this.alphaStart = this.now();
         this.alphaTarget = target;
         this.alphaDuration = duration;
         this.alphaRunning = true;
      }
   }

   public void updateAlpha(long time) {
      if (this.alphaRunning && !(this.alphaDuration <= 0.0F)) {
         float t = (float)((time - this.alphaStart) / 1.0E9) / this.alphaDuration;
         if (t <= 0.0F) {
            this.alpha = this.animFrom;
         } else if (t >= 1.0F) {
            this.alphaRunning = false;
            this.alpha = this.alphaTarget;
         } else {
            this.alpha = easeOutCubic(t) * (this.alphaTarget - this.animFrom) + this.animFrom;
         }
      } else {
         this.alpha = this.alphaTarget;
         this.alphaRunning = false;
      }
   }

   public void updatePositionAnimation(long time) {
      if (this.animatingPosition && this.animXCurrent != this.animXTarget) {
         float t = (float)((time - this.animStart) / 1.0E9) / this.animDuration;
         if (t <= 0.0F) {
            this.animXCurrent = this.animXFrom;
         } else if (t >= 1.0F) {
            this.animatingPosition = false;
            this.animXCurrent = this.animXTarget;
         } else {
            this.animXCurrent = easeOutCubic(t) * (this.animXTarget - this.animXFrom) + this.animXFrom;
         }
      }

      if (this.animatingPosition && this.animYCurrent != this.animYTarget) {
         float t = (float)((time - this.animStart) / 1.0E9) / this.animDuration;
         if (t <= 0.0F) {
            this.animYCurrent = this.animYFrom;
         } else if (t >= 1.0F) {
            this.animatingPosition = false;
            this.animYCurrent = this.animYTarget;
         } else {
            this.animYCurrent = easeOutCubic(t) * (this.animYTarget - this.animYFrom) + this.animYFrom;
         }
      }
   }

   public static float easeOutCubic(float t) {
      float inv = 1.0F - t;
      return 1.0F - inv * inv * inv;
   }

   public static float easeInCubic(float t) {
      return t * t * t;
   }

   public float uiHoverTest(float mx, float my) {
      boolean outside = mx < this.x || this.x + this.width < mx || my < this.y || this.y + this.height < my || hoveredComponent != null && !cursorSuppressed;
      float target;
      if (outside) {
         this.hovered = false;
         target = 0.0F;
      } else {
         this.hovered = true;
         target = 1.0F;
      }

      long time = this.now();
      this.hoverAnim.retarget(target, time);
      this.hoverAnim.update(time);
      return this.hoverAnim.current;
   }

   public boolean hitTest(double mx, double my) {
      return mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
   }

   public boolean hitTest(double mx, double my, float inset) {
      float hx = (this.width - inset) * 0.5F + this.x;
      float hy = (this.height - inset) * 0.5F + this.y;
      return hx <= mx && mx <= hx + inset && hy <= my && my <= hy + inset;
   }

   public static int uiThemeColor(int index) {
      return uiThemeColor(uiTheme(), index);
   }

   public static int uiThemeColor(Object theme, int offset) {
      return 0;
   }

   public static Object uiTheme() {
      return null;
   }

   public static void uiSound(int id) {
   }

   public static int uiLerpColor(int from, int to, float t) {
      if (t <= 0.0F) {
         return from;
      } else if (t >= 1.0F) {
         return to;
      } else {
         int out = 0;

         for (int shift = 0; shift < 32; shift += 8) {
            float a = from >>> shift & 0xFF;
            float b = to >>> shift & 0xFF;
            int v = (int)((b - a) * t + a);
            out |= v << shift;
         }

         return out;
      }
   }

   public static float[] uiIconMetrics(int icon) {
      return new float[2];
   }

   public static void uiDrawIcon(Object renderer, int icon, float x, float y, float w, float h, int color, float alpha) {
   }

   public static void uiDrawBox(
      Object renderer,
      float x,
      float y,
      float w,
      float h,
      float radiusTL,
      float radiusTR,
      float radiusBR,
      float radiusBL,
      int fillTop,
      int fillBottom,
      float fillAlpha,
      int borderColor,
      float borderWidth,
      float borderAlpha,
      float shadowAlpha,
      float alpha,
      int flags
   ) {
   }

   public static void uiDrawBox(Object renderer, float x, float y, float w, float h, int color, float alpha) {
      uiDrawBox(renderer, x, y, w, h, 0.0F, 0.0F, 0.0F, 0.0F, color, color, 1.0F, 0, 0.0F, 1.0F, 0.0F, alpha, 0);
   }

   public static void uiDrawBox(Object renderer, float x, float y, float w, float h, float radius, int color, float alpha) {
      uiDrawBox(renderer, x, y, w, h, radius, radius, radius, radius, color, color, 1.0F, 0, 0.0F, 1.0F, 0.0F, alpha, 0);
   }

   public void tick() {
   }

   public boolean isActive() {
      return false;
   }

   public boolean onClick() {
      return true;
   }

   public void render() {
   }

   public void render(Object renderer, float px, float py, float alpha) {
      this.render();
   }

   public void render(Object renderer, float px, float py) {
      this.render(renderer, px, py, 1.0F);
   }

   public boolean mouseDragged(double mx, double my, int button) {
      return false;
   }

   public float preferredWidth() {
      return this.width;
   }

   public float preferredHeight() {
      return this.height;
   }

   public void syncRows() {
   }

   public boolean mouseClicked(double mx, double my, int button) {
      return false;
   }

   public boolean mouseReleased(double mx, double my, int button) {
      return false;
   }

   public boolean mouseMoved(double mx, double my, double delta) {
      return false;
   }

   public boolean mouseScrolled(double mx, double my, double amount) {
      return false;
   }

   public boolean keyPressed(int keyCode, int modifiers) {
      return false;
   }

   public boolean keyReleased(int keyCode) {
      return false;
   }

   public boolean charTyped(char ch) {
      return false;
   }

   public void dispose() {
      this.children.clear();
      this.capture = null;
   }

   public static class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public long start;
      public boolean running;

      public Anim() {
      }

      public Anim(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
      }

      public void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.start = System.nanoTime();
         this.running = false;
      }

      public void retarget(float target, long time) {
         if (this.target != target) {
            this.from = this.current;
            this.start = time;
            this.target = target;
            this.running = true;
         }
      }

      public void update(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float t = (float)((time - this.start) / 1.0E9) / this.duration;
            if (t <= 0.0F) {
               this.current = this.from;
            } else if (t >= 1.0F) {
               this.running = false;
               this.current = this.target;
            } else {
               this.current = Component.easeOutCubic(t) * (this.target - this.from) + this.from;
            }
         } else {
            this.current = this.target;
            this.running = false;
         }
      }
   }
}

