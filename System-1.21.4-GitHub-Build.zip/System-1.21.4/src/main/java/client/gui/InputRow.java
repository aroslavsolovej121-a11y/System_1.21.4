package client.gui;

import client.Setting;

public class InputRow extends Component {
   public static final int SLOT_ROW_HEIGHT = 1;
   public static final int SLOT_ROW_HEIGHT_ALIAS = 2;
   public static final int SLOT_UPDATE = 3;
   public static final int SLOT_RENDER = 4;
   public static final int SLOT_MOUSE_CLICKED = 5;
   public static final int SLOT_METRIC = 6;
   public static final int SLOT_SPACING = 7;
   public static final int SLOT_OPACITY = 8;
   public static final int SLOT_ACCENT = 9;
   public static final int SLOT_SET_POSITION = 11;
   public static final int SLOT_KEY_PRESSED = 12;
   public static final int SLOT_KEY_RELEASED = 13;
   public static final int SLOT_CHAR_TYPED = 14;
   public static final int SLOT_COMMIT = 15;
   public static final float ROW_HEIGHT = 26.0F;
   public static final float ROW_SPACING = 4.0F;
   public static final float ROW_OPACITY = 1.0F;
   public static final float DEFAULT_ROW_HEIGHT = 4.5F;
   public static final float FONT_SIZE = 12.0F;
   public static final float FIELD_PAD_X = 8.0F;
   public static final float FIELD_OUTER_W = 96.0F;
   public static final float FIELD_H = 18.0F;
   public static final float FIELD_INNER_W = 84.0F;
   public static final float FIELD_TOP_PAD = 3.0F;
   public static final float FOCUS_DURATION = 0.15F;
   public static final float HOVER_DURATION = 0.15F;
   public static final float HOVER_EASE = 1.7F;
   public static final float EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static InputRow textInputOwner;
   public static boolean textInputActive;
   private static double pointerX;
   private static double pointerY;
   private Object owner;
   private Setting setting;
   private float rowHeight = 4.5F;
   private float reveal;
   private boolean rowVisible;
   private float rowY;
   private int rowFlags;
   private long tag;
   private Setting bound;
   private float boundsX;
   private float boundsY;
   private float boundsWidth;
   private float boundsHeight;
   private String text = "";
   private String value = "";
   private boolean focusedState;
   private final InputRow.Anim focusAnim = new InputRow.Anim(0.0F, 0.15F);
   private final InputRow.Anim hoverAnim = new InputRow.Anim(0.0F, 0.15F);
   private Object callback;
   private Object handler;
   private static final float DRAG_BIAS = 141.0F;
   private static final int BACK_COLOR = -15724524;
   private static final int ACCENT_COLOR = -1;
   private static final int TEXT_COLOR = -2039584;
   public static int cursorHint;

   public InputRow() {
   }

   public InputRow(Object owner, Setting setting) {
      this.owner = owner;
      this.setting = setting;
      this.bound = setting;
      this.text = settingText(setting);
      this.value = this.text;
      long time = this.now();
      this.focusAnim.update(time);
      this.hoverAnim.set(1.0F);
      this.hoverAnim.update(time);
   }

   public InputRow(Object owner, Setting setting, String initial) {
      this(owner, setting);
      if (initial != null) {
         this.text = initial;
         this.value = initial;
      }
   }

   private static String settingText(Setting setting) {
      if (setting == null) {
         return "";
      } else {
         String s = setting.getText();
         if (s == null || s.isEmpty()) {
            s = setting.getName();
         }

         return s == null ? "" : s;
      }
   }

   public float rowHeight() {
      return 26.0F;
   }

   public float rowSpacing() {
      return 4.0F;
   }

   public float opacity() {
      return 1.0F;
   }

   public int accentColor() {
      return -1;
   }

   public float metric(float a, float b) {
      return a + b - 8.0F - 96.0F;
   }

   public float drag(float value) {
      return value + 141.0F;
   }

   public void setReveal(float value) {
      if (this.reveal != value) {
         this.reveal = value;
      }
   }

   public void markVisible() {
      if (!this.rowVisible) {
         this.rowVisible = true;
         this.rowY = 0.0F;
      }
   }

   public void hideAt(float targetY) {
      if (this.rowVisible) {
         this.rowVisible = false;
         this.rowY = targetY <= 0.0F ? 0.0F : targetY;
      }
   }

   public void collapse() {
      this.boundsY = 1.0F;
      this.rowVisible = true;
      this.reveal = 1.0F;
   }

   public float reveal() {
      return this.reveal;
   }

   public boolean rowVisible() {
      return this.rowVisible;
   }

   public float rowY() {
      return this.rowY;
   }

   public Object owner() {
      return this.owner;
   }

   public Setting setting() {
      return this.setting;
   }

   public Setting boundSetting() {
      return this.bound;
   }

   public String text() {
      return this.text;
   }

   public void setText(String value) {
      this.text = value == null ? "" : value;
   }

   public boolean focusedState() {
      return this.focusedState;
   }

   public float measuredHeight() {
      return 26.0F;
   }

   public float measuredWidth() {
      return 26.0F;
   }

   public void update() {
   }

   @Override
   public void tick() {
      this.update();
   }

   @Override
   public void render() {
      this.renderWidget(null, this.x, this.y, this.width, (float)pointerX, (float)pointerY, this.alpha);
   }

   public void renderWidget(Object renderer, float px, float py, float pw, float mx, float my, float alpha) {
      float inner = px + pw - 8.0F - 96.0F;
      float top = py + 4.0F;
      boolean overField = mx >= inner && mx <= inner + 96.0F && my >= top && my <= top + 18.0F;
      if (overField) {
         cursorHint = 2;
      }

      long time = this.now();
      this.focusAnim.update(time);
      float focus = this.focusAnim.current;
      drawRounded(renderer, inner, top, 96.0F, 18.0F, 8.0F, -15724524, alpha);
      if (0.001F < focus) {
         drawOutline(renderer, inner, top, 96.0F, 18.0F, 8.0F, -1, focus * alpha);
      }

      float textX = inner + 8.0F;
      float target = !this.mouseOwned && !this.focusedState ? 1.0F : 0.0F;
      this.hoverAnim.retarget(target, time);
      this.hoverAnim.update(time);
      float hover = this.hoverAnim.current;
      if (0.001F < hover) {
         drawText(renderer, this.value, textX, top + 3.0F, 84.0F, 12.0F, -1, easeHover(hover) * alpha);
      }

      if (hover < 0.999F) {
         drawTextField(renderer, this.text, textX, top + 3.0F, 84.0F, -2039584, (1.0F - hover) * alpha, this.focusedState);
      }

      this.height = top + 18.0F - this.y;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      return this.mouseClickedAt(mx, my, button, this.x, this.y, this.width);
   }

   public boolean mouseClickedAt(double mx, double my, int button, float px, float py, float pw) {
      if (button != 0) {
         return false;
      } else {
         float inner = px + pw - 8.0F - 96.0F;
         float top = py + 4.0F;
         if (mx >= inner && mx <= inner + 96.0F && my >= top && my <= top + 18.0F) {
            this.setFocused(true);
            return true;
         } else {
            this.setFocused(false);
            return false;
         }
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      pointerX = mx;
      pointerY = my;
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      pointerX = mx;
      pointerY = my;
      return false;
   }

   public void setFocused(boolean value) {
      if (this.focusedState != value) {
         this.focusedState = value;
         long time = this.now();
         this.focusAnim.retarget(value ? 1.0F : 0.0F, time);
         this.focusAnim.update(time);
         if (value) {
            requestKeyboardFocus(this);
         } else {
            clearKeyboardFocus(this);
         }
      }
   }

   public void onCommit() {
      if (this.focusedState) {
         this.focusedState = false;
         long time = this.now();
         this.focusAnim.retarget(0.0F, time);
         this.focusAnim.update(time);
         clearKeyboardFocus(this);
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (!this.focusedState) {
         return false;
      } else if (keyCode != 27 && keyCode != 13) {
         textKey(this.text, keyCode);
         return true;
      } else {
         this.onCommit();
         return true;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      return false;
   }

   @Override
   public boolean charTyped(char ch) {
      if (!this.focusedState) {
         return false;
      } else {
         textChar(this.text, ch);
         return true;
      }
   }

   private static void requestKeyboardFocus(InputRow row) {
      textInputOwner = row;
      textInputActive = true;
   }

   private static void clearKeyboardFocus(InputRow row) {
      if (textInputOwner == row || textInputOwner == null) {
         textInputOwner = null;
         textInputActive = false;
      }
   }

   private static float easeHover(float t) {
      float clamped;
      if (t < 0.0F) {
         clamped = 0.0F;
      } else if (t > 1.0F) {
         clamped = 1.0F;
      } else {
         clamped = t;
      }

      return (float)Math.pow(clamped, 1.7F);
   }

   private static void drawRounded(Object renderer, float px, float py, float pw, float ph, float radius, int color, float alpha) {
   }

   private static void drawOutline(Object renderer, float px, float py, float pw, float ph, float radius, int color, float alpha) {
   }

   private static void drawText(Object renderer, String s, float px, float py, float pw, float size, int color, float alpha) {
   }

   private static void drawTextField(Object renderer, String s, float px, float py, float pw, int color, float alpha, boolean focusedNow) {
   }

   private static void textKey(String s, int keyCode) {
   }

   private static void textChar(String s, char ch) {
   }

   public static final class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public long start;
      public boolean running;

      public Anim(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
      }

      public void set(float value) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.running = false;
      }

      public void retarget(float value, long time) {
         if (this.target != value) {
            this.from = this.value(time);
            this.start = time;
            this.target = value;
            this.running = true;
         }
      }

      public float value(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float t = (float)((time - this.start) / 1.0E9) / this.duration;
            if (t <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (t >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = Component.easeOutCubic(t) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      public void update(long time) {
         this.value(time);
      }
   }
}

