package client.gui;

public class IconButton extends AbstractButton {
   public static final int ICON_INVALID = 89;
   public static final float ANIM_INIT_VALUE = 0.0F;
   public static final float ANIM_DURATION = 0.15F;
   protected int icon;
   protected int activeIcon = 89;
   protected boolean clickEnabled = false;
   protected boolean disabled = false;
   protected float iconSize;
   protected String tooltip = "";
   public final AbstractButton.Anim anim = new AbstractButton.Anim(0.0F, 0.15F);

   public IconButton(int icon, float size) {
      this.icon = icon;
      this.activeIcon = 89;
      this.clickEnabled = false;
      this.disabled = false;
      this.iconSize = size;
      this.tooltip = "";
      this.width = size;
      this.height = size;
   }

   @Override
   public boolean onClick(double mx, double my) {
      if (this.onChanged != null && !this.disabled) {
         this.onChanged.run();
      }

      return true;
   }

   public int getIcon() {
      return this.icon;
   }

   public void setActiveIcon(int value) {
      this.activeIcon = value;
   }

   public int getActiveIcon() {
      return this.activeIcon;
   }

   public void setDisabled(boolean value) {
      this.disabled = value;
   }

   public boolean isDisabled() {
      return this.disabled;
   }

   public void setTooltip(String value) {
      this.tooltip = value == null ? "" : value;
   }

   public String getTooltip() {
      return this.tooltip;
   }
}

