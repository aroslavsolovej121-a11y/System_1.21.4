package client.gui;

import java.util.function.IntSupplier;

public class ButtonBlock extends IconTextBlock {
   public static final int BUTTON = 0;
   public Runnable onClick;
   public IntSupplier counterSource;
   public IntSupplier badgeSource;
   public boolean selected;

   public ButtonBlock(String label, int icon, Runnable onClick) {
      super(label, icon);
      this.onClick = onClick;
      this.counterSource = null;
      this.badgeSource = null;
      this.selected = false;
   }

   public ButtonBlock(String label, int icon) {
      this(label, icon, null);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (mx < this.x || mx > this.x + this.width) {
         return false;
      } else if (my < this.y) {
         return false;
      } else {
         return !(my > this.y + this.height) && this.onClick != null ? this.onClick() : false;
      }
   }

   @Override
   public boolean onClick() {
      if (this.onClick != null) {
         this.onClick.run();
      }

      return true;
   }

   @Override
   public boolean isSelected() {
      return this.selected;
   }

   public void setSelected(boolean value) {
      this.selected = value;
   }

   @Override
   public int valueA() {
      return this.counterSource == null ? 0 : this.counterSource.getAsInt();
   }

   @Override
   public int badgeValue() {
      return this.badgeSource == null ? 0 : this.badgeSource.getAsInt();
   }

   public void setCounterSource(IntSupplier source) {
      this.counterSource = source;
   }

   public void setBadgeSource(IntSupplier source) {
      this.badgeSource = source;
   }

   @Override
   public void dispose() {
      super.dispose();
      this.onClick = null;
      this.counterSource = null;
      this.badgeSource = null;
      this.selected = false;
   }
}

