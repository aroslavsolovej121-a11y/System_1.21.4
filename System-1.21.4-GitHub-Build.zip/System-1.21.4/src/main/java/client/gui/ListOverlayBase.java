package client.gui;

import java.util.ArrayList;
import java.util.List;

public class ListOverlayBase extends AbstractOverlay {
   public static final float WIDTH = 335.0F;
   public static final float SEARCH_OFFSET = 311.0F;
   public static final float SEARCH_WIDTH = 303.0F;
   public static final float SEARCH_HEIGHT = 26.0F;
   public static final float SEARCH_PAD = 12.0F;
   public static final float SEARCH_GAP = 32.0F;
   public static final float LIST_ROW_WIDTH = 155.5F;
   public static final float LIST_ROW_HEIGHT = 28.0F;
   public static final float CLOSE_INSET = 14.0F;
   public static final float CLOSE_SIZE = 16.0F;
   public static final float ERROR_GAP = 4.0F;
   public static final float GAP = 8.0F;
   public static final float PAD = 12.0F;
   public static final float BODY_GAP = 10.0F;
   public static final float BODY_HEIGHT = 148.0F;
   public static final float BODY_INSET = 4.0F;
   public static final float BODY_TEXT_HEIGHT = 26.0F;
   public static final float SCROLL_STEP = 48.0F;
   public static final float SCROLLBAR_WIDTH = 6.0F;
   public static final float SCROLLBAR_HEIGHT = 40.0F;
   public static final float SCROLL_LIMIT = 140.0F;
   public static final float HEADER_TEXT_SCALE = 14.4F;
   public static final float HEADER_TEXT_BASE = 30.0F;
   public static final float TITLE_WIDTH = 24.0F;
   public static final float TITLE_GAP = 28.0F;
   public static final float TEXT_SIZE = 12.0F;
   public static final float TEXT_ADVANCE = 14.4F;
   public static final float ROW_TEXT_HEIGHT = 26.0F;
   public static final float ROW_SPACING = 4.0F;
   public static final float ROW_ROUND_TRIP = 2.0F;
   public static final float ROW_CURVE = 0.5F;
   public static final float ROW_HALF = 0.5F;
   public static final float ROW_QUARTER = 4.0F;
   public static final float ALT_BAND = 36.0F;
   public static final float EXTRA_ANIM_DURATION = 0.15F;
   public static final float ALT_BAND_ALT = 278.0F;
   public static final float DRAG_ANIM_DURATION = 0.28F;
   public static final float HOVER_EPSILON = 0.001F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float HALF = 0.5F;
   public static final float HEADER_ALPHA = 1.0F;
   public static final float BUCKET_COUNT = 7.0F;
   public static final float BUCKET_CAPACITY = 8.0F;
   public static final float BUCKET_SLOTS = 16.0F;
   protected final ListOverlayBase.SearchField search;
   protected boolean searchFocused;
   protected final AbstractOverlay.Animator searchAnim = new AbstractOverlay.Animator();
   protected float scroll;
   protected float scrollAnim;
   protected final AbstractOverlay.Animator dragAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator listAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator buttonAnim = new AbstractOverlay.Animator();
   protected boolean dragging;
   protected float dragGrab;
   protected final List<ListOverlayBase.Row> rows = new ArrayList<>();
   protected String pendingTitle = "";
   protected static boolean handCursor;

   public ListOverlayBase(String title) {
      this.search = new ListOverlayBase.SearchField(303.0F, 26.0F, title, 12.0F, 32.0F);
      this.searchFocused = false;
      resetAnimator(this.searchAnim, 0.0F, 0.28F, 2);
      this.scroll = 0.0F;
      this.scrollAnim = 0.0F;
      resetAnimator(this.dragAnim, 0.0F, 0.28F, 2);
      resetAnimator(this.listAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.buttonAnim, 0.0F, 0.15F, 0);
      this.dragging = false;
      this.dragGrab = 0.0F;
      this.pendingTitle = title == null ? "" : title;
      this.width = 335.0F;
   }

   public String title() {
      return "";
   }

   public String description() {
      return "";
   }

   public String filterLabel() {
      return "";
   }

   public String filterLabelAlt() {
      return "";
   }

   public boolean filterFlag() {
      return false;
   }

   public void toggleFilter() {
   }

   public void rebuildRows() {
   }

   public List<ListOverlayBase.Row> rowList() {
      return this.rows;
   }

   public ListOverlayBase.Row headerRowA() {
      return null;
   }

   public ListOverlayBase.Row headerRowB() {
      return null;
   }

   public void onHeaderRowA() {
   }

   public void onHeaderRowB() {
   }

   public boolean onRowClicked(ListOverlayBase.Row row, double mx, double my, float left, float top, float width) {
      return true;
   }

   public void onShowHook() {
   }

   public boolean onMouseMovedHook() {
      return false;
   }

   protected float headerHeight() {
      float maxWidth = this.width - 24.0F - 28.0F;
      float measured = measureText(this.description(), 12.0F, maxWidth);
      return measured * 14.4F + 30.0F;
   }

   protected static float measureText(String text, float size, float maxWidth) {
      return 0.0F;
   }

   protected boolean hasContent() {
      ListOverlayBase.Row a = this.headerRowA();
      if (a != null) {
         return true;
      } else {
         ListOverlayBase.Row b = this.headerRowB();
         return b != null;
      }
   }

   protected float bodyTop(float baseY) {
      return this.headerHeight() + baseY + 10.0F + 26.0F + 8.0F;
   }

   protected float listTop(float baseY) {
      return this.headerHeight() + baseY + 10.0F + 26.0F + 8.0F + 148.0F + 8.0F;
   }

   protected float rowsHeight() {
      float total = 0.0F;
      boolean first = true;

      for (int i = 0; i < this.rows.size(); i++) {
         float v = clamp01(this.rows.get(i).progress);
         if (0.5F <= v) {
            v = 2.0F - (v + v);
            v = 1.0F - v * v * v * 0.5F;
         } else {
            v = v * 4.0F * v * v;
         }

         if (!first) {
            total += v * 4.0F;
         }

         first = false;
         total += v * 26.0F;
      }

      return total;
   }

   public void onShow() {
      boolean hasA = this.headerRowA() != null;
      float band = 36.0F;
      if (!hasA) {
         boolean hasB = this.headerRowB() != null;
         if (!hasB) {
            band = 0.0F;
         }
      }

      this.height = this.headerHeight() + 10.0F + 26.0F + 8.0F + 148.0F + band + 12.0F;
      this.onShowHook();
      this.scroll = 0.0F;
      this.dragAnim.from = 0.0F;
      this.dragAnim.current = 0.0F;
      this.dragAnim.target = 0.0F;
      this.dragAnim.running = false;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return true;
      } else if (this.onMouseMovedHook()) {
         return true;
      } else {
         float baseY = this.y;
         float closeY = baseY + 14.0F - 4.0F;
         float closeX = this.x + this.width - 12.0F - 8.0F - 4.0F;
         if (mx >= closeX && mx <= closeX + 16.0F && my >= closeY && my <= closeY + 16.0F) {
            this.close();
            return true;
         } else {
            float searchX = (this.width - 303.0F) * 0.5F + this.x;
            float searchY = this.headerHeight() + baseY + 10.0F;
            if (mx >= searchX && mx <= searchX + 303.0F && my >= searchY && my <= searchY + 26.0F) {
               this.search.mousePressed(mx, my, 0);
               return true;
            } else {
               if (this.searchFocused) {
                  this.searchFocused = false;
                  animate(this.searchAnim, 0.0F);
                  this.search.reset();
               }

               if (this.hasContent()) {
                  float left = (this.width - 303.0F) * 0.5F + this.x;
                  float top = this.listTop(baseY);
                  ListOverlayBase.Row a = this.headerRowA();
                  if (a != null && mx >= left && mx <= left + 155.5F && my >= top && my <= top + 28.0F) {
                     this.onHeaderRowA();
                     this.scroll = 0.0F;
                     this.dragAnim.from = 0.0F;
                     this.dragAnim.current = 0.0F;
                     this.dragAnim.target = 0.0F;
                     this.dragAnim.running = false;
                     return true;
                  }

                  float rowBLeft = left + 155.5F;
                  float rowBBottom = top + 28.0F;
                  ListOverlayBase.Row b = this.headerRowB();
                  if (b != null && mx >= rowBLeft && mx <= rowBLeft + 155.5F && my >= top && my <= rowBBottom) {
                     this.onHeaderRowB();
                     return true;
                  }
               }

               float leftx = (this.width - 303.0F) * 0.5F + this.x;
               float topx = this.bodyTop(baseY);
               float contentHeight = this.rowsHeight();
               float right = leftx + 303.0F;
               boolean scrollBar = 140.0F < contentHeight;
               if (scrollBar) {
                  float barX = right - 4.0F - 6.0F;
                  float knob = this.rowsHeight() - 140.0F;
                  if (knob <= 0.0F) {
                     knob = 0.0F;
                  }

                  float barY = 0.0F;
                  if (0.0F < knob) {
                     barY = (topx + 148.0F - 4.0F - (topx + 4.0F) - 40.0F) * (this.dragAnim.current / knob);
                  }

                  barY = barY + topx + 4.0F;
                  if (mx >= barX && mx <= barX + 6.0F && my >= barY && my <= barY + 40.0F) {
                     this.dragging = true;
                     this.dragGrab = (float)my - barY;
                     return true;
                  }
               }

               if (mx >= leftx && mx <= right && my >= topx && my <= topx + 148.0F) {
                  float rowLeft = leftx + 4.0F;
                  float rowRight = right - 4.0F;
                  if (scrollBar) {
                     rowRight = rowRight - 6.0F - 4.0F;
                  }

                  for (int i = 0; i < this.rows.size(); i++) {
                     ListOverlayBase.Row row = this.rows.get(i);
                     float reveal = rowReveal(row);
                     if (0.001F < reveal && mx >= rowLeft && mx <= rowRight && my >= row.y && my <= row.y + 26.0F) {
                        return this.onRowClicked(row, mx, my, rowLeft, row.y, rowRight - rowLeft);
                     }
                  }
               }

               return true;
            }
         }
      }
   }

   protected static float rowReveal(ListOverlayBase.Row row) {
      return row.progress;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (!this.onMouseReleasedHook()) {
         if (!this.dragging || button != 0) {
            return false;
         }

         this.dragging = false;
      }

      return true;
   }

   public boolean onMouseReleasedHook() {
      return false;
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      if (this.onMouseMovedHook()) {
         return true;
      } else if (this.dragging && (int)delta == 0) {
         float top = this.listTop(this.y);
         float firstTop = top + 4.0F;
         float max = this.rowsHeight() - 140.0F;
         if (max <= 0.0F) {
            max = 0.0F;
         }

         float value = ((float)my - this.dragGrab - firstTop) / (top + 148.0F - 4.0F - firstTop - 40.0F) * max;
         if (value < 0.0F) {
            value = 0.0F;
         }

         if (max < value) {
            value = max;
         }

         this.scroll = value;
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      if (this.onKeyHook(keyCode, modifiers)) {
         return false;
      } else if (!this.searchFocused) {
         return false;
      } else {
         searchFieldKey(this.search, keyCode);
         return true;
      }
   }

   public boolean onKeyHook(int keyCode, int modifiers) {
      return false;
   }

   protected static void searchFieldKey(ListOverlayBase.SearchField field, int keyCode) {
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (this.onScrollHook()) {
         return true;
      } else {
         float left = (this.width - 311.0F) * 0.5F + this.x;
         float top = this.listTop(this.y);
         if (left <= mx && mx <= left + 311.0F && top <= my && my <= top + 148.0F) {
            float max = this.rowsHeight() - 140.0F;
            if (max <= 0.0F) {
               max = 0.0F;
            }

            float value = this.scroll - (float)amount * 48.0F;
            if (value < 0.0F) {
               value = 0.0F;
            }

            if (max < value) {
               value = max;
            }

            this.scroll = value;
            animate(this.dragAnim, value);
         }

         return true;
      }
   }

   public boolean onScrollHook() {
      return false;
   }

   protected static void searchFieldScroll(ListOverlayBase.SearchField field, double amount) {
   }

   @Override
   public boolean charTyped(char ch) {
      if (this.charTypedHook(ch)) {
         return false;
      } else if (!this.searchFocused) {
         return false;
      } else {
         searchFieldType(this.search, ch);
         return true;
      }
   }

   public boolean charTypedHook(char ch) {
      return false;
   }

   protected static void searchFieldType(ListOverlayBase.SearchField field, char ch) {
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      float weight = clamp01(parentAlpha);
      float top = (1.0F - weight) * 16.0F + this.y;
      ListOverlayBase.Draw.panel(target, this.x, top, this.width, this.height, 12.0F, 12.0F, 12.0F, 12.0F, 40.0F, weight);
      ListOverlayBase.Draw.text(target, this.x + 8.0F, top + 8.0F, this.title(), 12.0F, 12.0F, weight);
      String header = this.description();
      ListOverlayBase.Draw.text(target, this.x + 8.0F, top + 14.4F, header, 14.4F, 12.0F, weight);
      ListOverlayBase.Draw.row(target, this.x, (this.width - 303.0F) * 0.5F + this.x, top + 40.0F, 303.0F, 14.4F);
      this.search.render(target, this.x + 8.0F, top + 8.0F, weight);
      float left = (this.width - 303.0F) * 0.5F + this.x;
      float bodyY = this.bodyTop(top);
      ListOverlayBase.Draw.preview(target, left, bodyY, 303.0F, 30.0F, weight);
      ListOverlayBase.Draw.listHeader(target, left, top + 311.0F, this.width, 26.0F, 12.0F, weight);
      ListOverlayBase.Row a = this.headerRowA();
      ListOverlayBase.Row b = this.headerRowB();
      if (a != null || b != null) {
         this.renderHeaderRows(target, left, bodyY, weight);
         float footer = left + 303.0F - 12.0F - 40.0F - 4.0F;
         if (footer <= rx + 0.0F && rx <= footer + 12.0F && top + 8.0F <= ry && ry <= top + 8.0F + 12.0F) {
            handCursor = true;
         }

         this.onRenderHook(target, left, bodyY, rx, ry, weight);
      }
   }

   public void renderHeaderRows(Object target, float left, float top, float weight) {
   }

   public void onRenderHook(Object target, float left, float top, float rx, float ry, float weight) {
   }

   public void refresh() {
      cleanupTail(this.rows);
   }

   protected static void cleanupTail(List<ListOverlayBase.Row> rows) {
   }

   public static final class Draw {
      public static void panel(Object target, float x, float y, float width, float height, float a, float b, float c, float d, float e, float alpha) {
      }

      public static void text(Object target, float x, float y, String text, float size, float width, float alpha) {
      }

      public static void row(Object target, float x, float y, float top, float width, float alpha) {
      }

      public static void preview(Object target, float x, float y, float width, float height, float alpha) {
      }

      public static void listHeader(Object target, float x, float y, float width, float height, float size, float alpha) {
      }
   }

   public static class Row {
      public String name = "";
      public float progress;
      public float y;

      public Row() {
      }

      public Row(String name) {
         this.name = name == null ? "" : name;
      }
   }

   public static final class SearchField {
      public float x;
      public float y;
      public float width;
      public float height;
      public String value = "";
      public boolean focused;

      public SearchField(float width, float height, String value, float pad, float gap) {
         this.x = 0.0F;
         this.y = 0.0F;
         this.width = width;
         this.height = height;
         this.value = value == null ? "" : value;
         this.focused = false;
      }

      public void render(Object target, float rx, float ry, float alpha) {
      }

      public void mousePressed(double mx, double my, int button) {
      }

      public void reset() {
      }
   }
}

