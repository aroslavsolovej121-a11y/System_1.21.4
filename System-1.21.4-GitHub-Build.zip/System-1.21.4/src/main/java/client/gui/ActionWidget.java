package client.gui;

public class ActionWidget extends Component {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_SET_POSITION = 88;
   public static final int SLOT_ROW_HEIGHT = 96;
   public static final int SLOT_ROW_HEIGHT_ALIAS = 104;
   public static final int SLOT_ICON = 136;
   public static final int SLOT_SIZE_A = 144;
   public static final int SLOT_SIZE_B = 152;
   public static final int SLOT_EXTRA_A = 160;
   public static final int SLOT_EXTRA_B = 168;
   public static final float ROW_WIDTH = 269.0F;
   public static final float ROW_HEIGHT = 48.0F;
   public static final float ROW_HEIGHT_SLOT = 32.0F;
   public static final float ROW_SIZE_SLOT = 16.0F;
   public static final float HOVER_ALPHA = 1.0F;
   public static final int ICON_ACTION = 89;
   public static final int FLAG_HOVERED = 1;
   public static int hoverState;
   protected ActionWidget.Action action;
   protected float value = -1.0F;
   protected int flag6C;
   protected float value2 = -1.0F;
   protected int flag74;
   protected boolean flag78;

   public ActionWidget(ActionWidget.Action setting) {
      this.action = setting;
      this.width = 269.0F;
      this.height = 48.0F;
      this.value = -1.0F;
      this.value2 = -1.0F;
      this.flag6C = 0;
      this.flag74 = 0;
      this.flag78 = false;
   }

   @Override
   public void render() {
   }

   @Override
   public void render(Object renderer, float mouseX, float mouseY, float alpha) {
      float color = this.hoverColor(mouseX, mouseY);
      if ((this.flags & 0xFF) != 0) {
         hoverState = 1;
      }

      String name = this.action == null ? "" : this.action.name;
      drawActionRow(renderer, this.x, this.y, this.width, name, 89, color, alpha);
      this.height = 48.0F;
   }

   @Override
   public float preferredHeight() {
      return 32.0F;
   }

   protected float hoverColor(float mx, float my) {
      return 0.0F;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (mx < this.x || mx > this.x + this.width) {
         return false;
      } else if (my < this.y) {
         return false;
      } else if (my > this.y + 32.0F) {
         return false;
      } else {
         if (this.action != null && this.action.onClick != null) {
            this.action.onClick.run();
         }

         return true;
      }
   }

   public float rowHeight() {
      return 32.0F;
   }

   public float rowHeightAlias() {
      return 32.0F;
   }

   public int iconId() {
      return 89;
   }

   public float sizeSlot() {
      return 16.0F;
   }

   public static void drawActionRow(Object renderer, float x, float y, float width, String text, int style, float color, float alpha) {
   }

   public static void drawTextIcon(Object renderer, float x, float y, float width, String text, int icon, float color, float alpha) {
   }

   public static void drawPanel(Object renderer, float x, float y, float width, float height, float radius, float alpha) {
   }

   public static void drawRect(Object renderer, float x, float y, float right, float height) {
   }

   public static void drawTextAt(Object renderer, int id, float x, float y, float width, float height, int color, float alpha) {
   }

   public static void playClickSound(int sound) {
   }

   public static final class Action {
      public String name = "";
      public Runnable onClick;
   }
}

