package client.gui;

public class TextInput extends Component {
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int TEXT_OFFSET = 96;
   public static final int TEXT_SIZE_OFFSET = 112;
   public static final int TEXT_CAPACITY_OFFSET = 120;
   public static final int FONT_SIZE_OFFSET = 128;
   public static final int FLAG_84_OFFSET = 132;
   public static final int FLAG_85_OFFSET = 133;
   public static final int FLAG_86_OFFSET = 134;
   public static final int CURSOR_OFFSET = 136;
   public static final int SELECTION_OFFSET = 144;
   public static final int VIEW_TEXT_OFFSET = 152;
   public static final int SUBJECT_OFFSET = 240;
   public static final int RESERVED_130_OFFSET = 304;
   public static final int LABEL_OFFSET = 312;
   public static final int FIELD_HEIGHT_OFFSET = 344;
   public static final int FIELD_INSET_OFFSET = 348;
   public static final int FIELD_EXTRA_OFFSET = 352;
   public static final int FOCUSED_OFFSET = 356;
   public static final int FOCUS_ANIM_OFFSET = 360;
   public static final int GHOST_ANIM_OFFSET = 400;
   public static final float FIELD_RADIUS = 8.0F;
   public static final float FOCUS_DURATION = 0.15F;
   public static final float GHOST_DURATION = 0.15F;
   public static final float REVEAL_EXPONENT = 1.7F;
   public static final float EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final float HOVER_SCALE = 0.5F;
   public static final int HOVER_INPUT = 2;
   public static final int TEXT_ALIGNMENT = 0;
   public static final int FIELD_BORDER = 436207616;
   public static final int KEY_ESCAPE = 27;
   protected final TextInput.Anim rectAnim = new TextInput.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected String text = "";
   protected float fontSize;
   protected byte flag84;
   protected byte flag85;
   protected byte flag86;
   protected long cursor;
   protected long selection;
   protected String viewText = "";
   protected Object subject;
   protected long reserved130;
   protected String label = "";
   protected float fieldHeight;
   protected float fieldInset;
   protected float fieldExtra;
   protected boolean focused;
   protected final TextInput.Anim focusAnim = new TextInput.Anim();
   protected final TextInput.Anim ghostAnim = new TextInput.Anim();
   private static final float ONE = 1.0F;

   public TextInput() {
      this(0.0F, 0.0F, "", 0.0F, 0.0F, 0.0F);
   }

   public TextInput(float width, float height, String label, float fontSize, float inset, float extra) {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.text = "";
      this.fontSize = fontSize;
      this.flag84 = 0;
      this.flag85 = 0;
      this.flag86 = 0;
      this.cursor = 0L;
      this.selection = 0L;
      this.viewText = "";
      this.subject = null;
      this.reserved130 = 0L;
      this.label = "";
      this.label = label != null ? label : "";
      this.fieldHeight = fontSize;
      this.fieldInset = inset;
      this.fieldExtra = extra;
      this.focused = false;
      this.focusAnim.set(0.0F, 0.15F);
      this.ghostAnim.set(1.0F, 0.15F);
      this.width = width;
      this.height = height;
   }

   @Override
   public void dispose() {
      releaseGlobalTextOwner(this);
      resetString(312);
      freeString(312);
      freeString(96);
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      if (this.focused) {
         Screen.textInputActive = true;
      }

      if (this.x <= mouseX
         && mouseX <= this.x + this.width
         && this.y <= mouseY
         && mouseY <= this.y + this.height
         && (Screen.focusedInput == null || Screen.allowHover)) {
         Screen.hoveredWidget = 2;
      }

      float focus = this.focusAnim.advance(TextInput.Anim.now());
      int focusColor = mixColor(themeColor(12), themeColor(20), focus);
      uiDrawBox(mat, this.x, this.y, this.width, this.height, 8.0F, 8.0F, 8.0F, 8.0F, themeColor(0), focusColor, 1.0F, 436207616, 0.0F, 1.0F, 1.0F, alpha, 0);
      float textWidth = this.width - (this.fieldInset + this.fieldInset) - this.fieldExtra;
      float textY = (this.height - this.fieldHeight) * 0.5F + this.y;
      float textVisible = 0.0F;
      if (this.text.isEmpty() && !this.focused) {
         textVisible = 1.0F;
      }

      if (this.ghostAnim.target != textVisible) {
         long time = TextInput.Anim.now();
         float value = this.ghostAnim.advance(time);
         this.ghostAnim.from = value;
         this.ghostAnim.target = textVisible;
         this.ghostAnim.start = time;
         this.ghostAnim.running = true;
      }

      float ghost = this.ghostAnim.advance(TextInput.Anim.now());
      pushScissor(this.x + this.fieldInset, this.y, textWidth, this.height);
      if (0.001F < ghost) {
         float fade = clamp01(ghost);
         fade = (float)Math.pow(fade, 1.7F);
         drawText(0, mat, this.label, this.x + this.fieldInset, textY, this.fieldHeight, themeColor(16), fade * alpha);
      }

      if (ghost < 0.999F) {
         drawTextField(mat, this.text, this.x + this.fieldInset, textY, textWidth, themeColor(24), (1.0F - ghost) * alpha, this.focused);
      }

      popScissor();
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (this.x <= (float)mx && mx <= this.x + this.width && this.y <= (float)my && my <= this.y + this.height) {
         this.setFocused(true);
         return true;
      } else {
         this.setFocused(false);
         return false;
      }
   }

   public boolean keyPressed(int keyCode) {
      if (!this.focused) {
         return false;
      } else if (keyCode == 27) {
         this.focused = false;
         this.focusAnim.retarget(0.0F);
         clearGlobalFocus(this);
         return true;
      } else {
         return textKey(this.text, keyCode);
      }
   }

   @Override
   public boolean charTyped(char ch) {
      return !this.focused ? false : textChar(this.text, ch);
   }

   public void setFocused(boolean value) {
      if (this.focused != value) {
         this.focused = value;
         this.focusAnim.retarget(value ? 1.0F : 0.0F);
         if (value) {
            installGlobalFocus(this);
         } else {
            clearGlobalFocus(this);
         }
      }
   }

   public boolean isFocused() {
      return this.focused;
   }

   public String text() {
      return this.text;
   }

   public void setText(String value) {
      this.text = value != null ? value : "";
   }

   public String label() {
      return this.label;
   }

   public void setLabel(String value) {
      this.label = value != null ? value : "";
   }

   public void setSubject(Object value) {
      this.subject = value;
   }

   public static boolean releaseFocus(Object lambda) {
      TextInput widget = (TextInput)lambdaOwner(lambda);
      if (widget != null && widget.focused) {
         widget.focused = false;
         widget.focusAnim.retarget(0.0F);
         clearGlobalFocus(widget);
         return true;
      } else {
         return false;
      }
   }

   private static float clamp01(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private static void installGlobalFocus(TextInput widget) {
   }

   private static void clearGlobalFocus(TextInput widget) {
   }

   private static void releaseGlobalTextOwner(TextInput widget) {
   }

   private static Object lambdaOwner(Object lambda) {
      return null;
   }

   private static void resetString(int offset) {
   }

   private static void freeString(int offset) {
   }

   private static boolean textKey(String value, int keyCode) {
      return true;
   }

   private static boolean textChar(String value, char ch) {
      return true;
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static int mixColor(int from, int to, float t) {
      return 0;
   }

   private static void drawText(int alignment, Object mat, String text, float x, float y, float size, int color, float alpha) {
   }

   private static void drawTextField(Object mat, String value, float x, float y, float width, int color, float alpha, boolean focusedNow) {
   }

   private static void pushScissor(float x, float y, float width, float height) {
   }

   private static void popScissor() {
   }

   private static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }
}

