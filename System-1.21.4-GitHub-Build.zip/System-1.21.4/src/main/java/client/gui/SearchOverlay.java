package client.gui;

import java.util.ArrayList;
import java.util.List;

public class SearchOverlay extends AbstractOverlay {
   public static final int ITEM_TYPE_HEADER = 0;
   public static final int ITEM_TYPE_DIVIDER = 1;
   public static final int ITEM_TYPE_ROW = 2;
   public static final int ITEM_TYPE_ROW_ALT = 3;
   public static final int ITEM_TYPE_STATE = 4;
   public static final float PANEL_WIDTH = 500.0F;
   public static final float PANEL_HEIGHT = 50.0F;
   public static final float PANEL_MAX_WIDTH = 480.0F;
   public static final float PANEL_MARGIN_Y = 50.0F;
   public static final float ROW_WIDTH = 484.0F;
   public static final float ROW_HEIGHT = 36.0F;
   public static final float ROW_HEIGHT_ALT = 32.0F;
   public static final float HEADER_HEIGHT = 42.0F;
   public static final float INPUT_HEIGHT = 36.0F;
   public static final float LIST_TOP_OFFSET = 46.0F;
   public static final float SCROLL_STEP = 48.0F;
   public static final float HOVER_DAMP = 0.1F;
   public static final float HOVER_DAMP_MIN = 0.11F;
   public static final float ITEM_DAMP = 0.1F;
   public static final float ITEM_DAMP_MIN = 0.06F;
   public static final float VISIBLE_EPSILON = 0.001F;
   public static final float INPUT_TEXT_SIZE = 14.0F;
   public static final float DEFAULT_DURATION = 0.15F;
   public static final float SCROLL_DURATION = 0.28F;
   public static final int HOVER_SOUND_IN = 8;
   public static final int HOVER_SOUND_OUT = 9;
   public static final int ICON_SEARCH = 9;
   public static final int ICON_CLEAR = 80;
   public static final int ICON_LOADING = 12;
   public static final int HOVERED_WIDGET_SEARCH = 2;
   private static final String HINT_TEXT = "SearchOverlay.hint";
   private static final String QUERY_TEXT = "SearchOverlay.query";
   private static final String LOADING_ICON_TEXT = "SearchOverlay.loading";
   private static final String STATE_LABEL_SHORT = "SearchOverlay.stateShort";
   private static final String STATE_LABEL_LONG = "SearchOverlay.stateLong";
   private final List<SearchOverlay.Item> targets = new ArrayList<>();
   private final List<SearchOverlay.Item> entries = new ArrayList<>();
   private final List<SearchOverlay.Item> rows = new ArrayList<>();
   private final List<SearchOverlay.Item> visible = new ArrayList<>();
   private final TextInput textInput = new TextInput();
   private Object itemAction;
   private Object targetAction;
   private Object dismissAction;
   private float openAnimValue;
   private int selectedIndex = -1;
   private float hoverDampValue;
   private float hoverDampVelocity;
   private float itemDampValue;
   private float itemDampVelocity;
   private float inputTextSize = 14.0F;
   private boolean focusFlag;
   private boolean inputActive;
   private boolean inputHover;
   private float scroll;
   private float contentTop;
   private float contentBottom;
   private float lastMouseX;
   private float lastMouseY;
   private boolean mouseValid;
   private Object targetMap;
   private boolean inputTouched;
   private final AbstractOverlay.Animator selectAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   private final AbstractOverlay.Animator headerAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   private final AbstractOverlay.Animator inputAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   private final AbstractOverlay.Animator scrollAnim = new AbstractOverlay.Animator(0.0F, 0.28F, 2);

   public SearchOverlay() {
      this.itemAction = null;
      this.targetAction = null;
      this.dismissAction = null;
      this.inputTextSize = 14.0F;
      this.focusFlag = false;
      this.inputActive = false;
      this.inputHover = false;
      this.inputTouched = false;
      this.openAnimValue = 0.0F;
      this.selectedIndex = -1;
      this.hoverDampValue = 0.0F;
      this.hoverDampVelocity = 0.0F;
      this.itemDampValue = 0.0F;
      this.itemDampVelocity = 0.0F;
      this.scroll = 0.0F;
      this.contentTop = 0.0F;
      this.contentBottom = 0.0F;
      this.lastMouseX = 0.0F;
      this.lastMouseY = 0.0F;
      this.mouseValid = false;
      resetAnimator(this.selectAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.headerAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.inputAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.scrollAnim, 0.0F, 0.28F, 2);
      registerTargetMap();
      this.inputActive = true;
      this.width = 500.0F;
      this.height = 50.0F;
      setInputChangedCallback(this.textInput);
   }

   @Override
   public void dispose() {
      clearTargetMapEntries();
      clearTargetMap();
      releaseCollections();
      releaseCallback(264);
      releaseCallback(328);
      releaseCallback(392);
      clearTargetMap();
      releaseTargetMapStorage();
      releaseVisibleList();
      releaseRowList();
      releaseEntryList();
      releaseTargetList();
      releaseInputField();
      releaseCallback(392);
      releaseCallback(328);
      releaseCallback(264);
      super.dispose();
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      for (SearchOverlay.Item item : this.rows) {
         SearchRow row = item == null ? null : item.child;
         if (row != null && row.controls != null && controlsCaptured(row.controls)) {
            if (this.x <= mx && mx <= this.x + this.width && this.y <= my && my <= this.y + this.height) {
               row.mouseClicked(mx, my, button);
               return true;
            }

            controlsSetCaptured(row.controls, false);
            controlsSetLastInput(row.controls, 0);
            return true;
         }
      }

      return super.mouseClicked(mx, my, button);
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      for (SearchOverlay.Item item : this.rows) {
         SearchRow row = item == null ? null : item.child;
         if (row != null && row.controls != null && controlsStateA(row.controls, 496, mx, my, button)) {
            return true;
         }
      }

      return true;
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      for (SearchOverlay.Item item : this.rows) {
         SearchRow row = item == null ? null : item.child;
         if (row != null && row.controls != null && controlsStateB(row.controls, 496, mx, my, 0)) {
            return true;
         }
      }

      return true;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (this.x <= mx && mx <= this.x + this.width && this.contentTop <= my && my <= this.contentBottom - this.contentTop + this.contentTop) {
         float limit = this.openAnimValue + 50.0F;
         if (480.0F <= limit) {
            limit = 480.0F;
         }

         float maxScroll = this.openAnimValue - (limit - 8.0F - 42.0F);
         if (maxScroll <= 0.0F) {
            maxScroll = 0.0F;
         }

         float next = this.scroll - (float)amount * 48.0F;
         float result;
         if (next <= 0.0F) {
            result = 0.0F;
         } else if (next <= maxScroll) {
            result = next;
         } else {
            result = maxScroll;
         }

         this.scroll = result;
         animate(this.scrollAnim, result);
      }

      return true;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      this.inputTouched = false;

      for (SearchOverlay.Item item : this.rows) {
         SearchRow row = item == null ? null : item.child;
         if (row != null && row.controls != null && controlsCaptured(row.controls)) {
            controlsKeyA(row.controls, keyCode);
            this.inputTouched = true;
            return true;
         }
      }

      if (keyCode == 27 && inputHasContent()) {
         clearInputLine();
         return true;
      } else if (this.closeOnEscape && keyCode == 27) {
         this.close();
         return true;
      } else {
         return this.onKeyPressed(keyCode, modifiers);
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      for (SearchOverlay.Item item : this.rows) {
         SearchRow row = item == null ? null : item.child;
         if (row != null && row.controls != null && controlsCaptured(row.controls)) {
            controlsKeyB(row.controls, keyCode);
            return true;
         }
      }

      return true;
   }

   @Override
   public boolean charTyped(char ch) {
      if (!this.inputTouched) {
         for (SearchOverlay.Item item : this.rows) {
            SearchRow row = item == null ? null : item.child;
            if (row != null && row.controls != null && controlsCaptured(row.controls)) {
               this.inputTouched = false;
               return true;
            }
         }

         this.inputTouched = false;
         textInputCharTyped(this.textInput, ch);
         return true;
      } else {
         this.inputTouched = false;
         return true;
      }
   }

   @Override
   public float overlayConst() {
      return 18.0F;
   }

   @Override
   public boolean isActive() {
      return true;
   }

   @Override
   public void renderBody(Object renderer, float mouseX, float mouseY, float alpha) {
      this.layout();
      float limit;
      if (this.closed) {
         limit = 50.0F;
      } else {
         limit = this.openAnimValue + 50.0F;
         if (480.0F <= limit) {
            limit = 480.0F;
         }
      }

      float heightValue = smoothDamp(this.hoverDampValue, limit, 0.1F, 0.11F);
      this.hoverDampValue = heightValue;
      this.hoverDampVelocity = smoothDampVelocity(heightValue, this.hoverDampVelocity);
      float alphaClamped = alpha;
      if (alpha < 0.0F) {
         alphaClamped = 0.0F;
      }

      if (alphaClamped > 1.0F) {
         alphaClamped = 1.0F;
      }

      float halfWidth = this.width * 0.5F;
      this.height = heightValue;
      float top = (1.0F - alphaClamped) * 16.0F + this.y;
      Object rect = makeRect(renderer, alpha, halfWidth + this.x, heightValue * 0.5F + top);
      drawBackdrop(rect, this.x, top, this.width, this.height, 18.0F, alpha);
      this.renderHeader(rect, alpha, top);
      this.renderRows(rect, mouseX, mouseY, alpha, top);
      if (this.x <= mouseX && mouseX <= this.x + this.width && this.y <= mouseY && mouseY <= this.y + 46.0F) {
         Screen.hoveredWidget = 2;
      }
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      if (!(my < this.contentTop) && !(my > this.contentBottom)) {
         for (int index = 0; index < this.rows.size(); index++) {
            SearchOverlay.Item item = this.rows.get(index);
            if (item.type == 2 || item.type == 3) {
               if (item.child != null && item.child.mouseClicked(mx, my, button)) {
                  return true;
               }

               Component hit = item.child;
               if (hit == null) {
                  hit = item.altChild;
               }

               if (hit != null && hit.x <= mx && mx <= hit.x + hit.width && hit.y <= my && my <= hit.y + hit.height) {
                  this.selectedIndex = index;
                  if (button != 1) {
                     if (button != 0) {
                        return true;
                     }

                     if (item.actionAlt == null) {
                        return true;
                     }

                     invokeCallback(item.actionAlt);
                     return true;
                  }

                  if (item.child == null) {
                     return true;
                  }

                  Component toggle = readPointer(item.child, 104);
                  if (toggle == null) {
                     return true;
                  }

                  boolean state = readBool(toggle);
                  writeBool(toggle, !state);
                  return true;
               }
            }
         }

         return true;
      } else {
         return true;
      }
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      switch (keyCode) {
         case 9:
            this.moveSelection((int)((modifiers & 1 ^ 1L) * 2L - 1L), true);
            return true;
         case 13:
            this.handleEnterKey(modifiers);
            textInputKeyPressed(this.textInput, keyCode, modifiers);
            return true;
         case 33:
            this.moveSelection(-5, false);
            return true;
         case 34:
            this.moveSelection(5, false);
            return true;
         case 38:
            this.moveSelection(-1, true);
            return true;
         case 40:
            this.moveSelection(1, true);
            return true;
         default:
            textInputKeyPressed(this.textInput, keyCode, modifiers);
            return true;
      }
   }

   private void handleEnterKey(int modifiers) {
      boolean toggle = (modifiers & 1) != 0 || (modifiers & 2) != 0;
      if (this.selectedIndex >= 0) {
         SearchOverlay.Item item = this.rows.get(this.selectedIndex);
         if (toggle && item.child != null) {
            Component handle = readPointer(item.child, 104);
            if (handle != null) {
               boolean state = readBool(handle);
               writeBool(handle, !state);
               return;
            }
         }

         if (item.actionAlt != null) {
            invokeCallback(item.actionAlt);
         }
      }
   }

   private void layout() {
      initGuiMetrics();
      float scale = guiScale();
      float screenW = screenWidth();
      float screenH = screenHeight();
      this.x = Math.round((screenW / scale - this.width) * 0.5F);
      this.y = Math.round((screenH / scale - 480.0F) * 0.5F);
   }

   private void renderHeader(Object renderer, float alpha, float top) {
      float target;
      if (inputHasContent()) {
         target = 1.0F;
      } else {
         target = 0.0F;
      }

      if (this.headerAnim.target != target) {
         long time = this.now();
         float current = advance(this.headerAnim, time);
         this.headerAnim.start = time;
         this.headerAnim.from = current;
         this.headerAnim.target = target;
         this.headerAnim.running = true;
      }

      float headerValue = advance(this.headerAnim, this.now());
      float innerAlpha = (headerValue * 0.5F + 0.5F) * alpha;
      float left = this.x + 4.0F;
      float rowTop = top + 4.0F;
      float innerWidth = this.width - 8.0F;
      drawHeaderPlate(renderer, left, rowTop, innerWidth, 42.0F, 14.0F, innerAlpha, 1);
      float fieldLeft = left + 3.0F;
      float fieldTop = rowTop + 3.0F;
      float fieldWidth = innerWidth - 6.0F;
      drawHeaderPlateInner(renderer, fieldLeft, fieldTop, fieldWidth, 36.0F, 12.0F, headerPanelStyle(), innerAlpha);
      float iconTop = fieldTop + 18.0F;
      float[] icon = uiIconMetrics(9);
      uiDrawIcon(renderer, 9, fieldLeft + 12.0F, iconTop - icon[1] * 0.5F, icon[0], icon[1], uiThemeColor(uiTheme(), 24), innerAlpha);
      float inputTarget;
      if (inputHasContent() && this.selectedIndex >= 0) {
         inputTarget = 1.0F;
      } else {
         inputTarget = 0.0F;
      }

      if (this.inputAnim.target != inputTarget) {
         long time = this.now();
         float current = advance(this.inputAnim, time);
         this.inputAnim.start = time;
         this.inputAnim.from = current;
         this.inputAnim.target = inputTarget;
         this.inputAnim.running = true;
      }

      float inputValue = advance(this.inputAnim, this.now());
      float hintWidth = measureText(0, "SearchOverlay.hint", 12.0F);
      float boxWidth = measureText(0, "SearchOverlay.query", 12.0F) + hintWidth + 2.0F + 8.0F;
      float boxTop = iconTop - 10.0F;
      float right = fieldWidth + fieldLeft;
      float value = (20.0F - boxWidth) * inputValue + boxWidth;
      float boxLeft = right - 12.0F - value;
      drawInputBox(renderer, boxLeft, boxTop, value, 20.0F, uiThemeColor(uiTheme(), 8), innerAlpha);
      setScissor(boxLeft, boxTop, value, 20.0F);
      if (inputValue < 0.999F) {
         float faded = (1.0F - inputValue) * alpha;
         drawText(2, renderer, "SearchOverlay.hint", boxLeft + 4.0F, boxTop + 4.0F, 12.0F, uiThemeColor(uiTheme(), 24), faded);
         drawText(2, renderer, "SearchOverlay.query", boxLeft + 4.0F + hintWidth + 2.0F, boxTop + 4.0F, 12.0F, uiThemeColor(uiTheme(), 24), faded);
      }

      if (0.001F < inputValue) {
         float[] clearIcon = uiIconMetrics(80);
         uiDrawIcon(
            renderer,
            80,
            (value - clearIcon[0]) * 0.5F + boxLeft,
            (20.0F - clearIcon[1]) * 0.5F + boxTop,
            clearIcon[0],
            clearIcon[1],
            uiThemeColor(uiTheme(), 24),
            inputValue * alpha
         );
      }

      resetScissor();
      float listLeft = fieldLeft + 12.0F + icon[0] + 6.0F;
      float listWidth = boxLeft - 6.0F - listLeft;
      if (listWidth <= 0.0F) {
         listWidth = 0.0F;
      }

      setScissor(listLeft, fieldTop, listWidth, 36.0F);
      float fade = 1.0F - headerValue;
      if (0.001F < fade) {
         float clamped = fade;
         if (fade <= 0.0F) {
            clamped = 0.0F;
         }

         if (clamped > 1.0F) {
            clamped = 1.0F;
         }

         float eased = (float)Math.pow(clamped, 1.7);
         drawText(5, renderer, "SearchOverlay.loading", headerValue * 7.0F + listLeft, iconTop - 7.0F, 14.0F, uiThemeColor(uiTheme(), 24), eased * alpha);
      }

      SearchRow focused = null;

      for (SearchOverlay.Item item : this.rows) {
         SearchRow row = item == null ? null : item.child;
         if (row != null && row.controls != null && controlsCaptured(row.controls)) {
            focused = row;
            break;
         }
      }

      renderInputWidget(renderer, listLeft, iconTop - 7.0F, listWidth, uiThemeColor(uiTheme(), 24), alpha, focused == null);
      resetScissor();
   }

   private void renderRows(Object renderer, float mouseX, float mouseY, float alpha, float top) {
      this.contentBottom = top + this.height - 4.0F;
      this.contentTop = top + 4.0F + 42.0F;
      float maxScroll = this.openAnimValue + 50.0F;
      if (480.0F <= maxScroll) {
         maxScroll = 480.0F;
      }

      maxScroll = this.openAnimValue - (maxScroll - 8.0F - 42.0F);
      if (maxScroll <= 0.0F) {
         maxScroll = 0.0F;
      }

      float clampedScroll = this.scroll;
      if (clampedScroll <= 0.0F) {
         clampedScroll = 0.0F;
      }

      if (clampedScroll <= maxScroll) {
         clampedScroll = clampedScroll;
      } else {
         clampedScroll = maxScroll;
      }

      this.scroll = clampedScroll;
      if (this.scrollAnim.target != clampedScroll) {
         long time = this.now();
         float current = advance(this.scrollAnim, time);
         this.scrollAnim.start = time;
         this.scrollAnim.from = current;
         this.scrollAnim.target = clampedScroll;
         this.scrollAnim.running = true;
      }

      float scrollValue = advance(this.scrollAnim, this.now());
      float listY = this.contentTop - scrollValue;
      float rowLeft = this.x + 4.0F + 4.0F;
      boolean mouseMoved;
      if (!this.mouseValid) {
         mouseMoved = false;
      } else if (mouseX != this.lastMouseX || Float.isNaN(mouseY) || Float.isNaN(this.lastMouseY)) {
         mouseMoved = true;
      } else if (mouseY == this.lastMouseY) {
         mouseMoved = false;
      } else {
         mouseMoved = true;
      }

      this.lastMouseY = mouseY;
      this.lastMouseX = mouseX;
      this.mouseValid = true;
      SearchOverlay.Item selected = null;
      if (this.selectedIndex >= 0 && this.selectedIndex < this.rows.size()) {
         SearchOverlay.Item candidate = this.rows.get(this.selectedIndex);
         if (candidate != null && candidate.type == 2) {
            selected = candidate;
         }
      }

      float selectTarget = selected == null ? 0.0F : 1.0F;
      if (this.selectAnim.target != selectTarget) {
         long time = this.now();
         float current = advance(this.selectAnim, time);
         this.selectAnim.start = time;
         this.selectAnim.from = current;
         this.selectAnim.target = selectTarget;
         this.selectAnim.running = true;
      }

      float selectValue = advance(this.selectAnim, this.now());
      if (selected != null) {
         if (selectValue <= 0.001F) {
            this.itemDampValue = selected.reveal;
            this.itemDampVelocity = 0.0F;
         }

         this.itemDampValue = smoothDamp(this.itemDampValue, selected.reveal, 0.1F, 0.06F);
         this.itemDampVelocity = smoothDampVelocity(this.itemDampValue, this.itemDampVelocity);
      }

      float thumbStart = this.clampRange(scrollValue / 24.0F);
      float thumbSize = this.clampRange((maxScroll - scrollValue) / 24.0F);
      boolean needsLayers = 0.001F < thumbStart || 0.001F < thumbSize;
      if (needsLayers) {
         beginClipLayer();
      }

      float clipHeight = this.contentBottom - this.contentTop;
      if (clipHeight <= 0.0F) {
         clipHeight = 0.0F;
      }

      setScissor(this.x, this.contentTop, this.width, clipHeight);
      if (0.001F < selectValue) {
         float backdropAlpha = 1.0F;
         if (selected != null) {
            backdropAlpha = selected.exitA;
         }

         drawBackdrop(renderer, rowLeft - 1.0F, listY + this.itemDampValue + 2.0F - 1.0F, 486.0F, 38.0F, 14.0F, selectValue * alpha * backdropAlpha);
      }

      for (SearchOverlay.Item item : new ArrayList<>(this.visible)) {
         if (item != null) {
            this.renderItem(renderer, item, listY, mouseX, mouseY, alpha);
         }
      }

      int hoverIndex = -1;

      for (int index = 0; index < this.rows.size(); index++) {
         float rowWidth = 484.0F;
         float rowExtent = 36.0F;
         SearchOverlay.Item itemx = this.rows.get(index);
         boolean isSelected = index == this.selectedIndex;
         if (itemx.child != null) {
            itemx.child.selected = isSelected;
         }

         SearchRow alternate = itemx.altChild;
         if (alternate != null) {
            alternate.selected = isSelected;
         }

         this.renderItem(renderer, itemx, listY, mouseX, mouseY, alpha);
         if (mouseMoved && (itemx.type == 2 || itemx.type == 3) && this.contentTop <= mouseY && mouseY <= this.contentBottom) {
            float rowTop = listY + itemx.offset + 2.0F;
            if (itemx.type == 3) {
               rowExtent = 32.0F;
            }

            if (rowLeft <= mouseX && mouseX <= rowLeft + rowWidth && rowTop <= mouseY && mouseY <= rowExtent + rowTop) {
               hoverIndex = index;
            }
         }
      }

      resetScissor();
      if (needsLayers) {
         float matScaleX = 0.0F;
         float matOffsetY = 0.0F;
         float matOffsetX = 0.0F;
         float[] rectA = new float[10];
         float[] rectB = new float[10];
         float common = matOffsetY + matOffsetX;
         rectA[0] = (this.contentTop + 18.0F) * matScaleX + common;
         rectB[6] = (this.contentBottom - 18.0F) * matScaleX + common;
         rectA[1] = matScaleX * this.contentTop + common;
         rectA[3] = matScaleX * this.contentBottom + common;
         rectA[8] = thumbStart;
         drawScrollbar(1.0F, rectA, rectB);
      }

      this.compactVisible();
      if (hoverIndex >= 0 && hoverIndex != this.selectedIndex) {
         this.selectedIndex = hoverIndex;
      }
   }

   private void renderItem(Object renderer, SearchOverlay.Item item, float listY, float mouseX, float mouseY, float alpha) {
      item.offset = smoothDamp(item.offset, item.reveal, 0.1F, 0.06F);
      item.offsetVelocity = smoothDampVelocity(item.offset, item.offsetVelocity);
      float value = advance(item.alphaAnim, this.now());
      float itemTop = listY + item.offset;
      float reveal = value * alpha;
      if (0.001F < reveal && this.contentTop <= itemTop + 96.0F && itemTop <= this.contentBottom) {
         int type = item.type;
         float left = this.x + 4.0F + 4.0F;
         if (type == 0) {
            float headerLeft = left + 8.0F;
            float headerAlpha = reveal * 0.5F;
            float textTop = itemTop + 4.0F + 8.0F;
            drawText(3, renderer, item.title, headerLeft, textTop, 12.0F, uiThemeColor(uiTheme(), 24), headerAlpha);
            if (!item.subtitle.isEmpty()) {
               float titleWidth = measureText(0, item.title, 12.0F);
               drawText(2, renderer, item.subtitle, titleWidth + (headerLeft + 6.0F), textTop, 12.0F, uiThemeColor(uiTheme(), 16), headerAlpha);
            }
         } else if (type == 1) {
            drawBoxGradient(renderer, this.x + 4.0F, itemTop + 4.0F, this.width - 8.0F, 1.0F, 0.0F, uiThemeColor(uiTheme(), 12), reveal);
         } else if (type == 2) {
            SearchRow row = item.child;
            float rowY = itemTop + 2.0F;
            row.x = left;
            row.y = rowY;
            row.render(renderer, mouseX, mouseY, reveal);
         } else if (type == 3) {
            SearchRow row = item.altChild;
            float rowY = itemTop + 2.0F;
            row.x = left;
            row.y = rowY;
            this.renderAltRow(row, renderer, mouseX, mouseY, reveal);
         } else if (type == 4) {
            float phase = item.exitA;
            float stateTop = itemTop + 18.0F;
            float spin = phase * 3.0F;
            float centerX = this.width * 0.5F + this.x;
            float wave = (float)Math.sin((spin + spin) * (float) Math.PI);
            uiDrawIcon(renderer, 9, wave * (1.0F - phase) * 4.0F + (centerX - 10.0F), stateTop, 20.0F, 20.0F, uiThemeColor(uiTheme(), 16), reveal);
            float labelTop = stateTop + 20.0F + 10.0F;
            float labelWidth = measureText(0, "SearchOverlay.stateShort", 14.0F);
            drawText(5, renderer, "SearchOverlay.stateShort", centerX - labelWidth * 0.5F, labelTop, 14.0F, uiThemeColor(uiTheme(), 24), reveal);
            float hintWidth = measureText(0, "SearchOverlay.stateLong", 12.0F);
            drawText(0, renderer, "SearchOverlay.stateLong", centerX - hintWidth * 0.5F, labelTop + 14.0F + 6.0F, 12.0F, uiThemeColor(uiTheme(), 16), reveal);
         }
      }
   }

   private void moveSelection(int delta, boolean wrap) {
      List<Integer> selectable = new ArrayList<>();

      for (int index = 0; index < this.rows.size(); index++) {
         int type = this.rows.get(index).type;
         if (type == 2 || type == 3) {
            selectable.add(index);
         }
      }

      if (!selectable.isEmpty()) {
         int count = selectable.size();
         int position = 0;

         while (position < count && selectable.get(position) < this.selectedIndex) {
            position++;
         }

         if (position == count && 0 < delta) {
            position = -1;
         }

         int last = count - 1;
         position += delta;
         int next;
         if (!wrap) {
            if (position < 0) {
               next = 0;
            } else if (position <= last) {
               next = position;
            } else {
               next = last;
            }
         } else {
            next = (count + position % count) % count;
         }

         this.selectIndex(selectable.get(next), true);
      }
   }

   private void selectIndex(int index, boolean reveal) {
      this.selectedIndex = index;
      if (reveal && index >= 0) {
         SearchOverlay.Item item = this.rows.get(index);
         float itemTop = item.reveal + 2.0F;
         float anchor = itemTop;
         if (0 < index && this.rows.get(index - 1).type == 0) {
            anchor = this.rows.get(index - 1).reveal;
         }

         float extent = 36.0F;
         if (item.type == 3) {
            extent = 32.0F;
         }

         float view = this.scroll;
         if (view + 4.0F <= anchor) {
            float limit = this.openAnimValue + 50.0F;
            if (480.0F <= limit) {
               limit = 480.0F;
            }

            float maxScroll = limit - 8.0F - 42.0F;
            if (itemTop + extent <= maxScroll + view) {
               this.scroll = view;
               animate(this.scrollAnim, view);
            } else {
               float next = itemTop + extent + 4.0F - maxScroll;
               this.scroll = next;
               animate(this.scrollAnim, next);
            }
         } else {
            this.scroll = anchor;
            animate(this.scrollAnim, anchor);
         }
      }
   }

   private void compactVisible() {
      int size = this.visible.size();

      int keep;
      for (keep = 0; keep < size; keep++) {
         SearchOverlay.Item item = this.visible.get(keep);
         if (item == null || item.exitB <= 0.001F && item.exitA <= 0.001F) {
            break;
         }
      }

      if (keep != size) {
         for (int scan = keep + 1; scan < size; scan++) {
            SearchOverlay.Item candidate = this.visible.get(scan);
            if (candidate != null && (0.001F < candidate.exitB || 0.001F < candidate.exitA)) {
               this.visible.set(scan, null);
               SearchOverlay.Item moved = this.visible.get(keep);
               this.visible.set(keep, candidate);
               if (moved != null) {
                  releaseItem(moved);
               }

               keep++;
            }
         }
      }

      for (int tail = this.visible.size() - 1; tail >= keep; tail--) {
         SearchOverlay.Item removed = this.visible.remove(tail);
         if (removed != null) {
            releaseItem(removed);
         }
      }
   }

   private void addTarget(List<SearchOverlay.Item> items, Object target, List<Object> crumbs) {
      if (readByte(target, 32) == 1) {
         Object entry = findOrCreateEntry(target, crumbs, 3);
         if (readPointer(entry, 112) == null) {
            Object tile = createTile(readPointer(target, 56));
            writePointer(entry, 112, tile);
            writeFloat(tile, 16, 484.0F);
            initTile(tile);
         }

         bindCrumbs(entry, 120);
         releaseCrumbs(crumbs);
      } else {
         Object entry = findOrCreateEntry(target, crumbs, 0);
         if (readPointer(entry, 104) == null) {
            SearchRow row = new SearchRow(readInt(target, 36), 0.0F, 0.0F, 0.0F, 0.0F, readPointer(target, 40));
            writePointer(entry, 104, row);
         }

         Object row = readPointer(entry, 104);
         setRowCrumbs(row, takeCrumbs(crumbs));
         if (readInt(target, 32) < 0) {
            bindCrumbs(entry, 120);
         } else {
            bindCrumbsAlt(entry, 120);
         }

         releaseCrumbs(crumbs);
      }
   }

   private float clampRange(float value) {
      if (value <= 0.0F) {
         return 0.0F;
      } else {
         return value <= 1.0F ? value : 1.0F;
      }
   }

   private void renderAltRow(SearchRow row, Object renderer, float mouseX, float mouseY, float alpha) {
   }

   private static void clearTargetMapEntries() {
   }

   private static void clearTargetMap() {
   }

   private static void releaseTargetMapStorage() {
   }

   private static void releaseCollections() {
   }

   private static void releaseVisibleList() {
   }

   private static void releaseRowList() {
   }

   private static void releaseEntryList() {
   }

   private static void releaseTargetList() {
   }

   private static void releaseInputField() {
   }

   private static void releaseItem(Object item) {
   }

   private static void releaseCrumbs(List<Object> crumbs) {
   }

   private static void releaseCallback(int offset) {
   }

   private static void registerTargetMap() {
   }

   private static void bindCrumbs(Object entry, int offset) {
   }

   private static void bindCrumbsAlt(Object entry, int offset) {
   }

   private static void setRowCrumbs(Object row, List<Object> crumbs) {
   }

   private static List<Object> takeCrumbs(List<Object> crumbs) {
      List<Object> moved = new ArrayList<>(crumbs);
      crumbs.clear();
      return moved;
   }

   private static Object createTile(Object handle) {
      return null;
   }

   private static void initTile(Object tile) {
   }

   private static Object findOrCreateEntry(Object target, List<Object> crumbs, int kind) {
      return null;
   }

   private static <T> T readPointer(Object target, int offset) {
      return null;
   }

   private static void writePointer(Object target, int offset, Object value) {
   }

   private static int readInt(Object target, int offset) {
      return 0;
   }

   private static int readByte(Object target, int offset) {
      return 0;
   }

   private static float readFloat(Object target, int offset) {
      return 0.0F;
   }

   private static void writeFloat(Object target, int offset, float value) {
   }

   private static boolean readBool(Object target) {
      return false;
   }

   private static void writeBool(Object target, boolean value) {
   }

   private static void invokeCallback(Object callback) {
   }

   private static boolean controlsCaptured(Object controls) {
      return false;
   }

   private static void controlsSetCaptured(Object controls, boolean value) {
   }

   private static void controlsSetLastInput(Object controls, int value) {
   }

   private static boolean controlsStateA(Object controls, int offset, double mx, double my, int button) {
      return false;
   }

   private static boolean controlsStateB(Object controls, int offset, double mx, double my, int button) {
      return false;
   }

   private static boolean controlsKeyA(Object controls, int keyCode) {
      return false;
   }

   private static boolean controlsKeyB(Object controls, int keyCode) {
      return false;
   }

   private static boolean inputHasContent() {
      return false;
   }

   private static void clearInputLine() {
   }

   private static void setInputChangedCallback(TextInput input) {
   }

   private static void textInputCharTyped(TextInput input, char ch) {
   }

   private static void textInputKeyPressed(TextInput input, int keyCode, int modifiers) {
   }

   private static void renderInputWidget(Object renderer, float x, float y, float w, int color, float alpha, boolean focused) {
   }

   private static void initGuiMetrics() {
   }

   private static float guiScale() {
      return 1.0F;
   }

   private static int screenWidth() {
      return 0;
   }

   private static int screenHeight() {
      return 0;
   }

   private static float smoothDamp(float value, float target, float smoothTime, float maxSpeed) {
      return target;
   }

   private static float smoothDampVelocity(float value, float velocity) {
      return 0.0F;
   }

   private static float[] makeRect(Object renderer, float alpha, float right, float bottom) {
      return new float[8];
   }

   private static void drawBackdrop(Object rect, float x, float y, float w, float h, float radius, float alpha) {
   }

   private static void drawHeaderPlate(Object renderer, float x, float y, float w, float h, float radius, float alpha, int flags) {
   }

   private static void drawHeaderPlateInner(Object renderer, float x, float y, float w, float h, float radius, int style, float alpha) {
   }

   private static int headerPanelStyle() {
      return 0;
   }

   private static void drawInputBox(Object renderer, float x, float y, float w, float h, int color, float alpha) {
   }

   private static void drawBoxGradient(Object renderer, float x, float y, float w, float h, float color, int themeIndex, float alpha) {
   }

   private static void drawText(int style, Object renderer, String text, float x, float y, float size, int color, float alpha) {
   }

   private static float measureText(int style, String text, float size) {
      return 0.0F;
   }

   private static void drawScrollbar(float depth, float[] rectA, float[] rectB) {
   }

   private static void beginClipLayer() {
   }

   private static void setScissor(float x, float y, float w, float h) {
   }

   private static void resetScissor() {
   }

   public static int uiThemeColor(Object theme, int offset) {
      return 0;
   }

   public static Object uiTheme() {
      return null;
   }

   public static final class Item {
      public int type;
      public String title = "";
      public String subtitle = "";
      public SearchRow child;
      public SearchRow altChild;
      public Object action;
      public Object actionAlt;
      public float reveal;
      public float offset;
      public float offsetVelocity;
      public float exitA;
      public float exitB;
      public final AbstractOverlay.Animator alphaAnim = new AbstractOverlay.Animator(0.0F, 0.15F, 0);
   }
}

