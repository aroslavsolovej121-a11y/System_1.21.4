package client.gui;

import client.Setting;

public class AbstractTrackChoiceWidget extends Component {
   public static final int SLOT_DESTROY = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_MOUSE_RELEASED = 40;
   public static final int SLOT_MOUSE_DRAGGED = 48;
   public static final int SLOT_SET_POSITION = 88;
   public static final int SLOT_GET_HEIGHT = 96;
   public static final int SLOT_MEASURE = 104;
   public static final int SLOT_TYPE_ID = 136;
   public static final int SLOT_VALUE_PAD = 144;
   public static final int SLOT_VALUE_MIN = 152;
   public static final int SLOT_TRACK_COUNT = 160;
   public static final int SLOT_LABEL = 168;
   public static final int SLOT_ANIM_TARGET = 176;
   public static final int SLOT_SET_INDEX = 184;
   public static final int SLOT_RENDER_TRACK = 192;
   public static final float DEFAULT_WIDTH = 269.0F;
   public static final float ROW_HEIGHT = 32.0F;
   public static final float PAD_Y = 6.0F;
   public static final float PAD_X = 8.0F;
   public static final float TEXT_PAD = 16.0F;
   public static final float LABEL_FONT = 12.0F;
   public static final float VALUE_FONT = 14.0F;
   public static final float LABEL_LINE_HEIGHT = 14.4F;
   public static final float VALUE_LINE_HEIGHT = 16.800001F;
   public static final float VALUE_MIN_HEIGHT = 20.0F;
   public static final float INNER_GAP = 3.0F;
   public static final float CELL_GAP = 2.0F;
   public static final double CELL_INSET = 3.0;
   public static final float ICON_OFFSET = 7.0F;
   public static final float ROW_RADIUS = 10.0F;
   public static final float ANIM_DURATION = 0.22F;
   public static final float EPSILON = 0.001F;
   public static final float HALF = 0.5F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float DRAG_THRESHOLD = 1.5F;
   public static final long NANOS_PER_SECOND = 1000000000L;
   public static final int TYPE_ID = 89;
   public static final int TYPE_CHOICE = 73;
   public static final int TYPE_ALIGNMENT = 66;
   public static final int TYPE_CHECKBOX = 65;
   public static final int TYPE_COMPACT_GROUP = 27;
   public static final int TYPE_DROP_DOWN = 62;
   public static final int HOVER_KIND_NONE = 0;
   public static final int HOVER_KIND_ROW = 1;
   public static final int HOVER_KIND_TRACK_DRAG = 3;
   public static final int HOVER_KIND_DROP_DOWN = 4;
   public static final int ICON_ALIGN_LEFT = 42;
   public static final int ICON_ALIGN_CENTER = 43;
   public static final int ICON_ALIGN_RIGHT = 44;
   public static final int[] ALIGNMENT_VALUES = new int[]{0, 1, 2};
   public static boolean hoverGatePointerNull = true;
   public static boolean mouseInsideWindow;
   public static int hoveredWidget;
   public static byte metricRevision;
   protected Setting setting;
   protected float valueHeightKey = -1.0F;
   protected float valueHeight;
   protected float labelWidthKey = -1.0F;
   protected float labelHeight;
   protected byte metricRevisionLocal;
   protected float animFrom;
   protected float animCurrent;
   protected float animTarget;
   protected float animDuration = 0.22F;
   protected long animStart;
   protected boolean animRunning;
   protected boolean pressed;
   protected boolean dragging;
   protected double pressX;
   protected Setting trackSetting;

   public AbstractTrackChoiceWidget() {
   }

   public AbstractTrackChoiceWidget(Setting setting) {
      this.initSettingWidget(setting);
      this.animFrom = 0.0F;
      this.animCurrent = 0.0F;
      this.animTarget = 0.0F;
      this.animDuration = 0.22F;
      this.animStart = clock();
      this.animRunning = false;
      this.pressed = false;
      this.dragging = false;
      this.pressX = 0.0;
   }

   protected void initSettingWidget(Setting setting) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.animXFrom = 0.0F;
      this.animYFrom = 0.0F;
      this.animatingPosition = false;
      this.setting = setting;
      this.labelWidthKey = -1.0F;
      this.labelHeight = 0.0F;
      this.valueHeightKey = -1.0F;
      this.valueHeight = 0.0F;
      this.metricRevisionLocal = 0;
      this.width = 269.0F;
   }

   public Setting getSetting() {
      return this.setting;
   }

   public Setting getTrackSetting() {
      return this.trackSetting;
   }

   protected static long clock() {
      return System.nanoTime();
   }

   protected int getTypeId() {
      return 89;
   }

   protected float getValuePad() {
      return 16.0F;
   }

   protected float getValueMin() {
      return 16.0F;
   }

   protected int getTrackCount() {
      return 0;
   }

   protected String getTrackLabel() {
      return "";
   }

   protected float getTrackAnimTarget() {
      return 0.0F;
   }

   protected void setTrackIndex(int index) {
   }

   protected void renderTrack(Object mat, float top, float alpha) {
   }

   protected float cellWidth() {
      float trackWidth = this.width - 6.0F;
      int count = this.getTrackCount();
      return (trackWidth - ((float)(count - 1) + (count - 1))) / count;
   }

   protected float labelTextWidth() {
      return textWidth(this.getTrackLabel(), 12.0F) + 16.0F;
   }

   protected float measureLabelHeight(float available) {
      if (!this.settingVisible()) {
         return 0.0F;
      } else {
         if (this.metricRevisionLocal != metricRevision) {
            this.metricRevisionLocal = metricRevision;
            this.labelWidthKey = -1.0F;
            this.valueHeightKey = -1.0F;
         }

         if (available != this.labelWidthKey) {
            int lines = wrapLineCount(0, this.settingLabel(), 12.0F, available);
            float measured = lines * 14.4F;
            this.labelWidthKey = available;
            this.labelHeight = measured;
            return measured;
         } else {
            return this.labelHeight;
         }
      }
   }

   protected float measureValueHeight(float available) {
      int typeId = this.getTypeId();
      float pad = typeId == 89 ? 0.0F : 20.0F;
      float local = available - pad;
      if (local <= 0.0F) {
         local = 0.0F;
      }

      if (this.metricRevisionLocal != metricRevision) {
         this.metricRevisionLocal = metricRevision;
         this.labelWidthKey = -1.0F;
         this.valueHeightKey = -1.0F;
      }

      if (local != this.valueHeightKey) {
         int lines = wrapLineCount(2, this.settingValue(), 14.0F, local);
         float measured = lines * 16.800001F;
         if (typeId != 89) {
            float minimum = this.getValueMin();
            if (minimum > measured) {
               measured = minimum;
            }
         }

         this.valueHeightKey = local;
         this.valueHeight = measured;
         return measured;
      } else {
         return this.valueHeight;
      }
   }

   protected float drawHeader(Object mat, float available, float alpha) {
      float measured = this.measureValueHeight(available);
      int typeId = this.getTypeId();
      float pad = typeId == 89 ? 0.0F : 20.0F;
      float local = available - pad;
      if (local <= 0.0F) {
         local = 0.0F;
      }

      if (typeId != 89) {
         float valuePad = this.getValuePad();
         float minimum = this.getValueMin();
         int color = rendererSecondaryColor();
         drawText(mat, typeId, this.x + (16.0F - valuePad) * 0.5F, this.y + (14.0F - minimum) * 0.5F, valuePad, minimum, color, alpha);
      }

      drawValueText(mat, this.x + pad, this.y, 14.0F, local, rendererSecondaryColor(), alpha);
      return measured;
   }

   protected float drawLabel(Object mat, float yOffset, float alpha) {
      if (!this.settingVisible()) {
         return 0.0F;
      } else {
         float measured = this.measureLabelHeight(this.width);
         drawLabelText(mat, this.x, yOffset + this.y, 12.0F, rendererSecondaryColor(), alpha);
         return measured;
      }
   }

   protected boolean settingVisible() {
      return true;
   }

   protected String settingLabel() {
      return this.setting == null ? "" : this.setting.getName();
   }

   protected String settingValue() {
      return this.setting == null ? "" : this.setting.getName();
   }

   protected static float textWidth(String text, float size) {
      return 0.0F;
   }

   protected static int wrapLineCount(int align, String text, float size, float available) {
      if (!(available <= 0.0F) && text != null) {
         float wrapped = textWidth(text, size);

         int lines;
         for (lines = 1; wrapped > available; lines++) {
            wrapped -= available;
         }

         return lines;
      } else {
         return available <= 0.0F ? 0 : 1;
      }
   }

   protected static int rendererColor() {
      return 0;
   }

   protected static int rendererSecondaryColor() {
      return 0;
   }

   protected static void drawText(Object mat, int icon, float px, float py, float w, float h, int color, float alpha) {
   }

   protected static void drawValueText(Object mat, float px, float py, float size, float available, int color, float alpha) {
   }

   protected static void drawValueTextAtEdge(Object mat, float px, float py, String text, float alpha) {
   }

   protected static void drawLabelText(Object mat, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawCell(Object mat, float px, float py, float w, float h, int color, float alpha) {
   }

   protected static void drawRowBackground(Object mat, float px, float py, float w, float h, float radius, float alpha) {
   }

   protected static void drawRowDivider(Object mat, float px, float py, float w, float h, int color, float alpha) {
   }

   protected static void drawRowInner(Object mat, float px, float py, float w, float h, float radius, int color, float alpha) {
   }

   public static boolean hoverAllowed() {
      return hoverGatePointerNull || mouseInsideWindow;
   }

   protected static boolean inside(float rx, float ry, float rw, float rh, double mx, double my) {
      return mx >= rx && mx <= rx + rw && my >= ry && my <= ry + rh;
   }

   protected static float advanceAnim(AbstractTrackChoiceWidget widget) {
      if (widget.animRunning && !(widget.animDuration <= 0.0F)) {
         float t = (float)((clock() - widget.animStart) / 1.0E9) / widget.animDuration;
         if (t <= 0.0F) {
            widget.animCurrent = widget.animFrom;
            return widget.animCurrent;
         } else if (t >= 1.0F) {
            widget.animRunning = false;
            widget.animCurrent = widget.animTarget;
            return widget.animCurrent;
         } else {
            widget.animCurrent = easeOutCubic(t) * (widget.animTarget - widget.animFrom) + widget.animFrom;
            return widget.animCurrent;
         }
      } else {
         widget.animCurrent = widget.animTarget;
         widget.animRunning = false;
         return widget.animCurrent;
      }
   }

   protected static void setAnimTarget(AbstractTrackChoiceWidget widget, float target) {
      if (widget.animTarget != target) {
         float current = advanceAnim(widget);
         widget.animFrom = current;
         widget.animTarget = target;
         widget.animStart = clock();
         widget.animRunning = true;
      }
   }

   protected float wrapIndex(double mx) {
      float cells = this.cellWidth();
      float raw = (float)((mx - this.x - 3.0) / (cells + 2.0F)) - 0.5F;
      if (raw < 0.0F) {
         raw = 0.0F;
      }

      float limit = this.getTrackCount() - 1.0F;
      if (raw > limit) {
         raw = limit;
      }

      return raw;
   }

   protected float measureHeight() {
      float labelWidth = this.labelTextWidth();
      float base = this.measureValueHeight(this.width - labelWidth - 8.0F);
      float label = this.measureLabelHeight(this.width);
      if (label > 0.0F) {
         base = base + 0.0F + label;
      }

      return base + 6.0F + 32.0F;
   }

   public void measure() {
      this.measureHeight();
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         float label = this.measureLabelHeight(this.width);
         float labelWidth = this.labelTextWidth();
         float base = this.measureValueHeight(this.width - labelWidth - 8.0F);
         if (label > 0.0F) {
            base = base + 0.0F + label;
         }

         if (mx >= this.x && mx <= this.x + this.width) {
            float top = base + this.y + 6.0F;
            if (top <= my && my <= top + 32.0F) {
               this.pressX = mx;
               this.pressed = true;
               this.dragging = false;
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.pressed && button == 0) {
         this.pressed = false;
         this.dragging = false;
         int count = this.getTrackCount();
         int index;
         if (!this.dragging) {
            float cells = this.cellWidth();
            index = (int)Math.floor((mx - this.x - 3.0) / (cells + 2.0F));
         } else {
            index = Math.round(this.wrapIndex(mx));
         }

         if (index < 0) {
            index = 0;
         }

         if (index > count - 1) {
            index = count - 1;
         }

         this.setTrackIndex(index);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      if (this.pressed && (int)delta == 0) {
         if (!this.dragging) {
            if (Math.abs(mx - this.pressX) < 1.5) {
               return true;
            }

            this.dragging = true;
         }

         setAnimTarget(this, this.wrapIndex(mx));
         return true;
      } else {
         return false;
      }
   }

   public void renderTrackWidget(Object mat, float mouseX, float mouseY, float alpha) {
      float labelWidth = textWidth(this.getTrackLabel(), 12.0F);
      float valueMeasured = this.drawHeader(mat, this.width - (labelWidth + 16.0F) - 8.0F, alpha);
      float labelMeasured = this.drawLabel(mat, valueMeasured, alpha);
      drawValueTextAtEdge(mat, this.x + this.width, this.y, this.settingValue(), alpha);
      float top = valueMeasured;
      if (labelMeasured > 0.0F) {
         top = valueMeasured + 0.0F + labelMeasured;
      }

      top = top + this.y + 6.0F;
      if (!this.dragging) {
         if (this.pressed || inside(this.x, this.y, this.width, 32.0F, mouseX, mouseY) && hoverAllowed()) {
            hoveredWidget = 1;
         }
      } else {
         hoveredWidget = 3;
      }

      drawRowBackground(mat, this.x, top, this.width, 32.0F, 10.0F, alpha);
      this.cellWidth();
      int count = this.getTrackCount();
      int i = 0;
      if (count > 0) {
         do {
            float cells = this.cellWidth();
            drawRowDivider(mat, this.x + (cells + 2.0F) * i, top, cells, 32.0F, rendererColor(), alpha);
            i++;
            count = this.getTrackCount();
         } while (i < count);
      }

      if (!this.dragging) {
         float target = this.getTrackAnimTarget();
         if (this.animTarget != target) {
            setAnimTarget(this, target);
         }
      }

      drawRowInner(mat, this.x, top, this.width, 32.0F, 10.0F, rendererColor(), alpha);
      this.renderTrack(mat, top, alpha);
      this.height = top + 32.0F - this.y;
   }

   @Override
   public void render() {
   }
}

