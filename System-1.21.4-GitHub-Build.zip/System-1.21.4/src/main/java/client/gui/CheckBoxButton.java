package client.gui;

public class CheckBoxButton extends AbstractButton {
   public static final float DEFAULT_WIDTH = 16.0F;
   public static final float DEFAULT_HEIGHT = 16.0F;
   public static final float ANIM_VALUE_INIT = 0.0F;
   public static final float ANIM_DURATION = 0.22F;
   public static final int CLICK_EFFECT_UNCHECKED = 7;
   public static final int CLICK_EFFECT_CHECKED = 6;
   protected boolean value;
   protected boolean field0xC8 = false;
   protected boolean field0xF0 = false;
   public final AbstractButton.Anim animCheck = new AbstractButton.Anim(0.0F, 0.22F);
   public final AbstractButton.Anim animBox = new AbstractButton.Anim(0.0F, 0.22F);

   public CheckBoxButton(boolean checked) {
      this.value = checked;
      this.field0xC8 = false;
      this.field0xF0 = false;
      this.width = 16.0F;
      this.height = 16.0F;
      float initial = checked ? 1.0F : 0.0F;
      this.animCheck.reset(initial, 0.22F);
      this.animBox.reset(initial, 0.22F);
   }

   @Override
   public boolean onClick(double mx, double my) {
      boolean previous = this.value;
      if (previous != !previous) {
         this.value = !previous;
         float target = 1.0F;
         if (previous) {
            this.animCheck.animateTo(0.0F);
            target = 0.0F;
         } else {
            this.animCheck.animateTo(1.0F);
         }

         this.animBox.animateTo(target);
      }

      playClickEffect(this.value ? 6 : 7);
      this.notifyChanged();
      return true;
   }

   public boolean isChecked() {
      return this.value;
   }

   public void setChecked(boolean checked) {
      this.value = checked;
   }
}

