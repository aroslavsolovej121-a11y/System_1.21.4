package client.gui;

import client.Setting;

public class StaffNickListWidget extends ModalTriggerWidget {
   public static final int LIST_OFFSET = 384;
   public static final int FIELD_OFFSET = 392;
   public static final int CACHE_A_OFFSET = 832;
   public static final int CACHE_B_OFFSET = 840;
   public static final int CACHE_C_OFFSET = 848;
   public static final int ROW_GAP_OFFSET = 856;
   public static final int SCROLL_TARGET_OFFSET = 864;
   public static final int SCROLL_ANIM_OFFSET = 872;
   public static final int FILTER_FLAG_OFFSET = 904;
   public static final int ENTRY_COUNT_OFFSET = 912;
   public static final int CALLBACK_OFFSET = 488;
   public static final int MODAL_WIDTH_OFFSET = 192;
   public static final int MODAL_HEIGHT_OFFSET = 196;
   public static final int MODAL_FLAGS_OFFSET = 313;
   public static final float ROW_GAP = 4.0F;
   public static final float SCROLL_SPEED = 0.28F;
   public static final float MODAL_WIDTH = 310.0F;
   public static final float MODAL_HEIGHT = 232.0F;
   public static final float FIELD_WIDTH = 278.0F;
   public static final float FIELD_HEIGHT = 36.0F;
   public static final float FIELD_FONT_SIZE = 14.0F;
   public static final float FIELD_INSET = 12.0F;
   public static final String FIELD_PLACEHOLDER = "Вставьте ники через пробел, Enter";
   public static final String TITLE_TEXT = "Cвои ники";
   public static final int TRIGGER_KEY = 34;
   public static final int TITLE_LENGTH = 16;
   public static final long NO_TARGET = -1L;
   private Object list;
   private TextInput field;
   private float rowGap = 4.0F;
   private long scrollTarget = -1L;
   private float scrollAnim;
   private boolean filterActive;
   private int entryCount;
   private Object callback;

   public StaffNickListWidget() {
      this.list = null;
      this.field = null;
   }

   public StaffNickListWidget(Setting setting, Object list) {
      super(setting);
      this.list = list;
      this.field = new TextInput(278.0F, 36.0F, "Вставьте ники через пробел, Enter", 14.0F, 12.0F, 0.0F);
      this.rowGap = 4.0F;
      this.scrollTarget = -1L;
      this.scrollAnim = 0.0F;
      this.filterActive = false;
      this.entryCount = 0;
      this.callback = null;
   }

   @Override
   public int triggerKey() {
      return 34;
   }

   @Override
   public Object title() {
      return "Cвои ники";
   }

   @Override
   public void reset(Object callback) {
      this.entryCount = 0;
      this.scrollAnim = 0.0F;
      this.scrollTarget = 0L;
      this.filterActive = false;
      this.resetModalContent(callback);
   }

   @Override
   public Object openAction() {
      return this.field;
   }

   @Override
   public boolean isVisible() {
      return true;
   }

   public Object list() {
      return this.list;
   }

   public TextInput field() {
      return this.field;
   }

   public float rowGap() {
      return this.rowGap;
   }

   public long scrollTarget() {
      return this.scrollTarget;
   }

   public float scrollAnim() {
      return this.scrollAnim;
   }

   public boolean filterActive() {
      return this.filterActive;
   }

   public int entryCount() {
      return this.entryCount;
   }

   private void resetModalContent(Object callback) {
   }
}

