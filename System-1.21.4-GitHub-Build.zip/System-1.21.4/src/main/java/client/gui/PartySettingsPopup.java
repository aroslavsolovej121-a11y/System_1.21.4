package client.gui;

public class PartySettingsPopup extends AbstractOverlay {
   public static final int ROW_SLOT_EXPANDED = 14;
   public static final int ROW_SLOT_COLLAPSE = 15;
   public static final float CARD_WIDTH = 305.0F;
   public static final float EPSILON = 0.001F;
   public static final float HALF = 0.5F;
   public static final float ALPHA_SHIFT = 16.0F;
   public static final float OVERLAY_METRIC = 14.0F;
   public static final float EMPTY = 0.0F;
   public static final float FULL_ALPHA = 1.0F;
   protected ModuleCard card;

   public PartySettingsPopup(Object feature) {
      this.card = new ModuleCard(feature);
      this.width = 305.0F;
      if (0.001F < Math.abs(this.card.width - 305.0F)) {
         this.card.width = 305.0F;
         this.card.cachedChildWidth = Float.NaN;
      }
   }

   @Override
   public float overlayConst() {
      return 14.0F;
   }

   @Override
   public void setChild(Component value) {
      this.height = cardTargetHeight(this.card);
      super.setChild(value);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (!cardAcceptsMouse(this.card)) {
         return super.mouseClicked(mx, my, button);
      } else {
         if (!this.closed) {
            this.card.mouseClicked(mx, my, button);
         }

         return true;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      this.card.mouseReleased(mx, my, button);
      return true;
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      return this.card.mouseDragged(mx, my, (int)delta, 0.0, 0.0);
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      this.card.mouseScrolled(mx, my, amount);
      return true;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (!this.card.keyPressed(keyCode)) {
         if (!this.closeOnEscape || keyCode != 27) {
            return this.onKeyPressed(keyCode, modifiers);
         }

         this.close();
      }

      return true;
   }

   @Override
   public boolean keyReleased(int keyCode) {
      this.card.keyReleased(keyCode);
      return true;
   }

   @Override
   public boolean charTyped(char ch) {
      this.card.charTyped(ch);
      return true;
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      float cardHeight = cardPreferredHeight(this.card);
      float clamped = clamp01(parentAlpha);
      float top = (1.0F - clamped) * 16.0F + this.y;
      this.height = cardHeight;
      Object rect = PartySettingsPopup.OverlayDraw.makeRect(target, parentAlpha, this.width * 0.5F + this.x, cardHeight * 0.5F + top);
      this.card.x = this.x;
      this.card.y = top;
      cardLayoutHeader(this.card);
      this.card.render(rect, rx, ry, parentAlpha);
      this.card.layout(target, rx, ry, parentAlpha);
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      this.card.mouseClicked(mx, my, button);
      return true;
   }

   @Override
   public void onClosed() {
      for (Component child : this.card.ownedChildren) {
         if (isExpanded(child)) {
            collapse(child);
         }
      }
   }

   @Override
   public void dispose() {
      this.card = null;
      super.dispose();
   }

   public ModuleCard card() {
      return this.card;
   }

   private static boolean isExpanded(Component child) {
      return false;
   }

   private static void collapse(Component child) {
   }

   private static boolean cardAcceptsMouse(ModuleCard value) {
      return false;
   }

   private static float cardTargetHeight(ModuleCard value) {
      return 0.0F;
   }

   private static float cardPreferredHeight(ModuleCard value) {
      return 0.0F;
   }

   private static void cardLayoutHeader(ModuleCard value) {
   }

   private static final class OverlayDraw {
      public static Object makeRect(Object target, float alpha, float centerX, float centerY) {
         return null;
      }
   }
}

