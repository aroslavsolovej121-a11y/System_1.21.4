package client.gui;

public class MainHeader extends Component {
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int CALLBACK_STORAGE_1_OFFSET = 96;
   public static final int CALLBACK_1_OFFSET = 152;
   public static final int CALLBACK_STORAGE_2_OFFSET = 160;
   public static final int CALLBACK_2_OFFSET = 216;
   public static final int CALLBACK_STORAGE_3_OFFSET = 224;
   public static final int CALLBACK_3_OFFSET = 280;
   public static final int CALLBACK_STORAGE_4_OFFSET = 288;
   public static final int CALLBACK_4_OFFSET = 344;
   public static final int EXPANDED_OFFSET = 352;
   public static final int COLLAPSED_OFFSET = 353;
   public static final int TEXT_OFFSET = 360;
   public static final int EDIT_BUFFER_OFFSET = 392;
   public static final int MARKER_ANIM_OFFSET = 424;
   public static final int COMMITTING_OFFSET = 464;
   public static final int MARKER_DIR_OFFSET = 468;
   public static final int MARKER_ALT_OFFSET = 472;
   public static final int ICON_SWAP_OFFSET = 480;
   public static final int BUTTON_SIDEBAR_OFFSET = 488;
   public static final int BUTTON_FAVORITES_OFFSET = 736;
   public static final int BUTTON_LANGUAGE_OFFSET = 984;
   public static final int BUTTON_LIGHT_OFFSET = 1232;
   public static final int BUTTON_DARK_OFFSET = 1480;
   public static final int BUTTON_COLLAPSE_OFFSET = 1728;
   public static final int COLLAPSE_ANIM_OFFSET = 1976;
   public static final int THEME_ANIM_OFFSET = 2016;
   public static final int SEARCH_ANIM_OFFSET = 2056;
   public static final int SEARCH_READY_OFFSET = 2096;
   public static final int SEARCH_HOVER_ANIM_OFFSET = 2104;
   public static final int SEARCH_X_OFFSET = 2144;
   public static final int SEARCH_Y_OFFSET = 2148;
   public static final int BUTTON_ICON_OFFSET = 96;
   public static final int BUTTON_KEY_OFFSET = 100;
   public static final int BUTTON_SIZE_OFFSET = 108;
   public static final int BUTTON_TEXT_OFFSET = 216;
   public static final int BUTTON_CALLBACK_OFFSET = 208;
   public static final float DEFAULT_WIDTH = 964.0F;
   public static final float DEFAULT_HEIGHT = 50.0F;
   public static final float HEADER_INSET = 16.0F;
   public static final float HEADER_HEIGHT = 32.0F;
   public static final float PANEL_HEIGHT = 50.0F;
   public static final float PANEL_RADIUS = 18.0F;
   public static final float BUTTON_PANEL_SIZE = 42.0F;
   public static final float BUTTON_SIZE = 36.0F;
   public static final float BUTTON_SIZE_WIDE = 46.0F;
   public static final float BUTTON_GAP = 3.0F;
   public static final float BUTTON_ROW_INSET = 4.0F;
   public static final float TITLE_GAP = 6.0F;
   public static final float TITLE_INSET = 1.0F;
   public static final float FONT_SIZE = 14.0F;
   public static final float SEARCH_WIDTH = 300.0F;
   public static final float SEARCH_INNER_WIDTH = 294.0F;
   public static final float SEARCH_HEIGHT = 42.0F;
   public static final float SEARCH_RADIUS = 12.0F;
   public static final float TEXT_INSET_Y = 7.0F;
   public static final float CLEAR_TEXT_OFFSET = 4.0F;
   public static final float COLLAPSE_OFFSET = 46.0F;
   public static final float MARKER_DURATION = 0.18F;
   public static final float FADE_DURATION = 0.22F;
   public static final float SEARCH_DURATION = 0.32F;
   public static final float REVEAL_EXPONENT = 1.7F;
   public static final float EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final float HALF = 0.5F;
   public static final float MARKER_STEP = 3.0F;
   public static final float MARKER_CLEARANCE = 8.0F;
   public static final float ICON_GAP = 12.0F;
   public static final float LABEL_GAP = 18.0F;
   public static final float CLEAR_SIZE = 20.0F;
   public static final float CLEAR_OFFSET = 10.0F;
   public static final float CLEAR_INSET = 8.0F;
   public static final float INFO_RIGHT_INSET = 8.0F;
   public static final long INFO_INTERVAL_MS = 60000L;
   public static final int KEY_FAVORITES = 14;
   public static final int KEY_NONE = 89;
   public static final int ICON_COLLAPSE = 16;
   public static final int ICON_EXPAND = 15;
   public static final int ICON_SIDEBAR = 5;
   public static final int ICON_FAVORITES = 13;
   public static final int ICON_LANGUAGE = 19;
   public static final int ICON_LIGHT = 17;
   public static final int ICON_DARK = 18;
   public static final int SEARCH_GLYPH = 9;
   public static final int SEARCH_CLEAR_GLYPH = 74;
   public static final int FAVORITE_GLYPH = 5;
   public static final String LABEL_SIDEBAR = "Боковая панель";
   public static final String LABEL_FAVORITES = "Избранное";
   public static final String LABEL_LIGHT = "Светлая тема";
   public static final String LABEL_LIGHT_DISABLED = "Светлая тема недоступна с прозрачной темой";
   public static final String LABEL_DARK = "Тёмная тема";
   public static final String LABEL_COLLAPSE = "Свернуть всё";
   public static final String LABEL_EXPAND = "Развернуть";
   public static final String LABEL_EN = "Switch to EN";
   public static final String LABEL_RU = "Switch to RU";
   public static final String TEXT_INITIAL = "All";
   public static final String SEARCH_PLACEHOLDER = "Поиск";
   public static final String SEARCH_CLEAR_TEXT = "×";
   public static final String INFO_FORMAT = "{} ms";
   public static final String INFO_EMPTY = "- ms";
   protected final MainHeader.Anim rectAnim = new MainHeader.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected final byte[] callbackStorage1 = new byte[56];
   protected Object callback1;
   protected final byte[] callbackStorage2 = new byte[56];
   protected Object callback2;
   protected final byte[] callbackStorage3 = new byte[56];
   protected Object callback3;
   protected final byte[] callbackStorage4 = new byte[56];
   protected Object callback4;
   protected byte expanded;
   protected byte collapsed;
   protected String text = "All";
   protected String editBuffer = "";
   protected final MainHeader.Anim markerAnim = new MainHeader.Anim();
   protected byte committing;
   protected int markerDir = 1;
   protected int markerAlt = 1;
   protected byte iconSwap;
   protected IconButton sidebarButton;
   protected IconButton favoritesButton;
   protected IconButton languageButton;
   protected IconButton lightButton;
   protected IconButton darkButton;
   protected IconButton collapseButton;
   protected final MainHeader.Anim collapseAnim = new MainHeader.Anim();
   protected final MainHeader.Anim themeAnim = new MainHeader.Anim();
   protected final MainHeader.Anim searchAnim = new MainHeader.Anim();
   protected boolean searchReady;
   protected final MainHeader.Anim searchHoverAnim = new MainHeader.Anim();
   protected float searchX;
   protected float searchY;
   protected long infoStamp;
   protected static int frameMillis;
   private static final float ONE = 1.0F;
   private static final float RECT_ANIM_DURATION = 0.15F;

   public MainHeader() {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.callback1 = null;
      this.callback2 = null;
      this.callback3 = null;
      this.callback4 = null;
      this.expanded = 0;
      this.collapsed = 0;
      this.text = "All";
      this.editBuffer = "";
      this.markerAnim.from = 1.0F;
      this.markerAnim.current = 1.0F;
      this.markerAnim.target = 1.0F;
      this.markerAnim.duration = 0.18F;
      this.markerAnim.easing = 0;
      this.markerAnim.start = MainHeader.Anim.now();
      this.markerAnim.running = false;
      this.committing = 0;
      this.markerDir = 1;
      this.markerAlt = 1;
      this.iconSwap = 0;
      this.sidebarButton = new IconButton(5, 36.0F);
      this.favoritesButton = new IconButton(13, 36.0F);
      this.languageButton = new IconButton(19, 36.0F);
      this.lightButton = new IconButton(17, 36.0F);
      this.darkButton = new IconButton(18, 36.0F);
      this.collapseButton = new IconButton(16, 36.0F);
      this.collapseAnim.set(1.0F, 0.22F);
      this.themeAnim.set(themeLight() ? 1.0F : 0.0F, 0.22F);
      this.searchAnim.from = 0.0F;
      this.searchAnim.current = 0.0F;
      this.searchAnim.target = 0.0F;
      this.searchAnim.duration = 0.32F;
      this.searchAnim.easing = 2;
      this.searchAnim.start = MainHeader.Anim.now();
      this.searchAnim.running = false;
      this.searchHoverAnim.set(0.0F, 0.15F);
      this.width = 964.0F;
      this.height = 50.0F;
      this.markerAnim.easing = 1;
      setButtonSize(this.sidebarButton, 0.0F);
      setButtonSize(this.favoritesButton, 0.0F);
      setButtonSize(this.languageButton, 0.0F);
      setButtonSize(this.lightButton, 0.0F);
      setButtonSize(this.darkButton, 0.0F);
      setButtonSize(this.collapseButton, 0.0F);
      setButtonWidth(this.lightButton, 46.0F);
      setButtonWidth(this.darkButton, 46.0F);
      setButtonLabel(this.sidebarButton, "Боковая панель");
      setButtonCallback(this.sidebarButton, createSidebarAction());
      setButtonLabel(this.collapseButton, "Свернуть всё");
      setButtonCallback(this.collapseButton, createCollapseAction());
      setButtonLabel(this.lightButton, "Светлая тема");
      setButtonCallback(this.lightButton, createLightAction());
      setButtonLabel(this.darkButton, "Тёмная тема");
      setButtonCallback(this.darkButton, createDarkAction());
      setButtonCallback(this.languageButton, createLanguageAction());
      setButtonKey(this.favoritesButton, 14);
      setButtonLabel(this.favoritesButton, "Избранное");
      setButtonCallback(this.favoritesButton, createFavoritesAction());
   }

   @Override
   public void dispose() {
      resetString(360);
      resetString(392);
      clearButton(this.collapseButton);
      clearButton(this.darkButton);
      clearButton(this.lightButton);
      clearButton(this.languageButton);
      clearButton(this.favoritesButton);
      clearButton(this.sidebarButton);
      freeString(392);
      freeString(360);
      releaseChild(this.callback4, this.callback4 != this.callbackStorage4);
      this.callback4 = null;
      releaseChild(this.callback3, this.callback3 != this.callbackStorage3);
      this.callback3 = null;
      releaseChild(this.callback2, this.callback2 != this.callbackStorage2);
      this.callback2 = null;
      releaseChild(this.callback1, this.callback1 != this.callbackStorage1);
      this.callback1 = null;
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      float headerX = this.x + 16.0F;
      float headerWidth = this.width - 32.0F;
      Object panel = drawPanelTinted(mat, headerX, this.y, headerWidth, 50.0F, 18.0F, alpha);
      float fVar12 = this.y + 4.0F;
      float fVar13 = headerX + 4.0F;
      float fVar16 = 18.0F;
      this.drawButtonRow(panel, mat, this.sidebarButton, fVar13, fVar12, fVar16, mouseX, mouseY, alpha);
      this.drawFavoritesBadge(this, mat, fVar13, fVar12, alpha);
      float fVar16b = this.y;
      float marker = this.markerAnim.advance(MainHeader.Anim.now());
      if (this.committing != 0 && marker <= 0.001F) {
         if (!this.text.equals(this.editBuffer)) {
            this.text = this.editBuffer;
         }

         this.editBuffer = "";
         this.committing = 0;
         this.markerAnim.duration = 0.18F;
         this.markerAnim.easing = 1;
         this.markerAnim.retarget(1.0F);
         marker = this.markerAnim.advance(MainHeader.Anim.now());
      }

      int dir = -this.markerDir;
      if (this.committing == 0) {
         dir = this.markerDir;
      }

      float value = clamp01(marker);
      value = (float)Math.pow(value, 1.7F);
      drawText(mat, this.text, fVar13 + 42.0F + 6.0F, (1.0F - marker) * 6.0F * dir + fVar16b + 18.0F, 14.0F, themeColor(24), value * alpha);
      this.drawSearchField(mat, mouseX, mouseY, headerX, headerWidth, alpha);
      this.renderRightButtons(mat, mouseX, mouseY, headerX, headerWidth, alpha);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      IconButton[] order = new IconButton[]{
         this.sidebarButton, this.collapseButton, this.lightButton, this.darkButton, this.languageButton, this.favoritesButton
      };

      for (IconButton child : order) {
         boolean collapseReady = child != this.collapseButton || 0.5F <= this.collapseAnim.current;
         if (collapseReady
            && button == 0
            && child.x <= (float)mx
            && mx <= child.x + child.width
            && child.y <= (float)my
            && my <= child.y + child.height
            && invokeButton(child, mx, my)) {
            return true;
         }
      }

      if (button == 0 && this.searchX <= (float)mx && mx <= this.searchX + 300.0F && this.searchY <= (float)my && my <= this.searchY + 42.0F) {
         if (this.callback4 != null) {
            invokeCallback(this.callback4);
         }

         return true;
      } else {
         return false;
      }
   }

   public void renderRightButtons(Object mat, float mouseX, float mouseY, float headerX, float headerWidth, float alpha) {
      this.iconSwap = (byte)(16 - (this.expanded != 0 ? 1 : 0));
      setButtonLabel(this.collapseButton, this.expanded != 0 ? "Развернуть" : "Свернуть всё");
      setButtonLabel(this.languageButton, russianActive() ? "Switch to RU" : "Switch to EN");
      if (themeLightAvailable() != this.collapsed) {
         this.collapsed = themeLightAvailable();
         setButtonLabel(this.lightButton, this.collapsed != 0 ? "Светлая тема" : "Светлая тема недоступна с прозрачной темой");
      }

      float inset = 4.0F;
      float rightY = this.y + inset;
      float rightEdge = headerX + headerWidth - inset;
      float collapse = this.collapseAnim.advance(MainHeader.Anim.now());
      float collapseX = rightEdge - 42.0F;
      float cursor = rightEdge - collapse * 42.0F;
      if (0.001F < collapse) {
         cursor -= collapse * inset;
      }

      cursor -= 46.0F;
      float languageX = cursor - 46.0F;
      float favoritesX = languageX + -46.0F;
      Object handle = this.drawButtonRow(collapseX, mat, this.favoritesButton, favoritesX, rightY, 18.0F, mouseX, mouseY, alpha);
      this.drawButtonRow(handle, mat, this.languageButton, languageX, rightY, 18.0F, mouseX, mouseY, alpha);
      drawPanel(mat, cursor, rightY, 46.0F, 42.0F, 14.0F, alpha, 1.0F);
      if (0.001F < collapse) {
         float value = clamp01(collapse);
         value = (float)Math.pow(value, 1.7F);
         this.drawButtonRow(value * alpha, mat, this.collapseButton, collapseX, rightY, 18.0F, mouseX, mouseY, alpha);
      }

      float themeTarget = themeLight() ? 1.0F : 0.0F;
      this.themeAnim.retarget(themeTarget);
      float theme = this.themeAnim.advance(MainHeader.Anim.now());
      float lightX = cursor + 3.0F;
      float darkX = lightX + 46.0F + 3.0F;
      float themeY = rightY + 3.0F;
      drawThemeTrack(mat, (darkX - lightX) * theme + lightX, themeY, 46.0F, 46.0F, alpha);
      this.lightButton.x = lightX;
      this.lightButton.y = themeY;
      renderButton(this.lightButton, mat, mouseX, mouseY, alpha);
      this.darkButton.x = darkX;
      this.darkButton.y = themeY;
      renderButton(this.darkButton, mat, mouseX, mouseY, alpha);
      long tick = tickCount();
      if (60000L < tick - this.infoStamp) {
         this.infoStamp = tick;
         collectInfo();
      }

      String info = frameMillis >= 0 ? formatTemplate("{} ms", frameMillis) : "- ms";
      float infoWidth = measureText(info, 12.0F);
      drawTextAligned(mat, info, favoritesX - 8.0F - infoWidth, themeY, 14.0F, themeColor(24), alpha);
   }

   private Object drawButtonRow(Object handle, Object mat, IconButton button, float x, float y, float font, float mouseX, float mouseY, float alpha) {
      drawPanel(mat, x, y, 42.0F, 42.0F, 14.0F, alpha, 1.0F);
      float bx = x + 3.0F;
      float by = y + 3.0F;
      drawRoundedQuad(mat, bx, by, 36.0F, 36.0F, 12.0F, accentColor(), alpha);
      button.x = bx;
      button.y = by;
      renderButton(button, mat, mouseX, mouseY, alpha);
      return handle;
   }

   private void drawFavoritesBadge(MainHeader header, Object mat, float x, float y, float alpha) {
      float target = 1.0F;
      if (this.collapsed == 0) {
         target = 0.0F;
      }

      if (!this.searchReady) {
         this.searchAnim.from = target;
         this.searchAnim.current = target;
         this.searchAnim.target = target;
         this.searchAnim.running = false;
         this.searchReady = true;
      }

      this.searchAnim.retarget(target);
      float value = this.searchAnim.advance(MainHeader.Anim.now());
      float size = measureGlyph(5);
      float gy = (46.0F - measureGlyphHeight(5)) * 0.5F + y + 3.0F;
      float gx = (46.0F - size) * 0.5F + x + 3.0F;
      drawTexturePlaceholder(mat, (float)(value * Math.PI), glyphX(5) + gx, glyphY(5) + gy);
      drawGlyph(mat, 74, gx, gy, size, measureGlyphHeight(74), themeColor(24), alpha);
   }

   private void drawSearchField(Object mat, float mouseX, float mouseY, float headerX, float headerWidth, float alpha) {
      float searchTop = this.y + 4.0F;
      float centered = (headerWidth - 300.0F) * 0.5F + headerX;
      this.searchY = searchTop;
      this.searchX = centered;
      float target;
      if (!(mouseX < centered)
         && !(centered + 300.0F < mouseX)
         && !(mouseY < searchTop)
         && !(searchTop + 42.0F < mouseY)
         && (Screen.focusedInput == null || Screen.allowHover)) {
         Screen.hoveredWidget = 1;
         target = 1.0F;
      } else {
         target = 0.0F;
      }

      this.searchHoverAnim.retarget(target);
      float hover = this.searchHoverAnim.advance(MainHeader.Anim.now());
      float fade = (hover * 0.5F + 0.5F) * alpha;
      drawPanel(mat, this.searchX, this.searchY, 300.0F, 42.0F, 14.0F, fade, 1.0F);
      float innerX = this.searchX + 3.0F;
      float innerY = this.searchY + 3.0F;
      drawRoundedQuad(mat, innerX, innerY, 294.0F, 36.0F, 12.0F, accentColor(), fade);
      float glyphY = innerY + 18.0F;
      float glyphW = measureGlyph(9);
      float glyphH = measureGlyphHeight(9);
      drawGlyph(mat, 9, innerX + 12.0F, glyphY - glyphH * 0.5F, glyphW, glyphH, themeColor(24), fade);
      drawText(mat, "Поиск", innerX + 12.0F + glyphW + 6.0F, glyphY - 7.0F, 14.0F, themeColor(24), fade);
      float clearWidth = measureText("×", 12.0F) + 8.0F;
      float clearY = glyphY - 10.0F;
      float clearX = innerX + 294.0F - 12.0F - clearWidth;
      drawRoundedQuad(mat, clearX, clearY, clearWidth, 20.0F, 12.0F, themeColor(8), fade);
      drawText(mat, "×", clearX + 4.0F, clearY + 4.0F, 12.0F, themeColor(24), fade);
   }

   private static boolean themeLight() {
      return themeMode() == 1;
   }

   private static byte themeLightAvailable() {
      return 0;
   }

   private static boolean russianActive() {
      return false;
   }

   private static int themeMode() {
      return 0;
   }

   private static int accentColor() {
      return 0;
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static float clamp01(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private static void setButtonSize(IconButton button, float size) {
   }

   private static void setButtonWidth(IconButton button, float width) {
   }

   private static void setButtonKey(IconButton button, int key) {
   }

   private static void setButtonLabel(IconButton button, String text) {
   }

   private static void setButtonCallback(IconButton button, Object action) {
   }

   private static Object createSidebarAction() {
      return null;
   }

   private static Object createCollapseAction() {
      return null;
   }

   private static Object createLightAction() {
      return null;
   }

   private static Object createDarkAction() {
      return null;
   }

   private static Object createLanguageAction() {
      return null;
   }

   private static Object createFavoritesAction() {
      return null;
   }

   private static void clearButton(IconButton button) {
   }

   private static boolean invokeButton(IconButton button, double mx, double my) {
      return false;
   }

   private static void renderButton(IconButton button, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void invokeCallback(Object action) {
   }

   private static void releaseChild(Object sub, boolean heap) {
   }

   private static void resetString(int offset) {
   }

   private static void freeString(int offset) {
   }

   private static Object drawPanelTinted(Object mat, float x, float y, float width, float height, float radius, float alpha) {
      return null;
   }

   private static void drawPanel(Object mat, float x, float y, float width, float height, float radius, float alpha, float style) {
   }

   private static void drawRoundedQuad(Object mat, float x, float y, float width, float height, float radius, int color, float alpha) {
   }

   private static void drawThemeTrack(Object mat, float x, float y, float width, float height, float alpha) {
   }

   private static void drawText(Object mat, String text, float x, float y, float size, int color, float alpha) {
   }

   private static void drawTextAligned(Object mat, String text, float x, float y, float size, int color, float alpha) {
   }

   private static void drawGlyph(Object mat, int glyph, float x, float y, float width, float height, int color, float alpha) {
   }

   private static void drawTexturePlaceholder(Object mat, float angle, float x, float y) {
   }

   private static float measureText(String text, float size) {
      return 0.0F;
   }

   private static float measureGlyph(int glyph) {
      return 0.0F;
   }

   private static float measureGlyphHeight(int glyph) {
      return 0.0F;
   }

   private static float glyphX(int glyph) {
      return 0.0F;
   }

   private static float glyphY(int glyph) {
      return 0.0F;
   }

   private static long tickCount() {
      return 0L;
   }

   private static void collectInfo() {
   }

   private static String formatTemplate(String template, int value) {
      return template;
   }

   public static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }
}

