package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class WaypointsPart extends AbstractCollectionPart {
   public static final int INFO_SIZE = 168;
   public static final int INFO_SSO_CAPACITY = 15;
   public static final int TAB_WAYPOINTS = 0;
   public static final int TAB_EVENTS = 1;
   public static final long REFRESH_PERIOD_NANOS = 1500000000L;
   public static final int WAYPOINT_CACHE_MIN = 33;
   public static final int WAYPOINT_CACHE_LIMIT = Integer.MAX_VALUE;
   public static final float HEADER_HEIGHT = 126.0F;
   public static final float ZERO = 0.0F;
   public static final float ONE = 1.0F;
   public static final float LAYOUT_FADE_DURATION = 0.16F;
   public static final double POSITION_FLOOR_BIAS = 0.0;
   public static final double NANOS_PER_SECOND = 1.0E9;
   public static final int COLOR_PLATE_ERROR = -2343358;
   public static final int COLOR_PLATE_SUCCESS = -13919642;
   public static final int ICON_ADD_TILE = 35;
   public static final int ICON_ADD_TILE_FRAME = 61;
   public static final int ICON_TOOLBAR = 61;
   public static final int ICON_TOOLBAR_WIDGET = 53;
   public static final long KEY_FILTER_MASK = 864532803075702784L;
   public static final int KEY_FILTER_LIMIT = 59;
   public static final String TEXT_TAB_WAYPOINTS = "Шайпоинтз";
   public static final String TEXT_TAB_EVENTS = "Евентз";
   public static final String TEXT_TOOLBAR_TITLE = "Нажмите, чтобы отметить место, где стоите";
   public static final String TEXT_TOOLBAR_SECOND_LABEL = "Неш Шайпоинт";
   public static final String TEXT_ADD_TITLE = "Адд неш шайпоинт";
   public static final String TEXT_ADD_SUBTITLE = "Нажмите, чтобы отметить место, где стоите";
   public static final String TEXT_ADD_PLACEHOLDER = "Вставьте XYZ...";
   public static final String TEXT_COORD_PATTERN = "{} {} {}";
   public static final String EMPTY_TEXT = "";
   protected int tab = 0;
   protected long lastRefresh = 0L;
   private static final WaypointsPart.KeyPredicate KEY_FILTER = new WaypointsPart.KeyPredicate() {
      @Override
      public boolean test(int code) {
         return WaypointsPart.isCoordinateKey(code);
      }
   };
   public static final int WAYPOINT_SERVICE_PRIMARY = 0;
   public static final int WAYPOINT_SERVICE_LOCATE = 1;
   public static final int WAYPOINT_SERVICE_CREATE = 2;

   public WaypointsPart() {
      super(createToolbar(), createAddTileBox(35, "Адд неш шайпоинт", "Нажмите, чтобы отметить место, где стоите", "Вставьте XYZ...", 61));
      this.boardToolbar.onTabChanged = new IntConsumer() {
         @Override
         public void accept(int index) {
            WaypointsPart.this.onTabChanged(index);
         }
      };
      this.boardToolbar.onTitleChanged = new Consumer<String>() {
         public void accept(String value) {
            WaypointsPart.this.commitInput(value, WaypointsPart.this.plateAt(208, 576));
         }
      };
      this.boardToolbar.onClose = new Runnable() {
         @Override
         public void run() {
            WaypointsPart.this.addWaypointAtPlayer();
         }
      };
      installPlateKeyFilter(this.plateAt(208, 576), KEY_FILTER);
      this.addTile.onSubmitText = new Consumer<String>() {
         public void accept(String value) {
            WaypointsPart.this.commitInput(value, WaypointsPart.this.plateAt(216, 304));
         }
      };
      this.addTile.onSubmitEmpty = new Runnable() {
         @Override
         public void run() {
            WaypointsPart.this.addWaypointAtPlayer();
         }
      };
      installPlateKeyFilter(this.plateAt(216, 304), KEY_FILTER);
      this.refresh();
   }

   public static boolean isCoordinateKey(int code) {
      return code > 59 ? false : (864532803075702784L >>> code & 1L) != 0L;
   }

   private static BoardToolbar createToolbar() {
      List<BoardToolbar.Tab> tabs = new ArrayList<>();
      BoardToolbar.Tab waypointsTab = new BoardToolbar.Tab();
      waypointsTab.label = "Шайпоинтз";
      waypointsTab.flag = false;
      waypointsTab.label2 = null;
      waypointsTab.callback = null;
      tabs.add(waypointsTab);
      BoardToolbar.Tab eventsTab = new BoardToolbar.Tab();
      eventsTab.label = "Евентз";
      eventsTab.flag = false;
      eventsTab.label2 = null;
      eventsTab.callback = new Runnable() {
         @Override
         public void run() {
            WaypointsPart.tabCount();
         }
      };
      tabs.add(eventsTab);
      return new BoardToolbar(tabs, "Нажмите, чтобы отметить место, где стоите", 61, "Неш Шайпоинт", 53);
   }

   private static AbstractCollectionPart.AddTileBox createAddTileBox(int icon, String title, String subtitle, String placeholder, int icon2) {
      return new AbstractCollectionPart.AddTileBox();
   }

   private static void installPlateKeyFilter(Object plate, WaypointsPart.KeyPredicate filter) {
   }

   private Object plateAt(int ownerOffset, int plateOffset) {
      if (ownerOffset == 208 && plateOffset == 576) {
         return this.boardToolbar.plate;
      } else {
         return ownerOffset == 216 && plateOffset == 304 ? this.addTile : null;
      }
   }

   @Override
   public void dispose() {
      super.dispose();
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      if (1500000000L < this.now() - this.lastRefresh) {
         this.refresh();
      }

      super.render(renderer, px, py, alpha);
   }

   @Override
   public float headerHeight() {
      return 126.0F;
   }

   public void refresh() {
      this.lastRefresh = this.now();
      List<WaypointCard.WaypointInfo> snapshot = fetchWaypoints();
      List<Component> rebuilt = new ArrayList<>(snapshot.size());

      for (int i = 0; i < snapshot.size(); i++) {
         WaypointCard.WaypointInfo info = snapshot.get(i);
         String name = info.name;
         int size = name.length();
         if (size != 0 && info.broken == (this.tab == 1)) {
            boolean matched = false;

            for (int r = 0; r < this.rows.size(); r++) {
               Component row = this.rows.get(r);
               if (!cardClaimed(row) && cardName(row).equals(name)) {
                  applyCardInfo(row, info);
                  boolean selected = cardSelected(row);
                  if (cardSelectedFlag(row) != selected) {
                     setCardSelectedFlag(row, selected);
                     setCardAlphaTarget(row, selected ? 1.0F : 0.0F);
                  }

                  setCardCollapsed(row, !cardCollapsed(row));
                  rebuilt.add(row);
                  matched = true;
                  break;
               }
            }

            if (!matched) {
               rebuilt.add(this.buildCard(info));
            }
         }
      }

      for (int rx = 0; rx < this.rows.size(); rx++) {
         Component row = this.rows.get(rx);
         if (!cardClaimed(row) && !rebuilt.contains(row)) {
            setCardClaimed(row, true);
            if (cardAlphaAnimTarget(row) != 0.0F) {
               long time = this.now();
               advanceCardAlpha(row, time);
               setCardAlphaFrom(row, cardAlphaCurrent(row));
               setCardAlphaAnimTarget(row, 0.0F);
               setCardAlphaTick(row, time);
               setCardAlphaRunning(row, true);
            }

            rebuilt.add(row);
         }
      }

      this.rows.clear();
      this.rows.addAll(rebuilt);
      snapshot.clear();
   }

   public WaypointCard buildCard(WaypointCard.WaypointInfo info) {
      WaypointCard.WaypointInfo copy = copyWaypointInfo(info);
      WaypointCard card = createWaypointCard(copy);
      bindCardAction(card, 176, new WaypointsPart.WaypointAction() {
         @Override
         public void invoke(WaypointCard.WaypointInfo value) {
            WaypointsPart.this.onCardPrimary(value);
         }
      });
      bindCardAction(card, 240, new WaypointsPart.WaypointAction() {
         @Override
         public void invoke(WaypointCard.WaypointInfo value) {
            WaypointsPart.this.onCardSecondary(value);
         }
      });
      bindCardAction(card, 304, new WaypointsPart.WaypointAction() {
         @Override
         public void invoke(WaypointCard.WaypointInfo value) {
            WaypointsPart.this.onCardFlag(value);
         }
      });
      bindCardAction(card, 368, new WaypointsPart.WaypointAction() {
         @Override
         public void invoke(WaypointCard.WaypointInfo value) {
            WaypointsPart.this.onCardLocate(value);
         }
      });
      bindCardAction(card, 432, new WaypointsPart.WaypointStringAction() {
         @Override
         public void invoke(WaypointCard.WaypointInfo value, String text) {
            WaypointsPart.this.onCardRename(value, text);
         }
      });
      bindCardAction(card, 496, new WaypointsPart.WaypointColorAction() {
         @Override
         public void invoke(WaypointCard.WaypointInfo value, int r, int g, int b) {
            WaypointsPart.this.onCardColor(value, r, g, b);
         }
      });
      return card;
   }

   private static WaypointCard createWaypointCard(WaypointCard.WaypointInfo info) {
      return new WaypointCard(info);
   }

   private static WaypointCard.WaypointInfo copyWaypointInfo(WaypointCard.WaypointInfo info) {
      WaypointCard.WaypointInfo copy = new WaypointCard.WaypointInfo();
      if (info == null) {
         return copy;
      } else {
         copy.name = info.name;
         copy.key = info.key;
         copy.x = info.x;
         copy.y = info.y;
         copy.z = info.z;
         copy.world = info.world;
         copy.selected = info.selected;
         copy.extra = info.extra;
         copy.broken = info.broken;
         copy.flag99 = info.flag99;
         copy.deadline = info.deadline;
         return copy;
      }
   }

   private static void bindCardAction(WaypointCard card, int offset, Object action) {
   }

   private void onCardPrimary(WaypointCard.WaypointInfo info) {
      if (info.name.length() != 0) {
         invokeWaypointService(0, info.name, info);
         this.refresh();
      }
   }

   private void onCardSecondary(WaypointCard.WaypointInfo info) {
      int x = info.x;
      int y = info.y;
      int z = info.z;
      String text = formatCoordinates("{} {} {}", x, y, z);
      copyToClipboard(text);
   }

   private void onCardFlag(WaypointCard.WaypointInfo info) {
      if (info.name.length() != 0) {
         invokeWaypointFlagService(info.name, info.selected);
      }
   }

   private void onCardLocate(WaypointCard.WaypointInfo info) {
      if (info.name.length() != 0) {
         WaypointsPart.PlayerPosition position = playerPosition();
         if (position.valid) {
            invokeWaypointService(1, info.name, info);
            this.refresh();
         }
      }
   }

   private void onCardRename(WaypointCard.WaypointInfo info, String value) {
      if (info.name.length() != 0) {
         invokeWaypointRenameService(info.name, value);
         this.refresh();
      }
   }

   private void onCardColor(WaypointCard.WaypointInfo info, int r, int g, int b) {
      if (info.name.length() != 0) {
         invokeWaypointColorService(info.name, r, g, b);
         this.refresh();
      }
   }

   public static int tabCount() {
      List<WaypointCard.WaypointInfo> snapshot = fetchWaypoints();
      int count = 0;

      for (int i = 0; i < snapshot.size(); i++) {
         WaypointCard.WaypointInfo info = snapshot.get(i);
         int next = count + 1;
         if (!info.broken) {
            next = count;
         }

         count = next;
      }

      snapshot.clear();
      return count;
   }

   private void onTabChanged(final int index) {
      this.beginDeferredLayout(new Runnable() {
         @Override
         public void run() {
            WaypointsPart.this.applyTab(index);
         }
      });
   }

   private void applyTab(int index) {
      this.tab = index;
      this.refresh();
      this.layoutDirty = true;
   }

   private void beginDeferredLayout(Runnable action) {
      this.layoutCallback = action;
      this.overlayBlocked = true;
      this.easePow = 0.16F;
      this.layoutEase = 1;
      if (this.layoutFade != 0.0F) {
         long time = this.now();
         this.layoutAlphaB = this.layoutAlphaA;
         this.layoutFade = 0.0F;
         this.lastTime = time;
         this.suppressClick = true;
      }
   }

   private void commitInput(String value, Object plate) {
      WaypointsPart.WaypointDraft draft = parseCoordinates(value);
      String playerName = currentPlayerName();
      if (draft.valid && isInGame() && playerName.length() != 0) {
         invokeWaypointService(2, playerName, draft.x, draft.y, draft.z);
         setPlateColor(plate, -13919642);
         if (this.tab == 0) {
            this.refresh();
         } else {
            setToolbarTab(this.boardToolbar, 0);
            this.tab = 0;
            this.refresh();
         }
      } else {
         setPlateColor(plate, -2343358);
      }
   }

   private void addWaypointAtPlayer() {
      WaypointsPart.PlayerPosition position = playerPosition();
      String playerName = currentPlayerName();
      if (position.valid && playerName.length() != 0) {
         invokeWaypointService(2, playerName, position.x, position.y, position.z);
         if (this.tab != 0) {
            setToolbarTab(this.boardToolbar, 0);
            this.tab = 0;
         }

         this.refresh();
      } else {
         setPlateColor(this.plateAt(208, 576), -2343358);
      }
   }

   private static List<WaypointCard.WaypointInfo> fetchWaypoints() {
      List<WaypointCard.WaypointInfo> out = new ArrayList<>();
      if (!isWaypointStoreAvailable()) {
         return out;
      } else {
         List<WaypointCard.WaypointInfo> source = waypointStoreSnapshot();
         int count = source.size();

         for (int i = 0; i < count; i++) {
            out.add(copyWaypointInfo(source.get(i)));
         }

         return out;
      }
   }

   private static WaypointsPart.PlayerPosition playerPosition() {
      WaypointsPart.PlayerPosition out = new WaypointsPart.PlayerPosition();
      double px = 0.0;
      double py = 0.0;
      double pz = 0.0;
      if (isPlayerPresent()) {
         out.x = (int)Math.floor(px + 0.0);
         out.y = (int)Math.floor(py + 0.0);
         out.z = (int)Math.floor(pz + 0.0);
         out.valid = true;
         return out;
      } else {
         out.valid = false;
         return out;
      }
   }

   private static boolean isWaypointStoreAvailable() {
      return false;
   }

   private static List<WaypointCard.WaypointInfo> waypointStoreSnapshot() {
      return new ArrayList<>();
   }

   private static boolean isPlayerPresent() {
      return false;
   }

   private static boolean isInGame() {
      return false;
   }

   private static String currentPlayerName() {
      return "";
   }

   private static WaypointsPart.WaypointDraft parseCoordinates(String value) {
      return new WaypointsPart.WaypointDraft();
   }

   private static String formatCoordinates(String pattern, int x, int y, int z) {
      return "";
   }

   private static void copyToClipboard(String text) {
   }

   private static void setPlateColor(Object plate, int color) {
   }

   private static void setToolbarTab(BoardToolbar toolbar, int index) {
   }

   private static void invokeWaypointService(int service, String name, WaypointCard.WaypointInfo info) {
   }

   private static void invokeWaypointService(int service, String name, int x, int y, int z) {
   }

   private static void invokeWaypointFlagService(String name, boolean flag) {
   }

   private static void invokeWaypointRenameService(String name, String value) {
   }

   private static void invokeWaypointColorService(String name, int r, int g, int b) {
   }

   private static boolean cardClaimed(Component card) {
      return false;
   }

   private static void setCardClaimed(Component card, boolean value) {
   }

   private static String cardName(Component card) {
      return "";
   }

   private static void applyCardInfo(Component card, WaypointCard.WaypointInfo info) {
   }

   private static boolean cardSelected(Component card) {
      return false;
   }

   private static boolean cardSelectedFlag(Component card) {
      return false;
   }

   private static void setCardSelectedFlag(Component card, boolean value) {
   }

   private static boolean cardCollapsed(Component card) {
      return false;
   }

   private static void setCardCollapsed(Component card, boolean value) {
   }

   private static void setCardAlphaTarget(Component card, float value) {
   }

   private static float cardAlphaAnimTarget(Component card) {
      return 0.0F;
   }

   private static void setCardAlphaAnimTarget(Component card, float value) {
   }

   private static void advanceCardAlpha(Component card, long time) {
   }

   private static float cardAlphaCurrent(Component card) {
      return 0.0F;
   }

   private static void setCardAlphaFrom(Component card, float value) {
   }

   private static void setCardAlphaTick(Component card, long time) {
   }

   private static void setCardAlphaRunning(Component card, boolean value) {
   }

   public interface KeyPredicate {
      boolean test(int var1);
   }

   public static final class PlayerPosition {
      public int x;
      public int y;
      public int z;
      public boolean valid;
   }

   public interface WaypointAction {
      void invoke(WaypointCard.WaypointInfo var1);
   }

   public interface WaypointColorAction {
      void invoke(WaypointCard.WaypointInfo var1, int var2, int var3, int var4);
   }

   public static final class WaypointDraft {
      public int x;
      public int y;
      public int z;
      public boolean valid;
   }

   public interface WaypointStringAction {
      void invoke(WaypointCard.WaypointInfo var1, String var2);
   }
}

