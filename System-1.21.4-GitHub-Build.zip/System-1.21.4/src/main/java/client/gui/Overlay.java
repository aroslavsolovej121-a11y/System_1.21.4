package client.gui;

public class Overlay {
   public static final String RTTI_NAME = "Overlay@gui";
}
