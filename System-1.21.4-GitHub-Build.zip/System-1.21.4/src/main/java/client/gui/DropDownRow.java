package client.gui;

import client.Setting;
import java.util.ArrayList;
import java.util.List;

public class DropDownRow extends Component {
   public static final int SLOT_LIST_HEIGHT = 1;
   public static final int SLOT_COLLAPSED_HEIGHT = 2;
   public static final int SLOT_UPDATE = 3;
   public static final int SLOT_RENDER = 4;
   public static final int SLOT_MOUSE_CLICKED = 5;
   public static final int SLOT_DRAG = 6;
   public static final int SLOT_SPACING = 7;
   public static final int SLOT_OPACITY = 8;
   public static final int SLOT_ACCENT = 9;
   public static final int SLOT_SET_POSITION = 11;
   public static final int SLOT_COMMIT = 15;
   public static final float ROW_HEIGHT = 26.0F;
   public static final float ROW_SPACING = 4.0F;
   public static final float ROW_OPACITY = 1.0F;
   public static final float DEFAULT_ROW_HEIGHT = 4.5F;
   public static final float ITEM_STEP = 28.0F;
   public static final float EXPAND_DURATION = 0.32F;
   public static final float ITEM_DURATION = 0.22F;
   public static final float ITEM_SELECTED = 1.0F;
   public static final float ITEM_HOVERED = 0.7F;
   public static final float ITEM_IDLE = 0.4F;
   public static final float DRAG_BIAS = 141.0F;
   public static final float EPSILON = 0.001F;
   public static final float ARROW_SIZE = 6.0F;
   public static final float LABEL_GAP = 8.0F;
   public static final float LIST_INDENT = 30.0F;
   public static final float LIST_TOP_PAD = 2.0F;
   public static final float FONT_SIZE = 12.0F;
   public static final float ARROW_GLYPH_W = 6.5F;
   public static final int SOUND_OPEN = 5;
   public static final int SOUND_CLOSE = 4;
   public static final int SOUND_SELECT = 14;
   public static final int ARROW_GLYPH = 10;
   public static final int LABEL_GLYPH = 2;
   private Object owner;
   private Setting setting;
   private Setting choice;
   private float rowHeight = 4.5F;
   private float reveal;
   private boolean rowVisible;
   private float rowY;
   private int rowFlags;
   private long tag;
   private float boundsX;
   private float boundsY;
   private float boundsWidth;
   private float boundsHeight;
   private boolean expanded;
   private final Component.Anim expandAnim = new Component.Anim(0.0F, 0.32F);
   private final List<Component.Anim> itemAnims = new ArrayList<>();
   private Object handler;

   public DropDownRow() {
   }

   public DropDownRow(Object owner, Setting choice) {
      this.owner = owner;
      this.setting = choice;
      this.choice = choice;
      this.expandAnim.update(this.now());
      this.buildItemAnims();
   }

   public DropDownRow(Object owner, Setting choice, String label) {
      this(owner, choice);
   }

   private void buildItemAnims() {
      this.itemAnims.clear();
      int count = this.optionCount();

      for (int i = 0; i < count; i++) {
         float value = this.isSelected(i) ? 1.0F : 0.4F;
         Component.Anim anim = new Component.Anim(value, 0.22F);
         anim.update(this.now());
         this.itemAnims.add(anim);
      }
   }

   public int optionCount() {
      if (this.choice == null) {
         return 0;
      } else {
         List<String> modes = this.choice.getModes();
         return modes == null ? 0 : modes.size();
      }
   }

   public boolean isSelected(int index) {
      if (this.choice == null) {
         return false;
      } else {
         List<String> modes = this.choice.getModes();
         if (modes != null && index >= 0 && index < modes.size()) {
            String current = this.choice.getMode();
            return current != null && current.equals(modes.get(index));
         } else {
            return false;
         }
      }
   }

   public String optionLabel(int index) {
      if (this.choice == null) {
         return "";
      } else {
         List<String> modes = this.choice.getModes();
         if (modes != null && index >= 0 && index < modes.size()) {
            String s = modes.get(index);
            return s == null ? "" : s;
         } else {
            return "";
         }
      }
   }

   public float listHeight() {
      return this.optionCount() * 28.0F * this.reveal + 26.0F;
   }

   public float collapsedHeight() {
      return this.expanded ? this.optionCount() * 28.0F + 26.0F : 26.0F;
   }

   public float rowHeight() {
      return 26.0F;
   }

   public float rowSpacing() {
      return 4.0F;
   }

   public float opacity() {
      return 1.0F;
   }

   public int accentColor() {
      return uiThemeColor(0);
   }

   public float drag(float value) {
      return value + 141.0F;
   }

   public void setReveal(float value) {
      if (this.reveal != value) {
         this.reveal = value;
      }
   }

   public void markVisible() {
      if (!this.rowVisible) {
         this.rowVisible = true;
         this.rowY = 0.0F;
      }
   }

   public void hideAt(float targetY) {
      if (this.rowVisible) {
         this.rowVisible = false;
         this.rowY = targetY <= 0.0F ? 0.0F : targetY;
      }
   }

   public float reveal() {
      return this.reveal;
   }

   public boolean rowVisible() {
      return this.rowVisible;
   }

   public float rowY() {
      return this.rowY;
   }

   public boolean expanded() {
      return this.expanded;
   }

   public Object owner() {
      return this.owner;
   }

   public Setting setting() {
      return this.setting;
   }

   @Override
   public float preferredHeight() {
      return 26.0F;
   }

   @Override
   public float preferredWidth() {
      return 26.0F;
   }

   public void update() {
      this.reveal = this.expandAnim.current;
      this.expandAnim.update(this.now());
      this.reveal = this.expandAnim.current;
   }

   @Override
   public void tick() {
      this.update();
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      this.render(renderer, px, py, this.width, mouseX, mouseY);
   }

   public void render(Object renderer, float px, float py, float pw, float mx, float my) {
      float[] glyph = uiIconMetrics(10);
      float arrowX = px + pw - 8.0F - (glyph == null ? 0.0F : glyph[0]);
      float arrowY = (26.0F - (glyph == null ? 0.0F : glyph[1])) * 0.5F + py + 1.0F;
      uiDrawIcon(renderer, 10, arrowX, arrowY, 6.0F, 6.0F, uiThemeColor(0), this.alpha);
      float labelX = px + 141.0F;
      String label = this.currentLabel();
      float labelW = arrowX - 8.0F - labelX;
      drawText(renderer, 2, labelX, py + 4.0F, labelW, 12.0F, uiThemeColor(0), this.alpha);
      if (mx >= px && mx <= px + pw && my >= py && my <= py + 26.0F) {
         cursorStyle = 1;
      }

      float listY = py + 26.0F;
      if (0.001F < this.reveal) {
         float listH = this.optionCount() * 28.0F * this.reveal;
         uiDrawBox(renderer, px, listY, pw, listH, 0.0F, 0.0F, 0.0F, 0.0F, 0, 0, 0.0F, 0, 0.0F, 1.0F, 0.0F, this.alpha, 0);
         float itemX = px + 30.0F;
         float itemW = pw - 30.0F;
         int count = this.optionCount();
         if (count != 0) {
            float itemY = listY + 2.0F;
            long time = this.now();

            for (int i = 0; i < count; i++) {
               float top = i * 28.0F + itemY;
               boolean over = mx >= itemX && mx <= itemX + itemW && my >= top && my <= top + 26.0F;
               if (over && this.expanded) {
                  cursorStyle = 1;
               }

               float target;
               if (this.isSelected(i)) {
                  target = 1.0F;
               } else if (over) {
                  target = 0.7F;
               } else {
                  target = 0.4F;
               }

               Component.Anim anim = this.itemAnims.get(i);
               anim.retarget(target, time);
               anim.update(time);
               uiDrawBox(renderer, itemX, top, itemW, 26.0F, 4.0F, 4.0F, 4.0F, 4.0F, uiThemeColor(0), uiThemeColor(0), 1.0F, 0, 0.0F, 1.0F, 0.0F, this.alpha, 0);
               drawText(renderer, 2, itemX + 4.0F, top + 4.0F, itemW - 12.0F, 12.0F, uiThemeColor(0), this.alpha);
            }
         }
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      return this.mouseClicked(mx, my, button, this.x, this.y, this.width);
   }

   public boolean mouseClicked(double mx, double my, int button, float px, float py, float pw) {
      if (button != 0) {
         return false;
      } else if (mx >= px && mx <= px + pw && my >= py && my <= py + 26.0F) {
         this.expanded = !this.expanded;
         long time = this.now();
         this.expandAnim.retarget(this.expanded ? 1.0F : 0.0F, time);
         this.expandAnim.update(time);
         uiSound(this.expanded ? 5 : 4);
         return true;
      } else {
         int count = this.optionCount();
         if (this.expanded && count != 0) {
            for (int i = 0; i < count; i++) {
               float top = i * 28.0F + py + 26.0F + 2.0F;
               if (mx >= px + 30.0F && mx <= pw - 30.0F + px + 30.0F && my >= top && my <= top + 26.0F) {
                  uiSound(14);
                  this.selectOption(i);
                  return true;
               }
            }
         }

         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      mouseX = (float)mx;
      mouseY = (float)my;
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      mouseX = (float)mx;
      mouseY = (float)my;
      return false;
   }

   private void selectOption(int index) {
      if (this.choice != null) {
         String label = this.optionLabel(index);
         if (!label.isEmpty()) {
            this.choice.setMode(label);
         }
      }
   }

   private String currentLabel() {
      if (this.choice == null) {
         return "";
      } else {
         String s = this.choice.getMode();
         return s == null ? "" : s;
      }
   }

   private static void drawText(Object renderer, int glyph, float px, float py, float pw, float size, int color, float alpha) {
   }
}

