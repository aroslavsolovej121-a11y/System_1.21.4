package client.gui;

import java.util.function.Consumer;

public class WaypointCard extends AbstractCard {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_ATTACH = 16;
   public static final int SLOT_DETACH = 24;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_MOUSE_RELEASED = 40;
   public static final int SLOT_MOUSE_MOVED = 48;
   public static final int SLOT_MOUSE_SCROLLED = 56;
   public static final int SLOT_KEY_PRESSED = 64;
   public static final int SLOT_CHAR_TYPED = 72;
   public static final int SLOT_KEY_RELEASED = 80;
   public static final int SLOT_SET_POSITION = 88;
   public static final int SLOT_SET_STATE = 96;
   public static final int SLOT_RENDER_CONTENT = 104;
   public static final int SLOT_ON_MOUSE = 112;
   public static final int INFO_NAME_OFFSET = 560;
   public static final int CALLBACK_MOVE_OFFSET = 176;
   public static final int CALLBACK_MOVE_SLOT_OFFSET = 232;
   public static final int CALLBACK_COPY_OFFSET = 240;
   public static final int CALLBACK_COPY_SLOT_OFFSET = 296;
   public static final int CALLBACK_TOGGLE_OFFSET = 304;
   public static final int CALLBACK_TOGGLE_SLOT_OFFSET = 360;
   public static final int CALLBACK_DELETE_OFFSET = 368;
   public static final int CALLBACK_DELETE_SLOT_OFFSET = 424;
   public static final int CALLBACK_TITLE_OFFSET = 432;
   public static final int CALLBACK_TITLE_SLOT_OFFSET = 488;
   public static final int CALLBACK_COORD_OFFSET = 496;
   public static final int CALLBACK_COORD_SLOT_OFFSET = 552;
   public static final int SWITCHER_OFFSET = 728;
   public static final int PLATE_MOVE_OFFSET = 920;
   public static final int PLATE_COPY_OFFSET = 1208;
   public static final int PLATE_DELETE_OFFSET = 1496;
   public static final int ICON_MOVE_OFFSET = 1784;
   public static final int ICON_COPY_OFFSET = 2032;
   public static final int ICON_DELETE_OFFSET = 2280;
   public static final int ALPHA_ANIM_OFFSET = 2528;
   public static final int INPUT_TITLE_OFFSET = 2568;
   public static final int INPUT_X_OFFSET = 2576;
   public static final int INPUT_Y_OFFSET = 2584;
   public static final int INPUT_Z_OFFSET = 2592;
   public static final int HIDDEN_RECT_OFFSET = 2600;
   public static final int SLOT_X_OFFSET = 2616;
   public static final int SLOT_Y_OFFSET = 2628;
   public static final int SLOT_W_OFFSET = 2632;
   public static final int TOGGLE_X_OFFSET = 2636;
   public static final int TOGGLE_Y_OFFSET = 2640;
   public static final int ENABLED_OFFSET = 1024;
   public static final int ALPHA_A_OFFSET = 1032;
   public static final int ALPHA_B_OFFSET = 1036;
   public static final int ALPHA_C_OFFSET = 1040;
   public static final int FLAG_428_OFFSET = 1064;
   public static final int SWITCHER_ON_OFFSET = 96;
   public static final int SWITCHER_LOCKED_OFFSET = 97;
   public static final int SWITCHER_CALLBACK_OFFSET = 160;
   public static final int SWITCHER_TARGET_OFFSET = 168;
   public static final int SWITCHER_FADE_OFFSET = 172;
   public static final int SWITCHER_KNOB_OFFSET = 176;
   public static final int SWITCHER_DRAGGING_OFFSET = 180;
   public static final int SWITCHER_DRAG_PAST_OFFSET = 181;
   public static final int SWITCHER_PRESS_STATE_OFFSET = 182;
   public static final int SWITCHER_PRESS_X_OFFSET = 184;
   public static final int SWITCHER_STATE_MIRROR_OFFSET = 824;
   public static final int SWITCHER_FADE_OUT_OFFSET = 896;
   public static final int PLATE_ICON_OFFSET = 96;
   public static final int PLATE_ENABLED_OFFSET = 104;
   public static final int PLATE_ANIM_OFFSET = 112;
   public static final int PLATE_ACTION_OFFSET = 192;
   public static final int PLATE_LABEL_OFFSET = 216;
   public static final int ICON_ID_OFFSET = 96;
   public static final int ICON_ACTIVE_OFFSET = 100;
   public static final int ICON_ENABLED_OFFSET = 104;
   public static final int ICON_DISABLED_OFFSET = 105;
   public static final int ICON_SIZE_OFFSET = 108;
   public static final int ICON_ANIM_OFFSET = 112;
   public static final int ICON_CALLBACK_OFFSET = 208;
   public static final int ICON_LABEL_OFFSET = 216;
   public static final int INPUT_TEXT_OFFSET = 0;
   public static final int INPUT_SIZE_OFFSET = 32;
   public static final int INPUT_FLAG_25_OFFSET = 37;
   public static final int INPUT_FLAG_26_OFFSET = 38;
   public static final int INPUT_MIN_OFFSET = 40;
   public static final int INPUT_MAX_OFFSET = 80;
   public static final int INPUT_CUSTOM_TEXT_OFFSET = 216;
   public static final int INPUT_KEY_CAPTURE_OFFSET = 360;
   public static final int INPUT_ALLOC_SIZE = 424;
   public static final int INFO_NAME_STRUCT_OFFSET = 0;
   public static final int INFO_KEY_STRUCT_OFFSET = 32;
   public static final int INFO_X_STRUCT_OFFSET = 64;
   public static final int INFO_Y_STRUCT_OFFSET = 68;
   public static final int INFO_Z_STRUCT_OFFSET = 72;
   public static final int INFO_WORLD_STRUCT_OFFSET = 80;
   public static final int INFO_SELECTED_STRUCT_OFFSET = 112;
   public static final int INFO_EXTRA_STRUCT_OFFSET = 120;
   public static final int INFO_BROKEN_STRUCT_OFFSET = 152;
   public static final int INFO_FLAG99_STRUCT_OFFSET = 153;
   public static final int INFO_DEADLINE_STRUCT_OFFSET = 160;
   public static final int INFO_SIZE = 168;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float HALF = 0.5F;
   public static final float MINUS_ONE = -1.0F;
   public static final float CARD_WIDTH = 930.0F;
   public static final float CARD_HEIGHT = 62.0F;
   public static final float CARD_HEIGHT_EXPANDED = 126.0F;
   public static final float DIM_ALPHA = 0.7F;
   public static final float ANIM_DURATION_MEDIUM = 0.22F;
   public static final float ROW_HEIGHT = 42.0F;
   public static final float RADIUS = 18.0F;
   public static final float RADIUS_COLLAPSED = 14.0F;
   public static final float PAD_18 = 18.0F;
   public static final float PAD_16 = 16.0F;
   public static final float PAD_12 = 12.0F;
   public static final float GAP_8 = 8.0F;
   public static final float GAP_6 = 6.0F;
   public static final float GAP_4 = 4.0F;
   public static final float GAP_3 = 3.0F;
   public static final float GAP_2 = 2.0F;
   public static final float GAP_1 = 1.0F;
   public static final float SWITCH_INSET = -28.0F;
   public static final float SWITCH_INSET_POSITIVE = 28.0F;
   public static final float SWITCH_STEP = -8.0F;
   public static final float SWITCH_OFFSET_Y = 13.0F;
   public static final float BUTTON_SPAN = 36.0F;
   public static final float BUTTON_STEP = 22.0F;
   public static final float BUTTON_STEP_NEGATIVE = -22.0F;
   public static final float COORD_ROW_SPAN = 270.0F;
   public static final float COLLAPSED_INSET = 32.0F;
   public static final float COLLAPSED_ROW_STEP = 24.0F;
   public static final float VISIBLE_EPSILON = 0.001F;
   public static final float FIELD_HEIGHT = 20.0F;
   public static final float MEASURE_PAD = 9.0F;
   public static final float MEASURE_EXTRA = 26.0F;
   public static final float ICON_SIZE = 20.0F;
   public static final float ADD_BUTTON_SIZE_A = 16.0F;
   public static final float ADD_BUTTON_SIZE_B = 12.0F;
   public static final int PLATE_ICON_MOVE = 30;
   public static final int PLATE_ICON_COPY = 37;
   public static final int PLATE_ICON_DELETE = 82;
   public static final int ICON_ID_MOVE = 30;
   public static final int ICON_ID_COPY = 37;
   public static final int ICON_ID_DELETE = 32;
   public static final int ICON_ID_HEADER = 35;
   public static final int SOUND_ENABLE = 8;
   public static final int SOUND_MOVE = 12;
   public static final int SOUND_COPY = 14;
   public static final int SOUND_DELETE = 13;
   public static final int HOVER_TOGGLE = 1;
   public static final int HOVER_FIELD = 2;
   public static final int STATE_COLLAPSED = 0;
   public static final int STATE_EXPANDED = 1;
   public static final int MAX_KEY_CODE = 59;
   public static final long KEY_MASK = 864532803075702784L;
   public static final int TEXT_MODE_PLAIN = 2;
   public static final int TEXT_MODE_WRAPPED = 4;
   public static final int TEXT_MODE_MEASURED = 1;
   public static final long TICKS_PER_MILLI = 10000L;
   public static final long MILLIS_PER_SECOND = 1000L;
   public static final long SECONDS_PER_MINUTE = 60L;
   public static final int AXIS_X = 0;
   public static final int AXIS_Y = 1;
   public static final int AXIS_Z = 2;
   public static final String LABEL_MOVE = "Перенести сюда — где стоите";
   public static final String LABEL_COPY = "Скопировать координаты";
   public static final String LABEL_DELETE = "Удалить точку";
   public static final String COORD_X = "X";
   public static final String COORD_Y = "Y";
   public static final String COORD_Z = "Z";
   public static final int ICON_INVALID = 89;
   protected WaypointCard.WaypointInfo info;
   protected WaypointCard.SwitcherButton switcher;
   protected WaypointCard.PlateIconButton plateMove;
   protected WaypointCard.PlateIconButton plateCopy;
   protected WaypointCard.PlateIconButton plateDelete;
   protected WaypointCard.IconButton iconMove;
   protected WaypointCard.IconButton iconCopy;
   protected WaypointCard.IconButton iconDelete;
   protected final AbstractCard.Anim alphaAnim = new AbstractCard.Anim(1.0F, 0.22F, 0);
   protected WaypointCard.PlateInput inputTitle;
   protected WaypointCard.PlateInput inputX;
   protected WaypointCard.PlateInput inputY;
   protected WaypointCard.PlateInput inputZ;
   protected Object callbackMove;
   protected Object callbackCopy;
   protected Object callbackToggle;
   protected Object callbackDelete;
   protected Object callbackTitle;
   protected Object callbackCoord;
   protected boolean enabled;
   protected float alphaA;
   protected float alphaB;
   protected float alphaC;
   protected boolean flag428;
   protected float hiddenRectX;
   protected float hiddenRectY;
   protected float hiddenRectW;
   protected float hiddenRectH;
   protected final float[] slotX = new float[3];
   protected float slotY;
   protected float slotW;
   protected float toggleX;
   protected float toggleY;

   public WaypointCard(WaypointCard.WaypointInfo waypointInfo) {
      this.callbackMove = null;
      this.callbackCopy = null;
      this.callbackToggle = null;
      this.callbackDelete = null;
      this.callbackTitle = null;
      this.callbackCoord = null;
      this.info = waypointInfo;
      this.switcher = new WaypointCard.SwitcherButton(this.info.selected);
      this.plateMove = new WaypointCard.PlateIconButton(30, "Перенести сюда — где стоите");
      this.plateCopy = new WaypointCard.PlateIconButton(37, "Скопировать координаты");
      this.plateDelete = new WaypointCard.PlateIconButton(82, "Удалить точку");
      this.iconMove = new WaypointCard.IconButton(30, 20.0F);
      this.iconCopy = new WaypointCard.IconButton(37, 20.0F);
      this.iconDelete = new WaypointCard.IconButton(32, 20.0F);
      this.inputTitle = (WaypointCard.PlateInput)this.addIconButton(16.0F, this::onTitleAction);
      this.inputX = (WaypointCard.PlateInput)this.addIconButton(12.0F, this::onCoordXAction);
      this.inputY = (WaypointCard.PlateInput)this.addIconButton(12.0F, this::onCoordYAction);
      this.inputZ = (WaypointCard.PlateInput)this.addIconButton(12.0F, this::onCoordZAction);
      this.hiddenRectX = 0.0F;
      this.hiddenRectY = 0.0F;
      this.hiddenRectW = 0.0F;
      this.hiddenRectH = 0.0F;
      this.slotX[0] = 0.0F;
      this.slotX[1] = 0.0F;
      this.slotX[2] = 0.0F;
      this.slotY = 0.0F;
      this.slotW = 0.0F;
      this.toggleX = -1.0F;
      this.toggleY = -1.0F;
      assignKeyCapture(this.inputX, WaypointCard::acceptKeyCode);
      assignKeyCapture(this.inputY, WaypointCard::acceptKeyCode);
      assignKeyCapture(this.inputZ, WaypointCard::acceptKeyCode);
      assignPlateAction(this.plateMove, this.iconMove, "Перенести сюда — где стоите", this::onPlateMoveAction);
      this.iconMove.iconSize = 0.0F;
      assignLabel(this.iconMove, "Перенести сюда — где стоите");
      assignIconAction(this.iconMove, this::onPlateMoveAction);
      assignPlateAction(this.plateCopy, this.iconCopy, "Скопировать координаты", this::onPlateCopyAction);
      this.iconCopy.iconSize = 0.0F;
      assignLabel(this.iconCopy, "Скопировать координаты");
      assignIconAction(this.iconCopy, this::onPlateCopyAction);
      assignPlateAction(this.plateDelete, this.iconDelete, "Удалить точку", this::onPlateDeleteAction);
      this.iconDelete.iconSize = 0.0F;
      assignLabel(this.iconDelete, "Удалить точку");
      assignIconAction(this.iconDelete, this::onPlateDeleteAction);
      this.enabled = !this.info.broken;
      float availability = this.enabled ? 1.0F : 0.0F;
      this.alphaA = availability;
      this.alphaB = availability;
      this.alphaC = availability;
      this.flag428 = false;
      this.switcher.locked = false;
      float start = !this.info.selected && !this.info.broken ? 0.7F : 1.0F;
      this.alphaAnim.from = start;
      this.alphaAnim.current = start;
      this.alphaAnim.target = start;
      this.alphaAnim.running = false;
      this.state = 0;
      this.width = 930.0F;
      this.height = 62.0F;
      releaseInfoCopy(waypointInfo);
   }

   @Override
   public void dispose() {
      releaseIconButton(this.iconDelete);
      releaseIconButton(this.iconCopy);
      releaseIconButton(this.iconMove);
      releasePlateButton(this.plateDelete);
      releasePlateButton(this.plateCopy);
      releasePlateButton(this.plateMove);
      releaseCallback(this.switcher.callback);
      this.switcher.callback = null;
      releaseSwitcher(this.switcher);
      releaseInfo(this.info);
      releaseCallback(this.callbackCoord);
      this.callbackCoord = null;
      releaseCallback(this.callbackTitle);
      this.callbackTitle = null;
      releaseCallback(this.callbackDelete);
      this.callbackDelete = null;
      releaseCallback(this.callbackToggle);
      this.callbackToggle = null;
      releaseCallback(this.callbackCopy);
      this.callbackCopy = null;
      releaseCallback(this.callbackMove);
      this.callbackMove = null;
      super.dispose();
   }

   @Override
   public void setState(int newState, float newWidth) {
      this.width = newWidth;
      this.state = newState;
      if (newState == 1) {
         this.height = 126.0F;
      } else {
         this.height = 62.0F;
      }
   }

   public void renderContent(Object mat, float mouseX, float mouseY, float alpha) {
      float fVar10 = mouseX;
      float fVar9 = 1.0F;
      if (!this.info.selected && !this.info.broken) {
         fVar9 = 0.7F;
      }

      if (this.alphaAnim.target != fVar9) {
         long time = this.now();
         float value = this.alphaAnim.update(time);
         this.alphaAnim.start = time;
         this.alphaAnim.from = value;
         this.alphaAnim.target = fVar9;
         this.alphaAnim.running = true;
      }

      long time = this.now();
      float fade = this.alphaAnim.update(time);
      float radius = 18.0F;
      if (this.state == 1) {
         radius = 14.0F;
      }

      drawPanel(mat, this.x, this.y, this.width, this.height, radius, alpha);
      if (!this.info.broken
         && !(mouseX < this.x)
         && !(this.x + this.width < mouseX)
         && !(mouseY < this.y)
         && !(this.y + this.height < mouseY)
         && (Screen.focusedWidget == null || Screen.allowHover)) {
         float fVar2 = this.toggleX;
         if (0.0F <= fVar2 && fVar2 <= mouseX && mouseX <= fVar2 + 42.0F && this.toggleY <= mouseY && mouseY <= this.toggleY + 42.0F) {
            Screen.hoveredWidget = 1;
         } else {
            boolean inside;
            if (this.hiddenRectW <= 0.0F) {
               inside = false;
            } else {
               inside = !(mouseX < this.hiddenRectX)
                  && !(this.hiddenRectW + this.hiddenRectX < mouseX)
                  && !(mouseY < this.hiddenRectY)
                  && !(this.hiddenRectY + this.hiddenRectH < mouseY);
            }

            for (int i = 0; i < this.slotX.length && !inside; i++) {
               inside = !(fVar10 < this.slotX[i]) && !(this.slotX[i] + this.slotW < fVar10) && !(mouseY < this.slotY) && !(this.slotY + 36.0F < mouseY);
            }

            if (inside) {
               Screen.hoveredWidget = 2;
            }
         }
      }

      if (this.state == 1) {
         this.renderCollapsed(mat, mouseX, mouseY, alpha);
      } else {
         this.renderExpanded(mat, mouseX, mouseY, fade * alpha);
      }
   }

   @Override
   public boolean onMouse(double mouseXD, double mouseYD, int button) {
      float mouseX = (float)mouseXD;
      float mouseY = (float)mouseYD;
      if (this.state == 1) {
         WaypointCard.IconButton[] expanded = new WaypointCard.IconButton[]{this.iconDelete, this.iconCopy, this.iconMove};

         for (int i = 0; i < expanded.length; i++) {
            WaypointCard.IconButton current = expanded[i];
            if ((current != this.iconMove || !this.info.broken)
               && button == 0
               && mouseXD >= current.x
               && mouseXD <= current.x + current.width
               && mouseYD >= current.y
               && mouseYD <= current.y + current.height
               && current.mousePressed(mouseX, mouseY)) {
               AbstractCard.blurFocusedChildren(this);
               return true;
            }
         }
      } else {
         WaypointCard.PlateIconButton[] collapsed = new WaypointCard.PlateIconButton[]{this.plateDelete, this.plateCopy, this.plateMove};

         for (int ix = 0; ix < collapsed.length; ix++) {
            WaypointCard.PlateIconButton current = collapsed[ix];
            if (current.enabled
               && 0.001F <= current.enabledAnim.current
               && button == 0
               && mouseXD >= current.x
               && mouseXD <= current.x + current.width
               && mouseYD >= current.y
               && mouseYD <= current.y + current.height
               && current.mousePressed(mouseX, mouseY)) {
               AbstractCard.blurFocusedChildren(this);
               return true;
            }
         }
      }

      if (!this.info.broken) {
         if (button != 0) {
            return false;
         }

         if (mouseXD >= this.switcher.x
            && mouseXD <= this.switcher.x + this.switcher.width
            && mouseYD >= this.switcher.y
            && mouseYD <= this.switcher.y + this.switcher.height
            && this.switcher.mousePressed(mouseX, mouseY)) {
            AbstractCard.blurFocusedChildren(this);
            return true;
         }
      } else if (button != 0) {
         return false;
      }

      if (this.info.broken) {
         return false;
      } else {
         float fVar1 = this.toggleX;
         if (0.0F <= fVar1 && fVar1 <= mouseXD && mouseXD <= fVar1 + 42.0F && this.toggleY <= mouseYD && mouseYD <= this.toggleY + 42.0F) {
            AbstractCard.blurFocusedChildren(this);
            boolean cVar3 = this.info.selected;
            boolean bVar12 = !cVar3;
            this.info.selected = bVar12;
            if (this.switcher.on != bVar12) {
               this.switcher.on = bVar12;
               this.switcher.target = bVar12 ? 1.0F : 0.0F;
            }

            playClickSound((cVar3 ? 1 : 0) + 8);
            if (this.callbackToggle == null) {
               return true;
            } else {
               invokeInfoCallback(this.callbackToggle, this.info);
               return true;
            }
         } else if (0.0F < this.hiddenRectW
            && mouseXD >= this.hiddenRectX
            && mouseXD <= this.hiddenRectX + this.hiddenRectW
            && mouseYD >= this.hiddenRectY
            && mouseYD <= this.hiddenRectY + this.hiddenRectH) {
            AbstractCard.focusChildWithText(this, this.inputTitle, this.info.key);
            return true;
         } else {
            for (int ixx = 0; ixx < this.slotX.length; ixx++) {
               if (!(mouseXD < this.slotX[ixx]) && !(this.slotX[ixx] + this.slotW < mouseXD) && !(mouseYD < this.slotY) && !(this.slotY + 36.0F < mouseYD)) {
                  int coordinate;
                  WaypointCard.PlateInput field;
                  if (ixx == 0) {
                     field = this.inputX;
                     coordinate = this.info.x;
                  } else if (ixx == 1) {
                     field = this.inputY;
                     coordinate = this.info.y;
                  } else {
                     field = this.inputZ;
                     coordinate = this.info.z;
                  }

                  AbstractCard.focusChildWithText(this, field, toCoordinateText(coordinate));
                  return true;
               }
            }

            return false;
         }
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (!this.info.broken && this.switcher.mouseReleased(mx, my, button)) {
         if (this.switcher.on != this.info.selected) {
            Object callback = this.callbackToggle;
            this.info.selected = this.switcher.on;
            if (callback != null) {
               invokeInfoCallback(callback, this.info);
            }
         }

         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      return !this.info.broken && this.switcher.mouseMoved(mx, my, delta);
   }

   private void renderExpanded(Object mat, float mouseX, float mouseY, float alpha) {
      float rowY = (this.height - 42.0F) * 0.5F + this.y;
      drawLabel(this, mat, this.x + 12.0F, rowY);
      this.toggleX = this.x + 12.0F;
      this.toggleY = rowY;
      float cursor = this.x + this.width - 12.0F;
      if (!this.info.broken) {
         cursor += -28.0F;
         this.switcher.x = cursor;
         this.switcher.y = rowY + 13.0F;
         boolean selected = this.info.selected;
         if (this.switcher.on != selected) {
            this.switcher.on = selected;
            this.switcher.target = selected ? 1.0F : 0.0F;
         }

         this.switcher.render(mat, mouseX, mouseY, alpha);
         cursor += -8.0F;
      }

      float step = 4.0F;
      WaypointCard.PlateIconButton[] order = new WaypointCard.PlateIconButton[]{this.plateDelete, this.plateCopy, this.plateMove};

      for (int i = 0; i < order.length; i++) {
         WaypointCard.PlateIconButton button = order[i];
         float value = button.enabledAnim.update(this.now()) * 42.0F;
         button.width = value;
         button.x = cursor - value;
         button.y = rowY;
         if (0.001F < value) {
            cursor -= value + step;
         }
      }

      WaypointCard.PlateIconButton[] drawOrder = new WaypointCard.PlateIconButton[]{this.plateMove, this.plateCopy, this.plateDelete};

      for (int ix = 0; ix < drawOrder.length; ix++) {
         drawIconButton(drawOrder[ix], mat, mouseX, mouseY, alpha);
      }

      cursor -= 270.0F;
      this.drawCoordRow(mat, cursor, rowY, 270.0F, alpha);
      float textX = this.x + 12.0F + 42.0F + 6.0F;
      float available = cursor - step - textX;
      if (available <= 0.0F) {
         available = 0.0F;
      }

      this.drawTitleRow(mat, textX, rowY + 1.0F, available, alpha);
      if (!this.info.world.isEmpty()) {
         String wrapped = wrapText(this.info.world, available, 12.0F);
         rendererState();
         drawText(2, mat, wrapped, textX);
      }
   }

   private void renderCollapsed(Object mat, float mouseX, float mouseY, float alpha) {
      this.toggleY = -1.0F;
      this.toggleX = -1.0F;
      float fVar6 = this.y + 16.0F;
      float fVar5 = this.x + 16.0F;
      float fVar7 = this.width - 32.0F;
      rendererState();
      drawTextAt(mat, 35, fVar5, fVar6 + 3.0F, 18.0F, 18.0F);
      fVar7 += fVar5;
      if (!this.info.broken) {
         this.switcher.x = fVar7 - 28.0F;
         this.switcher.y = fVar6 + 4.0F;
         boolean selected = this.info.selected;
         if (this.switcher.on != selected) {
            this.switcher.on = selected;
            this.switcher.target = selected ? 1.0F : 0.0F;
         }

         this.switcher.render(mat, mouseX, mouseY, alpha);
      }

      float titleX = fVar5 + 18.0F + 6.0F;
      float available = Math.max(this.switcher.x - 8.0F - titleX, 0.0F);
      this.drawTitleRow(mat, titleX, fVar6, available, alpha);
      this.drawCoordRow(mat, fVar5, fVar6 + 24.0F + 6.0F, this.width - 32.0F, alpha);
      float rowY = this.height + this.y - 16.0F - 16.0F;
      float iconX = fVar7 - 20.0F;
      rowY -= 2.0F;
      this.iconDelete.x = iconX + 2.0F;
      this.iconDelete.y = rowY;
      renderIconButton(this.iconDelete, mat, mouseX, mouseY, alpha);
      fVar7 -= 22.0F;
      this.iconCopy.x = fVar7 - 20.0F + 2.0F;
      this.iconCopy.y = rowY;
      renderIconButton(this.iconCopy, mat, mouseX, mouseY, alpha);
      fVar7 -= 22.0F;
      if (!this.info.broken) {
         this.iconMove.x = fVar7 - 20.0F + 2.0F;
         this.iconMove.y = rowY;
         renderIconButton(this.iconMove, mat, mouseX, mouseY, alpha);
         fVar7 += -22.0F;
      }

      if (!this.info.key.isEmpty()) {
         float captionWidth = fVar7 - 8.0F - fVar5;
         if (captionWidth <= 0.0F) {
            captionWidth = 0.0F;
         }

         String wrapped = wrapText(this.info.key, captionWidth, 12.0F);
         rendererState();
         drawText(2, mat, wrapped, fVar5);
      }
   }

   private void drawTitleRow(Object mat, float px, float py, float available, float alpha) {
      String caption = this.formatCaption();
      float measured;
      if (caption.isEmpty()) {
         measured = 0.0F;
      } else {
         measured = textWidth(caption, 9.0F) + 26.0F + 6.0F;
      }

      float rowY = py + 4.0F;
      float rest = available - measured;
      if (rest <= 0.0F) {
         rest = 0.0F;
      }

      float keyWidth;
      if (!this.info.broken) {
         rendererState();
         keyWidth = drawAndMeasure(mat, this.inputTitle, this.info.key, px);
         this.hiddenRectX = px - 2.0F;
         this.hiddenRectY = rowY - 2.0F;
         this.hiddenRectW = rest + 4.0F;
         this.hiddenRectH = 20.0F;
      } else {
         String wrapped = wrapText(this.info.key, rest, 16.0F);
         rendererState();
         drawText(4, mat, wrapped, px);
         keyWidth = textWidth(wrapped, 12.0F);
         this.hiddenRectW = 0.0F;
      }

      if (!caption.isEmpty()) {
         if (keyWidth <= rest) {
            rest = keyWidth;
         }

         float captionX = rest + px + 6.0F;
         drawCaption(mat, captionX, py + 2.0F);
      }
   }

   private void drawCoordRow(Object mat, float px, float py, float available, float alpha) {
      drawFrame(mat, px, py, available, 42.0F, 14.0F, alpha, 0);
      float fVar3 = 3.0F;
      float fVar12 = 12.0F;
      float fVar4 = 36.0F;
      float positionY = py + 3.0F;
      float positionX = px + 3.0F;
      float fVar7 = available - 6.0F - 4.0F;
      this.slotY = positionY;
      this.slotW = fVar7 / 3.0F;
      float fVar60 = (this.slotW + 2.0F) * 0.0F + positionX;
      this.slotX[0] = fVar60;
      drawField(mat, fVar60, this.slotY, this.slotW, fVar4, fVar12, 0.0F, 0.0F, fVar12, alpha);
      this.drawCoordField(mat, 0, this.slotX[0], this.slotY, this.slotW, alpha);
      float fVar61 = this.slotW + 2.0F + positionX;
      this.slotX[1] = fVar61;
      drawField(mat, fVar61, this.slotY, this.slotW, fVar4, 0.0F, 0.0F, 0.0F, 0.0F, alpha);
      this.drawCoordField(mat, 1, this.slotX[1], this.slotY, this.slotW, alpha);
      float fVar62 = this.slotW + 2.0F + (this.slotW + 2.0F + positionX);
      this.slotX[2] = fVar62;
      drawField(mat, fVar62, this.slotY, this.slotW, fVar4, 0.0F, fVar12, fVar12, 0.0F, alpha);
      this.drawCoordField(mat, 2, this.slotX[2], this.slotY, this.slotW, alpha);
   }

   private void drawCoordField(Object mat, int index, float px, float py, float pw, float alpha) {
      WaypointCard.PlateInput field;
      int coordinate;
      if (index == 0) {
         field = this.inputX;
         coordinate = this.info.x;
      } else if (index == 1) {
         field = this.inputY;
         coordinate = this.info.y;
      } else {
         field = this.inputZ;
         coordinate = this.info.z;
      }

      String value;
      if (!field.customText) {
         value = toCoordinateText(coordinate);
      } else {
         value = field.text;
      }

      String label = coordLabel(index);
      float fVar14 = 12.0F;
      float fVar15 = px + 12.0F;
      float fVar16 = py + 12.0F;
      rendererState();
      drawText(4, mat, label, fVar15);
      float labelWidth = textWidth(label, fVar14);
      float fVar13 = px + pw - fVar14;
      fVar13 = fVar13 - fVar15 - (labelWidth + 8.0F);
      if (fVar13 <= 0.0F) {
         fVar13 = 0.0F;
      }

      String fitted = ellipsize(value, fVar13, fVar14);
      float fittedWidth = textWidth(fitted, fVar14);
      float valueX = px + pw - fVar14 - fittedWidth;
      rendererState();
      drawText(4, mat, fitted, valueX);
      if (field.customText && isFocused(field)) {
         rendererState();
         drawCaret(mat, valueX + fVar14 + 1.0F, fVar16);
      }

      releaseText(value);
      releaseText(label);
      releaseText(fitted);
   }

   private String formatCaption() {
      if (0L < this.info.deadline) {
         long ticks = systemTicks();
         long left = this.info.deadline - ticks / 10000L;
         if (0L < left) {
            long seconds = left / 1000L;
            long minutes = seconds / 60L;
            long remainder = seconds + minutes * -60L;
            return formatCaptionPair(minutes, remainder);
         }
      }

      if (this.info.flag99) {
         return "";
      } else {
         String world = currentWorldName();
         if (world == null) {
            return "";
         } else if (!world.equals(this.info.world)) {
            return "";
         } else {
            double dx = playerX() - this.info.x;
            double dy = playerY() - this.info.y;
            double dz = playerZ() - this.info.z;
            return toDistanceText(Math.sqrt(dx * dx + dy * dy + dz * dz));
         }
      }
   }

   public void onTitleChanged(String value) {
      int start = 0;
      int end = value.length();

      while (start < end && ' ' >= value.charAt(start)) {
         start++;
      }

      while (start < end && ' ' >= value.charAt(end - 1)) {
         end--;
      }

      if (start < end && value.charAt(start) == '+') {
         start++;
      }

      if (start != end) {
         if (!value.substring(start, end).equals(this.info.key)) {
            if (this.callbackTitle != null) {
               invokeInfoCallback(this.callbackTitle, this.info);
            }
         }
      }
   }

   public void onCoordChanged(String value, int axis) {
      int currentX = this.info.x;
      int currentY = this.info.y;
      int currentZ = this.info.z;
      int[] triple = parseCoordinateTriple(value);
      int newX;
      int newY;
      int newZ;
      if (triple != null) {
         newX = triple[0];
         newY = triple[1];
         newZ = triple[2];
      } else {
         int parsed = parseCoordinate(value);
         newX = parsed;
         newY = currentY;
         newZ = currentZ;
         if (axis != 0) {
            newX = currentX;
            newY = parsed;
            if (axis != 1) {
               newY = currentY;
               newZ = parsed;
            }
         }
      }

      if (newX != currentX || newY != currentY || newZ != currentZ) {
         if (this.callbackCoord != null) {
            invokeCoordCallback(this.callbackCoord, this.info, newX, newY, newZ);
         }
      }
   }

   private void onPlateMoveAction(WaypointCard card, Object closure) {
      playClickSound(12);
      if (card.callbackDelete != null) {
         invokeInfoCallback(card.callbackDelete, card.info);
      }
   }

   private void onPlateCopyAction(WaypointCard card, Object closure) {
      playClickSound(14);
      if (card.callbackCopy != null) {
         invokeInfoCallback(card.callbackCopy, card.info);
      }
   }

   private void onPlateDeleteAction(WaypointCard card, Object closure) {
      playClickSound(13);
      if (card.callbackMove != null) {
         invokeInfoCallback(card.callbackMove, card.info);
      }
   }

   private void onTitleAction(String value) {
      this.onTitleChanged(value);
   }

   private void onCoordXAction(String value) {
      this.onCoordChanged(value, 0);
   }

   private void onCoordYAction(String value) {
      this.onCoordChanged(value, 1);
   }

   private void onCoordZAction(String value) {
      this.onCoordChanged(value, 2);
   }

   public Component addIconButton(float size, Consumer<String> onChanged) {
      WaypointCard.PlateInput input = new WaypointCard.PlateInput(size, onChanged);
      this.add(input);
      return input;
   }

   private static boolean acceptKeyCode(int code) {
      return (code & 4294967295L) > 59L ? false : (864532803075702784L >>> code & 1L) != 0L;
   }

   private static String coordLabel(int index) {
      if (index == 0) {
         return "X";
      } else {
         return index == 1 ? "Y" : "Z";
      }
   }

   private static String formatCaptionPair(long minutes, long seconds) {
      return minutes + ":" + (seconds < 10L ? "0" : "") + seconds;
   }

   private static String toCoordinateText(int value) {
      return Integer.toString(value);
   }

   private static String toDistanceText(double distance) {
      return Double.toString(distance);
   }

   private static int[] parseCoordinateTriple(String value) {
      return null;
   }

   private static int parseCoordinate(String value) {
      return 0;
   }

   private static String currentWorldName() {
      return null;
   }

   private static double playerX() {
      return 0.0;
   }

   private static double playerY() {
      return 0.0;
   }

   private static double playerZ() {
      return 0.0;
   }

   private static long systemTicks() {
      return System.currentTimeMillis();
   }

   private static void assignPlateAction(WaypointCard.PlateIconButton plate, WaypointCard.IconButton icon, String label, WaypointCard.PlateAction action) {
   }

   private static void assignIconAction(WaypointCard.IconButton icon, WaypointCard.PlateAction action) {
   }

   private static void assignLabel(WaypointCard.IconButton icon, String label) {
   }

   private static void assignKeyCapture(WaypointCard.PlateInput input, WaypointCard.KeyPredicate predicate) {
   }

   private static void invokeInfoCallback(Object callback, WaypointCard.WaypointInfo value) {
   }

   private static void invokeCoordCallback(Object callback, WaypointCard.WaypointInfo value, int px, int py, int pz) {
   }

   private static void releaseCallback(Object callback) {
   }

   private static void releaseInfo(WaypointCard.WaypointInfo value) {
   }

   private static void releaseInfoCopy(WaypointCard.WaypointInfo value) {
   }

   private static void releaseSwitcher(WaypointCard.SwitcherButton value) {
   }

   private static void releasePlateButton(WaypointCard.PlateIconButton value) {
   }

   private static void releaseIconButton(WaypointCard.IconButton value) {
   }

   private static void releaseText(String value) {
   }

   private static void playClickSound(int sound) {
   }

   private static void rendererState() {
   }

   private static float textWidth(String value, float reference) {
      return 0.0F;
   }

   private static String wrapText(String value, float width, float reference) {
      return value;
   }

   private static String ellipsize(String value, float width, float reference) {
      return value;
   }

   private static boolean isFocused(WaypointCard.PlateInput field) {
      return false;
   }

   private static void drawPanel(Object mat, float px, float py, float pw, float ph, float radius, float alpha) {
   }

   private static void drawLabel(WaypointCard card, Object mat, float px, float py) {
   }

   private static void drawIconButton(WaypointCard.PlateIconButton button, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void renderIconButton(WaypointCard.IconButton button, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void drawTextAt(Object mat, int id, float px, float py, float pw, float ph) {
   }

   private static void drawFrame(Object mat, float px, float py, float pw, float ph, float radius, float alpha, int flags) {
   }

   private static void drawField(Object mat, float px, float py, float pw, float ph, float radius, float cornerA, float cornerB, float cornerC, float alpha) {
   }

   private static void drawText(int mode, Object mat, String value, float px) {
   }

   private static float drawAndMeasure(Object mat, WaypointCard.PlateInput field, String value, float px) {
      return 0.0F;
   }

   private static void drawCaption(Object mat, float px, float py) {
   }

   private static void drawCaret(Object mat, float px, float py) {
   }

   public static class IconButton extends Component {
      public int icon;
      public int activeIcon = 89;
      public boolean clickEnabled;
      public boolean disabled;
      public float iconSize;
      public final AbstractCard.Anim anim = new AbstractCard.Anim(0.0F, 0.15F, 0);
      public Runnable onClick;
      public Consumer<String> onAction;
      public String label = "";

      public IconButton(int icon, float size) {
         this.icon = icon;
         this.activeIcon = 89;
         this.clickEnabled = false;
         this.disabled = false;
         this.iconSize = size;
         this.setSize(size, size);
      }

      public boolean mousePressed(float mouseX, float mouseY) {
         this.fire();
         return true;
      }

      public void fire() {
         if (this.onClick != null) {
            this.onClick.run();
         }
      }
   }

   public interface KeyPredicate {
      boolean test(int var1);
   }

   public interface PlateAction {
      void run(WaypointCard var1, Object var2);
   }

   public static class PlateIconButton extends Component {
      public int icon;
      public int variant;
      public boolean enabled = true;
      public final AbstractCard.Anim enabledAnim = new AbstractCard.Anim(1.0F, 0.22F, 0);
      public final AbstractCard.Anim hoverAnim = new AbstractCard.Anim(0.0F, 0.15F, 0);
      public String label = "";
      public Consumer<String> onAction;

      public PlateIconButton(int icon, String label) {
         this.icon = icon;
         this.variant = 0;
         this.label = label;
         this.setSize(42.0F, 42.0F);
      }

      public boolean mousePressed(float mouseX, float mouseY) {
         this.fire();
         return true;
      }

      public void fire() {
         if (this.onAction != null) {
            this.onAction.accept(this.label);
         }
      }
   }

   public static class PlateInput extends Component {
      public String text = "";
      public float size;
      public boolean flag25;
      public boolean flag26;
      public String minimum = "";
      public String maximum = "";
      public boolean customText;
      public WaypointCard.KeyPredicate keyCapture;
      public Consumer<String> onChanged;

      public PlateInput(float size, Consumer<String> onChanged) {
         this.size = size;
         this.flag25 = true;
         this.flag26 = false;
         this.customText = false;
         this.onChanged = onChanged;
         this.setSize(size, size);
      }

      public String value() {
         return this.text;
      }

      public void setValue(String value) {
         this.text = value == null ? "" : value;
      }
   }

   public static class SwitcherButton extends Component {
      public static final float DEFAULT_WIDTH = 28.0F;
      public static final float DEFAULT_HEIGHT = 16.0F;
      public static final float DRAG_THRESHOLD = 1.5F;
      public static final float DRAG_ORIGIN_PAD = 2.0F;
      public static final float DRAG_ORIGIN_EXTRA = 6.0F;
      public static final float DRAG_RANGE_INSET = 12.0F;
      public static final float DRAG_RANGE_EXTRA = 4.0F;
      public static final int HOVER_NONE = 0;
      public static final int HOVER_SWITCH = 1;
      public static final int HOVER_DRAG = 3;
      public static final int OPTION_ON_INDEX = 8;
      public boolean on;
      public boolean locked;
      public Object callback;
      public float target;
      public float fade;
      public float knob;
      public boolean dragging;
      public boolean dragPastThreshold;
      public boolean pressState;
      public double pressX;

      public SwitcherButton(boolean value) {
         this.on = value;
         float initial = value ? 1.0F : 0.0F;
         this.target = initial;
         this.fade = initial;
         this.knob = initial;
         this.dragging = false;
         this.dragPastThreshold = false;
         this.pressState = false;
         this.pressX = 0.0;
         this.setSize(28.0F, 16.0F);
      }

      public boolean mousePressed(float mouseX, float mouseY) {
         this.pressState = this.on;
         this.pressX = mouseX;
         this.dragging = true;
         this.dragPastThreshold = false;
         return true;
      }

      @Override
      public boolean mouseReleased(double mx, double my, int button) {
         if (this.dragging && button == 0) {
            this.dragging = false;
            this.dragPastThreshold = false;
            boolean value;
            if (!this.dragPastThreshold) {
               value = this.pressState;
            } else {
               value = 0.5F <= this.target;
            }

            if (this.on != value) {
               this.on = value;
               if (!this.locked) {
                  updateOption((value ? 0 : 1) + 8);
               }

               if (this.callback != null) {
                  invokeSwitcherCallback(this.callback);
               }
            }

            this.target = value ? 1.0F : 0.0F;
            return true;
         } else {
            return false;
         }
      }

      @Override
      public boolean mouseMoved(double mx, double my, double delta) {
         if (!this.dragging) {
            return false;
         } else {
            if (!this.dragPastThreshold) {
               if (Math.abs(mx - this.pressX) < 1.5) {
                  return true;
               }

               this.dragPastThreshold = true;
            }

            float fraction = (float)((mx - (this.x + 2.0F + 6.0F)) / (this.width - 12.0F - 4.0F));
            if (fraction < 0.0F) {
               fraction = 0.0F;
            }

            if (fraction > 1.0F) {
               fraction = 1.0F;
            }

            this.target = fraction;
            return true;
         }
      }

      @Override
      public void render(Object mat, float mouseX, float mouseY, float alpha) {
         if (this.dragPastThreshold) {
            Screen.hoveredWidget = 3;
         } else if (this.dragging
            || !(mouseX < this.x)
               && !(this.x + this.width < mouseX)
               && !(mouseY < this.y)
               && !(this.y + this.height < mouseY)
               && (Screen.focusedWidget == null || Screen.allowHover)) {
            Screen.hoveredWidget = 1;
         }

         drawSwitch(mat, this.x, this.y, this.width, this.height, this.knob, this.fade, this.on, alpha);
      }

      public boolean isOn() {
         return this.on;
      }

      private static void updateOption(int index) {
      }

      private static void invokeSwitcherCallback(Object target) {
      }

      private static void drawSwitch(Object mat, float px, float py, float pw, float ph, float knob, float fade, boolean on, float alpha) {
      }
   }

   public static final class WaypointInfo {
      public static final int NAME_OFFSET = 0;
      public static final int KEY_OFFSET = 32;
      public static final int X_OFFSET = 64;
      public static final int Y_OFFSET = 68;
      public static final int Z_OFFSET = 72;
      public static final int WORLD_OFFSET = 80;
      public static final int SELECTED_OFFSET = 112;
      public static final int EXTRA_OFFSET = 120;
      public static final int BROKEN_OFFSET = 152;
      public static final int FLAG99_OFFSET = 153;
      public static final int DEADLINE_OFFSET = 160;
      public static final int SIZE = 168;
      public String name = "";
      public String key = "";
      public int x;
      public int y;
      public int z;
      public String world = "";
      public boolean selected;
      public String extra = "";
      public boolean broken;
      public boolean flag99;
      public long deadline;
   }
}

