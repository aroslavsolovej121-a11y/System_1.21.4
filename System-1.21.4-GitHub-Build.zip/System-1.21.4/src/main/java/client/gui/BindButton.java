package client.gui;

import client.Setting;

public class BindButton extends AbstractButton {
   public static final float DEFAULT_HEIGHT = 24.0F;
   public static final float ANIM_INIT_VALUE = 0.0F;
   public static final float STATE_E0_INIT = -1.0F;
   public static final float STATE_F0_INIT = 0.0F;
   public static final int STATE_B8_INIT = 0;
   public static final int PENDING_KEY_INIT = 0;
   public static final long STATE_E4_INIT = 0L;
   public static final byte STATE_EC_INIT = 0;
   protected boolean listening;
   protected int pendingKey;
   protected int field0xB8 = 0;
   protected String label = "";
   protected float field0xE0 = -1.0F;
   protected long field0xE4 = 0L;
   protected byte field0xEC = 0;
   protected float field0xF0 = 0.0F;
   public final AbstractButton.Anim anim = new AbstractButton.Anim(0.0F, 0.15F);

   public BindButton(Setting target) {
      this.bindTarget = target;
      this.listening = false;
      this.pendingKey = 0;
      this.field0xB8 = 0;
      this.label = "";
      this.field0xE0 = -1.0F;
      this.field0xE4 = 0L;
      this.field0xEC = 0;
      this.field0xF0 = 0.0F;
      this.height = 24.0F;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.bindTarget == null) {
         return false;
      } else if (this.listening) {
         if (button == 0 && this.contains(mx, my)) {
            this.listening = false;
            this.pendingKey = 0;
            return true;
         } else {
            this.assignBind(mouseButtonCode(button), 0);
            this.listening = false;
            this.pendingKey = 0;
            this.notifyChanged();
            return true;
         }
      } else {
         return button == 0 && this.contains(mx, my) ? this.onClick(mx, my) : false;
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (this.bindTarget == null) {
         return false;
      } else {
         if (!this.listening) {
            if (keyCode != 46) {
               return false;
            }

            if ((this.flags & 0xFF) == 0) {
               return false;
            }

            if (this.bindIsEmpty()) {
               return false;
            }

            this.clearBind();
         } else {
            if (keyCode == 27) {
               this.listening = false;
               this.pendingKey = 0;
               return true;
            }

            if (keyCode == 46) {
               this.clearBind();
            } else {
               if (isModifierKey(keyCode)) {
                  this.pendingKey = keyCode;
                  return true;
               }

               this.assignBind(keyCode, modifiers);
            }

            this.pendingKey = 0;
            this.listening = false;
         }

         this.notifyChanged();
         return true;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (this.listening) {
         int pending = this.pendingKey;
         if (pending != 0 && keyCode == pending) {
            this.assignBind(pending, 0);
            this.listening = false;
            this.pendingKey = 0;
            this.notifyChanged();
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean onClick(double mx, double my) {
      this.pendingKey = 0;
      this.listening = !this.listening;
      return true;
   }
}

