package client.gui;

import client.Setting;

public class HotkeyRow extends Component {
   public static final int SLOT_ROW_HEIGHT = 1;
   public static final int SLOT_ROW_HEIGHT_ALIAS = 2;
   public static final int SLOT_UPDATE = 3;
   public static final int SLOT_RENDER = 4;
   public static final int SLOT_MOUSE_CLICKED = 5;
   public static final int SLOT_METRIC = 6;
   public static final int SLOT_SPACING = 7;
   public static final int SLOT_OPACITY = 8;
   public static final int SLOT_ACCENT = 9;
   public static final int SLOT_SET_POSITION = 11;
   public static final int SLOT_KEY_PRESSED = 12;
   public static final int SLOT_KEY_RELEASED = 13;
   public static final int SLOT_COMMIT = 15;
   public static final float ROW_HEIGHT = 26.0F;
   public static final float ROW_SPACING = 4.0F;
   public static final float ROW_OPACITY = 1.0F;
   public static final float DEFAULT_ROW_HEIGHT = 4.5F;
   public static final float CAPTURE_DURATION = 0.15F;
   public static final float HOVER_DURATION = 0.15F;
   public static final float PRESS_DURATION = 0.15F;
   public static final float KEY_DURATION = 0.55F;
   public static final float EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final float DRAG_BIAS = 141.0F;
   public static final float BADGE_W = 20.0F;
   public static final float CAPTURE_W = 70.0F;
   public static final float ZONE_H = 18.0F;
   public static final float BADGE_PAD_X = 8.0F;
   public static final float BADGE_PAD_Y = 5.0F;
   public static final float INSET = 2.0F;
   public static final float GLYPH_SIZE = 16.0F;
   public static final float SECTION_H = 32.0F;
   public static final float TEXT_INSET = 3.0F;
   public static final float BADGE_TEXT_OFFSET = 4.0F;
   public static final float BADGE_ANIM_SCALE = 2.0F;
   private Object owner;
   private Setting setting;
   private Setting keyBind;
   private float rowHeight = 4.5F;
   private float reveal;
   private boolean rowVisible;
   private float rowY;
   private int rowFlags;
   private long tag;
   private float boundsX;
   private float boundsY;
   private float boundsWidth;
   private float boundsHeight;
   private boolean capturing;
   private int pendingModifier;
   private int boundKey;
   private int boundModifiers;
   private Object handler;
   private final Component.Anim captureAnim = new Component.Anim(0.0F, 0.15F);
   private final Component.Anim hoverAnim = new Component.Anim(0.0F, 0.15F);
   private final Component.Anim pressAnim = new Component.Anim(0.0F, 0.15F);
   private final Component.Anim keyAnim = new Component.Anim(0.0F, 0.55F);
   public static final float PI = (float) Math.PI;
   public static final int GLYPH_ICON = 68;

   public HotkeyRow() {
   }

   public HotkeyRow(Object owner, Setting keyBind) {
      this.owner = owner;
      this.setting = keyBind;
      this.keyBind = keyBind;
      this.boundKey = keyBind == null ? 0 : keyBind.getKey();
      this.boundModifiers = 0;
      long time = this.now();
      this.captureAnim.update(time);
      this.hoverAnim.update(time);
      this.pressAnim.update(time);
      this.keyAnim.update(time);
   }

   public HotkeyRow(Object owner, Setting keyBind, String label) {
      this(owner, keyBind);
   }

   public float rowHeight() {
      return 26.0F;
   }

   public float rowSpacing() {
      return 4.0F;
   }

   public float opacity() {
      return 1.0F;
   }

   public int accentColor() {
      return uiThemeColor(0);
   }

   public float drag(float value) {
      return value + 141.0F;
   }

   public float metric(float a, float b) {
      return a + b - 8.0F - 20.0F - 4.0F - 70.0F;
   }

   public void setReveal(float value) {
      if (this.reveal != value) {
         this.reveal = value;
      }
   }

   public void markVisible() {
      if (!this.rowVisible) {
         this.rowVisible = true;
         this.rowY = 0.0F;
      }
   }

   public void hideAt(float targetY) {
      if (this.rowVisible) {
         this.rowVisible = false;
         this.rowY = targetY <= 0.0F ? 0.0F : targetY;
      }
   }

   public float reveal() {
      return this.reveal;
   }

   public boolean rowVisible() {
      return this.rowVisible;
   }

   public float rowY() {
      return this.rowY;
   }

   public Object owner() {
      return this.owner;
   }

   public Setting setting() {
      return this.setting;
   }

   public boolean capturing() {
      return this.capturing;
   }

   @Override
   public float preferredHeight() {
      return 26.0F;
   }

   @Override
   public float preferredWidth() {
      return 26.0F;
   }

   public void update() {
   }

   @Override
   public void tick() {
      this.update();
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      this.render(renderer, px, py, this.width, mouseX, mouseY, alpha);
   }

   public void render(Object renderer, float px, float py, float pw, float mx, float my, float alpha) {
      float zoneX = px + pw - 20.0F - 20.0F;
      float captureX = zoneX - 4.0F - 70.0F;
      float zoneY = py + 5.0F - 2.0F;
      long time = this.now();
      this.captureAnim.retarget(this.capturing ? 1.0F : 0.0F, time);
      this.captureAnim.update(time);
      float capture = this.captureAnim.current;
      boolean overCapture = !this.capturing && mx >= captureX && mx <= captureX + 70.0F && my >= zoneY && my <= zoneY + 18.0F;
      this.hoverAnim.retarget(overCapture ? 1.0F : 0.0F, time);
      this.hoverAnim.update(time);
      float hover = this.hoverAnim.current;
      if (overCapture) {
         cursorStyle = 1;
      }

      String label;
      if (!this.capturing) {
         label = this.keyLabel();
      } else {
         label = "";
      }

      float textW = fontWidth(label, 12.0F);
      float textX = (70.0F - textW) * 0.5F + captureX;
      if (0.001F < capture || 0.001F < hover) {
         uiDrawIcon(renderer, 0, textX, zoneY + 3.0F, textW, 18.0F, uiThemeColor(0), alpha);
      }

      boolean overBadge = mx >= zoneX && mx <= zoneX + 20.0F && my >= zoneY && my <= zoneY + 18.0F;
      if (overBadge) {
         cursorStyle = 1;
      }

      if (overCapture || overBadge) {
         cursorStyle = 1;
      }

      this.pressAnim.retarget(overBadge ? 1.0F : 0.0F, time);
      this.pressAnim.update(time);
      float press = this.pressAnim.current;
      float glyphX = zoneX + 4.0F;
      float glyphY = zoneY + 3.0F;
      if (0.001F < press && press < 0.999F) {
         float angle = (press + press) * (float) Math.PI;
         uiDrawBox(renderer, glyphX, glyphY, 16.0F, 16.0F, angle, angle, angle, angle, 0, 0, 0.0F, uiThemeColor(0), 1.0F, press * alpha, 0.0F, alpha, 0);
      }

      uiDrawIcon(renderer, 68, glyphX, glyphY, 16.0F, 16.0F, uiThemeColor(0), alpha);
      this.height = zoneY + 32.0F - this.y;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      return this.mouseClicked(mx, my, button, this.x, this.y, this.width);
   }

   public boolean mouseClicked(double mx, double my, int button, float px, float py, float pw) {
      float zoneX = px + pw - 20.0F - 20.0F;
      float captureX = zoneX - 4.0F - 70.0F;
      float zoneY = py + 5.0F - 2.0F;
      boolean overCapture = mx >= captureX && mx <= captureX + 70.0F && my >= zoneY && my <= zoneY + 18.0F;
      boolean overBadge = mx >= zoneX && mx <= zoneX + 20.0F && my >= zoneY && my <= zoneY + 18.0F;
      if (this.capturing) {
         int key = 0;
         if (button != 0 || !overCapture) {
            if (button == 0) {
               key = 1;
            } else if (button == 1) {
               key = 2;
            } else if (button == 2) {
               key = 4;
            } else if (button == 3) {
               key = 5;
            } else if (button == 4) {
               key = 6;
            }

            if (this.boundKey != key || this.boundModifiers != 0) {
               this.boundKey = key;
               this.boundModifiers = 0;
               this.applyKey();
            }
         }

         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      } else if (button != 0) {
         return false;
      } else if (!overBadge) {
         if (overCapture) {
            this.capturing = true;
            this.pendingModifier = 0;
            return true;
         } else {
            return false;
         }
      } else {
         if (this.boundKey != 0 || this.boundModifiers != 0) {
            this.boundKey = 0;
            this.boundModifiers = 0;
            this.applyKey();
         }

         long time = this.now();
         this.keyAnim.set(0.0F, 0.55F);
         this.keyAnim.retarget(1.0F, time);
         this.keyAnim.update(time);
         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      mouseX = (float)mx;
      mouseY = (float)my;
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      mouseX = (float)mx;
      mouseY = (float)my;
      return false;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (!this.capturing) {
         return false;
      } else if (keyCode == 27) {
         if (this.boundKey != 0 || this.boundModifiers != 0) {
            this.boundKey = 0;
            this.boundModifiers = 0;
            this.applyKey();
         }

         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      } else if ((keyCode < 16 || keyCode > 18) && (keyCode < 160 || keyCode > 165)) {
         if (this.boundKey != keyCode || this.boundModifiers != modifiers) {
            this.boundKey = keyCode;
            this.boundModifiers = modifiers;
            this.applyKey();
         }

         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      } else {
         this.pendingModifier = keyCode;
         return true;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (!this.capturing) {
         return false;
      } else {
         int pending = this.pendingModifier;
         if (pending != 0 && keyCode == pending) {
            if (this.boundKey != pending || this.boundModifiers != 0) {
               this.boundKey = pending;
               this.boundModifiers = 0;
               this.applyKey();
            }

            this.pendingModifier = 0;
            this.capturing = false;
            return true;
         } else {
            return false;
         }
      }
   }

   public void onCommit() {
      if (this.capturing) {
         this.capturing = false;
         this.pendingModifier = 0;
      }
   }

   private void applyKey() {
      if (this.keyBind != null) {
         this.keyBind.setKey(this.boundKey);
      }
   }

   private String keyLabel() {
      return this.boundKey == 0 ? "" : nameOf(this.boundKey);
   }

   private static String nameOf(int key) {
      return "";
   }

   private static float fontWidth(String s, float size) {
      return s != null && !s.isEmpty() ? s.length() * size : 0.0F;
   }
}

