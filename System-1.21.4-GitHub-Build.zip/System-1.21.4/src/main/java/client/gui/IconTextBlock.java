package client.gui;

public class IconTextBlock extends AbstractSidebarBlock {
   public static final float DEFAULT_WIDTH = 208.0F;
   public static final float DEFAULT_HEIGHT = 32.0F;
   public static final float ANIM_SECONDS = 0.15F;
   public static final float HIDDEN_ALPHA = 0.0F;
   public static final float HOVER_ALPHA = 0.82F;
   public static final float ACTIVE_ALPHA = 1.0F;
   public static final float ICON_SIZE = 16.0F;
   public static final float ICON_LEFT = 8.0F;
   public static final float LABEL_GAP = 10.0F;
   public static final float COUNTER_RIGHT = 8.0F;
   public static final float COUNTER_GAP = 4.0F;
   public static final float LABEL_SIZE = 14.0F;
   public static final float PILL_RADIUS = 12.0F;
   public static final float EMPTY_WIDTH = 0.0F;
   public static final float COUNTER_SUM_MIN = 1.0F;
   public static final float BADGE_MIN = 1.0F;
   public static final int BADGE_COLOR_A = -2343358;
   public static final int BADGE_COLOR_B = -772;
   public static final int THEME_PILL = 8;
   public static final int THEME_COUNTER = 0;
   public static final int THEME_LABEL = 24;
   public static final int CURSOR_HAND = 1;
   public static final int ICON_COUNT = 89;
   public static final int ICON_FIRST = 1;
   public int icon;
   public final Component.Anim highlightAnim = new Component.Anim(0.0F, 0.15F);
   public final Component.Anim counterAnim = new Component.Anim(0.0F, 0.15F);
   public final Component.Anim badgeAnim = new Component.Anim(0.0F, 0.15F);
   public final IconTextBlock.TextSlot counterA = new IconTextBlock.TextSlot();
   public final IconTextBlock.TextSlot counterB = new IconTextBlock.TextSlot();
   public final IconTextBlock.TextSlot badge = new IconTextBlock.TextSlot();

   public IconTextBlock(String label, int icon) {
      super(label, 208.0F, 32.0F);
      this.icon = icon;
      this.counterA.reset();
      this.counterB.reset();
      this.badge.reset();
   }

   public IconTextBlock(String label) {
      this(label, 1);
   }

   public int getIcon() {
      return this.icon;
   }

   public void setIcon(int value) {
      this.icon = value;
   }

   public boolean isSelected() {
      return false;
   }

   public int valueA() {
      return 0;
   }

   public int valueB() {
      return 0;
   }

   public int badgeValue() {
      return 0;
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      boolean outside = px < this.x || this.x + this.width < px || py < this.y || this.y + this.height < py || hoveredComponent != null && !cursorSuppressed;
      this.hovered = !outside;
      if (!outside) {
         cursorStyle = 1;
      }

      float target = this.isSelected() ? 1.0F : (this.hovered ? 0.82F : 0.0F);
      this.highlightAnim.retarget(target, this.now());
      this.highlightAnim.update(this.now());
      float highlight = this.highlightAnim.current;
      if (highlight > 0.001F) {
         uiDrawBox(renderer, (int)this.x, (int)this.y, this.width, this.height, 12.0F, uiThemeColor(8), highlight * alpha);
      }

      uiDrawIcon(renderer, this.icon, this.x + 8.0F, (this.height - 16.0F) * 0.5F + this.y, 16.0F, 16.0F, uiThemeColor(24), alpha);
      float dimAlpha = this.visibleAlpha(alpha);
      float cursor = this.x + this.width - 8.0F;
      int first = this.valueA();
      int second = this.valueB();
      boolean show = this.isSelected() && second + first >= 1.0F;
      this.counterAnim.retarget(show ? 1.0F : 0.0F, this.now());
      this.counterAnim.update(this.now());
      float counters = this.counterAnim.current;
      if (counters > 0.001F) {
         float used = drawCounters(
            renderer,
            cursor,
            first > 0 ? this.counterA.value(first) : "",
            second > 0 ? this.counterB.value(second) : "",
            uiThemeColor(0),
            uiThemeColor(24),
            counters * dimAlpha,
            true
         );
         cursor -= (used + 4.0F) * counters;
      }

      int badgeSource = this.badgeValue();
      this.badgeAnim.retarget(badgeSource < 1.0F ? 0.0F : 1.0F, this.now());
      this.badgeAnim.update(this.now());
      float badgeAlpha = this.badgeAnim.current;
      if (badgeAlpha > 0.001F) {
         float used = drawCounters(renderer, cursor, this.badge.value(badgeSource), "", -2343358, -772, badgeAlpha * dimAlpha, false);
         cursor -= (used + 4.0F) * badgeAlpha;
      }

      float labelX = this.x + 8.0F + 16.0F + 10.0F;
      float labelW = cursor - labelX;
      if (labelW <= 0.0F) {
         labelW = 0.0F;
      }

      this.drawLabel(renderer, labelX, (this.height - 14.0F) * 0.5F + this.y, labelW, 14.0F, uiThemeColor(24), dimAlpha);
   }

   @Override
   public void dispose() {
      super.dispose();
      this.counterA.reset();
      this.counterB.reset();
      this.badge.reset();
   }

   public static enum Icon {
      ICON_00,
      ICON_01,
      ICON_02,
      ICON_03,
      ICON_04,
      ICON_05,
      ICON_06,
      ICON_07,
      ICON_08,
      ICON_09,
      ICON_10,
      ICON_11,
      ICON_12,
      ICON_13,
      ICON_14,
      ICON_15,
      ICON_16,
      ICON_17,
      ICON_18,
      ICON_19,
      ICON_20,
      ICON_21,
      ICON_22,
      ICON_23,
      ICON_24,
      ICON_25,
      ICON_26,
      ICON_27,
      ICON_28,
      ICON_29,
      ICON_30,
      ICON_31,
      ICON_32,
      ICON_33,
      ICON_34,
      ICON_35,
      ICON_36,
      ICON_37,
      ICON_38,
      ICON_39,
      ICON_40,
      ICON_41,
      ICON_42,
      ICON_43,
      ICON_44,
      ICON_45,
      ICON_46,
      ICON_47,
      ICON_48,
      ICON_49,
      ICON_50,
      ICON_51,
      ICON_52,
      ICON_53,
      ICON_54,
      ICON_55,
      ICON_56,
      ICON_57,
      ICON_58,
      ICON_59,
      ICON_60,
      ICON_61,
      ICON_62,
      ICON_63,
      ICON_64,
      ICON_65,
      ICON_66,
      ICON_67,
      ICON_68,
      ICON_69,
      ICON_70,
      ICON_71,
      ICON_72,
      ICON_73,
      ICON_74,
      ICON_75,
      ICON_76,
      ICON_77,
      ICON_78,
      ICON_79,
      ICON_80,
      ICON_81,
      ICON_82,
      ICON_83,
      ICON_84,
      ICON_85,
      ICON_86,
      ICON_87,
      ICON_88;

      public int id() {
         return this.ordinal();
      }

      public static IconTextBlock.Icon of(int id) {
         return id >= 0 && id < 89 ? values()[id] : ICON_01;
      }
   }

   public static final class TextSlot {
      public static final int CACHED_NONE = -1;
      public String text = "";
      public int cached = -1;

      public String value(int source) {
         if (source > 0 && source != this.cached) {
            this.text = Integer.toString(source);
            this.cached = source;
         }

         return this.text;
      }

      public void reset() {
         this.text = "";
         this.cached = -1;
      }
   }
}

