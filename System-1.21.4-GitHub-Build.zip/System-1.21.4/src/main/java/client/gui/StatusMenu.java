package client.gui;

public class StatusMenu extends AbstractOverlay {
   public static final int ROW_STRIDE = 72;
   public static final int ROW_COUNT = 4;
   public static final int ROW_ID = 0;
   public static final int ROW_DESCRIPTION = 8;
   public static final int ROW_DESCRIPTION_LENGTH = 16;
   public static final int ROW_HIGHLIGHT = 24;
   public static final int ROW_LAYOUT_Y = 64;
   public static final int ROW_HEIGHT = 68;
   public static final int STATUS_OFFLINE = 0;
   public static final int STATUS_ONLINE = 1;
   public static final int STATUS_IDLE = 2;
   public static final int STATUS_DO_NOT_DISTURB = 3;
   public static final int SOUND_SELECT = 14;
   public static final float OVERLAY_METRIC = 20.0F;
   public static final float FULL_ALPHA = 1.0F;
   public static final float HALF = 0.5F;
   public static final float HOVER_ALPHA = 0.8F;
   public static final float IDLE_ALPHA = 0.5F;
   public static final float ALPHA_EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final float ALPHA_SHIFT = 16.0F;
   public static final float EMPTY = 0.0F;
   public static final float ROW_ANIM_DURATION = 0.15F;
   public static final float SLIDE_ANIM_DURATION = 0.22F;
   public static final float LABEL_SIZE = 12.0F;
   public static final float DESCRIPTION_SIZE = 10.0F;
   public static final float LABEL_GAP = 8.0F;
   public static final float ROW_HEIGHT_SCALE = 16.0F;
   public static final float ROW_HEIGHT_BASE = 10.0F;
   public static final float ROW_GAP = 2.0F;
   public static final float ROW_TOP = 4.0F;
   public static final float WIDTH_PAD_LABEL = 16.0F;
   public static final float WIDTH_PAD_EDGE = 8.0F;
   public static final float PANEL_PAD = 8.0F;
   public static final float INDICATOR_INSET = 4.0F;
   public static final float INDICATOR_MAX_RADIUS = 16.0F;
   public static final float DOT_SIZE = 4.0F;
   public static final float DOT_RADIUS = 2.0F;
   public static final float DOT_OFFSET = 5.0F;
   public static final float DOT_GAP = 6.0F;
   public static final float LABEL_OFFSET = 2.0F;
   public static final float TEXT_PAD = 4.0F;
   public static final float DESCRIPTION_OFFSET = 16.0F;
   public static final float DESCRIPTION_GAP = 3.0F;
   public static final float DESCRIPTION_ALPHA = 0.5F;
   public static final int COLOR_ONLINE = -13919642;
   public static final int COLOR_IDLE = -17896;
   public static final int COLOR_DO_NOT_DISTURB = -2276315;
   public static final int COLOR_OFFLINE = -8158333;
   public static final String LABEL_ONLINE = "Онлине";
   public static final String LABEL_IDLE = "Идле";
   public static final String LABEL_DO_NOT_DISTURB = "До нот дизтурб";
   public static final String LABEL_OFFLINE = "Оффлине";
   public static final String DESCRIPTION_DO_NOT_DISTURB = "Приглашения в пати до тебя не дойдут";
   public static final String DESCRIPTION_OFFLINE = "Для всех ты будешь не в сети";
   protected StatusMenu.StatusListener callback;
   protected final StatusMenu.Row[] rows = new StatusMenu.Row[4];
   protected int selectedStatus;
   protected final AbstractOverlay.Animator selectYAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator selectHeightAnim = new AbstractOverlay.Animator();
   protected float revealY;

   public StatusMenu() {
      this.callback = null;
      this.rows[0] = new StatusMenu.Row();
      this.rows[0].id = 1;
      this.rows[0].description = "";
      resetAnimator(this.rows[0].highlight, 0.0F, 0.15F, 0);
      this.rows[0].layoutY = 0.0F;
      this.rows[0].height = 0.0F;
      this.rows[1] = new StatusMenu.Row();
      this.rows[1].id = 2;
      this.rows[1].description = "";
      resetAnimator(this.rows[1].highlight, 0.0F, 0.15F, 0);
      this.rows[1].layoutY = 0.0F;
      this.rows[1].height = 0.0F;
      this.rows[2] = new StatusMenu.Row();
      this.rows[2].id = 3;
      this.rows[2].description = "Приглашения в пати до тебя не дойдут";
      resetAnimator(this.rows[2].highlight, 0.0F, 0.15F, 0);
      this.rows[2].layoutY = 0.0F;
      this.rows[2].height = 0.0F;
      this.rows[3] = new StatusMenu.Row();
      this.rows[3].id = 0;
      this.rows[3].description = "Для всех ты будешь не в сети";
      resetAnimator(this.rows[3].highlight, 0.0F, 0.15F, 0);
      this.rows[3].layoutY = 0.0F;
      this.rows[3].height = 0.0F;
      this.selectedStatus = 1;
      resetAnimator(this.selectYAnim, 0.0F, 0.22F, 2);
      resetAnimator(this.selectHeightAnim, 0.0F, 0.22F, 2);
      this.revealY = 0.0F;
      this.rebuild();
   }

   @Override
   public float overlayConst() {
      return 20.0F;
   }

   public void rebuild() {
      float labelSize = 12.0F;
      float descriptionSize = 10.0F;
      float labelScale = 16.0F;
      float labelGap = 8.0F;
      float rowGap = 2.0F;
      float full = 1.0F;
      float accumulated = 4.0F;
      float widest = 0.0F;
      float trailing = 4.0F;

      for (StatusMenu.Row row : this.rows) {
         String label = labelFor(row.id);
         float labelWidth = StatusMenu.OverlayDraw.measureText(0, label, labelSize);
         float descriptionWidth;
         if (row.description.length() == 0) {
            descriptionWidth = 0.0F;
         } else {
            descriptionWidth = StatusMenu.OverlayDraw.measureText(1, row.description, descriptionSize);
         }

         widest = maxOf(widest, labelWidth + labelGap, descriptionWidth);
         row.layoutY = accumulated;
         float height = (row.description.length() == 0 ? full : labelWidth) * labelScale + 10.0F;
         row.height = height;
         accumulated = accumulated + height + rowGap;
      }

      accumulated = accumulated - rowGap + trailing;
      this.width = widest + 16.0F + 8.0F;
      this.height = accumulated;
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      this.rebuild();
      float half = 0.5F;
      float clamped = clamp01(parentAlpha);
      float offsetY = (1.0F - clamped) * 16.0F + this.y;
      this.revealY = offsetY;
      Object rect = StatusMenu.OverlayDraw.makeRect(target, parentAlpha, this.width * half + this.x, this.height * half + offsetY);
      StatusMenu.OverlayDraw.drawPanelTinted(rect, this.x, this.revealY, this.width, this.height, 20.0F, parentAlpha);

      for (StatusMenu.Row row : this.rows) {
         if (row.id == this.selectedStatus) {
            float layoutY = row.layoutY;
            if (this.selectYAnim.target != layoutY) {
               animate(this.selectYAnim, layoutY);
            }

            float rowHeight = row.height;
            if (this.selectHeightAnim.target != rowHeight) {
               animate(this.selectHeightAnim, rowHeight);
            }
         }
      }

      float selectedHeight = advance(this.selectHeightAnim, this.now());
      float innerWidth = this.width - 8.0F;
      float selectedY = advance(this.selectYAnim, this.now());
      float barX = this.x + 4.0F;
      int accent = StatusMenu.OverlayDraw.accentColor();
      StatusMenu.Row hoveredRow = null;
      float radius = selectedHeight * half;
      if (16.0F <= radius) {
         radius = 16.0F;
      }

      StatusMenu.OverlayDraw.drawPanelRect(rect, barX, selectedY + this.revealY, innerWidth, selectedHeight, radius, accent, 0, 0, 0, 20.0F, half, parentAlpha);
      if (!this.closed) {
         hoveredRow = this.hitRow(rx, ry);
         if (hoveredRow != null && hoveredRow.id != this.selectedStatus) {
            Screen.hoveredWidget = 1;
         }
      }

      float rowLeft = this.x + 4.0F + 8.0F;

      for (StatusMenu.Row rowx : this.rows) {
         float rowTarget = 1.0F;
         if (rowx.id != this.selectedStatus) {
            rowTarget = 0.5F;
            if (rowx == hoveredRow) {
               rowTarget = 0.8F;
            }
         }

         if (rowx.highlight.target != rowTarget) {
            animate(rowx.highlight, rowTarget);
         }

         float rowAlpha = advance(rowx.highlight, this.now()) * parentAlpha;
         float dotTop = rowx.layoutY + this.revealY + 5.0F;
         StatusMenu.OverlayDraw.drawPanel(
            rect,
            rowLeft,
            dotTop + 6.0F,
            4.0F,
            4.0F,
            2.0F,
            2.0F,
            2.0F,
            2.0F,
            statusColor(rowx.id),
            0,
            0,
            0,
            0,
            0,
            0,
            rowAlpha,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F,
            0.0F
         );
         StatusMenu.OverlayDraw.drawText(
            5, rect, labelFor(rowx.id), rowLeft + 4.0F + 4.0F, dotTop + 2.0F, 12.0F, StatusMenu.OverlayDraw.themeColor(24), rowAlpha
         );
         if (rowx.description.length() != 0) {
            StatusMenu.OverlayDraw.drawText(
               2, rect, rowx.description, rowLeft, dotTop + 16.0F + 3.0F, 10.0F, StatusMenu.OverlayDraw.themeColor(24), rowAlpha * 0.5F
            );
         }
      }
   }

   public StatusMenu.Row hitRow(double mx, double my) {
      float left = this.x + 4.0F;

      for (StatusMenu.Row row : this.rows) {
         float top = row.layoutY + this.revealY;
         if (left <= mx && mx <= this.width - 8.0F + left && top <= my && my <= top + row.height) {
            return row;
         }
      }

      return null;
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      if (button == 0) {
         StatusMenu.Row row = this.hitRow(mx, my);
         if (row != null) {
            StatusMenu.OverlayDraw.playSound(14);
            int id = row.id;
            if (id != this.selectedStatus) {
               StatusMenu.StatusListener listener = this.callback;
               this.selectedStatus = id;
               if (listener != null) {
                  listener.onStatusSelected(id);
               }
            }

            this.close();
         }
      }

      return true;
   }

   @Override
   public void dispose() {
      this.callback = null;
      super.dispose();
   }

   public int selectedStatus() {
      return this.selectedStatus;
   }

   public void setSelectedStatus(int status) {
      this.selectedStatus = status;
   }

   public StatusMenu.StatusListener listener() {
      return this.callback;
   }

   private static float maxOf(float a, float b, float c) {
      return Math.max(a, Math.max(b, c));
   }

   public static int statusColor(int status) {
      if (status == 1) {
         return -13919642;
      } else if (status == 2) {
         return -17896;
      } else {
         return status == 3 ? -2276315 : -8158333;
      }
   }

   public static String labelFor(int status) {
      if (status == 1) {
         return "Онлине";
      } else if (status == 2) {
         return "Идле";
      } else {
         return status == 3 ? "До нот дизтурб" : "Оффлине";
      }
   }

   private static final class OverlayDraw {
      public static final int STYLE_LABEL = 0;
      public static final int STYLE_DESCRIPTION = 1;
      public static final int THEME_OFFSET_00 = 0;
      public static final int THEME_OFFSET_04 = 4;
      public static final int THEME_OFFSET_08 = 8;
      public static final int THEME_OFFSET_0C = 12;
      public static final int THEME_OFFSET_10 = 16;
      public static final int THEME_OFFSET_14 = 20;
      public static final int THEME_OFFSET_18 = 24;
      public static boolean THEME_GATE_A = false;
      public static boolean THEME_GATE_B = false;
      public static boolean THEME_GATE_C = false;
      public static boolean THEME_GATE_D = false;
      public static final float ACCENT_TINT_MAIN = 0.9F;
      public static final float ACCENT_TINT_ALT = 0.55F;
      public static final float PANEL_TINT = 0.08F;

      public static void drawPanel(
         Object target,
         float x,
         float y,
         float w,
         float h,
         float radiusA,
         float radiusB,
         float radiusC,
         float radiusD,
         int color,
         int arg11,
         int arg12,
         int arg13,
         int arg14,
         int arg15,
         int arg16,
         float alpha,
         float arg18,
         float arg19,
         float arg20,
         float arg21,
         float arg22,
         float arg23,
         float arg24,
         float arg25,
         float arg26,
         float arg27,
         float arg28,
         float arg29,
         float arg30
      ) {
      }

      public static void drawPanelRect(
         Object target, float x, float y, float w, float h, float radius, int fill, int arg8, int arg9, int arg10, float arg11, float arg12, float alpha
      ) {
      }

      public static void drawPanelTinted(Object target, float x, float y, float w, float h, float radius, float alpha) {
      }

      public static void drawText(int align, Object target, String text, float x, float y, float size, int color, float alpha) {
      }

      public static void drawIcon(Object target, int icon, float x, float y, float w, float h, int color, float alpha) {
      }

      public static void drawIconInBox(Object target, int icon, float x, float y, float boxSize, int color, float alpha) {
      }

      public static Object makeRect(Object target, float alpha, float centerX, float centerY) {
         return null;
      }

      public static float measureText(int style, String text, float size) {
         return 0.0F;
      }

      public static int themeColor(int offset) {
         return 0;
      }

      public static int accentColor() {
         return THEME_GATE_A && THEME_GATE_B && THEME_GATE_C && !THEME_GATE_D ? themeTint(themeColor(8), 0.55F) : themeTint(themeColor(0), 0.9F);
      }

      public static int themeTint(int color, float factor) {
         return 0;
      }

      public static void playSound(int id) {
      }
   }

   public static final class Row {
      public int id;
      public String description = "";
      public final AbstractOverlay.Animator highlight = new AbstractOverlay.Animator();
      public float layoutY;
      public float height;
   }

   public interface StatusListener {
      void onStatusSelected(int var1);
   }
}

