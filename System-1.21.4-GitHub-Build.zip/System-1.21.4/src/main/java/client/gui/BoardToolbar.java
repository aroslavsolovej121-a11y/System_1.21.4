package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class BoardToolbar extends Component {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_KEY_PRESSED = 64;
   public static final int SLOT_KEY_RELEASED = 80;
   public static final int SLOT_SET_POSITION = 88;
   public static final int TABSTATE_SIZE = 376;
   public static final int TAB_SIZE = 200;
   public static final String LABEL_BUTTON1 = "Списком";
   public static final String LABEL_BUTTON2 = "Плитками";
   public static final int WIDGET_FLAG_88 = 136;
   public static final float WIDTH = 964.0F;
   public static final float HEIGHT = 36.0F;
   public static final float TAB_ANIM_DURATION = 0.32F;
   public static final float TAB_ALPHA_DURATION = 0.32F;
   public static final float TAB_FADE_DURATION = 0.22F;
   public static final float BUTTON_ANIM_DURATION = 0.36F;
   public static final float TAB_ROW_PAD = 2.0F;
   public static final float TAB_ROW_HEIGHT = 36.0F;
   public static final float ROW_STEP = 4.0F;
   public static final float ROW_STEP2 = 5.0F;
   public static final float ROW_EDGE = 4.0F;
   public static final float ROW_OFFSET = 3.0F;
   public static final float BG_PAD = 16.0F;
   public static final float BG_INSET = 32.0F;
   public static final float BG_HEIGHT = 50.0F;
   public static final float BG_RADIUS = 18.0F;
   public static final float BG_ROUND = 42.0F;
   public static final float BG_ROUND2 = 14.0F;
   public static final float BG_ROUND3 = 12.0F;
   public static final float TAB_ROW_HEIGHT2 = 36.0F;
   public static final float TAB_RADIUS = 12.0F;
   public static final float SEARCH_WIDTH = 100.0F;
   public static final float SEARCH_HEIGHT = 42.0F;
   public static final float SEARCH_RADIUS = 14.0F;
   public static final float SEARCH_INSET = 46.0F;
   public static final float TAB_ROW_INSET = 36.0F;
   public static final float SCROLL_EDGE = 2.0F;
   public static final float CLAMP_UNIT = 3.0F;
   public static final float HALF_SCALE = 0.5F;
   public static final float BG_ALPHA_OFF = 100.0F;
   public static final float BG_ALPHA_OFF2 = 46.0F;
   public static final float PLATE_WIDTH = 230.0F;
   public static final float BUTTON_SIZE = 46.0F;
   public static final float WIDGET_SHRINK = 4.0F;
   public static final float HALF = 0.5F;
   public static final float ANIM_EPSILON = 0.001F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float TAB_ALPHA_SHOWN = 1.0F;
   public static final float TAB_ALPHA_HIDDEN = 0.0F;
   public static final int LIST_LAYOUT_INDEX = 1;
   public static final int ICON_PLATE = 54;
   public static final int ICON_BUTTON1 = 79;
   public static final int ICON_BUTTON2 = 78;
   public static final int SOUND_TAB = 11;
   public static final int KEY_ESCAPE = 27;
   public static final int KEY_ENTER = 13;
   public Consumer<AbstractCollectionPart.BoardLayout> onLayoutRequested;
   public IntConsumer onTabChanged;
   public Consumer<String> onTitleChanged;
   public Runnable onClose;
   public Runnable onTabMenuAction;
   public BoardToolbar.TabListener tabListener;
   public final List<BoardToolbar.TabState> tabStates = new ArrayList<>();
   public int selectedTab = -1;
   public int tabLayoutIndex;
   public final AbstractCollectionPart.Anim tabAnim1 = new AbstractCollectionPart.Anim(0.0F, 0.32F, 2);
   public final AbstractCollectionPart.Anim tabAnim2 = new AbstractCollectionPart.Anim(0.0F, 0.32F, 2);
   public boolean tabAnim1Running;
   public final AbstractCollectionPart.Anim tabAlphaAnim = new AbstractCollectionPart.Anim(0.0F, 0.22F, 0);
   public float tabAlphaA;
   public float tabAlphaB;
   public float tabAlphaTarget;
   public float tabAlphaDuration = 0.22F;
   public int tabAlphaEase = 0;
   public long tabAlphaStart;
   public boolean tabAlphaRunning;
   public BoardToolbar.PlateInput plate;
   public BoardToolbar.ToolButton button1;
   public BoardToolbar.ToolButton button2;
   public BoardToolbar.ToolWidget widget1;
   public BoardToolbar.ToolWidget widget2;
   public float tabRowX;
   public float tabRowY;
   public float tabRowW;
   public boolean searchAlpha;
   public Object label1;
   public float label1Alpha;
   public boolean label1Running;
   public boolean plateFocused;
   public Component keyFilter;
   public Component field;
   public boolean rootFlag;

   public BoardToolbar() {
   }

   public BoardToolbar(List<BoardToolbar.Tab> tabs, String title, int icon, String secondLabel, int icon2) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.tabListener = null;
      this.tabStates.clear();
      this.selectedTab = -1;
      this.tabLayoutIndex = 0;
      this.tabAnim1.duration = 0.32F;
      this.tabAnim2.duration = 0.32F;
      this.tabAnim1Running = false;
      this.tabAlphaAnim.duration = 0.22F;
      this.tabAlphaAnim.ease = 0;
      this.plate = new BoardToolbar.PlateInput();
      this.plate.callback = null;
      this.plate.setSize(230.0F, 0.0F);
      this.button1 = new BoardToolbar.ToolButton();
      this.button1.icon = 79;
      this.button1.flag = 0.36F;
      this.button2 = new BoardToolbar.ToolButton();
      this.button2.icon = 78;
      this.button2.flag = 0.36F;
      this.widget1 = new BoardToolbar.ToolWidget();
      this.widget1.icon = icon2;
      this.widget1.mode = 0;
      this.widget2 = new BoardToolbar.ToolWidget();
      this.widget2.icon = 0;
      this.tabRowX = 0.0F;
      this.tabRowW = 0.0F;
      this.width = 964.0F;
      this.height = 36.0F;
      if (tabs != null && !tabs.isEmpty()) {
         int i = 0;

         for (int count = tabs.size(); i < count; i++) {
            BoardToolbar.Tab tab = tabs.get(i);
            BoardToolbar.TabState state = new BoardToolbar.TabState();
            state.label = tab.label;
            state.callback = tab.callback;
            state.flag = tab.flag;
            state.callback2 = tab.callback2;
            state.label2 = tab.label2;
            state.index = -1;
            state.x = 0.0F;
            state.w = 0.0F;
            state.selected = false;
            state.extraLabel = "";
            state.anim.from = 0.0F;
            state.anim.current = 0.0F;
            state.anim.target = 0.0F;
            state.anim.running = false;
            this.tabStates.add(state);
         }
      }

      if (!this.tabStates.isEmpty()) {
         BoardToolbar.TabState first = this.tabStates.get(0);
         first.anim.from = 1.0F;
         first.anim.current = 1.0F;
         first.anim.target = 1.0F;
         first.anim.running = false;
      }

      float v = 0.0F;
      if (this.tabLayoutIndex != 1) {
         v = 1.0F;
      }

      this.tabAlphaA = v;
      this.tabAlphaB = v;
      this.tabAlphaTarget = v;
      this.tabAlphaRunning = false;
      this.button1.setSize(46.0F, 46.0F);
      this.button2.setSize(46.0F, 46.0F);
      this.button1.label = "Списком";
      this.button2.label = "Плитками";
      this.widget1.label = secondLabel;
      this.plate.callback = null;
      this.button1.callback = this.onClickButton1();
      this.button2.callback = this.onClickButton2();
      this.plate.callback = this.onPlateSubmit();
      this.widget1.callback = this.onClickWidget1();
      this.widget2.callback = this.onClickWidget2();
      this.widget1.flag88 = 1;
      this.widget2.flag88 = 1;
      this.searchAlpha = false;
      this.label1 = null;
      this.label1Alpha = 0.0F;
      this.label1Running = false;
      this.rootFlag = true;
   }

   protected Runnable onClickButton1() {
      return null;
   }

   protected Runnable onClickButton2() {
      return null;
   }

   protected Consumer<String> onPlateSubmit() {
      return null;
   }

   protected Runnable onClickWidget1() {
      return null;
   }

   protected Runnable onClickWidget2() {
      return null;
   }

   public List<BoardToolbar.TabState> tabs() {
      return this.tabStates;
   }

   public int currentTab() {
      return this.selectedTab;
   }

   public void setTab(int index) {
      this.setTab(index, true);
   }

   public void setTab(int index, boolean animate) {
      if (index >= 0 && index < this.tabStates.size()) {
         this.selectedTab = index;
         int count = this.tabStates.size();

         for (int i = 0; i < count; i++) {
            BoardToolbar.TabState state = this.tabStates.get(i);
            float target = i == index ? 1.0F : 0.0F;
            if (!animate) {
               state.anim.from = target;
               state.anim.current = target;
               state.anim.target = target;
               state.anim.running = false;
            } else if (state.anim.target != target) {
               long time = this.now();
               state.anim.advance(time);
               float value = state.anim.current;
               state.anim.target = target;
               state.anim.start = time;
               state.anim.running = true;
               state.anim.from = value;
            }
         }

         if (!animate) {
            this.tabAnim1Running = false;
         }
      }
   }

   public boolean acceptsKey(int keyCode) {
      return this.keyFilter == null;
   }

   public boolean insertTextChar(int keyCode) {
      return this.plate == null ? false : this.plate.insertTextChar(keyCode);
   }

   public boolean plateKeyPressed(int keyCode) {
      return this.plate == null ? false : this.plate.plateKeyPressed(keyCode);
   }

   public boolean plateRectHit(double mx, double my) {
      return this.plate == null
         ? false
         : mx >= this.plate.x && mx <= this.plate.x + this.plate.width && my >= this.plate.y && my <= this.plate.y + this.plate.height;
   }

   public boolean plateHasText() {
      return this.plate != null && this.plate.hasText();
   }

   public boolean overlayOpen() {
      return this.plate != null && this.plate.focused;
   }

   public void setPlateText(String value) {
      if (this.plate != null) {
         this.plate.text = value;
      }
   }

   @Override
   public void render() {
      this.renderToolbar(0.0F, 0.0F, 0.0F);
   }

   protected void renderToolbar(float offsetX, float offsetY, float alpha) {
      float bgX = this.x + 16.0F;
      float bgW = this.width - 32.0F;
      this.renderBackground(bgX, this.y, bgW, 50.0F, 18.0F, alpha);
      float rowY = this.y + 4.0F;
      this.renderTabRow(offsetX, offsetY, bgX + 4.0F, this.y + 5.0F, alpha);
      float right = bgW + bgX - 4.0F;
      if (this.widget2 != null) {
         float h = this.widget2.measuredHeight();
         this.widget2.y = rowY;
         this.widget2.x = right - h;
         right -= this.widget2.widthCache;
         if (0.001F < this.widget2.widthCache) {
            right += 4.0F;
         }
      }

      if (this.widget1 != null) {
         float h = this.widget1.measuredHeight();
         this.widget1.x = right - h;
         this.widget1.y = rowY;
      }

      float widgetW = 0.0F;
      if (this.widget1 != null) {
         widgetW = this.widget1.widthCache;
      }

      float rowX = right - (widgetW + 4.0F) - 100.0F;
      this.renderBackground2(rowX, rowY, 100.0F, 42.0F, 14.0F, alpha, 1);
      long time = this.now();
      float y2 = rowY + 3.0F;
      float x2 = rowX + 3.0F;
      float x3 = x2 + 46.0F + 2.0F;
      float t = AbstractCollectionPart.easeValue(0, 0.0F);
      this.renderBackground3(t * (x3 - x2) + x2, y2, 46.0F, 36.0F, 12.0F, time, alpha);
      if (this.button2 != null) {
         this.button2.x = x2;
         this.button2.y = y2;
         this.renderButton(this.button2, offsetX, offsetY, alpha);
      }

      if (this.button1 != null) {
         this.button1.x = x3;
         this.button1.y = y2;
         this.renderButton(this.button1, offsetX, offsetY, alpha);
      }

      if (this.widget1 != null) {
         this.renderWidget(this.widget1, offsetX, offsetY, alpha);
      }

      if (this.widget2 != null) {
         this.renderWidget(this.widget2, offsetX, offsetY, alpha);
      }

      if (this.plate != null) {
         float w = 230.0F;
         this.plate.y = rowY;
         this.plate.x = (bgW - w) * 0.5F + bgX;
         this.renderPlate(this.plate, offsetX, offsetY);
      }
   }

   protected void renderBackground(float px, float py, float pw, float ph, float radius, float alpha) {
   }

   protected void renderBackground2(float px, float py, float pw, float ph, float radius, float alpha, int mode) {
   }

   protected void renderBackground3(float px, float py, float pw, float ph, float radius, long time, float alpha) {
   }

   protected void renderTabRow(float offsetX, float offsetY, float px, float py, float alpha) {
      this.tabRowX = px;
      this.tabRowY = py;

      for (int i = 0; i < this.tabStates.size(); i++) {
         BoardToolbar.TabState state = this.tabStates.get(i);
         state.anim.advance(this.now());
         state.x = this.tabRowX;
         state.w = state.anim.value();
      }
   }

   protected void renderButton(BoardToolbar.ToolButton button, float offsetX, float offsetY, float alpha) {
   }

   protected void renderWidget(BoardToolbar.ToolWidget widget, float offsetX, float offsetY, float alpha) {
   }

   protected void renderPlate(BoardToolbar.PlateInput input, float offsetX, float offsetY) {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.plate != null && this.plate.plateClicked(mx, my, button)) {
         return true;
      } else if (this.widget1 != null && this.widget1.widgetHit(mx, my, button)) {
         return true;
      } else if (this.widget2 != null && this.widget2.widgetHit(mx, my, button)) {
         return true;
      } else if (this.button1 != null && this.button1.iconHit(mx, my, button)) {
         return true;
      } else if (this.button2 != null && this.button2.iconHit(mx, my, button)) {
         return true;
      } else {
         if (button == 0) {
            int count = this.tabStates.size();
            if (count != 0) {
               float rowTop = this.tabRowY + 2.0F;
               float rowBottom = rowTop + 36.0F;
               int i = 0;

               BoardToolbar.TabState state;
               for (state = this.tabStates.get(0); mx < state.x || mx > state.x + state.w || my < rowTop || my > rowBottom; state = this.tabStates.get(i)) {
                  if (count <= ++i) {
                     return this.selfHit(mx, my);
                  }
               }

               if (i != this.selectedTab && !state.selected) {
                  this.setTab(i, true);
                  uiSound(11);
                  if (this.tabListener != null) {
                     this.tabListener.acceptInt(i);
                  }
               }

               return true;
            }
         }

         return this.selfHit(mx, my);
      }
   }

   protected boolean selfHit(double mx, double my) {
      return mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      return this.plate == null ? false : this.plate.plateKeyPressed(keyCode);
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (!this.overlayOpen()) {
         return false;
      } else {
         return this.keyFilter != null && !this.acceptsKey(keyCode) ? false : this.insertTextChar(keyCode);
      }
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   @Override
   public void dispose() {
      if (this.tabListener != null) {
         this.tabListener = null;
      }

      this.tabStates.clear();
      if (this.plate != null) {
         this.plate.dispose();
      }

      if (this.button1 != null) {
         this.button1.dispose();
      }

      if (this.button2 != null) {
         this.button2.dispose();
      }

      if (this.widget1 != null) {
         this.widget1.dispose();
      }

      if (this.widget2 != null) {
         this.widget2.dispose();
      }

      super.dispose();
   }

   public static class PlateInput extends Component {
      public Consumer<String> callback;
      public Component keyFilter;
      public String text = "";
      public boolean focused;
      public float hover;
      public final AbstractCollectionPart.Anim anim = new AbstractCollectionPart.Anim(0.0F, 0.32F, 2);

      public boolean plateClicked(double mx, double my, int button) {
         if (button != 0) {
            return false;
         } else {
            boolean inside = mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
            this.hover = inside ? 1.0F : 0.0F;
            return inside;
         }
      }

      public String trimmed() {
         int start = 0;
         int end = this.text.length();

         while (start < end && this.text.charAt(start) <= ' ') {
            start++;
         }

         while (end > start && this.text.charAt(end - 1) <= ' ') {
            end--;
         }

         return this.text.substring(start, end);
      }

      public boolean hasText() {
         return this.trimmed().length() != 0;
      }

      public boolean commit() {
         String value = this.trimmed();
         if (value.length() == 0) {
            return false;
         } else {
            if (this.callback != null) {
               this.callback.accept(value);
            }

            this.clearText();
            if (this.focused) {
               this.focused = false;
               this.anim.setTarget(0.0F, this.now());
               this.notifyFocusChanged();
            }

            return true;
         }
      }

      public void clearText() {
         this.text = "";
      }

      public boolean plateKeyPressed(int keyCode) {
         if (!this.focused) {
            return false;
         } else if (keyCode == 27) {
            this.focused = false;
            this.anim.setTarget(0.0F, this.now());
            this.notifyFocusChanged();
            return true;
         } else if (keyCode == 13) {
            this.commit();
            return true;
         } else {
            return this.insertTextChar(keyCode);
         }
      }

      public boolean insertTextChar(int keyCode) {
         if (keyCode >= 32 && keyCode != 127) {
            this.text = this.text + (char)keyCode;
            return true;
         } else {
            return false;
         }
      }

      public void notifyFocusChanged() {
      }
   }

   public static class Tab {
      public String label;
      public Runnable callback;
      public boolean flag;
      public Runnable callback2;
      public String label2;

      public Tab() {
      }

      public Tab(String label, Runnable callback, boolean flag, Runnable callback2, String label2) {
         this.label = label;
         this.callback = callback;
         this.flag = flag;
         this.callback2 = callback2;
         this.label2 = label2;
      }
   }

   public interface TabListener {
      void acceptInt(int var1);
   }

   public static class TabState {
      public String label;
      public Runnable callback;
      public boolean flag;
      public Runnable callback2;
      public String label2;
      public final AbstractCollectionPart.Anim anim = new AbstractCollectionPart.Anim(1.0F, 0.22F, 0);
      public boolean selected;
      public String extraLabel = "";
      public int index = -1;
      public float x;
      public float w;
   }

   public static class ToolButton extends Component {
      public Runnable callback;
      public int icon;
      public float flag;
      public String label = "";

      public boolean iconHit(double mx, double my, int button) {
         return button != 0 ? false : mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
      }
   }

   public static class ToolWidget extends Component {
      public Object callback;
      public int icon;
      public String label = "";
      public int mode;
      public int flag88;
      public float widthCache;
      public float heightCache;

      public boolean widgetHit(double mx, double my, int button) {
         return button != 0 ? false : mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
      }

      public float measuredHeight() {
         return this.heightCache;
      }
   }
}

