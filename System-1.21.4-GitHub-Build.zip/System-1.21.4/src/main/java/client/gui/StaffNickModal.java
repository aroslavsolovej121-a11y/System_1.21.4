package client.gui;

import java.util.ArrayList;
import java.util.List;

public class StaffNickModal extends AbstractOverlay {
   public static final float PAD = 16.0F;
   public static final float PAD_2X = 32.0F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float HALF = 0.5F;
   public static final float RADIUS = 12.0F;
   public static final float HEADER = 36.0F;
   public static final float GAP = 8.0F;
   public static final float EPS = 0.001F;
   public static final float ROW_GAP = 4.0F;
   public static final float ROW_INSET = 6.0F;
   public static final float ROW_BOTTOM = 3.0F;
   public static final float ROW_ACTION = 13.0F;
   public static final float ROW_ICON_GAP = 5.0F;
   public static final float ROW_STEP = 20.0F;
   public static final float ROW_TEXT_GAP = 10.0F;
   public static final float F14 = 14.0F;
   public static final float F48 = 48.0F;
   public static final float MODAL_WIDTH = 310.0F;
   public static final float MODAL_HEIGHT = 232.0F;
   public static final float FIELD_WIDTH = 278.0F;
   public static final float FIELD_HEIGHT = 36.0F;
   public static final float FIELD_PAD = 12.0F;
   public static final float FIELD_SCROLL = 0.28F;
   public static final float FOCUS_DURATION = 0.15F;
   public static final int THEME_PRIMARY = 0;
   public static final int THEME_SECONDARY = 8;
   public static final int THEME_PANEL = 12;
   public static final int THEME_ROW_A = 16;
   public static final int THEME_ROW_B = 24;
   private static final String PLACEHOLDER = "Вставьте ники через пробел, Enter";
   protected StaffNickModal.NickList setting;
   protected StaffNickModal.TextField input;
   protected boolean active;
   protected final AbstractOverlay.Animator focusAnim = new AbstractOverlay.Animator();
   protected final List<StaffNickModal.NickRow> rows = new ArrayList<>();
   protected float rowGap = 4.0F;
   protected int rowIndex = -1;
   protected final AbstractOverlay.Animator scrollAnim = new AbstractOverlay.Animator();
   protected float scrollPos;
   protected Runnable onChanged;

   public StaffNickModal(StaffNickModal.NickList setting) {
      this.setting = setting;
      this.input = new StaffNickModal.TextField(278.0F, 36.0F, "Вставьте ники через пробел, Enter", 14.0F, 12.0F, 0);
      this.rows.clear();
      this.rowGap = 4.0F;
      this.rowIndex = -1;
      resetAnimator(this.scrollAnim, 0.0F, 0.28F, 2);
      this.scrollPos = 0.0F;
      this.width = 310.0F;
      this.height = 232.0F;
      this.closeOnOutsideClick = false;
   }

   @Override
   public void dispose() {
      this.freeRows();
      this.input.dispose();
      if (this.child != null) {
         this.child = null;
      }

      this.children.clear();
      this.capture = null;
   }

   @Override
   public void setChild(Component value) {
      this.scrollPos = 0.0F;
      this.scrollAnim.from = 0.0F;
      this.scrollAnim.current = 0.0F;
      this.scrollAnim.target = 0.0F;
      this.scrollAnim.running = false;
      super.setChild(value);
   }

   @Override
   public void setChildAlt(Component value) {
      this.scrollPos = 0.0F;
      this.scrollAnim.from = 0.0F;
      this.scrollAnim.current = 0.0F;
      this.scrollAnim.target = 0.0F;
      this.scrollAnim.running = false;
      super.setChildAlt(value);
   }

   public boolean onTextChanged() {
      String text = this.input.text;
      int length = text.length();
      if (length == 0) {
         return true;
      } else {
         int added = 0;
         int index = 0;

         while (true) {
            while (index >= length || !isSpace(text.charAt(index))) {
               int end = index;
               if (index < length) {
                  while (end < length && !isSpace(text.charAt(end))) {
                     end++;
                  }

                  if (index < end) {
                     String word = text.substring(index, end);
                     if (this.setting.add(word)) {
                        added++;
                     }
                  }
               }

               index = end;
               if (end >= length) {
                  if (added != 0) {
                     this.input.clearText();
                     if (this.onChanged != null) {
                        this.onChanged.run();
                     }

                     this.scrollPos = 0.0F;
                  }

                  return true;
               }
            }

            index++;
         }
      }
   }

   public float contentHeight(float viewHeight) {
      float weightMax = 1.0F;
      float step = 20.0F;
      float total = 0.0F;
      float viewport = viewHeight - 8.0F;
      boolean first = true;

      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow row = this.rows.get(i);
         float weight = row.weight;
         if (weight < 0.0F) {
            weight = 0.0F;
         }

         if (weight > weightMax) {
            weight = weightMax;
         }

         float rowHeight = row.measuredHeight(weight);
         if (!first) {
            total += rowHeight * this.rowGap;
         }

         first = false;
         total += rowHeight * step;
      }

      if (viewport <= 0.0F) {
         viewport = 0.0F;
      }

      total -= viewport;
      if (total <= 0.0F) {
         total = 0.0F;
      }

      return total;
   }

   public void syncRows(Object target, float mouseX, float mouseY, float alpha, float top, float viewHeight) {
      String[] names = this.setting.nameArray();
      this.mergeRows(names, 0.0F);
      this.rebuildRows(names);
      this.sortRows();
      float left = this.x + 16.0F;
      float listWidth = this.width - 32.0F;
      drawBoxGradient(target, left, top, listWidth);
      float maxScroll = this.contentHeight(viewHeight);
      float next = this.scrollPos;
      if (next < 0.0F) {
         next = 0.0F;
      }

      if (next > maxScroll) {
         next = maxScroll;
      }

      this.scrollPos = next;
      if (this.scrollAnim.target != next) {
         animate(this.scrollAnim, next);
      }

      long time = this.now();
      advance(this.scrollAnim, time);
      float rowLeft = left + 4.0F;
      float y = top + 4.0F - this.scrollAnim.current;
      boolean first = true;

      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow row = this.rows.get(i);
         float weight = row.weight;
         if (weight < 0.0F) {
            weight = 0.0F;
         }

         if (weight > 1.0F) {
            weight = 1.0F;
         }

         float rowHeight = row.measuredHeight(weight);
         if (!first) {
            y += rowHeight * this.rowGap;
         }

         first = false;
         row.posTarget = y;
         if (!row.posInitialized) {
            row.pos = y;
            row.posInitialized = true;
         }

         y += rowHeight * 20.0F;
      }

      setScissor(rowLeft, top, listWidth, viewHeight);

      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow rowx = this.rows.get(i);
         float weightx = rowx.weight;
         if (weightx < 0.0F) {
            weightx = 0.0F;
         }

         if (weightx > 1.0F) {
            weightx = 1.0F;
         }

         float rowHeightx = rowx.measuredHeight(weightx);
         if (0.001F < rowHeightx) {
            float rowY = rowx.pos;
            if (top <= rowY + 20.0F && rowY <= top + viewHeight) {
               this.drawRow(rowHeightx * alpha, target, rowx, rowLeft, rowY, listWidth, mouseX, mouseY);
            }
         }
      }

      resetScissor();
   }

   public void drawRow(float rowAlpha, Object target, StaffNickModal.NickRow row, float left, float rowY, float listWidth, float mouseX, float mouseY) {
      float inset = 6.0F;
      drawRowBackground(target, left, rowY);
      drawIcon(target, 34, left + inset, rowY + 5.0F);
      float actionLeft = left + listWidth - inset - 13.0F;
      float iconTop = rowY + 3.0F;
      float textLeft = left + inset + 10.0F + inset;
      float textWidth = actionLeft - inset - textLeft;
      if (textWidth <= 0.0F) {
         textWidth = 0.0F;
      }

      String clipped = clipText(row.name, textWidth, 12.0F);
      drawText(1, target, clipped, textLeft);
      float hover = 0.0F;
      if (actionLeft <= mouseX && mouseX <= actionLeft + 13.0F && iconTop <= mouseY && mouseY <= iconTop + 14.0F) {
         Screen.hoveredWidget = 1;
         hover = 1.0F;
      }

      if (row.hoverAnim.target != hover) {
         animate(row.hoverAnim, hover);
      }

      long time = this.now();
      float eased = advance(row.hoverAnim, time);
      uiLerpColor(themeColor(16), themeColor(24), eased);
      drawIcon(target, 32, actionLeft, iconTop);
   }

   @Override
   public void renderBody(Object target, float px, float py, float parentAlpha) {
      float top = (1.0F - clamp01(parentAlpha)) * 16.0F + this.y;
      float bottom = this.height * 0.5F + top;
      Object rect = makeRect(new float[8], bottom, parentAlpha, this.width * 0.5F + this.x, bottom);
      int themePrimary = themeColor(0);
      int themePanel = themeColor(12);
      drawPanel(
         rect,
         this.x,
         top,
         this.width,
         this.height,
         12.0F,
         12.0F,
         12.0F,
         12.0F,
         themePrimary,
         themePanel,
         1.0F,
         0,
         0,
         0.0F,
         0.0F,
         parentAlpha,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0
      );
      this.input.x = this.x + 16.0F;
      this.input.y = top + 16.0F;
      this.input.render(target, rect, px, py, parentAlpha);
      float listTop = top + 16.0F + 36.0F + 8.0F;
      this.syncRows(target, px, py, parentAlpha, listTop, top + this.height - 16.0F - listTop);
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      float pad = 16.0F;
      float rowStep = 20.0F;
      if (button == 0) {
         float fieldLeft = this.x + 16.0F;
         if (!(mx < fieldLeft) && !(this.width - 32.0F + fieldLeft < mx) && !(my < this.y + 16.0F) && !(this.y + 16.0F + 36.0F < my)) {
            this.input.mouseClicked(mx, my, button);
         } else {
            if (this.active) {
               this.active = false;
               animate(this.focusAnim, 0.0F);
               this.input.blur();
            }

            float listLeft = this.x + 16.0F;
            float listTop = this.y + 16.0F + 36.0F + 8.0F;
            float listWidth = this.width - 32.0F;
            if (listLeft <= mx && mx <= listWidth + listLeft && listTop <= my && my <= this.y + this.height - 16.0F - listTop + listTop) {
               float innerWidth = listWidth - 8.0F;
               float innerLeft = listLeft + 4.0F;

               for (int i = 0; i < this.rows.size(); i++) {
                  StaffNickModal.NickRow row = this.rows.get(i);
                  float weight = row.weight;
                  if (weight < 0.0F) {
                     weight = 0.0F;
                  }

                  if (weight > 1.0F) {
                     weight = 1.0F;
                  }

                  float rowHeight = row.measuredHeight(weight);
                  if (0.5F < rowHeight) {
                     float rowY = row.pos;
                     if (innerLeft <= mx && mx <= innerWidth + innerLeft && rowY <= my && my <= rowY + rowStep) {
                        float actionLeft = innerWidth + innerLeft - 6.0F - 13.0F;
                        if (mx < actionLeft) {
                           return true;
                        }

                        if (actionLeft + 13.0F < mx) {
                           return true;
                        }

                        if (my < rowY + 3.0F) {
                           return true;
                        }

                        if (rowY + 3.0F + 14.0F < my) {
                           return true;
                        }

                        this.setting.toggle(row.name);
                        return true;
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      float listLeft = this.x + 16.0F;
      float listTop = this.y + 16.0F + 36.0F + 8.0F;
      if (listLeft <= mx && mx <= this.width - 32.0F + listLeft && listTop <= my && my <= listTop + (this.y + this.height - 16.0F - listTop)) {
         float maxScroll = this.contentHeight(this.y + this.height - 16.0F - listTop);
         float next = this.scrollPos - (float)amount * 48.0F;
         if (next <= 0.0F) {
            next = 0.0F;
         }

         if (next > maxScroll) {
            next = maxScroll;
         }

         if (next < 0.0F) {
            next = 0.0F;
         }

         this.scrollPos = next;
         animate(this.scrollAnim, this.scrollPos);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      if (!this.active) {
         return false;
      } else if (keyCode == 27) {
         this.active = false;
         animate(this.focusAnim, 0.0F);
         this.input.blur();
         return true;
      } else {
         this.input.keyPressed(keyCode, modifiers);
         return true;
      }
   }

   @Override
   public boolean charTyped(char ch) {
      if (!this.active) {
         return false;
      } else {
         this.input.charTyped(ch);
         return true;
      }
   }

   @Override
   public void onClosed() {
      if (this.active) {
         this.active = false;
         animate(this.focusAnim, 0.0F);
         this.input.blur();
      }
   }

   public void mergeRows(String[] names, float delayStep) {
      int added = 0;

      for (int i = 0; i < names.length; i++) {
         String name = names[i];
         StaffNickModal.NickRow found = null;

         for (int j = 0; j < this.rows.size(); j++) {
            StaffNickModal.NickRow row = this.rows.get(j);
            if (row != null && row.name.equals(name)) {
               found = row;
               break;
            }
         }

         if (found != null) {
            if (!found.enabled) {
               found.enabled = true;
               found.delay = 0.0F;
            }
         } else {
            StaffNickModal.NickRow created = this.createRow(name);
            if (created != null) {
               if (delayStep <= 0.0F) {
                  if (!created.enabled) {
                     created.delay = 0.0F;
                     created.enabled = true;
                  }
               } else {
                  float delay = added * delayStep;
                  if (!created.enabled) {
                     if (delay <= 0.0F) {
                        delay = 0.0F;
                     }

                     created.delay = delay;
                     created.enabled = true;
                  }
               }

               this.rows.add(created);
               added++;
            }
         }
      }

      int removed = 0;

      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow row = this.rows.get(i);
         if (row != null) {
            boolean present = false;

            for (int jx = 0; jx < names.length; jx++) {
               if (names[jx].equals(row.name)) {
                  present = true;
                  break;
               }
            }

            if (!present && row.enabled) {
               float delay = 0.0F;
               if (delayStep > 0.0F) {
                  delay = removed * delayStep;
                  if (delay <= 0.0F) {
                     delay = 0.0F;
                  }
               }

               row.enabled = false;
               row.delay = delay;
               removed++;
            }
         }
      }
   }

   public void rebuildRows(String[] names) {
      int matched = 0;

      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow row = this.rows.get(i);
         if (row != null) {
            for (int j = 0; j < names.length; j++) {
               if (names[j].equals(row.name)) {
                  if (names.length <= matched) {
                     this.rebuildRowsSlow(names);
                     return;
                  }

                  if (!names[matched].equals(row.name)) {
                     this.rebuildRowsSlow(names);
                     return;
                  }

                  matched++;
                  break;
               }
            }
         }
      }

      if (matched != names.length) {
         this.rebuildRowsSlow(names);
      }
   }

   private void rebuildRowsSlow(String[] names) {
      List<StaffNickModal.NickRow> next = new ArrayList<>();
      List<StaffNickModal.NickRow> pool = new ArrayList<>(this.rows);

      for (int i = 0; i < names.length; i++) {
         StaffNickModal.NickRow row = null;

         for (int j = 0; j < pool.size(); j++) {
            StaffNickModal.NickRow candidate = pool.get(j);
            if (candidate != null && candidate.name.equals(names[i])) {
               row = candidate;
               pool.set(j, null);
               break;
            }
         }

         if (row == null) {
            row = this.createRow(names[i]);
         }

         next.add(row);
      }

      for (int i = 0; i < pool.size(); i++) {
         StaffNickModal.NickRow leftover = pool.get(i);
         if (leftover != null) {
            leftover.dispose();
         }
      }

      this.rows.clear();
      this.rows.addAll(next);
   }

   public void sortRows() {
      long key = this.now();

      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow row = this.rows.get(i);
         if (row != null) {
            row.sortKey = key;
         }
      }

      int first;
      for (first = 0; first < this.rows.size(); first++) {
         StaffNickModal.NickRow row = this.rows.get(first);
         if (row == null || !row.enabled && !(0.001F < row.weight)) {
            break;
         }
      }

      if (first != this.rows.size()) {
         for (int scan = first + 1; scan < this.rows.size(); scan++) {
            StaffNickModal.NickRow row = this.rows.get(scan);
            if (row != null && (row.enabled || 0.001F < row.weight)) {
               StaffNickModal.NickRow previous = this.rows.get(first);
               this.rows.set(scan, null);
               this.rows.set(first, row);
               if (previous != null) {
                  previous.dispose();
               }

               first++;
            }
         }

         if (first != this.rows.size()) {
            for (int ix = first; ix < this.rows.size(); ix++) {
               StaffNickModal.NickRow row = this.rows.get(ix);
               if (row != null) {
                  row.dispose();
               }
            }

            while (this.rows.size() > first) {
               this.rows.remove(this.rows.size() - 1);
            }
         }
      }
   }

   public void freeRows() {
      for (int i = 0; i < this.rows.size(); i++) {
         StaffNickModal.NickRow row = this.rows.get(i);
         if (row != null) {
            row.dispose();
         }
      }

      this.rows.clear();
   }

   private StaffNickModal.NickRow createRow(String name) {
      return new StaffNickModal.NickRow(name);
   }

   protected static boolean isSpace(char ch) {
      return ch == ' ' || (ch - '\t' & 250) == 0 && ch != 14;
   }

   protected static int themeColor(int index) {
      return 0;
   }

   protected static void drawPanel(
      Object rect,
      float px,
      float py,
      float pw,
      float ph,
      float r1,
      float r2,
      float r3,
      float r4,
      int colorA,
      int colorB,
      float alpha1,
      int border,
      int borderWidth,
      float cornerSpread,
      float thickness,
      float alpha2,
      int z1,
      int z2,
      int z3,
      int z4,
      int z5,
      int z6,
      int z7,
      int z8,
      int z9,
      int z10,
      int z11,
      int z12,
      int z13
   ) {
   }

   protected static void drawBox(
      Object target,
      float px,
      float py,
      float pw,
      float ph,
      float r1,
      float r2,
      float r3,
      float r4,
      int fillTop,
      int fillBottom,
      float fillAlpha,
      int border,
      float borderWidth,
      float borderAlpha,
      float shadowAlpha,
      float alpha,
      int flags
   ) {
   }

   protected static void drawBoxGradient(Object target, float px, float py, float pw) {
   }

   protected static void drawText(int mode, Object target, Object text, float px) {
   }

   protected static void drawText(int mode, Object target, Object text, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawIcon(Object target, int icon, float px, float py) {
   }

   protected static void drawIcon(Object target, int icon, float px, float py, float pw, float ph, int color, float alpha) {
   }

   protected static float measureText(Object target, Object text, float size) {
      return 0.0F;
   }

   protected static int measureLines(Object target, Object text, float size, float maxWidth) {
      return 0;
   }

   protected static Object makeRect(Object out, float px, float py, float pw, float ph) {
      return out;
   }

   protected static String clipText(String text, float maxWidth, float size) {
      return text;
   }

   protected static void setScissor(float px, float py, float pw, float ph) {
   }

   protected static void resetScissor() {
   }

   protected static void drawRowBackground(Object target, float px, float py) {
   }

   protected static void drawRowIcon(Object target, int icon, float px, float py, float pw, float ph, int color, float alpha) {
   }

   public static class NickList {
      public final List<String> names = new ArrayList<>();

      public boolean add(String name) {
         for (int i = 0; i < this.names.size(); i++) {
            if (this.names.get(i).equals(name)) {
               return false;
            }
         }

         this.names.add(name);
         return true;
      }

      public void toggle(String name) {
         for (int i = 0; i < this.names.size(); i++) {
            if (this.names.get(i).equals(name)) {
               this.names.remove(i);
               return;
            }
         }

         this.names.add(name);
      }

      public String[] nameArray() {
         return this.names.toArray(new String[this.names.size()]);
      }
   }

   public static class NickRow {
      public String name;
      public final AbstractOverlay.Animator hoverAnim = new AbstractOverlay.Animator();
      public float weight;
      public boolean enabled;
      public float delay;
      public float pos;
      public boolean posInitialized;
      public float posTarget;
      public long sortKey;

      public NickRow(String name) {
         this.name = name;
         this.enabled = true;
         this.delay = 0.0F;
      }

      public float measuredHeight(float value) {
         return value;
      }

      public void dispose() {
      }
   }

   public static class TextField {
      public float x;
      public float y;
      public float width;
      public float height;
      public String text = "";
      public int textLen;
      public int textCap;
      public int textBacking;
      public boolean focused;
      public final AbstractOverlay.Animator focusAnim = new AbstractOverlay.Animator();
      public final AbstractOverlay.Animator caretAnim = new AbstractOverlay.Animator();
      public final String placeholder;
      public final float padding;
      public final float radius;
      public final int flags;

      public TextField(float width, float height, String placeholder, float padding, float radius, int flags) {
         this.width = width;
         this.height = height;
         this.placeholder = placeholder;
         this.padding = padding;
         this.radius = radius;
         this.flags = flags;
      }

      public void render(Object target, Object rect, float mouseX, float mouseY, float alpha) {
         if (this.focused) {
            Screen.textInputActive = true;
         }

         if (this.x <= mouseX
            && mouseX <= this.x + this.width
            && this.y <= mouseY
            && mouseY <= this.y + this.height
            && (AbstractOverlay.activeOverlay == null || Screen.allowHover)) {
            Screen.hoveredWidget = 2;
         }

         StaffNickModal.drawBox(
            target,
            this.x,
            this.y,
            this.width,
            this.height,
            8.0F,
            8.0F,
            8.0F,
            8.0F,
            StaffNickModal.themeColor(0),
            StaffNickModal.themeColor(12),
            1.0F,
            436207616,
            0.0F,
            1.0F,
            1.0F,
            alpha,
            0
         );
         float innerWidth = this.width - this.padding - this.padding - 14.0F;
         float innerY = (this.height - 8.0F) * 0.5F + this.y;
         if (!this.focused && this.text.isEmpty()) {
            StaffNickModal.drawText(0, target, this.placeholder, this.x + this.padding, innerY, 14.0F, StaffNickModal.themeColor(12), alpha);
         } else {
            StaffNickModal.drawText(0, target, this.text, this.x + this.padding, innerY, 14.0F, StaffNickModal.themeColor(12), alpha);
         }

         StaffNickModal.setScissor(this.x + this.padding, this.y, innerWidth, this.height);
         if (0.001F < alpha) {
            StaffNickModal.drawText(0, target, this.text, this.x + this.padding, innerY, 14.0F, StaffNickModal.themeColor(12), alpha);
         }

         if (alpha < 0.999F) {
            StaffNickModal.drawBoxGradient(target, this.x + this.padding, innerY, innerWidth);
         }

         StaffNickModal.resetScissor();
      }

      public boolean mouseClicked(double mx, double my, int button) {
         if (button != 0) {
            return false;
         } else if (this.x <= mx && mx <= this.x + this.width && this.y <= my && my <= this.y + this.height) {
            this.setFocused(true);
            return true;
         } else {
            this.setFocused(false);
            return false;
         }
      }

      public boolean keyPressed(int keyCode, int modifiers) {
         if (keyCode == 13) {
            return true;
         } else {
            if ((modifiers & 2) != 0) {
               if (keyCode == 65) {
                  this.textBacking = 0;
                  this.textLen = this.text.length();
                  return true;
               }

               if (keyCode == 67) {
                  return true;
               }

               if (keyCode == 88) {
                  return true;
               }

               if (keyCode == 86) {
                  return true;
               }
            }

            if (keyCode == 37) {
               return true;
            } else if (keyCode == 39) {
               return true;
            } else if (keyCode == 36) {
               return true;
            } else if (keyCode == 35) {
               return true;
            } else if (keyCode == 8) {
               if (!this.text.isEmpty()) {
                  this.text = this.text.substring(0, this.text.length() - 1);
                  this.textLen = this.text.length();
                  this.textBacking = this.text.length();
               }

               return true;
            } else {
               return keyCode == 46;
            }
         }
      }

      public boolean charTyped(char ch) {
         int value = ch & '\uffff';
         if (value >= 32 && value != 127) {
            int bytes = value < 128 ? 1 : (value < 2048 ? 2 : (value < 65536 ? 3 : 4));
            this.appendUtf8(value, bytes);
            return true;
         } else {
            return false;
         }
      }

      private void appendUtf8(int value, int bytes) {
         if (bytes == 1) {
            this.text = this.text + (char)value;
         } else if (bytes == 2) {
            this.text = this.text + (char)(192 | value >> 6) + (char)(128 | value & 63);
         } else if (bytes == 3) {
            this.text = this.text + (char)(224 | value >> 12) + (char)(128 | value >> 6 & 63) + (char)(128 | value & 63);
         } else {
            this.text = this.text + (char)(240 | value >> 18) + (char)(128 | value >> 12 & 63) + (char)(128 | value >> 6 & 63) + (char)(128 | value & 63);
         }

         this.textLen = this.text.length();
         this.textBacking = this.text.length();
      }

      public void clearText() {
         this.text = "";
         this.textLen = 0;
         this.textBacking = 0;
         this.textCap = 0;
      }

      public void blur() {
         if (Screen.focusedInput == this) {
            Screen.focusedInput = null;
         }

         this.focused = false;
      }

      public void dispose() {
         if (Screen.focusedInput == this) {
            Screen.focusedInput = null;
         }

         this.focused = false;
         this.focusAnim.running = false;
         this.caretAnim.running = false;
      }

      private void setFocused(boolean value) {
         this.focused = value;
         if (value) {
            Screen.focusedInput = this;
         } else if (Screen.focusedInput == this) {
            Screen.focusedInput = null;
         }
      }
   }
}

