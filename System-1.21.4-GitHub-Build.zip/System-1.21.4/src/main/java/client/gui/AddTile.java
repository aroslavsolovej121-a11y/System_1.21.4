package client.gui;

public class AddTile extends Component {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_KEY_PRESSED = 64;
   public static final int SLOT_KEY_RELEASED = 80;
   public static final int SLOT_SET_POSITION = 88;
   public static final float INPUT_WIDTH = 230.0F;
   public static final float TILE_HEIGHT = 62.0F;
   public static final float INPUT_BOX_HEIGHT = 24.0F;
   public static final float ICON_BOX_SIZE = 42.0F;
   public static final float PADDING = 12.0F;
   public static final float GAP = 6.0F;
   public static final float ICON_INSET = 3.0F;
   public static final float ICON_TEXT_INSET = 13.0F;
   public static final float TEXT_ROW_Y_OFFSET = 1.0F;
   public static final float HOVER_ALPHA = 1.0F;
   public static final int DRAW_MODE_TITLE = 5;
   public static final int DRAW_MODE_SUBTITLE = 2;
   public static int hoverState;
   protected int icon;
   protected String title;
   protected String subtitle;
   protected int flag128;
   protected Runnable onClick;
   protected final AddTile.PlateInput input = new AddTile.PlateInput(230.0F);
   protected AbstractCard.Anim animX;
   protected AbstractCard.Anim animY;
   protected boolean animatingPosition;
   private static final AddTile.TextRow TEXT_ROW_TITLE = new AddTile.TextRow();
   private static final AddTile.TextRow TEXT_ROW_SUBTITLE = new AddTile.TextRow();

   public AddTile(int tileIcon, String tileTitle, String tileSubtitle, String inputText, int trailingIcon) {
      this.icon = tileIcon;
      this.title = tileTitle == null ? "" : tileTitle;
      this.subtitle = tileSubtitle == null ? "" : tileSubtitle;
      this.flag128 = 0;
      this.input.setText(inputText == null ? "" : inputText);
      this.input.onCommit = this::onInputCommitted;
      this.add(this.input);
      this.height = 62.0F;
   }

   private void onInputCommitted(String value) {
   }

   @Override
   public void render() {
   }

   @Override
   public void render(Object renderer, float mouseX, float mouseY, float alpha) {
      this.applyPositionAnimation(this.now());
      if (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height) {
         hoverState = 1;
      }

      float titleX = this.x + 12.0F;
      float rowY = (this.height - 42.0F) * 0.5F + this.y;
      float inputBoxX;
      float inputBoxY;
      if (this.flag128 == 1) {
         pushClip();
         float measuredTitle = measureText(TEXT_ROW_TITLE, this.title, 12.0F);
         float measuredSubtitle = measureText(TEXT_ROW_SUBTITLE, this.subtitle, 12.0F);
         float longest = measuredTitle <= measuredSubtitle ? measuredSubtitle : measuredTitle;
         float shortest = measuredTitle <= measuredSubtitle ? measuredTitle : measuredSubtitle;
         float capped = longest <= 230.0F ? longest : 230.0F;
         float left = (this.x - capped) * 0.5F + this.x;
         float boxY = (this.height - 24.0F) * 0.5F + this.y;
         inputBoxX = (this.x - capped) * 0.5F + this.x;
         inputBoxY = boxY + 24.0F + 6.0F;
         float textWidth = (this.x - capped) * 0.5F + this.x;
      } else {
         drawPanel(renderer, this.x, this.y, this.width, this.height);
         float start = this.x + 12.0F;
         float boxY = (this.height - 42.0F) * 0.5F + this.y;
         float right = this.x + this.width - 12.0F - 230.0F;
         float inputY = (this.height - 24.0F) * 0.5F + this.y;
         float available = right - 6.0F - (start + 12.0F + 6.0F);
         inputBoxX = right;
         inputBoxY = inputY;
         float textWidth = available <= 0.0F ? 0.0F : available;
      }

      drawRectOutline(renderer, titleX, rowY, 42.0F, 42.0F);
      pushClip();
      drawCornerMarks(renderer, titleX + 3.0F, rowY + 3.0F);
      rendererState();
      drawTextAt(renderer, this.icon, titleX + 13.0F, rowY + 13.0F, alpha);
      float textX = titleX + 42.0F + 6.0F;
      rendererState();
      drawTextAt2(5, renderer, titleX, this.title, textX);
      drawTextAt2(2, renderer, titleX, this.subtitle, textX);
      this.input.setSize(230.0F, 24.0F);
      this.input.setPosition(inputBoxX, inputBoxY);
      this.input.render(renderer, mouseX, mouseY, alpha);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.input.mousePressed(mx, my, button)) {
         return true;
      } else if (button != 0) {
         return false;
      } else if (mx < this.x || mx > this.x + this.width) {
         return false;
      } else if (my < this.y || my > this.y + this.height) {
         return false;
      } else if (this.input.focusState()) {
         this.input.select();
         return true;
      } else if (this.onClick != null) {
         this.onClick.run();
         return true;
      } else if (!this.input.focused) {
         this.input.setFocused(true);
         return true;
      } else {
         return true;
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      return this.input.keyPressedInput(keyCode, modifiers);
   }

   @Override
   public boolean keyReleased(int keyCode) {
      return this.input.keyReleasedInput(keyCode);
   }

   @Override
   public void setPosition(float px, float py) {
      this.setPositionAnimated(px, py);
   }

   public void setPositionAnimated(float px, float py) {
      if (this.animX == null) {
         this.animX = new AbstractCard.Anim(px, 0.0F, 1);
         this.animY = new AbstractCard.Anim(py, 0.0F, 1);
      }

      if (!this.animatingPosition) {
         this.animX.snap(px);
         this.animY.snap(py);
         this.x = px;
         this.y = py;
         this.animatingPosition = true;
      } else {
         this.animX.setTarget(px);
         this.animY.setTarget(py);
      }
   }

   public void applyPositionAnimation(long time) {
      if (this.animatingPosition && this.animX != null && this.animY != null) {
         this.x = this.animX.update(time);
         this.y = this.animY.update(time);
      }
   }

   public static void drawPanel(Object renderer, float x, float y, float width, float height) {
   }

   public static void drawRectOutline(Object renderer, float x, float y, float width, float height) {
   }

   public static void pushClip() {
   }

   public static void drawCornerMarks(Object renderer, float x, float y) {
   }

   public static Object rendererState() {
      return null;
   }

   public static void drawTextAt(Object renderer, int icon, float x, float y, float alpha) {
      uiDrawIcon(renderer, icon, x, y, 42.0F, 42.0F, -1, alpha);
   }

   public static void drawTextAt2(int mode, Object renderer, float x, String text, float textX) {
   }

   public static void playClickSound(int sound) {
      uiSound(sound);
   }

   public static float measureText(AddTile.TextRow row, String text, float size) {
      return 0.0F;
   }

   public interface Consumer2 {
      void accept(String var1);
   }

   public static class PlateInput extends Component implements AbstractCard.InputChild {
      public String text = "";
      public boolean selected;
      public boolean shiftCommit;
      public AddTile.Consumer2 onCommit;
      public final AbstractCard.Anim focusAnim = new AbstractCard.Anim(0.0F, 0.22F, 0);

      public PlateInput(float width) {
         this.setSize(width, 24.0F);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }

      public boolean focusState() {
         return this.focused;
      }

      public void select() {
         this.selected = true;
      }

      public void setFocused(boolean value) {
         this.focused = value;
         this.focusAnim.setTarget(value ? 1.0F : 0.0F);
      }

      public boolean keyPressedInput(int keyCode, int modifiers) {
         return false;
      }

      public boolean keyReleasedInput(int keyCode) {
         if (!this.focused) {
            return false;
         } else {
            return this.capture != null && this.capture instanceof AbstractCard.KeyCapture && !((AbstractCard.KeyCapture)this.capture).onKey(keyCode)
               ? false
               : AbstractCard.insertCodePoint(this, keyCode);
         }
      }

      @Override
      public void render(Object renderer, float mouseX, float mouseY, float alpha) {
      }

      @Override
      public String getText() {
         return this.text;
      }

      @Override
      public void setText(String value) {
         this.text = value == null ? "" : value;
      }

      @Override
      public boolean isShiftCommit() {
         return this.shiftCommit;
      }

      @Override
      public void commit() {
         if (this.onCommit != null) {
            this.onCommit.accept(this.text);
         }

         this.focused = false;
      }

      @Override
      public void cancel() {
         this.focused = false;
      }

      @Override
      public void blur(String value) {
         if (this.onCommit != null) {
            this.onCommit.accept(value);
         }
      }
   }

   public static final class TextRow {
      public String text = "";
   }
}

