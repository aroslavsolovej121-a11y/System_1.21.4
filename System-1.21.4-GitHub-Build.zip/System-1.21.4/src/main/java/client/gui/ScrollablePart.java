package client.gui;

public class ScrollablePart extends Component {
   public static final int X_OFFSET = 8;
   public static final int Y_OFFSET = 12;
   public static final int WIDTH_OFFSET = 16;
   public static final int HEIGHT_OFFSET = 20;
   public static final int FLAGS_OFFSET = 24;
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int ARENA_A_OFFSET = 72;
   public static final int ARENA_B_OFFSET = 80;
   public static final int STATE_OFFSET = 88;
   public static final int SCROLL_ANIM_OFFSET = 96;
   public static final int SCROLL_OFFSET = 136;
   public static final int SCROLL_LIMIT_OFFSET = 140;
   public static final int HANDLE_OFFSET = 200;
   public static final int TOOLBAR_OFFSET = 208;
   public static final int ADD_TILE_OFFSET = 216;
   public static final int CHILDREN_BEGIN_OFFSET = 224;
   public static final int CHILDREN_END_OFFSET = 232;
   public static final int CHILDREN_CAP_OFFSET = 240;
   public static final int FLAG_F8_OFFSET = 248;
   public static final int VALUE_FC_OFFSET = 252;
   public static final int SCALE_ANIM_OFFSET = 256;
   public static final int FLAG_120_OFFSET = 288;
   public static final int FLAG_128_OFFSET = 296;
   public static final int STATE_168_OFFSET = 360;
   public static final int STATE_170_OFFSET = 368;
   public static final int VALUE_178_OFFSET = 376;
   public static final int FLAG_17C_OFFSET = 380;
   public static final int VALUE_180_OFFSET = 384;
   private static final int EASE_OUT_CUBIC = 0;
   private static final int EASE_OUT_EXPO = 1;
   private static final int EASE_IN_CUBIC = 2;
   public static final float DEFAULT_WIDTH = 965.0F;
   public static final float SCROLL_ANIM_DURATION = 0.28F;
   public static final float RECT_ANIM_DURATION = 0.15F;
   public static final float SCALE_ANIM_DURATION = 0.16F;
   public static final float SCROLL_EDGE_PADDING = 16.0F;
   public static final float SCROLL_STEP = 48.0F;
   public static final int FLAG_VISIBLE = 256;
   protected float x;
   protected float y;
   protected float width;
   protected float height;
   protected int flags = 256;
   protected ScrollablePart.Anim rectAnim = new ScrollablePart.Anim(0.0F, 0.15F, 0);
   protected long arenaA;
   protected long arenaB;
   protected boolean state58;
   protected ScrollablePart.Anim scrollAnim = new ScrollablePart.Anim(0.0F, 0.28F, 1);
   protected float scroll;
   protected float scrollLimit;
   protected long handle;
   protected Object toolbar;
   protected Object addTile;
   protected long childrenBegin;
   protected long childrenEnd;
   protected long childrenCap;
   protected boolean flagF8;
   protected float valueFC;
   protected ScrollablePart.Anim scaleAnim = new ScrollablePart.Anim(1.0F, 0.16F, 2);
   protected boolean flag120;
   protected boolean flag128;
   protected long state168;
   protected long state170;
   protected float value178;
   protected boolean flag17C;
   protected float value180;

   public ScrollablePart(Object toolbar, Object addTile) {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      this.rectAnim = ScrollablePart.Anim.init(0.0F, 0.15F, 0);
      this.arenaA = 0L;
      this.arenaB = 0L;
      this.state58 = false;
      this.scrollAnim = ScrollablePart.Anim.init(0.0F, 0.28F, 1);
      this.scroll = 0.0F;
      this.scrollLimit = 0.0F;
      this.handle = 0L;
      this.toolbar = toolbar;
      this.addTile = addTile;
      this.childrenBegin = 0L;
      this.childrenEnd = 0L;
      this.childrenCap = 0L;
      this.flagF8 = false;
      this.valueFC = 0.0F;
      this.scaleAnim = ScrollablePart.Anim.init(1.0F, 0.16F, 2);
      this.scaleAnim.from = 1.0F;
      this.scaleAnim.current = 1.0F;
      this.scaleAnim.target = 1.0F;
      this.flag120 = false;
      this.flag128 = false;
      this.state168 = 0L;
      this.state170 = 0L;
      this.value178 = 0.0F;
      this.flag17C = false;
      this.value180 = 0.0F;
      this.width = 965.0F;
      this.scaleAnim.easing = 2;
      attachBoardLayoutListener(this.toolbar, this);
      releaseToolbar(toolbar);
      releaseAddTile(addTile);
   }

   @Override
   public void dispose() {
      super.dispose();
      if (Screen.focusedInput == this) {
         Screen.focusedInput = null;
      }
   }

   @Override
   public void render(Object mat, float x, float y, float alpha) {
      super.render();
   }

   public void layout(Object mat, float x, float y, float alpha) {
   }

   public void update() {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (mx < this.x || mx > this.x + this.width) {
         return false;
      } else if (!(my < this.y) && !(my > this.y + this.height)) {
         float limit = this.scrollLimit - this.height + 16.0F;
         float next = this.scroll - (float)amount * 48.0F;
         if (limit <= 0.0F) {
            limit = 0.0F;
         }

         float clamped;
         if (next < 0.0F) {
            clamped = 0.0F;
         } else {
            clamped = next;
         }

         if (next > limit) {
            clamped = limit;
         }

         this.scroll = clamped;
         this.scrollAnim.retarget(this.scroll, this.now());
         return true;
      } else {
         return false;
      }
   }

   public boolean keyPressed(int keyCode) {
      return false;
   }

   @Override
   public boolean keyReleased(int keyCode) {
      return false;
   }

   public boolean charTyped(int codePoint) {
      return false;
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   private static void attachBoardLayoutListener(Object toolbar, ScrollablePart self) {
   }

   private static void releaseToolbar(Object toolbar) {
   }

   private static void releaseAddTile(Object addTile) {
   }

   protected static float easeCubicOut(float t) {
      float inv = 1.0F - t;
      return 1.0F - inv * inv * inv;
   }

   protected static float easeCubicIn(float t) {
      return t * t * t;
   }

   protected static float easeExpoOut(float t) {
      return t >= 1.0F ? 1.0F : 1.0F - (float)Math.exp(t * -6.931472F);
   }

   protected static class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing;
      public long lastTick;
      public boolean animating;

      public Anim() {
      }

      public Anim(float value, float seconds, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = seconds;
         this.easing = easing;
      }

      public static ScrollablePart.Anim init(float value, float seconds, int easing) {
         ScrollablePart.Anim anim = new ScrollablePart.Anim(value, seconds, easing);
         anim.lastTick = System.nanoTime();
         anim.animating = false;
         return anim;
      }

      public void retarget(float target, long time) {
         if (this.target != target) {
            this.from = this.advance(time);
            this.lastTick = time;
            this.target = target;
            this.animating = true;
         }
      }

      public float advance(long time) {
         if (this.animating && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.lastTick) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.from;
            } else if (k >= 1.0F) {
               this.animating = false;
               this.current = this.target;
               return this.target;
            } else {
               this.current = ease(this.easing, k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.animating = false;
            return this.target;
         }
      }

      private static float ease(int easing, float t) {
         if (easing == 0) {
            return ScrollablePart.easeCubicOut(t);
         } else {
            return easing == 2 ? ScrollablePart.easeCubicIn(t) : ScrollablePart.easeExpoOut(t);
         }
      }
   }
}

