package client.gui;

public class HeaderBlock extends AbstractSidebarBlock {
   public static final float DEFAULT_WIDTH = 224.0F;
   public static final float DEFAULT_HEIGHT = 49.0F;
   public static final float CAPTION_WIDTH = 208.0F;
   public static final float CAPTION_HEIGHT = 32.0F;
   public static final float ICON_SIZE = 20.0F;
   public static final float ICON_X_PAD = 16.0F;
   public static final float ICON_X_INSET = 2.0F;
   public static final float ICON_BOTTOM_PAD = 15.0F;
   public static final float LABEL_GAP = 6.0F;
   public static final float LABEL_RIGHT_PAD = 8.0F;
   public static final float LABEL_SIZE = 16.0F;
   public static final float LABEL_DY = 2.0F;
   public static final float EMPTY_WIDTH = 0.0F;
   public static final int THEME_ICON = 24;
   public static final int THEME_LABEL = 20;
   public static final String DEFAULT_LABEL = "Systеm";
   public static final String DEFAULT_CAPTION = "Сlient categories";
   public int icon = 0;
   public String caption;

   public HeaderBlock(String label, String caption) {
      super(label, 224.0F, 49.0F);
      this.caption = caption == null ? "" : caption;
   }

   public HeaderBlock() {
      this("Systеm", "Сlient categories");
   }

   public int getIcon() {
      return this.icon;
   }

   public void setIcon(int value) {
      this.icon = value;
   }

   public String getCaption() {
      return this.caption;
   }

   public void setCaption(String value) {
      this.caption = value == null ? "" : value;
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      float iconX = this.x + 16.0F - 2.0F;
      float iconY = this.y + this.height - 15.0F - 20.0F;
      uiDrawIcon(renderer, this.icon, iconX, iconY, 20.0F, 20.0F, uiThemeColor(24), alpha);
      float dimAlpha = this.visibleAlpha(alpha);
      float labelX = iconX + 20.0F + 6.0F;
      float labelW = this.x + this.width - 8.0F - labelX;
      if (labelW <= 0.0F) {
         labelW = 0.0F;
      }

      this.drawLabel(renderer, labelX, iconY + 2.0F, labelW, 16.0F, uiThemeColor(20), dimAlpha);
   }

   @Override
   public void dispose() {
      super.dispose();
      this.icon = 0;
      this.caption = "";
   }
}

