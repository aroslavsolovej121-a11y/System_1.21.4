package client.gui;

import java.util.ArrayList;
import java.util.List;

public class BlockListModal extends ListOverlayBase {
   public static final int LOOKUP_STRING = 0;
   public static final int LOOKUP_STRING_SIZE = 24;
   public static final int LOOKUP_STRING_CAP = 32;
   public static final int LOOKUP_FLAG = 32;
   public static final int SELECTION_VECTOR = 280;
   public static final int SELECTION_VECTOR_END = 288;
   public static final int ENTRY_STRIDE = 40;
   public static final int ENTRY_FLAG = 32;
   public static final float COLOR_MODAL_WIDTH = 293.0F;
   public static final float COLOR_MODAL_HEIGHT = 383.0F;
   public static final float ROW_TEXT_INSET = 6.0F;
   public static final float ROW_TEXT_GAP = 5.0F;
   public static final float ROW_TEXT_SIZE = 12.0F;
   public static final float ROW_TEXT_OFFSET = 8.0F;
   public static final float ROW_TEXT_PAD = 26.0F;
   public static final float ROW_TEXT_WIDTH = 32.0F;
   public static final float ROW_GLYPH_SIZE = 16.0F;
   public static final float ROW_GLYPH_INSET = 6.0F;
   public static final float ROW_GLYPH_OFFSET = 56.0F;
   public static final float ROW_MIN_WIDTH = 30.0F;
   public static final float ROW_MIN_HEIGHT = 4.0F;
   public static final float ROW_ALPHA = 1.0F;
   public static final float ROW_ANIM_DURATION = 0.22F;
   public static final float ROW_ACCESSORY_HEIGHT = 22.0F;
   public static final float ROW_CORNER = 4.0F;
   public static final float ROW_BODY_GAP = 10.0F;
   public static final float ROW_BODY_HEIGHT = 26.0F;
   public static final float MIN_ROW_WIDTH = 30.0F;
   public static final float ZERO = 0.0F;
   public static final float ONE = 1.0F;
   public static final float HALF = 0.5F;
   public static final float EPSILON = 0.001F;
   public static final String TITLE = "Отображаемые блоки";
   public static final String DESCRIPTION = "Настройте отображение блоков в подсветке руды и контейнеров.";
   public static final String FILTER_ONLY_ENABLED = "Только вкл.";
   public static final String FILTER_SHOW_ALL = "Показать все";
   public static final String DISABLE_ALL = "Выключить все";
   public static final String EDIT_PLACEHOLDER = "Введите название блока";
   public static final String EDIT_ID = "__blocklist_edit";
   protected BlockListModal.BlockList blockList;
   protected final List<ListOverlayBase.Row> rows;
   protected boolean showOnlyEnabled;
   protected final BlockListModal.EditField editField;
   protected final ColorModal colorModal;
   protected String lastQuery;

   public BlockListModal(BlockListModal.BlockList blockList) {
      super("Введите название блока");
      this.rows = super.rows;
      this.editField = new BlockListModal.EditField("__blocklist_edit", "Введите название блока");
      this.colorModal = new ColorModal(null, null);
      this.lastQuery = "";
      this.blockList = blockList;
      this.rows.clear();
      this.showOnlyEnabled = false;
      this.lastQuery = "";
      this.colorModal.closeOnOutsideClick = false;
      this.editField.setChangeHandler(this::onQueryChanged);
   }

   protected void onQueryChanged(String value) {
   }

   @Override
   public String title() {
      return "Отображаемые блоки";
   }

   @Override
   public String description() {
      return "Настройте отображение блоков в подсветке руды и контейнеров.";
   }

   @Override
   public String filterLabel() {
      return this.showOnlyEnabled ? "Показать все" : "Только вкл.";
   }

   @Override
   public String filterLabelAlt() {
      return "Выключить все";
   }

   @Override
   public boolean filterFlag() {
      return this.showOnlyEnabled;
   }

   @Override
   public void toggleFilter() {
      this.showOnlyEnabled = !this.showOnlyEnabled;
      this.syncRows();
   }

   @Override
   public List<ListOverlayBase.Row> rowList() {
      List<ListOverlayBase.Row> out = new ArrayList<>();

      for (int i = 0; i < this.rows.size(); i++) {
         out.add(this.rows.get(i));
      }

      return out;
   }

   @Override
   public ListOverlayBase.Row headerRowA() {
      if (this.blockList == null) {
         return null;
      } else {
         boolean enabled = false;

         for (int i = 0; i < this.blockList.entries.size(); i++) {
            if (this.blockList.entries.get(i).enabled) {
               enabled = true;
               break;
            }
         }

         return new BlockListModal.BlockRow(this.blockList.name, enabled);
      }
   }

   @Override
   public ListOverlayBase.Row headerRowB() {
      return null;
   }

   @Override
   public boolean onRowClicked(ListOverlayBase.Row row, double mx, double my, float left, float top, float width) {
      BlockListModal.BlockRow blockRow = (BlockListModal.BlockRow)row;
      boolean enabled = !blockRow.enabled;
      blockRow.enabled = enabled;
      applyEntryEnabled(this.blockList, blockRow.name, enabled);
      this.syncRows();
      return true;
   }

   private static void applyEntryEnabled(BlockListModal.BlockList list, String name, boolean enabled) {
      if (list != null) {
         for (int i = 0; i < list.entries.size(); i++) {
            BlockListModal.BlockEntry entry = list.entries.get(i);
            if (entry.name.equalsIgnoreCase(name)) {
               entry.enabled = enabled;
               list.notifyChanged();
               return;
            }
         }
      }
   }

   @Override
   public void rebuildRows() {
      this.rows.clear();
      if (this.blockList != null) {
         if (this.blockList.selection.isEmpty()) {
            for (int i = 0; i < this.blockList.entries.size(); i++) {
               BlockListModal.BlockEntry entry = this.blockList.entries.get(i);
               this.addRow(entry.name, entry.enabled);
            }
         } else {
            for (int i = 0; i < this.blockList.selection.size(); i++) {
               String name = this.blockList.selection.get(i);
               boolean enabled = false;

               for (int j = 0; j < this.blockList.entries.size(); j++) {
                  BlockListModal.BlockEntry entry = this.blockList.entries.get(j);
                  if (entry.name.equalsIgnoreCase(name)) {
                     enabled = entry.enabled;
                     break;
                  }
               }

               this.addRow(name, enabled);
            }
         }

         sortRows(this.rows);
      }
   }

   protected void addRow(String name, boolean enabled) {
      if (!this.showOnlyEnabled || enabled) {
         boolean skip = false;
         if (this.blockList != null && !this.blockList.query.isEmpty()) {
            String lower = name.toLowerCase();
            if (lower.length() < this.blockList.query.length() || !lower.contains(this.blockList.query.toLowerCase())) {
               skip = true;
            }
         }

         if (!skip) {
            this.rows.add(new BlockListModal.BlockRow(name, enabled));
         }
      }
   }

   protected static void sortRows(List<ListOverlayBase.Row> rows) {
   }

   @Override
   public void syncRows() {
      this.lastQuery = this.editField.text;
      this.rebuildRows();
   }

   public BlockListModal.BlockRow createRow(String name, boolean enabled) {
      return new BlockListModal.BlockRow(name, enabled);
   }

   public boolean colorModalHit(double mx, double my) {
      return !(0.001F < this.colorModal.alphaCurrent()) && !(0.001F < this.colorModal.alphaTarget)
         ? false
         : mx >= this.colorModal.getX() && mx <= this.colorModal.getX() + 293.0F && my >= this.colorModal.getY() && my <= this.colorModal.getY() + 383.0F;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (!this.colorModalHit(mx, my)) {
         return super.mouseClicked(mx, my, button);
      } else if (this.closed) {
         return true;
      } else {
         this.syncChildPosition();
         return this.listMouseClicked(mx, my, button);
      }
   }

   protected boolean listMouseClicked(double mx, double my, int button) {
      return super.mouseClicked(mx, my, button);
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      super.renderBody(target, rx, ry, parentAlpha);
      float weight = clamp01(parentAlpha);
      float top = (1.0F - weight) * 16.0F + this.y;
      this.editField.render(target, this.x, top, weight);
      this.blockRowListRender(target, rx, ry, parentAlpha);
      if (0.001F < this.colorModal.alphaCurrent() || 0.001F < this.colorModal.alphaTarget) {
         this.colorModal.renderOverlay(target, rx, ry, parentAlpha);
      }
   }

   protected void blockRowListRender(Object target, float rx, float ry, float parentAlpha) {
   }

   @Override
   public void onShowHook() {
      this.rebuildRows();
   }

   public boolean showsOnlyEnabled() {
      return this.showOnlyEnabled;
   }

   public BlockListModal.BlockList blockList() {
      return this.blockList;
   }

   public ColorModal colorModal() {
      return this.colorModal;
   }

   public List<ListOverlayBase.Row> rows() {
      return this.rows;
   }

   public static final class BlockEntry {
      public String name = "";
      public boolean enabled;

      public BlockEntry() {
      }

      public BlockEntry(String name, boolean enabled) {
         this.name = name == null ? "" : name;
         this.enabled = enabled;
      }
   }

   public static final class BlockList {
      public String name = "";
      public String query = "";
      public final List<BlockListModal.BlockEntry> entries = new ArrayList<>();
      public final List<String> selection = new ArrayList<>();

      public void notifyChanged() {
      }
   }

   public static class BlockRow extends ListOverlayBase.Row {
      public boolean enabled;

      public BlockRow() {
      }

      public BlockRow(String name, boolean enabled) {
         super(name);
         this.enabled = enabled;
      }
   }

   public interface ChangeHandler {
      void onChanged(String var1);
   }

   public static final class EditField {
      public String text = "";
      public String id;
      public String placeholder;
      public boolean focused;
      public BlockListModal.ChangeHandler handler;

      public EditField(String id, String placeholder) {
         this.id = id == null ? "" : id;
         this.placeholder = placeholder == null ? "" : placeholder;
      }

      public void setChangeHandler(BlockListModal.ChangeHandler handler) {
         this.handler = handler;
      }

      public void render(Object target, float x, float y, float alpha) {
      }
   }
}

