package client.gui;

public class ProfileMenu extends AbstractOverlay {
   public static final int STATUS_MENU_SIZE = 656;
   public static final float WIDTH = 284.0F;
   public static final float HEIGHT = 158.0F;
   public static final float OVERLAY_METRIC = 24.0F;
   public static final float HEADER_OFFSET = 12.0F;
   public static final float BLOCK_HEIGHT = 38.0F;
   public static final float CARD_WIDTH = 260.0F;
   public static final float CARD_HEIGHT = 88.0F;
   public static final float CARD_INSET = 16.0F;
   public static final float ICON_BOX = 16.0F;
   public static final float LABEL_GAP = 3.0F;
   public static final float SUBTITLE_STEP = 22.0F;
   public static final float CARD_RADIUS = 16.0F;
   public static final float STATUS_BUTTON_WIDTH = 244.0F;
   public static final float STATUS_BUTTON_HEIGHT = 30.0F;
   public static final float STATUS_BUTTON_INSET = 2.0F;
   public static final float STATUS_BUTTON_HEIGHT_DRAW = 26.0F;
   public static final float STATUS_BUTTON_RADIUS = 8.0F;
   public static final float STATUS_BUTTON_RADIUS_BASE = 10.0F;
   public static final float COPY_REGION_SIZE = 16.0F;
   public static final float COPY_HOVER_THRESHOLD = 0.5F;
   public static final float PRESENCE_ANIM_DURATION = 0.22F;
   public static final float HOVER_ANIM_DURATION = 0.15F;
   public static final float COPIED_ANIM_DURATION = 1.2F;
   public static final float ALPHA_SHIFT = 16.0F;
   public static final float FADE_POW = 1.7F;
   public static final float TINT_MIX = 0.85F;
   public static final float DOT_INSET = 2.0F;
   public static final float DOT_SIZE = 4.0F;
   public static final float DOT_RADIUS = 2.0F;
   public static final float DOT_DROP = 13.0F;
   public static final float DOT_GAP = 6.0F;
   public static final float LABEL_INSET = 8.0F;
   public static final float LABEL_STEP = 4.0F;
   public static final float FADE_DISTANCE = 4.0F;
   public static final float TITLE_SIZE = 14.0F;
   public static final float SUBTITLE_SIZE = 12.0F;
   public static final float HALF = 0.5F;
   public static final float EMPTY = 0.0F;
   public static final float FULL_ALPHA = 1.0F;
   public static final float NEAR_ONE = 0.999F;
   public static final float EPSILON = 0.001F;
   public static final int ICON_HEADER = 84;
   public static final int ICON_STATUS = 11;
   public static final int ICON_COPY_A = 37;
   public static final int ICON_COPY_B = 12;
   public static final int SOUND_COPY = 14;
   public static final int COLOR_ONLINE = -13919642;
   public static final int COLOR_IDLE = -17896;
   public static final int COLOR_DO_NOT_DISTURB = -2276315;
   public static final int COLOR_OFFLINE = -8158333;
   public static final String LABEL = "Установить статус";
   public static final String SUBTITLE = "Как тебя видят друзья";
   public static final String TOOLTIP_COPY = "Скопировать ник";
   public static final String TOOLTIP_COPIED = "Скопировано";
   protected static boolean INPUT_GRACE = false;
   protected ProfileBlock block;
   protected StatusMenu statusMenu;
   protected boolean statusListOpen;
   protected ProfileMenu.PresenceListener presenceListener;
   protected float copyRegionX;
   protected float copyRegionY;
   protected float copyRegionWidth;
   protected float copyRegionHeight;
   protected float statusButtonX;
   protected float statusButtonY;
   protected float statusButtonWidth;
   protected float statusButtonHeight;
   protected int presence;
   protected int presencePrevious;
   protected final AbstractOverlay.Animator copyHoverAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator statusHoverAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator copiedAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator presenceAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.ColorAnim presenceColor = new AbstractOverlay.ColorAnim();

   public ProfileMenu(ProfileBlock block) {
      this.block = block;
      this.statusMenu = new StatusMenu();
      this.copyRegionX = 0.0F;
      this.copyRegionY = 0.0F;
      this.copyRegionWidth = 0.0F;
      this.copyRegionHeight = 0.0F;
      this.statusButtonX = 0.0F;
      this.statusButtonY = 0.0F;
      this.statusButtonWidth = 0.0F;
      this.statusButtonHeight = 0.0F;
      resetAnimator(this.copyHoverAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.statusHoverAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.copiedAnim, 0.0F, 0.22F, 0);
      this.presence = 1;
      this.presencePrevious = 1;
      resetAnimator(this.presenceAnim, 1.0F, 0.22F, 0);
      resetColorAnimator(this.presenceColor, -13919642, 0.22F);
      this.width = 284.0F;
      this.height = 158.0F;
      this.presenceListener = new ProfileMenu.PresenceListener() {
         @Override
         public void onPresence(int value) {
         }
      };
   }

   @Override
   public void reset() {
      this.statusMenu.closed = false;
      this.statusMenu.animFrom = 0.0F;
      this.statusMenu.alpha = 0.0F;
      this.statusMenu.alphaTarget = 0.0F;
      this.statusMenu.alphaRunning = false;
      this.closed = false;
      this.animFrom = 0.0F;
      this.alpha = 0.0F;
      this.alphaTarget = 0.0F;
      this.alphaRunning = false;
   }

   @Override
   public float overlayConst() {
      return 24.0F;
   }

   @Override
   public void setChild(Component value) {
      int current = readPresence();
      this.presencePrevious = current;
      this.presence = current;
      this.presenceAnim.from = 1.0F;
      this.presenceAnim.current = 1.0F;
      this.presenceAnim.target = 1.0F;
      this.presenceAnim.running = false;
      int color = colorForPresence(current);
      this.presenceColor.colorFrom = color;
      this.presenceColor.colorTarget = color;
      this.presenceColor.from = 1.0F;
      this.presenceColor.current = 1.0F;
      this.presenceColor.target = 1.0F;
      this.presenceColor.running = false;
      super.setChild(value);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if ((!(this.statusMenu.alpha <= 0.001F) || !(this.statusMenu.alphaTarget <= 0.001F)) && !this.statusMenu.closed) {
         if (!this.closed) {
            if (this.statusMenu.x <= mx
               && mx <= this.statusMenu.x + this.statusMenu.width
               && this.statusMenu.y <= my
               && my <= this.statusMenu.y + this.statusMenu.height) {
               return this.statusMenu.mouseClicked(mx, my, button);
            }

            this.statusMenu.close();
            if (mx < this.statusButtonX
               || this.statusButtonX + this.statusButtonWidth < mx
               || my < this.statusButtonY
               || this.statusButtonY + this.statusButtonHeight < my) {
               return super.mouseClicked(mx, my, button);
            }
         }

         return true;
      } else {
         return super.mouseClicked(mx, my, button);
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (keyCode == 27 && (0.001F < this.statusMenu.alpha || 0.001F < this.statusMenu.alphaTarget) && !this.statusMenu.closed) {
         this.statusMenu.close();
         return true;
      } else if (this.closeOnEscape && keyCode == 27) {
         this.close();
         return true;
      } else {
         return this.onKeyPressed(keyCode, modifiers);
      }
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      int value = readPresence();
      if (value != this.presence) {
         int previous = this.presence;
         this.presence = value;
         this.presencePrevious = previous;
         this.presenceAnim.from = 0.0F;
         this.presenceAnim.current = 0.0F;
         this.presenceAnim.target = 0.0F;
         this.presenceAnim.running = false;
         animate(this.presenceAnim, 1.0F);
      }

      animateColor(this.presenceColor, colorForPresence(this.presence));
      float half = 0.5F;
      float top = (1.0F - clamp01(parentAlpha)) * 16.0F + this.y;
      Object rect = ProfileMenu.OverlayDraw.makeRect(target, parentAlpha, this.width * half + this.x, this.height * half + top);
      ProfileMenu.OverlayDraw.drawPanelTinted(rect, this.x, top, this.width, this.height, 24.0F, parentAlpha);
      float blockTop = top + 12.0F;
      this.renderHeader(target, rx, ry, blockTop, parentAlpha);
      float cardX = this.x + 12.0F;
      float cardY = blockTop + 38.0F + 8.0F;
      ProfileMenu.OverlayDraw.drawPanelTinted(rect, cardX, cardY, 260.0F, 88.0F, 16.0F, parentAlpha);
      cardX += 8.0F;
      cardY += 8.0F;
      float[] metrics = ProfileMenu.OverlayDraw.iconMetrics(84);
      ProfileMenu.OverlayDraw.drawIcon(
         rect,
         84,
         (16.0F - metrics[0]) * half + cardX,
         (16.0F - metrics[1]) * half + cardY + 2.0F,
         metrics[0],
         metrics[1],
         ProfileMenu.OverlayDraw.themeColor(24),
         parentAlpha
      );
      ProfileMenu.OverlayDraw.drawText(
         2, rect, "Установить статус", cardX + 16.0F + 4.0F, cardY + 3.0F, 14.0F, ProfileMenu.OverlayDraw.themeColor(24), parentAlpha
      );
      cardY += 22.0F;
      ProfileMenu.OverlayDraw.drawText(0, rect, "Как тебя видят друзья", cardX, cardY + 2.0F, 12.0F, ProfileMenu.OverlayDraw.themeColor(24), parentAlpha * half);
      this.statusButtonX = cardX;
      this.statusButtonY = cardY + 22.0F;
      this.statusButtonWidth = 244.0F;
      this.statusButtonHeight = 30.0F;
      this.renderStatusButton(target, rx, ry, parentAlpha);
      this.statusMenu.renderOverlay(target, rx, ry, parentAlpha);
   }

   public void renderHeader(Object target, float rx, float ry, float blockTop, float alpha) {
      renderBlock(this.block, target, blockTop, alpha);
      blockTop += 38.0F;
      float tint = advance(this.presenceColor, this.now());
      mixColor(this.presenceColor.colorFrom, this.presenceColor.colorTarget, tint);
      ProfileMenu.OverlayDraw.drawBox(target, blockTop - 2.0F - 8.0F, alpha + 38.0F - 2.0F - 8.0F, 8.0F);
      blockTop += 8.0F;
      float rightEdge = this.x + this.width - 12.0F;
      float copyTop = alpha + 1.0F;
      this.copyRegionX = rightEdge - 16.0F;
      this.copyRegionY = copyTop - 1.0F;
      this.copyRegionWidth = 16.0F;
      this.copyRegionHeight = 16.0F;
      float iconT = 1.0F;
      if (!this.closed
         && this.copyRegionX <= rx
         && rx <= this.copyRegionX + this.copyRegionWidth
         && this.copyRegionY <= ry
         && ry <= this.copyRegionY + this.copyRegionHeight
         && (activeOverlay == null || INPUT_GRACE)) {
         Screen.hoveredWidget = 1;
         String tooltip = 0.5F < this.copiedAnim.current ? "Скопировано" : "Скопировать ник";
         ProfileMenu.OverlayDraw.tooltip(tooltip, this.copyRegionX, this.copyRegionY, this.copyRegionWidth);
      } else {
         iconT = 0.0F;
      }

      if (this.copyHoverAnim.target != iconT) {
         animate(this.copyHoverAnim, iconT);
      }

      float copied = advance(this.copiedAnim, this.now());
      advance(this.copyHoverAnim, this.now());
      if (copied < 0.999F) {
         ProfileMenu.OverlayDraw.applyTheme();
         drawIconInBox(target, 37, this.copyRegionX, this.copyRegionY, 16.0F, alpha);
      }

      if (0.001F < copied) {
         ProfileMenu.OverlayDraw.applyTheme();
         drawIconInBox(target, 12, this.copyRegionX, this.copyRegionY, 16.0F, alpha);
      }

      float titleWidth = this.copyRegionX - 4.0F - blockTop;
      if (titleWidth <= 0.0F) {
         titleWidth = 0.0F;
      }

      ProfileMenu.OverlayDraw.applyTheme();
      ProfileMenu.OverlayDraw.drawText(4, target, ProfileMenu.OverlayDraw.truncate(this.block.pinnedText, titleWidth, 14.0F), blockTop);
      float statusWidth = rightEdge - blockTop;
      if (statusWidth <= 0.0F) {
         statusWidth = 0.0F;
      }

      ProfileMenu.OverlayDraw.applyTheme();
      ProfileMenu.OverlayDraw.drawText(2, target, ProfileMenu.OverlayDraw.truncate(this.block.statusText, statusWidth, 12.0F), blockTop);
   }

   public void renderStatusButton(Object target, float rx, float ry, float alpha) {
      ProfileMenu.OverlayDraw.drawStatusButton(target, this.statusButtonX, this.statusButtonY, this.statusButtonWidth, this.statusButtonHeight, 10.0F, alpha, 0);
      float hover = 1.0F;
      if (this.closed
         || rx < this.statusButtonX
         || this.statusButtonX + this.statusButtonWidth < rx
         || ry < this.statusButtonY
         || this.statusButtonY + this.statusButtonHeight < ry
         || activeOverlay != null && !INPUT_GRACE) {
         if (this.statusMenu.alpha <= 0.001F && this.statusMenu.alphaTarget <= 0.001F) {
            hover = 0.0F;
         }
      } else {
         Screen.hoveredWidget = 1;
      }

      if (this.statusHoverAnim.target != hover) {
         animate(this.statusHoverAnim, hover);
      }

      float buttonX = this.statusButtonX + 2.0F;
      float buttonY = this.statusButtonY + 2.0F;
      float buttonWidth = this.statusButtonWidth - 4.0F;
      float eased = advance(this.statusHoverAnim, this.now());
      int accent = ProfileMenu.OverlayDraw.accentColor();
      ProfileMenu.OverlayDraw.applyTheme();
      int tinted = mixColor(accent, ProfileMenu.OverlayDraw.themeColor(8), 0.85F);
      int border = mixColor(accent, tinted, eased);
      ProfileMenu.OverlayDraw.drawPanelRect(target, buttonX, buttonY, buttonWidth, 26.0F, 8.0F, border, 0, 0, 0, 24.0F, 0.5F, alpha);
      buttonY += 13.0F;
      int dotColor = mixColor(this.presenceColor.colorFrom, this.presenceColor.colorTarget, this.presenceColor.current);
      ProfileMenu.OverlayDraw.drawBox(target, buttonX + 8.0F, buttonY - 2.0F, 4.0F, 4.0F, 2.0F, 2.0F, 2.0F, 2.0F, dotColor, 0, 0, 0, 0, 0, 0, alpha, 0);
      float pulse = advance(this.presenceAnim, this.now());
      float labelY = buttonY - 6.0F;
      buttonX = buttonX + 8.0F + 4.0F + 4.0F;
      float fade = 1.0F - pulse;
      if (pulse < 0.999F) {
         ProfileMenu.OverlayDraw.applyTheme();
         ProfileMenu.OverlayDraw.drawText(
            5,
            target,
            StatusMenu.labelFor(this.presencePrevious),
            buttonX,
            labelY - pulse * 4.0F,
            12.0F,
            ProfileMenu.OverlayDraw.themeColor(24),
            powf(clamp01(fade)) * alpha
         );
      }

      ProfileMenu.OverlayDraw.applyTheme();
      ProfileMenu.OverlayDraw.drawText(
         5,
         target,
         StatusMenu.labelFor(this.presence),
         buttonX,
         fade * 4.0F + labelY,
         12.0F,
         ProfileMenu.OverlayDraw.themeColor(24),
         powf(clamp01(pulse)) * alpha
      );
      ProfileMenu.OverlayDraw.applyTheme();
      drawIconInBox(target, 11, buttonWidth + buttonY - 8.0F - 16.0F, buttonY - 8.0F, 16.0F, alpha);
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      if (button == 0) {
         if (this.copyRegionX <= mx
            && mx <= this.copyRegionX + this.copyRegionWidth
            && this.copyRegionY <= my
            && my <= this.copyRegionY + this.copyRegionHeight) {
            ProfileMenu.OverlayDraw.playSound(14);
            ProfileMenu.OverlayDraw.copyToClipboard(this.block.pinnedText);
            this.copiedAnim.from = 1.0F;
            this.copiedAnim.current = 1.0F;
            this.copiedAnim.target = 1.0F;
            this.copiedAnim.running = false;
            animateDelayed(this.copiedAnim, 0.0F, 1.2F);
            return true;
         }

         if (this.statusButtonX <= mx
            && mx <= this.statusButtonX + this.statusButtonWidth
            && this.statusButtonY <= my
            && my <= this.statusButtonY + this.statusButtonHeight) {
            ProfileMenu.OverlayDraw.playSound(14);
            if ((0.001F < this.statusMenu.alpha || 0.001F < this.statusMenu.alphaTarget) && !this.statusMenu.closed) {
               this.statusMenu.close();
               return true;
            }

            this.statusMenu.selectedStatus = this.presence;
            this.statusMenu.rebuild();

            for (StatusMenu.Row row : this.statusMenu.rows) {
               if (row.id == this.statusMenu.selectedStatus) {
                  float layoutY = row.layoutY;
                  this.statusMenu.selectYAnim.from = layoutY;
                  this.statusMenu.selectYAnim.current = layoutY;
                  this.statusMenu.selectYAnim.target = layoutY;
                  this.statusMenu.selectYAnim.running = false;
                  float rowHeight = row.height;
                  this.statusMenu.selectHeightAnim.from = rowHeight;
                  this.statusMenu.selectHeightAnim.current = rowHeight;
                  this.statusMenu.selectHeightAnim.target = rowHeight;
                  this.statusMenu.selectHeightAnim.running = false;
               }
            }

            for (StatusMenu.Row rowx : this.statusMenu.rows) {
               float value = rowx.id == this.statusMenu.selectedStatus ? 1.0F : 0.5F;
               rowx.highlight.from = value;
               rowx.highlight.current = value;
               rowx.highlight.target = value;
               rowx.highlight.running = false;
            }

            this.statusMenu.setChildAlt(new ProfileMenu.StatusListLayout(this));
         }
      }

      return true;
   }

   @Override
   public void onClosed() {
      if ((0.001F < this.statusMenu.alpha || 0.001F < this.statusMenu.alphaTarget) && !this.statusMenu.closed) {
         this.statusMenu.close();
      }
   }

   @Override
   public void dispose() {
      this.statusMenu.dispose();
      super.dispose();
   }

   public void toggleStatusList() {
      this.statusListOpen = !this.statusListOpen;
   }

   public boolean isStatusListOpen() {
      return this.statusListOpen;
   }

   public ProfileBlock block() {
      return this.block;
   }

   public StatusMenu statusMenu() {
      return this.statusMenu;
   }

   private static float powf(float value) {
      return (float)Math.pow(value, 1.7F);
   }

   private static void animateDelayed(AbstractOverlay.Animator animator, float target, float delay) {
      if (animator.target != target) {
         long time = System.nanoTime();
         float current = advance(animator, time);
         animator.from = current;
         animator.running = true;
         animator.target = target;
         animator.start = time + (long)(delay * 1.0E9);
      }
   }

   private static void animateColor(AbstractOverlay.ColorAnim animator, int color) {
      if (animator.colorTarget != color) {
         animator.colorFrom = mixColor(animator.colorFrom, animator.colorTarget, animator.current);
         animator.colorTarget = color;
         animator.from = 0.0F;
         animator.current = 0.0F;
         animator.target = 0.0F;
         animator.running = false;
         animate(animator, 1.0F);
      }
   }

   private static void drawIconInBox(Object target, int icon, float x, float y, float boxSize, float alpha) {
      float[] metrics = ProfileMenu.OverlayDraw.iconMetrics(icon);
      ProfileMenu.OverlayDraw.drawIcon(
         target,
         icon,
         (boxSize - metrics[0]) * 0.5F + x,
         (boxSize - metrics[1]) * 0.5F + y,
         metrics[0],
         metrics[1],
         ProfileMenu.OverlayDraw.themeColor(24),
         alpha
      );
   }

   private static void renderBlock(ProfileBlock block, Object target, float blockY, float alpha) {
   }

   private static int colorForPresence(int value) {
      if (value == 1) {
         return -13919642;
      } else if (value == 2) {
         return -17896;
      } else {
         return value == 3 ? -2276315 : -8158333;
      }
   }

   private static Object presenceSource() {
      return null;
   }

   private static boolean presenceBound(Object source) {
      return source != null;
   }

   private static Object presenceCallback(Object source) {
      return null;
   }

   private static int presenceValue(Object callback) {
      return 1;
   }

   private static int readPresence() {
      Object source = presenceSource();
      if (!presenceBound(source)) {
         return 1;
      } else {
         Object callback = presenceCallback(source);
         return callback == null ? 1 : presenceValue(callback);
      }
   }

   private static final class OverlayDraw {
      public static final int THEME_OFFSET_00 = 0;
      public static final int THEME_OFFSET_04 = 4;
      public static final int THEME_OFFSET_08 = 8;
      public static final int THEME_OFFSET_0C = 12;
      public static final int THEME_OFFSET_10 = 16;
      public static final int THEME_OFFSET_14 = 20;
      public static final int THEME_OFFSET_18 = 24;
      public static final float ACCENT_TINT_MAIN = 0.9F;
      public static final float ACCENT_TINT_ALT = 0.55F;
      public static final float BORDER_TINT = 0.08F;
      public static boolean THEME_GATE_A = false;
      public static boolean THEME_GATE_B = false;
      public static boolean THEME_GATE_C = false;
      public static boolean THEME_GATE_D = false;

      public static Object makeRect(Object target, float alpha, float centerX, float centerY) {
         return null;
      }

      public static void drawPanelTinted(Object target, float x, float y, float w, float h, float radius, float alpha) {
      }

      public static void drawPanelRect(
         Object target, float x, float y, float w, float h, float radius, int fill, int arg8, int arg9, int arg10, float arg11, float arg12, float alpha
      ) {
      }

      public static void drawBox(
         Object target,
         float x,
         float y,
         float w,
         float h,
         float radiusA,
         float radiusB,
         float radiusC,
         float radiusD,
         int color,
         int arg11,
         int arg12,
         int arg13,
         int arg14,
         int arg15,
         int arg16,
         float alpha,
         int flags
      ) {
      }

      public static void drawBox(Object target, float x, float y, float w) {
      }

      public static void drawStatusButton(Object target, float x, float y, float w, float h, float radius, float alpha, int selected) {
      }

      public static void drawIcon(Object target, int icon, float x, float y, float w, float h, int color, float alpha) {
      }

      public static void drawText(int align, Object target, String text, float x, float y, float size, int color, float alpha) {
      }

      public static void drawText(int align, Object target, String text, float x) {
      }

      public static float[] iconMetrics(int icon) {
         return new float[2];
      }

      public static String truncate(String text, float maxWidth, float size) {
         return text;
      }

      public static void tooltip(String text, float x, float y, float width) {
      }

      public static void copyToClipboard(String text) {
      }

      public static void playSound(int id) {
      }

      public static void applyTheme() {
      }

      public static int themeColor(int offset) {
         return 0;
      }

      public static int accentColor() {
         return THEME_GATE_A && THEME_GATE_B && THEME_GATE_C && !THEME_GATE_D ? themeTint(themeColor(8), 0.55F) : themeTint(themeColor(0), 0.9F);
      }

      public static int themeTint(int color, float factor) {
         return 0;
      }
   }

   public interface PresenceListener {
      void onPresence(int var1);
   }

   public static final class StatusListLayout extends Component {
      public static final float CHILD_GAP = 8.0F;
      protected final ProfileMenu owner;

      public StatusListLayout(ProfileMenu owner) {
         this.owner = owner;
      }

      @Override
      public float getX() {
         return this.owner.width + this.owner.x + 8.0F;
      }

      @Override
      public float getY() {
         float bottom = this.owner.height + this.owner.y - this.owner.statusMenu.height;
         float centered = this.owner.statusButtonHeight * 0.5F + this.owner.statusButtonY - this.owner.statusMenu.height * 0.5F;
         if (centered <= bottom) {
            bottom = centered;
         }

         return bottom;
      }
   }
}

