package client.gui;

import client.Setting;
import java.util.ArrayList;
import java.util.List;

public class CompactGroupWidget extends Component {
   public static final int SLOT_DESTROY = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_MOUSE_RELEASED = 40;
   public static final int SLOT_MOUSE_DRAGGED = 48;
   public static final int SLOT_MOUSE_MOVED = 64;
   public static final int SLOT_KEY_PRESSED = 72;
   public static final int SLOT_KEY_RELEASED = 80;
   public static final int SLOT_GET_HEIGHT = 96;
   public static final int SLOT_CONTENT_HEIGHT = 104;
   public static final int SLOT_TYPE_ID = 136;
   public static final int SLOT_VALUE_PAD = 144;
   public static final int SLOT_VALUE_MIN = 152;
   public static final float DEFAULT_WIDTH = 269.0F;
   public static final float ROW_SPACING = 2.0F;
   public static final float ROW_SPACING_COLLAPSED = 0.04F;
   public static final float PAD_Y = 6.0F;
   public static final float PAD_X = 8.0F;
   public static final float ROW_INSET = 3.0F;
   public static final float ROW_SIDE_INSET = 6.0F;
   public static final float ROW_RADIUS = 10.0F;
   public static final float OPTION_RADIUS = 8.0F;
   public static final float LABEL_FONT = 12.0F;
   public static final float VALUE_FONT = 14.0F;
   public static final float LABEL_LINE_HEIGHT = 14.4F;
   public static final float VALUE_LINE_HEIGHT = 16.800001F;
   public static final float VALUE_MIN_HEIGHT = 20.0F;
   public static final float EPSILON = 0.001F;
   public static final float HALF = 0.5F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final int TYPE_ID = 27;
   public static final int HOVER_KIND_ROW = 1;
   public static boolean hoverGatePointerNull = true;
   public static boolean mouseInsideWindow;
   public static int hoveredWidget;
   protected Setting group;
   protected final List<Setting> members = new ArrayList<>();
   protected final List<CompactGroupWidget.Row> rows = new ArrayList<>();
   protected float rowSpacing = 2.0F;
   protected float revealHint;
   protected CompactGroupWidget.Row capturedRow;
   protected boolean collapsed = true;
   protected float labelWidthKey = -1.0F;
   protected float labelHeight;
   protected float valueHeightKey = -1.0F;
   protected float valueHeight;
   public static final float INNER_GAP = 3.0F;

   public CompactGroupWidget() {
   }

   public CompactGroupWidget(Setting group) {
      this.initSettingWidget(group);
   }

   public void setMembers(List<Setting> values) {
      this.members.clear();
      if (values != null) {
         this.members.addAll(values);
      }
   }

   public List<Setting> getMembers() {
      return this.members;
   }

   protected void initSettingWidget(Setting group) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.animXFrom = 0.0F;
      this.animYFrom = 0.0F;
      this.animatingPosition = false;
      this.group = group;
      this.rows.clear();
      this.rowSpacing = 2.0F;
      this.revealHint = 0.0F;
      this.capturedRow = null;
      this.collapsed = true;
      this.width = 269.0F;
   }

   public Setting getGroup() {
      return this.group;
   }

   public List<CompactGroupWidget.Row> getRows() {
      return this.rows;
   }

   protected static long clock() {
      return System.nanoTime();
   }

   protected int getTypeId() {
      return 27;
   }

   protected float getValuePad() {
      return 16.0F;
   }

   protected float getValueMin() {
      return 16.0F;
   }

   protected static int wrapLineCount(int align, String text, float size, float available) {
      if (!(available <= 0.0F) && text != null) {
         float measured = AbstractTrackChoiceWidget.textWidth(text, size);

         int lines;
         for (lines = 1; measured > available; lines++) {
            measured -= available;
         }

         return lines;
      } else {
         return available <= 0.0F ? 0 : 1;
      }
   }

   protected float measureLabelHeight(float available) {
      if (available != this.labelWidthKey) {
         int lines = wrapLineCount(0, this.settingLabel(), 12.0F, available);
         float measured = lines * 14.4F;
         this.labelWidthKey = available;
         this.labelHeight = measured;
         return measured;
      } else {
         return this.labelHeight;
      }
   }

   protected float measureValueHeight(float available) {
      float local = available - 20.0F;
      if (local <= 0.0F) {
         local = 0.0F;
      }

      if (local != this.valueHeightKey) {
         int lines = wrapLineCount(2, this.settingValue(), 14.0F, local);
         float measured = lines * 16.800001F;
         this.valueHeightKey = local;
         this.valueHeight = measured;
         return measured;
      } else {
         return this.valueHeight;
      }
   }

   protected String settingLabel() {
      return this.group == null ? "" : this.group.getName();
   }

   protected String settingValue() {
      return this.group == null ? "" : this.group.getName();
   }

   protected float drawHeader(Object mat, float available, float alpha) {
      float measured = this.measureValueHeight(available);
      drawValueTextAtEdge(mat, this.x + this.width, this.y, this.settingValue(), alpha);
      return measured;
   }

   protected float drawLabel(Object mat, float yOffset, float alpha) {
      float measured = this.measureLabelHeight(this.width);
      drawLabelText(mat, this.x, yOffset + this.y, 12.0F, AbstractTrackChoiceWidget.rendererColor(), alpha);
      return measured;
   }

   protected static void drawValueTextAtEdge(Object mat, float px, float py, String text, float alpha) {
   }

   protected static void drawLabelText(Object mat, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawRowBackground(Object mat, float px, float py, float w, float h, float radius, float alpha) {
   }

   protected static void drawRowInner(Object mat, float px, float py, float w, float h, float radius, int color, float alpha) {
   }

   protected static void drawRowDivider(Object mat, float px, float py, float w, float h, int color, float alpha) {
   }

   protected static void drawRowIcon(Object mat, CompactGroupWidget.Row row, float px, float alpha) {
   }

   protected static void drawRowText(Object mat, String text, float px, float available, float size, float alpha) {
   }

   public static boolean hoverAllowed() {
      return hoverGatePointerNull || mouseInsideWindow;
   }

   public static CompactGroupWidget.Row createRow(CompactGroupWidget owner, Setting setting) {
      if (setting == null) {
         return null;
      } else {
         Setting.Type type = setting.getType();
         if (type == Setting.Type.KEYBIND) {
            return new CompactGroupWidget.HotkeyRow(owner, setting);
         } else if (type == Setting.Type.BOOLEAN) {
            return new CompactGroupWidget.SwitchRow(owner, setting);
         } else if (type == Setting.Type.NUMBER) {
            return new CompactGroupWidget.SliderRow(owner, setting);
         } else if (type == Setting.Type.COLOR) {
            return new CompactGroupWidget.ColorRow(owner, setting);
         } else if (type == Setting.Type.GRADIENT) {
            return new CompactGroupWidget.ColorRow(owner, setting);
         } else if (type == Setting.Type.MODE) {
            return new CompactGroupWidget.DropDownRow(owner, setting);
         } else {
            return type == Setting.Type.TEXT ? new CompactGroupWidget.InputRow(owner, setting) : null;
         }
      }
   }

   protected List<Setting> groupSettings() {
      List<Setting> list = new ArrayList<>();

      for (Setting child : this.members) {
         if (child != null && this.settingVisible(child)) {
            list.add(child);
         }
      }

      return list;
   }

   protected boolean settingVisible(Setting candidate) {
      return candidate == null || candidate.isVisible();
   }

   @Override
   public void syncRows() {
      List<Setting> wanted = new ArrayList<>();

      for (Setting child : this.members) {
         if (child != null && this.settingVisible(child)) {
            wanted.add(child);
         }
      }

      float spacing = this.collapsed ? 0.0F : 0.04F;
      List<CompactGroupWidget.Row> ordered = new ArrayList<>();
      int visibleIndex = 0;

      for (Setting candidate : wanted) {
         CompactGroupWidget.Row existing = null;

         for (CompactGroupWidget.Row row : this.rows) {
            if (row.setting == candidate) {
               existing = row;
               break;
            }
         }

         if (existing != null) {
            if (!existing.visible) {
               existing.visible = true;
               existing.y = 0.0F;
            }

            ordered.add(existing);
         } else {
            CompactGroupWidget.Row created = createRow(this, candidate);
            if (created != null) {
               if (spacing <= 0.0F) {
                  if (!created.visible) {
                     created.y = 0.0F;
                     created.visible = true;
                  }
               } else {
                  float target = visibleIndex * spacing;
                  if (!created.visible) {
                     if (target <= 0.0F) {
                        target = 0.0F;
                     }

                     created.y = target;
                     created.visible = true;
                  }
               }

               this.rows.add(created);
               ordered.add(created);
               visibleIndex++;
            }
         }
      }

      int hiddenIndex = 0;

      for (CompactGroupWidget.Row rowx : this.rows) {
         boolean present = false;

         for (CompactGroupWidget.Row keep : ordered) {
            if (keep == rowx) {
               present = true;
               break;
            }
         }

         if (!present && rowx.visible) {
            float target;
            if (spacing <= 0.0F) {
               target = 0.0F;
            } else {
               target = hiddenIndex * spacing;
               if (target <= 0.0F) {
                  target = 0.0F;
               }
            }

            rowx.visible = false;
            rowx.y = target;
            hiddenIndex++;
         }
      }

      List<CompactGroupWidget.Row> reordered = new ArrayList<>();
      reordered.addAll(ordered);

      for (CompactGroupWidget.Row rowx : this.rows) {
         if (!reordered.contains(rowx)) {
            reordered.add(rowx);
         }
      }

      this.rows.clear();
      this.rows.addAll(reordered);
      this.assignRows();
      if (this.collapsed) {
         for (CompactGroupWidget.Row rowxx : this.rows) {
            rowxx.reveal = 1.0F;
            rowxx.visible = true;
         }

         this.collapsed = false;
      }

      this.compactRows();

      for (CompactGroupWidget.Row rowxx : this.rows) {
         rowxx.markVisible();
      }
   }

   protected void assignRows() {
   }

   protected void compactRows() {
   }

   protected float rowHeightTotal() {
      float clampHigh = 1.0F;
      boolean first = true;
      float total = 0.0F;

      for (CompactGroupWidget.Row row : this.rows) {
         float clamped = row.reveal;
         if (clamped < 0.0F) {
            clamped = 0.0F;
         }

         if (clamped > clampHigh) {
            clamped = clampHigh;
         }

         float weight = row.heightForReveal(clamped);
         if (!first) {
            total += weight * this.rowSpacing;
         }

         first = false;
         float spacing = row.spacing();
         total += spacing * weight;
      }

      return 0.001F < total ? total + 6.0F : 0.0F;
   }

   protected float measureHeight() {
      this.syncRows();
      float label = this.measureLabelHeight(this.width);
      float value = this.measureValueHeight(this.width);
      if (label > 0.0F) {
         value = value + 0.0F + label;
      }

      float rowsHeight = this.rowHeightTotal();
      return rowsHeight + value + 6.0F;
   }

   public void measure() {
      this.measureHeight();
   }

   protected float contentHeight() {
      float label = this.measureLabelHeight(this.width);
      float value = this.measureValueHeight(this.width);
      float rowHeight = 26.0F;
      float accumulated = 0.0F;
      int count = 0;

      for (Setting child : this.members) {
         if (child != null && this.settingVisible(child)) {
            float height = rowHeight;

            for (CompactGroupWidget.Row row : this.rows) {
               if (row.setting == child) {
                  height = row.heightValue();
               }
            }

            accumulated += height;
            count++;
         }
      }

      if (label > 0.0F) {
         value = value + 0.0F + label;
      }

      value += 6.0F;
      float extra = 0.0F;
      if (count != 0) {
         extra = (float)(count - 1) + (count - 1) + accumulated + 6.0F;
      }

      return value + extra;
   }

   protected List<CompactGroupWidget.RowEntry> collectRows() {
      List<CompactGroupWidget.RowEntry> list = new ArrayList<>();
      float boundsX = this.x + 3.0F;
      float boundsWidth = this.width - 6.0F;
      int index = 0;

      for (CompactGroupWidget.Row row : this.rows) {
         float clamped = row.reveal;
         if (clamped < 0.0F) {
            clamped = 0.0F;
         }

         if (clamped > 1.0F) {
            clamped = 1.0F;
         }

         float weight = row.heightForReveal(clamped);
         if (0.001F < weight) {
            list.add(new CompactGroupWidget.RowEntry(row, boundsX, row.boundsY, boundsWidth, index));
         }

         index++;
      }

      return list;
   }

   protected void drawRow(Object mat, CompactGroupWidget.Row row, float boundsX, float boundsY, float boundsWidth, float mouseX, float mouseY, float alpha) {
      drawRowDivider(mat, boundsX, boundsY, boundsWidth, row.height, 0, alpha);
      drawRowInner(mat, boundsX, boundsY, boundsWidth, row.height, 10.0F, 0, alpha);
      row.preRender();
      drawRowIcon(mat, row, boundsX, alpha);
      float textX = boundsX + 8.0F + 16.0F + 6.0F;
      float content = row.measureContent(boundsX, alpha);
      float inset = row.contentInset();
      row.postContent();
      float available = content - textX - inset;
      drawRowText(mat, row.setting == null ? "" : row.setting.getName(), textX, available, 12.0F, alpha);
      row.render(mat, boundsX, boundsY, boundsWidth, mouseX, mouseY, alpha);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      boolean handled = false;

      for (CompactGroupWidget.RowEntry entry : this.collectRows()) {
         if (!handled) {
            boolean rowHandled = entry.row.mouseClicked(mx, my, button, entry.boundsX, entry.boundsY, entry.boundsWidth);
            if (rowHandled) {
               handled = true;
            } else {
               entry.row.reset();
            }
         } else {
            entry.row.reset();
         }
      }

      return handled;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (this.capturedRow == null) {
         boolean any = false;
         boolean previous = false;

         for (CompactGroupWidget.Row row : this.rows) {
            Object target = row.interactionTarget();
            if (target != null) {
               boolean handled = buttonRelease(target, mx, my);
               previous = any;
               if (handled) {
                  any = true;
                  previous = true;
               }
            }
         }

         return previous;
      } else {
         this.capturedRow = null;
         return true;
      }
   }

   protected static boolean buttonRelease(Object target, double mx, double my) {
      return false;
   }

   protected static boolean buttonDrag(Object target, double mx, double my) {
      return false;
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      int button = (int)delta;
      if (button != 0) {
         return false;
      } else if (this.capturedRow != null) {
         for (CompactGroupWidget.RowEntry entry : this.collectRows()) {
            if (entry.row == this.capturedRow) {
               return entry.row.drag(this.capturedRow.interactionTarget(), mx, entry.index);
            }
         }

         return false;
      } else {
         for (CompactGroupWidget.Row row : this.rows) {
            Object target = row.interactionTarget();
            if (target != null && buttonDrag(target, mx, my)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean mouseMovedRows(double mx, double my) {
      for (CompactGroupWidget.Row row : this.rows) {
         if (row.mouseMoved(mx, my)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      for (CompactGroupWidget.Row row : this.rows) {
         if (row.keyPressed(keyCode)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean keyReleased(int keyCode) {
      for (CompactGroupWidget.Row row : this.rows) {
         if (row.keyReleased(keyCode)) {
            return true;
         }
      }

      return false;
   }

   public void renderWidget(Object mat, float mouseX, float mouseY, float alpha) {
      this.syncRows();
      float valueMeasured = this.drawHeader(mat, this.width, alpha);
      float labelMeasured = this.drawLabel(mat, valueMeasured, alpha);
      if (labelMeasured > 0.0F) {
         valueMeasured = valueMeasured + 0.0F + labelMeasured;
      }

      float top = this.y + valueMeasured + 6.0F;
      boolean anyVisible = false;

      for (CompactGroupWidget.Row row : this.rows) {
         if (0.001F < row.reveal) {
            anyVisible = true;
            break;
         }
      }

      if (!anyVisible) {
         this.height = top - this.y;
      } else {
         float rowsHeight = this.rowHeightTotal();
         drawRowBackground(mat, this.x, top, this.width, rowsHeight, 10.0F, alpha);
         boolean first = true;
         float cursor = top + 3.0F;
         float boundsX = this.x + 3.0F;

         for (CompactGroupWidget.Row rowx : this.rows) {
            float clamped = rowx.reveal;
            if (clamped < 0.0F) {
               clamped = 0.0F;
            }

            if (clamped > 1.0F) {
               clamped = 1.0F;
            }

            float weight = rowx.heightForReveal(clamped);
            if (!first) {
               cursor += weight * this.rowSpacing;
            }

            first = false;
            rowx.boundsY = cursor;
            if (!rowx.homeSet) {
               rowx.homeY = cursor;
               rowx.homeSet = true;
            }

            float spacing = rowx.spacing();
            cursor += spacing * weight;
         }

         for (CompactGroupWidget.Row rowx : this.rows) {
            float clampedx = rowx.reveal;
            if (clampedx < 0.0F) {
               clampedx = 0.0F;
            }

            if (clampedx > 1.0F) {
               clampedx = 1.0F;
            }

            float weightx = rowx.heightForReveal(clampedx);
            if (0.001F < weightx) {
               this.drawRow(mat, rowx, boundsX, rowx.boundsY, this.width - 6.0F, mouseX, mouseY, weightx * alpha);
            }
         }

         this.height = top - this.y + rowsHeight;
      }
   }

   @Override
   public void render() {
   }

   public static final class ColorRow extends CompactGroupWidget.Row {
      public boolean gradient;

      public ColorRow() {
      }

      public ColorRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.gradient = setting != null && setting.getType() == Setting.Type.GRADIENT;
      }
   }

   public static final class ColorToggleRow extends CompactGroupWidget.Row {
      public boolean enabled;

      public ColorToggleRow() {
      }

      public ColorToggleRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.enabled = setting != null && setting.getBoolean();
      }
   }

   public static final class DropDownRow extends CompactGroupWidget.Row {
      public boolean expanded;
      public final List<CompactGroupWidget.DropDownRow.OptionEntry> options = new ArrayList<>();

      public DropDownRow() {
      }

      public DropDownRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.expanded = false;
         this.buildOptions(setting);
      }

      protected void buildOptions(Setting setting) {
         if (setting != null) {
            for (String mode : setting.getModes()) {
               boolean selected = mode != null && mode.equals(setting.getMode());
               this.options.add(new CompactGroupWidget.DropDownRow.OptionEntry(mode, selected ? 1 : 0));
            }
         }
      }

      public static final class OptionEntry {
         public String text;
         public int color;

         public OptionEntry(String text, int color) {
            this.text = text;
            this.color = color;
         }
      }
   }

   public static final class HotkeyRow extends CompactGroupWidget.Row {
      public boolean listening;
      public float animFrom;
      public float animTarget;
      public long animStart;
      public boolean animRunning;

      public HotkeyRow() {
      }

      public HotkeyRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.listening = false;
         this.animFrom = 0.0F;
         this.animTarget = 0.0F;
         this.animStart = 0L;
         this.animRunning = false;
      }
   }

   public static final class InputRow extends CompactGroupWidget.Row {
      public String text = "";
      public String value = "";
      public float labelHeight = 12.0F;
      public boolean multiline = true;
      public boolean secret;
      public boolean focused;
      public float focusAnim;
      public float fieldAnim = 1.0F;

      public InputRow() {
      }

      public InputRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.labelHeight = 12.0F;
         this.value = "";
         this.text = setting == null ? "" : setting.getText();
         this.multiline = true;
         this.fieldAnim = 1.0F;
      }

      public void setFocused(boolean value0) {
         if (this.focused != value0) {
            this.focused = value0;
            if (value0) {
               this.focusAnim = 1.0F;
            } else {
               this.focusAnim = 0.0F;
            }
         }
      }
   }

   public static class Row {
      public static final int SLOT_DESTROY = 0;
      public static final int SLOT_SPACING = 8;
      public static final int SLOT_HEIGHT_VALUE = 16;
      public static final int SLOT_MARK_VISIBLE = 24;
      public static final int SLOT_RENDER = 32;
      public static final int SLOT_MOUSE_CLICKED = 40;
      public static final int SLOT_MEASURE_CONTENT = 48;
      public static final int SLOT_CONTENT_INSET = 56;
      public static final int SLOT_PRE_RENDER = 64;
      public static final int SLOT_POST_CONTENT = 72;
      public static final int SLOT_INTERACTION_TARGET = 80;
      public static final int SLOT_DRAG = 88;
      public static final int SLOT_MOUSE_MOVED = 96;
      public static final int SLOT_KEY_PRESSED = 104;
      public static final int SLOT_KEY_RELEASED = 112;
      public static final int SLOT_RESET = 120;
      public static final float DEFAULT_HEIGHT = 4.5F;
      public static final float DEFAULT_REVEAL = 0.0F;
      public static final float ROW_HEIGHT = 26.0F;
      public CompactGroupWidget owner;
      public Setting setting;
      public float height = 4.5F;
      public float reveal = 0.0F;
      public boolean visible;
      public float y;
      public float homeY;
      public boolean homeSet;
      public float boundsY;
      public short flags;
      public float boundsX;
      public float boundsWidth;

      public Row() {
      }

      public Row(CompactGroupWidget owner, Setting setting) {
         this.owner = owner;
         this.setting = setting;
         this.height = 4.5F;
         this.reveal = 0.0F;
         this.visible = false;
         this.y = 0.0F;
         this.flags = 0;
         this.homeSet = false;
         this.homeY = 0.0F;
         this.boundsY = 0.0F;
      }

      public float heightForReveal(float value) {
         return 26.0F;
      }

      public float spacing() {
         return 0.0F;
      }

      public float heightValue() {
         return 26.0F;
      }

      public void markVisible() {
         if (!this.visible) {
            this.visible = true;
            this.y = 0.0F;
         }
      }

      public void render(Object mat, float boundsX0, float boundsY0, float boundsWidth0, float mouseX, float mouseY, float alpha) {
      }

      public boolean mouseClicked(double mx, double my, int button, float boundsX0, float boundsY0, float boundsWidth0) {
         return false;
      }

      public float measureContent(float boundsX0, float alpha) {
         return 0.0F;
      }

      public float contentInset() {
         return 0.0F;
      }

      public void preRender() {
      }

      public void postContent() {
      }

      public Object interactionTarget() {
         return null;
      }

      public boolean drag(Object target, double mx, int index) {
         return false;
      }

      public boolean mouseMoved(double mx, double my) {
         return false;
      }

      public boolean keyPressed(int key) {
         return false;
      }

      public boolean keyReleased(int key) {
         return false;
      }

      public void reset() {
      }
   }

   public static final class RowEntry {
      public final CompactGroupWidget.Row row;
      public final float boundsX;
      public final float boundsY;
      public final float boundsWidth;
      public final int index;

      public RowEntry(CompactGroupWidget.Row row, float boundsX, float boundsY, float boundsWidth, int index) {
         this.row = row;
         this.boundsX = boundsX;
         this.boundsY = boundsY;
         this.boundsWidth = boundsWidth;
         this.index = index;
      }
   }

   public static final class SliderRow extends CompactGroupWidget.Row {
      public float value;
      public boolean draggingValue;
      public float lastValue;
      public float dragAnim = -1.0F;

      public SliderRow() {
      }

      public SliderRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.value = 0.0F;
         this.draggingValue = false;
         this.lastValue = 0.0F;
         this.dragAnim = -1.0F;
      }
   }

   public static final class SwitchRow extends CompactGroupWidget.Row {

      public SwitchRow() {
      }

      public SwitchRow(CompactGroupWidget owner, Setting setting) {
         super(owner, setting);
         this.bindToggle(setting != null && setting.getBoolean());
      }

      protected void bindToggle(boolean value) {
      }
   }
}

