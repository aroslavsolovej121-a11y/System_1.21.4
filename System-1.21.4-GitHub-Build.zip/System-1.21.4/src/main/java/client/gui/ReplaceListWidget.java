package client.gui;

import client.Setting;

public class ReplaceListWidget extends SettingWidget {
   public static final int NAME_MEASURE_KEY_OFFSET = 104;
   public static final int NAME_MEASURE_OFFSET = 108;
   public static final int DESC_MEASURE_KEY_OFFSET = 112;
   public static final int DESC_MEASURE_OFFSET = 116;
   public static final int MEASURE_LANG_OFFSET = 120;
   public static final int LIST_SETTING_OFFSET = 128;
   public static final int ROWS_BEGIN_OFFSET = 136;
   public static final int ROWS_END_OFFSET = 144;
   public static final int ROWS_CAP_OFFSET = 152;
   public static final int CACHED_Y_OFFSET = 160;
   public static final int ROW_FIRST_OFFSET = 0;
   public static final int ROW_SECOND_OFFSET = 8;
   public static final int ROW_STEP_ANIM_OFFSET = 16;
   public static final int ROW_STEP_FROM_OFFSET = 16;
   public static final int ROW_STEP_CURRENT_OFFSET = 20;
   public static final int ROW_STEP_TARGET_OFFSET = 24;
   public static final int ROW_STEP_DURATION_OFFSET = 28;
   public static final int ROW_STEP_EASING_OFFSET = 32;
   public static final int ROW_STEP_LAST_TICK_OFFSET = 40;
   public static final int ROW_STEP_RUNNING_OFFSET = 48;
   public static final int ROW_FADE_ANIM_OFFSET = 56;
   public static final int ROW_FADE_FROM_OFFSET = 56;
   public static final int ROW_FADE_CURRENT_OFFSET = 60;
   public static final int ROW_FADE_TARGET_OFFSET = 64;
   public static final int ROW_FADE_DURATION_OFFSET = 68;
   public static final int ROW_FADE_EASING_OFFSET = 72;
   public static final int ROW_FADE_LAST_TICK_OFFSET = 80;
   public static final int ROW_FADE_RUNNING_OFFSET = 88;
   public static final int ROW_FLAG_OFFSET = 96;
   public static final int ROW_SIZE = 104;
   public static final int SETTING_NAME_OFFSET = 40;
   public static final int SETTING_DESC_OFFSET = 72;
   public static final int SETTING_ENTRIES_BEGIN_OFFSET = 232;
   public static final int SETTING_ENTRIES_END_OFFSET = 240;
   public static final int SETTING_ENTRY_SIZE = 64;
   public static final int TEXT_INPUT_TEXT_OFFSET = 96;
   public static final int TEXT_INPUT_TEXT_SIZE_OFFSET = 112;
   public static final int TEXT_INPUT_FOCUSED_OFFSET = 356;
   public static final int TEXT_INPUT_X_OFFSET = 8;
   public static final int TEXT_INPUT_Y_OFFSET = 12;
   public static final int TEXT_INPUT_WIDTH_OFFSET = 16;
   public static final int EASE_OUT_CUBIC = 0;
   public static final int ICON_ID = 26;
   public static final int ARROW_ICON = 60;
   public static final int ICON_INVALID = 89;
   public static final int TEXT_ALIGN_LEFT = 0;
   public static final int TEXT_ALIGN_CENTER = 2;
   public static final int KEY_ESCAPE = 27;
   public static final float ROW_SPACING = 40.0F;
   public static final float ROW_GAP = 6.0F;
   public static final float EDGE_PAD = 8.0F;
   public static final float EDGE_INSET = 16.0F;
   public static final float ARROW_GAP = 28.0F;
   public static final float ARROW_SIZE = 12.0F;
   public static final float ARROW_OFFSET_X = 2.0F;
   public static final float ARROW_OFFSET_Y = 10.0F;
   public static final float NAME_FONT_SIZE = 14.0F;
   public static final float DESC_FONT_SIZE = 12.0F;
   public static final float FIELD_FONT_SIZE = 14.0F;
   public static final float FIELD_TEXT_SIZE = 12.0F;
   public static final float ICON_WIDTH = 12.0F;
   public static final float ICON_HEIGHT = 12.0F;
   public static final float ICON_RESERVE = 20.0F;
   public static final float STEP_EPSILON = 0.001F;
   public static final float FADE_EPSILON = 0.001F;
   public static final float HIT_HALF = 0.5F;
   public static final float HALF = 0.5F;
   public static final float ZERO = 0.0F;
   public static final float ONE = 1.0F;
   public static final float NONE = -1.0F;
   public static final float NAME_MEASURE_SCALE = 0.015625F;
   public static final float DESC_MEASURE_SCALE = 14.4F;
   public static final String SEARCH_PLACEHOLDER = "Что искать";
   public static final String REPLACE_PLACEHOLDER = "Замена";
   public static final String EMPTY = "";
   protected Setting listSetting;
   protected ReplaceListWidget.Row[] rows = new ReplaceListWidget.Row[0];
   protected float cachedY;
   protected float nameMeasureKey = -1.0F;
   protected float nameMeasure;
   protected float descMeasureKey = -1.0F;
   protected float descMeasure;
   private static boolean languageEnglish;
   protected boolean languageCache;
   public static final float ROW_STEP_DURATION = 0.22F;

   public ReplaceListWidget(Setting setting) {
      super(setting);
      this.listSetting = setting;
      this.rows = new ReplaceListWidget.Row[0];
      this.cachedY = 0.0F;
      this.nameMeasureKey = -1.0F;
      this.nameMeasure = 0.0F;
      this.descMeasureKey = -1.0F;
      this.descMeasure = 0.0F;
      int count = settingEntryCount(setting);
      int index = count;

      while (index != 0) {
         String first = settingEntryText(setting, --index, 0);
         String second = settingEntryText(setting, index, 1);
         this.insertTop(first, second, true);
      }

      this.insertTop("", "", true);
   }

   @Override
   public void dispose() {
      disposeRows();
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      float label = this.drawLabel(mat, this.width, alpha);
      float description = this.drawDescription(mat, label, this.width, alpha);
      if (0.0F < description) {
         label = label + 0.0F + description;
      }

      this.cachedY = label + this.y + 6.0F;
      if (this.rows.length != 0 && textLength(this.rows[0].first) != 0 && textLength(this.rows[0].second) != 0) {
         this.insertTop("", "", false);
      }

      for (int index = 1; index < this.rows.length; index++) {
         ReplaceListWidget.Row row = this.rows[index];
         if (!row.flag60 && textLength(row.first) == 0 && !isFocused(row.first) && !isFocused(row.second)) {
            row.flag60 = true;
            if (row.stepAnim.target != 0.0F) {
               long time = this.now();
               row.stepAnim.from = row.stepAnim.advance(time);
               row.stepAnim.target = 0.0F;
               row.stepAnim.lastTick = time;
               row.stepAnim.animating = true;
            }
         }
      }

      float spacing = 40.0F;
      float rowY = this.cachedY;
      float halfWidth = (this.width - 16.0F - 16.0F) * 0.5F;
      float cursor = 8.0F;
      float gap = 16.0F;

      for (int i = 0; i < this.rows.length; i++) {
         ReplaceListWidget.Row row = this.rows[i];
         float step = row.stepAnim.advance(this.now());
         if (0.001F < step) {
            float target = 1.0F;
            if (textLength(row.first) == 0 && textLength(row.second) == 0) {
               target = 0.0F;
            }

            if (row.fadeAnim.target != target) {
               long time = this.now();
               row.fadeAnim.from = row.fadeAnim.advance(time);
               row.fadeAnim.target = target;
               row.fadeAnim.lastTick = time;
               row.fadeAnim.animating = true;
            }

            float fade = row.fadeAnim.advance(this.now());
            float full = this.width;
            float left = this.x;
            float firstWidth = (halfWidth - full) * fade + full;
            setTextInputBounds(row.first, left, rowY, firstWidth);
            cursor = left + firstWidth + cursor;
            float secondX = cursor + gap + 8.0F;
            float secondWidth = left + full - secondX;
            renderRow(row.first, mat, mouseX, mouseY, step * alpha);
            if (0.001F < fade) {
               float arrowAlpha = step * alpha * fade;
               rowTheme();
               drawIcon(mat, 60, cursor + 2.0F, rowY + 10.0F, 12.0F, 12.0F, rowThemeColor(), arrowAlpha);
               if (28.0F < secondWidth) {
                  setTextInputBounds(row.second, secondX, rowY, secondWidth);
                  renderRow(row.second, mat, mouseX, mouseY, arrowAlpha);
               }
            }

            rowY += step * spacing;
            gap = 16.0F;
            cursor = 8.0F;
         }
      }

      this.compactRows();
      float total = 0.0F;

      for (int ix = 0; ix < this.rows.length; ix++) {
         total += this.rows[ix].fadeAnim.current * spacing;
      }

      total -= cursor;
      if (total <= 0.0F) {
         total = 0.0F;
      }

      this.height = this.cachedY - this.y + total;
   }

   @Override
   public void layout(Object mat, float x, float y, float alpha) {
   }

   @Override
   public void update() {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         boolean handled = false;

         for (int i = 0; i < this.rows.length; i++) {
            ReplaceListWidget.Row row = this.rows[i];
            if (!row.flag60) {
               if (hitTest(row.first, mx, my) || handled) {
                  handled = true;
               }

               if (row.fadeAnim.current <= 0.5F) {
                  if (isFocused(row.second)) {
                     blurTextInput(row.second);
                  }
               } else if (hitTest(row.second, mx, my) || handled) {
                  handled = true;
               }
            }
         }

         return handled;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      return false;
   }

   @Override
   public boolean keyPressed(int key, int modifiers) {
      for (int i = 0; i < this.rows.length; i++) {
         ReplaceListWidget.Row row = this.rows[i];
         if (isFocused(row.first)) {
            if (key == 27) {
               blurTextInput(row.first);
               return true;
            }

            if (insertKey(row.first, key, modifiers)) {
               return true;
            }
         }

         if (isFocused(row.second)) {
            if (key == 27) {
               blurTextInput(row.second);
               return true;
            }

            if (insertKey(row.second, key, modifiers)) {
               return true;
            }
         }
      }

      return false;
   }

   @Override
   public boolean keyReleased(int key) {
      return false;
   }

   @Override
   public boolean charTyped(int codePoint) {
      for (int i = 0; i < this.rows.length; i++) {
         ReplaceListWidget.Row row = this.rows[i];
         if (isFocused(row.first) && insertChar(row.first, codePoint)) {
            return true;
         }

         if (isFocused(row.second) && insertChar(row.second, codePoint)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   @Override
   public float contentHeight() {
      float label = this.descriptionHeight(this.width);
      float extra = this.nameHeight(this.width);
      float total = 0.0F;

      for (int i = 0; i < this.rows.length; i++) {
         total += this.rows[i].fadeAnim.current * 40.0F;
      }

      total -= 8.0F;
      if (total <= 0.0F) {
         total = 0.0F;
      }

      if (0.0F < label) {
         extra = extra + 0.0F + label;
      }

      return extra + 6.0F + total;
   }

   @Override
   public void measure() {
      this.measureContentHeight();
   }

   @Override
   public void closeModal() {
   }

   @Override
   public boolean isOpen() {
      return false;
   }

   public int iconId() {
      return 26;
   }

   public float iconWidth() {
      return 12.0F;
   }

   public float iconHeight() {
      return 12.0F;
   }

   public void insertTop(String first, String second, boolean animate) {
      float start = 1.0F;
      if (!animate) {
         start = 0.0F;
      }

      ReplaceListWidget.Row row = new ReplaceListWidget.Row();
      row.first = createTextInput(this.width, 40.0F, "Что искать", 14.0F, 12.0F);
      row.second = createTextInput(0.0F, 40.0F, "Замена", 14.0F, 12.0F);
      row.stepAnim = ReplaceListWidget.Anim.init(start, 0.22F, 0);
      row.fadeAnim = ReplaceListWidget.Anim.init(animate ? 1.0F : 0.0F, 0.22F, 0);
      setText(row.first, first);
      resetTextCursor(row.first);
      setText(row.second, second);
      resetTextCursor(row.second);
      if (!animate && start != 1.0F) {
         long time = this.now();
         row.fadeAnim.from = row.fadeAnim.advance(time);
         row.fadeAnim.target = 1.0F;
         row.fadeAnim.lastTick = time;
         row.fadeAnim.animating = true;
      }

      setOnTextChanged(row.first, this);
      setOnTextChanged(row.second, this);
      setOnSubmit(row.first, row.second);
      setOnSubmit(row.second, row.second);
      this.insertRow(0, row);
   }

   private void measureContentHeight() {
      float label = this.descriptionHeight(this.width);
      float extra = this.nameHeight(this.width);
      float count = 0.0F;

      for (int i = 0; i < this.rows.length; i++) {
         if (!this.rows[i].flag60) {
            count++;
         }
      }

      float gap = count - 1.0F;
      if (gap <= 0.0F) {
         gap = 0.0F;
      }

      if (0.0F < label) {
         extra = extra + 0.0F + label;
      }

      this.height = extra + 6.0F + count * 40.0F + gap * 8.0F;
   }

   private void insertRow(int index, ReplaceListWidget.Row row) {
      ReplaceListWidget.Row[] next = new ReplaceListWidget.Row[this.rows.length + 1];

      for (int i = 0; i < index; i++) {
         next[i] = this.rows[i];
      }

      next[index] = row;

      for (int i = index; i < this.rows.length; i++) {
         next[i + 1] = this.rows[i];
      }

      this.rows = next;
   }

   private void compactRows() {
      int write = 0;

      for (int i = 0; i < this.rows.length; i++) {
         ReplaceListWidget.Row row = this.rows[i];
         if (i == 0 || row.flag60 || textLength(row.first) != 0 || textLength(row.second) != 0 || isFocused(row.first) || isFocused(row.second)) {
            this.rows[write] = row;
            write++;
         }
      }

      if (write != this.rows.length) {
         ReplaceListWidget.Row[] next = new ReplaceListWidget.Row[write];

         for (int ix = 0; ix < write; ix++) {
            next[ix] = this.rows[ix];
         }

         this.rows = next;
      }
   }

   private static void disposeRows() {
   }

   private float nameHeight(float width) {
      int icon = this.iconId();
      float reserve = 20.0F;
      if (icon == 89) {
         reserve = 0.0F;
      }

      width -= reserve;
      if (width <= 0.0F) {
         width = 0.0F;
      }

      if (this.langFlag() != languageEnglish) {
         this.setLangFlag(languageEnglish);
         this.descMeasureKey = -1.0F;
         this.nameMeasureKey = -1.0F;
      }

      if (width != this.nameMeasureKey) {
         this.nameMeasureKey = width;
         String name = settingText(40);
         float measured = measureWrapped(name, 14.0F, width);
         this.nameMeasure = (float)((long)measured) * 0.015625F;
      }

      return this.nameMeasure;
   }

   private float descriptionHeight(float width) {
      if (!hasText(settingText(72))) {
         return 0.0F;
      } else {
         if (this.langFlag() != languageEnglish) {
            this.setLangFlag(languageEnglish);
            this.descMeasureKey = -1.0F;
            this.nameMeasureKey = -1.0F;
         }

         if (width != this.descMeasureKey) {
            this.descMeasureKey = width;
            String description = settingText(72);
            float measured = measureWrapped(description, 12.0F, width);
            this.descMeasure = (float)((long)measured) * 14.4F;
         }

         return this.descMeasure;
      }
   }

   private float drawLabel(Object mat, float x, float alpha) {
      float extra = this.nameHeight(x);
      int icon = this.iconId();
      float reserve = 20.0F;
      if (icon == 89) {
         reserve = 0.0F;
      }

      x -= reserve;
      if (x <= 0.0F) {
         x = 0.0F;
      }

      if (icon != 89) {
         float w = this.iconWidth();
         float h = this.iconHeight();
         int color = rowThemeColor();
         drawIcon(mat, icon, (12.0F - w) * 0.5F + this.x, (14.0F - h) * 0.5F + this.y, w, h, color, alpha);
      }

      int color = rowThemeColor();
      String name = settingText(40);
      drawText(mat, 2, name, reserve + this.x, this.y, 14.0F, x, color, alpha);
      return extra;
   }

   private float drawDescription(Object mat, float y, float width, float alpha) {
      if (!hasText(settingText(72))) {
         return 0.0F;
      } else {
         float height = this.descriptionHeight(width);
         int color = rowThemeColor();
         String description = settingText(72);
         drawText(mat, 0, description, this.x, y + this.y + 0.0F, 12.0F, height, color, alpha);
         return height;
      }
   }

   private boolean langFlag() {
      return this.languageCache;
   }

   private void setLangFlag(boolean value) {
      this.languageCache = value;
   }

   private static int settingEntryCount(Setting setting) {
      return 0;
   }

   private static String settingEntryText(Setting setting, int index, int which) {
      return "";
   }

   private static String settingText(int offset) {
      return "";
   }

   private static boolean hasText(String value) {
      if (value == null) {
         return false;
      } else {
         int start = 0;
         int end = value.length();

         while (start < end && isBlank(value.charAt(start))) {
            start++;
         }

         if (start == end) {
            return false;
         } else {
            int tail = end;

            while (tail > start && isBlank(value.charAt(tail - 1))) {
               tail--;
            }

            return tail != start;
         }
      }
   }

   private static boolean isBlank(char c) {
      return c == ' ' || (c - '\t' & 250) == 0 && c != 14;
   }

   private static float measureWrapped(String text, float size, float width) {
      return 0.0F;
   }

   private static Object createTextInput(float width, float height, String placeholder, float fontSize, float textSize) {
      return null;
   }

   private static int textLength(Object textInput) {
      return 0;
   }

   private static boolean isFocused(Object textInput) {
      return false;
   }

   private static void setText(Object textInput, String value) {
   }

   private static void resetTextCursor(Object textInput) {
   }

   private static void setTextInputBounds(Object textInput, float x, float y, float width) {
   }

   private static boolean hitTest(Object textInput, double mx, double my) {
      return false;
   }

   private static boolean insertKey(Object textInput, int key, int modifiers) {
      return false;
   }

   private static boolean insertChar(Object textInput, int codePoint) {
      return false;
   }

   private static void blurTextInput(Object textInput) {
   }

   private static void setOnTextChanged(Object textInput, ReplaceListWidget widget) {
   }

   private static void setOnSubmit(Object textInput, Object next) {
   }

   private static void renderRow(Object textInput, Object mat, float mouseX, float mouseY, float alpha) {
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float w, float h, int color, float alpha) {
   }

   private static void drawText(Object mat, int align, String text, float x, float y, float size, float maxWidth, int color, float alpha) {
   }

   private static void rowTheme() {
   }

   private static int rowThemeColor() {
      return 0;
   }

   @Override
   protected long now() {
      return System.nanoTime();
   }

   public static final class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing;
      public long lastTick;
      public boolean animating;
      public static final float ROW_STEP_DURATION = 0.22F;

      public Anim() {
      }

      public Anim(float value, float seconds, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = seconds;
         this.easing = easing;
      }

      public static ReplaceListWidget.Anim init(float value, float seconds, int easing) {
         ReplaceListWidget.Anim anim = new ReplaceListWidget.Anim(value, seconds, easing);
         anim.lastTick = System.nanoTime();
         anim.animating = false;
         return anim;
      }

      public float advance(long time) {
         if (this.animating && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.lastTick) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.animating = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = ease(this.easing, k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.animating = false;
            return this.current;
         }
      }

      private static float ease(int easing, float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }
   }

   private static final class Row {
      Object first;
      Object second;
      ReplaceListWidget.Anim stepAnim;
      ReplaceListWidget.Anim fadeAnim;
      boolean flag60;
   }
}

