package client.gui;

public class ConfirmOverlay extends AbstractOverlay {
   public static final float SHOW_X = 320.0F;
   public static final float SHOW_Y_BASE = 40.0F;
   public static final float SHOW_Y_TEXT_SCALE = 14.4F;
   public static final float SHOW_Y_STEP_A = 12.0F;
   public static final float SHOW_Y_STEP_B = 16.0F;
   public static final float SHOW_Y_STEP_C = 12.0F;
   public static final float SHOW_Y_STEP_D = 32.0F;
   public static final float SHOW_Y_STEP_E = 16.0F;
   public static final float PAD = 16.0F;
   public static final float GAP = 8.0F;
   public static final float HALF = 0.5F;
   public static final float BUTTON_ROW_HEIGHT = 32.0F;
   public static final float LABEL_SIZE = 16.0F;
   public static final float DESCRIPTION_SIZE = 12.0F;
   public static final float BUTTON_TEXT_INSET = 2.0F;
   public static final float EMPTY = 0.0F;
   public static final String NOTE_LABEL = "Не показывать снова";
   public static final String CANCEL_LABEL = "Назад";
   public static final String ACCEPT_LABEL = "Окей";
   protected String title = "";
   protected String description = "";
   protected float cancelY;
   protected float cancelX;
   protected float acceptX;
   protected float buttonHalfWidth;
   protected ConfirmOverlay.ConfirmCallback callback;
   protected boolean hovered;
   protected final ConfirmOverlay.CheckBoxButton noteCheckBox = new ConfirmOverlay.CheckBoxButton(false);
   protected final AbstractOverlay.Animator cancelAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator acceptAnim = new AbstractOverlay.Animator();
   protected static boolean handCursor;

   public ConfirmOverlay() {
      resetAnimator(this.cancelAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.acceptAnim, 0.0F, 0.15F, 0);
      this.title = "";
      this.description = "";
      this.cancelY = 0.0F;
      this.cancelX = 0.0F;
      this.acceptX = 0.0F;
      this.buttonHalfWidth = 0.0F;
      this.callback = null;
      this.hovered = false;
   }

   public void show(String titleText, String descriptionText, ConfirmOverlay.ConfirmCallback handler) {
      this.title = titleText == null ? "" : titleText;
      this.description = descriptionText == null ? "" : descriptionText;
      this.callback = handler;
      resetAnimator(this.cancelAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.acceptAnim, 0.0F, 0.15F, 0);
      if (this.hovered) {
         this.hovered = false;
         animate(this.cancelAnim, 0.0F);
         animate(this.acceptAnim, 0.0F);
      }

      this.x = 320.0F;
      this.y = ConfirmOverlay.OverlayDraw.measure(this.description, 12.0F) * 14.4F + 40.0F + 12.0F + 16.0F + 12.0F + 32.0F + 16.0F;
      this.layoutForScreen();
      this.activate();
   }

   public void layoutForScreen() {
      float screenWidth = ConfirmOverlay.OverlayDraw.measure(null, 0.0F);
      float screenHeight = ConfirmOverlay.OverlayDraw.measure(null, 0.0F);
      float scale = screenScale();
      float sx = (screenWidth / scale - this.width) * 0.5F;
      if (sx <= 0.0F) {
         sx = 0.0F;
      }

      this.x = Math.round(sx);
      float sy = (screenHeight / scale - this.height) * 0.5F;
      if (sy <= 0.0F) {
         sy = 0.0F;
      }

      this.y = Math.round(sy);
   }

   protected static float screenScale() {
      return 1.0F;
   }

   @Override
   public void renderBody(Object target, float rx, float ry, float parentAlpha) {
      this.layoutForScreen();
      float alphaScale = clamp01(parentAlpha);
      float top = (1.0F - alphaScale) * 16.0F + this.y;
      float boxX = this.x + this.width * 0.5F;
      float boxY = top + this.height * 0.5F;
      ConfirmOverlay.OverlayDraw.roundRect(target, this.x, top, this.width, this.height, parentAlpha, 0.0F, 0.0F);
      ConfirmOverlay.OverlayDraw.text(target, this.x + 16.0F, top + 16.0F, this.title, 16.0F, parentAlpha);
      ConfirmOverlay.OverlayDraw.text(target, this.x + 16.0F, top + 16.0F + 16.0F + 8.0F, this.description, 12.0F, parentAlpha);
      float halfWidth = (this.width - 32.0F) * 0.5F;
      float rowTop = top + this.height - 16.0F - 32.0F;
      this.cancelX = this.x + 16.0F;
      this.buttonHalfWidth = halfWidth;
      this.cancelY = rowTop;
      this.acceptX = halfWidth + this.cancelX + 8.0F;
      this.noteCheckBox.renderBody(target, this.cancelX, this.cancelY, parentAlpha);
      ConfirmOverlay.OverlayDraw.text(target, this.cancelX + 16.0F + 8.0F, this.cancelY + 2.0F, "Не показывать снова", 12.0F, parentAlpha);
      boolean overCancel = inRect(rx, ry, this.cancelX, this.cancelY, this.buttonHalfWidth, 32.0F);
      boolean overAccept = inRect(rx, ry, this.acceptX, this.cancelY, this.buttonHalfWidth, 32.0F);
      if (overCancel || overAccept) {
         handCursor = true;
      }

      animate(this.cancelAnim, overCancel ? 1.0F : 0.0F);
      animate(this.acceptAnim, overAccept ? 1.0F : 0.0F);
      long time = this.now();
      float cancel = advance(this.cancelAnim, time);
      float accept = advance(this.acceptAnim, time);
      ConfirmOverlay.OverlayDraw.roundRect(target, this.cancelX, this.cancelY, this.buttonHalfWidth, 32.0F, parentAlpha, cancel, cancel);
      ConfirmOverlay.OverlayDraw.text(target, this.cancelX + 0.5F * this.buttonHalfWidth, this.cancelY + 16.0F, "Назад", 12.0F, parentAlpha);
      ConfirmOverlay.OverlayDraw.roundRect(target, this.acceptX, this.cancelY, this.buttonHalfWidth, 32.0F, parentAlpha, accept, accept);
      ConfirmOverlay.OverlayDraw.text(target, this.acceptX + 0.5F * this.buttonHalfWidth, this.cancelY + 16.0F, "Окей", 12.0F, parentAlpha);
      ConfirmOverlay.OverlayDraw.glyph(target, boxX, boxY, 0.0F, 0.0F, parentAlpha);
   }

   private static boolean inRect(double mx, double my, float x, float y, float width, float height) {
      return mx >= x && mx <= x + width && my >= y && my <= y + height;
   }

   @Override
   public boolean onMouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (inRect(mx, my, this.noteCheckBox.getX(), this.noteCheckBox.getY(), this.noteCheckBox.getWidth(), this.noteCheckBox.getHeight())
         && this.noteCheckBox.hitTest(mx, my)) {
         return true;
      } else if (inRect(mx, my, this.cancelX, this.cancelY, this.buttonHalfWidth, 32.0F)) {
         this.confirm();
         return true;
      } else if (inRect(mx, my, this.acceptX, this.cancelY, this.buttonHalfWidth, 32.0F)) {
         this.close();
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      if (keyCode != 13) {
         return false;
      } else {
         this.confirm();
         return true;
      }
   }

   public void confirm() {
      ConfirmOverlay.ConfirmCallback handler = this.callback;
      this.callback = null;
      boolean value = this.noteCheckBox.checked;
      this.close();
      if (handler != null) {
         handler.invoke(value);
      }
   }

   @Override
   public void onDisposed() {
      this.callback = null;
      this.title = "";
      this.description = "";
   }

   public boolean noteRequested() {
      return this.noteCheckBox.checked;
   }

   public static boolean handCursor() {
      return handCursor;
   }

   public static final class CheckBoxButton extends Component {
      public static final float DEFAULT_SIZE = 16.0F;
      public static final float ANIM_DURATION = 0.22F;
      public boolean checked;
      public boolean hovered;
      public final AbstractOverlay.Animator focusAnim = new AbstractOverlay.Animator();
      public final AbstractOverlay.Animator fillAnim = new AbstractOverlay.Animator();

      public CheckBoxButton(boolean checked) {
         this.flags = 256;
         this.x = 0.0F;
         this.y = 0.0F;
         this.width = 0.0F;
         this.height = 0.0F;
         this.animXFrom = 0.0F;
         this.animXCurrent = 0.0F;
         this.animXTarget = 0.0F;
         this.animYFrom = 0.0F;
         this.animYCurrent = 0.0F;
         this.animYTarget = 0.0F;
         this.animatingPosition = false;
         this.animFrom = 0.0F;
         this.alpha = 0.0F;
         this.alphaTarget = 0.0F;
         this.alphaDuration = 0.15F;
         this.alphaStart = this.now();
         this.alphaRunning = false;
         this.checked = checked;
         this.width = 16.0F;
         this.height = 16.0F;
         float value = checked ? 1.0F : 0.0F;
         AbstractOverlay.resetAnimator(this.focusAnim, value, 0.22F, 0);
         AbstractOverlay.resetAnimator(this.fillAnim, value, 0.22F, 0);
         this.focusAnim.running = false;
         this.fillAnim.running = false;
         this.hovered = false;
      }

      @Override
      public boolean hitTest(double mx, double my) {
         return true;
      }

      public void renderBody(Object target, float rx, float ry, float parentAlpha) {
         if (this.contains(rx, ry)) {
            this.hovered = true;
         }

         long time = this.now();
         float fill = AbstractOverlay.advance(this.fillAnim, time);
         float focus = AbstractOverlay.advance(this.focusAnim, time);
         ConfirmOverlay.OverlayDraw.roundRect(target, this.x, this.y, this.width, this.height, parentAlpha, fill, focus);
         if (0.001F < focus) {
            ConfirmOverlay.OverlayDraw.glyph(target, this.x + (this.width - 8.0F) * 0.5F, this.y + (this.height - 8.0F) * 0.5F, 8.0F, 6.0F, focus * parentAlpha);
         }
      }
   }

   public interface ConfirmCallback {
      void invoke(boolean var1);
   }

   public static final class OverlayDraw {
      public static void roundRect(Object target, float x, float y, float width, float height, float parentAlpha, float fill, float border) {
      }

      public static void glyph(Object target, float x, float y, float width, float height, float alpha) {
      }

      public static void text(Object target, float x, float y, String text, float size, float alpha) {
      }

      public static float measure(String text, float size) {
         return 0.0F;
      }
   }
}

