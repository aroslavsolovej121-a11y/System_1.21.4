package client.gui;

import java.util.function.Consumer;

public class ConfigCard extends Component {
   public static final float CARD_WIDTH = 930.0F;
   public static final float CARD_HEIGHT = 62.0F;
   public static final float CARD_HEIGHT_SELECTED = 174.0F;
   public static final float FAVOURITE_SIZE = 14.0F;
   public static final float ICON_SIZE = 20.0F;
   public static final float ADD_BUTTON_SIZE_A = 16.0F;
   public static final float ADD_BUTTON_SIZE_B = 12.0F;
   public static final float FADE_THRESHOLD = 0.5F;
   public static final float PANEL_RADIUS = 18.0F;
   public static final float HIDDEN_RECT_SIZE = 42.0F;
   public static final float INPUT_RECT_SIZE_A = 16.0F;
   public static final float INPUT_RECT_SIZE_B = 12.0F;
   public static final float ROW_HEIGHT = 42.0F;
   public static final float ROW_PADDING = 12.0F;
   public static final float BUTTON_GAP = 6.0F;
   public static final float SHRINK_SCALE = 0.5F;
   public static final int ICON_SAVE = 30;
   public static final int ICON_COPY = 31;
   public static final int ICON_DELETE = 82;
   public static final int ICON_SETTINGS = 27;
   public static final int ICON_TOGGLE = 32;
   public static final int SOUND_ENABLE = 8;
   public static final int SOUND_CANCEL = 14;
   public static final int SOUND_TOGGLE_ON = 9;
   public static final String LABEL_SAVE = "Сохранить в этот конфиг";
   public static final String LABEL_COPY = "Скопировать ключ";
   public static final String LABEL_DELETE = "Удалить конфиг";
   public static final String LABEL_SETTINGS = "Настройки конфига";
   public static int hoverState;
   protected ConfigCard.ConfigInfo info;
   protected final ConfigCard.FavouriteButton favouriteButton = new ConfigCard.FavouriteButton();
   protected final ConfigCard.SwitcherButton switcherButton = new ConfigCard.SwitcherButton(true);
   protected final ConfigCard.PlateIconButton saveButton = new ConfigCard.PlateIconButton(30, "Сохранить в этот конфиг");
   protected final ConfigCard.PlateIconButton copyButton = new ConfigCard.PlateIconButton(31, "Скопировать ключ");
   protected final ConfigCard.PlateIconButton deleteButton = new ConfigCard.PlateIconButton(82, "Удалить конфиг");
   protected final ConfigCard.PlateIconButton settingsButton = new ConfigCard.PlateIconButton(27, "Настройки конфига");
   protected final ConfigCard.IconButton iconButtonA = new ConfigCard.IconButton(30, 20.0F);
   protected final ConfigCard.IconButton iconButtonB = new ConfigCard.IconButton(31, 20.0F);
   protected final ConfigCard.IconButton iconButtonC = new ConfigCard.IconButton(32, 20.0F);
   protected final ConfigCard.IconButton iconButtonD = new ConfigCard.IconButton(27, 20.0F);
   protected final AbstractCard.Anim fadeAnimA = new AbstractCard.Anim(1.0F, 0.22F, 0);
   protected final AbstractCard.Anim fadeAnimB = new AbstractCard.Anim(1.0F, 0.22F, 0);
   protected final AbstractCard.Anim panelAnimA = new AbstractCard.Anim(0.0F, 0.22F, 0);
   protected final AbstractCard.Anim panelAnimB = new AbstractCard.Anim(0.0F, 0.22F, 0);
   protected final AbstractCard.Anim rectAnimA = new AbstractCard.Anim(0.0F, 0.0F, 0);
   protected final AbstractCard.Anim rectAnimB = new AbstractCard.Anim(0.0F, 0.0F, 0);
   protected final ConfigCard.IconInputButton addButtonA = new ConfigCard.IconInputButton(16.0F);
   protected final ConfigCard.IconInputButton addButtonB = new ConfigCard.IconInputButton(12.0F);
   protected final ConfigCard.PlateIconButton[] collapsedButtons = new ConfigCard.PlateIconButton[]{
      this.settingsButton, this.deleteButton, this.copyButton, this.saveButton
   };
   protected final ConfigCard.IconButton[] expandedButtons = new ConfigCard.IconButton[]{
      this.iconButtonD, this.iconButtonC, this.iconButtonB, this.iconButtonA
   };
   protected Consumer<ConfigCard.ConfigInfo> onClose;
   protected Consumer<ConfigCard.ConfigInfo> onCancel;
   protected final ConfigCard.Rect toggleRect = new ConfigCard.Rect(-1.0F, -1.0F, 0.0F, 0.0F);
   protected final ConfigCard.Rect okRect = new ConfigCard.Rect(-1.0F, -1.0F, 0.0F, 0.0F);
   protected final ConfigCard.Rect cancelRect = new ConfigCard.Rect(-1.0F, -1.0F, 0.0F, 0.0F);
   protected final ConfigCard.Rect inputRectA = new ConfigCard.Rect(-1.0F, -1.0F, 0.0F, 0.0F);
   protected final ConfigCard.Rect inputRectB = new ConfigCard.Rect(-1.0F, -1.0F, 0.0F, 0.0F);
   protected int state;
   protected AbstractCard.Anim animX;
   protected AbstractCard.Anim animY;
   protected boolean animatingPosition;
   protected final ConfigCard.Rect deleteRect = new ConfigCard.Rect(-1.0F, -1.0F, 42.0F, 42.0F);

   public ConfigCard(ConfigCard.ConfigInfo configInfo, boolean selected) {
      this.info = configInfo;
      this.add(this.favouriteButton);
      this.add(this.switcherButton);
      this.add(this.saveButton);
      this.add(this.copyButton);
      this.add(this.deleteButton);
      this.add(this.settingsButton);
      this.add(this.iconButtonA);
      this.add(this.iconButtonB);
      this.add(this.iconButtonC);
      this.add(this.iconButtonD);
      this.add(this.addButtonA);
      this.add(this.addButtonB);
      this.favouriteButton.favourite = selected;
      this.favouriteButton.value = selected ? 1.0F : 0.0F;
      this.favouriteButton.valueAnim.snap(selected ? 1.0F : 0.0F);
      this.favouriteButton.setSize(14.0F, 14.0F);
      this.favouriteButton.onClick = this::onToggleFavourite;
      this.switcherButton.selected = configInfo != null && configInfo.valid;
      this.switcherButton.onChange = this::onToggleSwitcher;
      this.switcherButton.setSize(14.0F, 14.0F);
      this.saveButton.onAction = this::onSaveToThisConfig;
      this.copyButton.onAction = this::onCopyKey;
      this.deleteButton.onAction = this::onDeleteConfig;
      this.settingsButton.onAction = this::onOpenConfigSettings;
      this.iconButtonA.onClick = this::onIconActionA;
      this.iconButtonB.onClick = this::onIconActionB;
      this.iconButtonC.onClick = this::onIconActionC;
      this.iconButtonD.onClick = this::onIconActionD;
      this.iconButtonB.flagD9 = true;
      this.addButtonB.flagD9 = true;
      this.refreshState(true);
      this.state = 0;
      this.width = 930.0F;
      this.height = 62.0F;
   }

   private void onToggleFavourite() {
   }

   private void onToggleSwitcher() {
   }

   private void onSaveToThisConfig(String value) {
   }

   private void onCopyKey(String value) {
   }

   private void onDeleteConfig(String value) {
   }

   private void onOpenConfigSettings(String value) {
   }

   private void onIconActionA() {
   }

   private void onIconActionB() {
   }

   private void onIconActionC() {
   }

   private void onIconActionD() {
   }

   public Component addIconButton(float size, Consumer<String> onClick) {
      ConfigCard.IconInputButton button = new ConfigCard.IconInputButton(size);
      button.onAction = onClick;
      this.add(button);
      return button;
   }

   public void refreshState(boolean instant) {
      boolean canSave = this.info != null && !this.info.broken && !this.info.group;
      boolean canSettings = this.info != null && !this.info.broken;
      this.copyButton.enabled = canSave;
      this.settingsButton.enabled = canSettings;
      if (instant) {
         this.copyButton.enabledAnim.snap(canSave ? 1.0F : 0.0F);
         this.settingsButton.enabledAnim.snap(canSettings ? 1.0F : 0.0F);
         this.fadeAnimA.snap(canSave ? 1.0F : 0.0F);
         this.fadeAnimB.snap(canSettings ? 1.0F : 0.0F);
      } else {
         this.copyButton.enabledAnim.setTarget(canSave ? 1.0F : 0.0F);
         this.settingsButton.enabledAnim.setTarget(canSettings ? 1.0F : 0.0F);
         this.fadeAnimA.setTarget(canSave ? 1.0F : 0.0F);
         this.fadeAnimB.setTarget(canSettings ? 1.0F : 0.0F);
      }
   }

   public void setState(int newState, float newWidth) {
      this.width = newWidth;
      this.state = newState;
      this.height = newState == 1 ? 174.0F : 62.0F;
   }

   public void applyPositionAnimation(long time) {
      if (this.animatingPosition && this.animX != null && this.animY != null) {
         this.x = this.animX.update(time);
         this.y = this.animY.update(time);
      }
   }

   public void setPositionAnimated(float px, float py) {
      if (this.animX == null) {
         this.animX = new AbstractCard.Anim(px, 0.0F, 1);
         this.animY = new AbstractCard.Anim(py, 0.0F, 1);
      }

      if (!this.animatingPosition) {
         this.animX.snap(px);
         this.animY.snap(py);
         this.x = px;
         this.y = py;
         this.animatingPosition = true;
      } else {
         this.animX.setTarget(px);
         this.animY.setTarget(py);
      }
   }

   @Override
   public void setPosition(float px, float py) {
      this.setPositionAnimated(px, py);
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.state != 0) {
         return false;
      } else if (!this.switcherButton.mouseReleased(mx, my, button)) {
         return false;
      } else {
         if (this.switcherButton.selected && this.info != null && !this.info.valid) {
            playClickSound(8);
            if (this.onClose != null) {
               this.onClose.accept(this.info);
            }
         }

         return true;
      }
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      return this.state != 0 ? false : this.switcherButton.mouseDragged(mx, my, button);
   }

   @Override
   public void render(Object renderer, float mouseX, float mouseY, float alpha) {
      this.applyPositionAnimation(this.now());
      float targetA = this.info != null && this.info.valid ? 1.0F : 0.0F;
      if (this.panelAnimA.target != targetA) {
         this.panelAnimA.from = this.panelAnimA.update(this.now());
         this.panelAnimA.target = targetA;
         this.panelAnimA.start = this.now();
         this.panelAnimA.running = true;
      }

      float targetB = this.info != null && this.info.group ? 1.0F : 0.0F;
      if (this.panelAnimB.target != targetB) {
         this.panelAnimB.from = this.panelAnimB.update(this.now());
         this.panelAnimB.target = targetB;
         this.panelAnimB.start = this.now();
         this.panelAnimB.running = true;
      }

      this.panelAnimA.update(this.now());
      this.panelAnimB.update(this.now());
      drawPanel(renderer, this.x, this.y, this.width, this.height, 18.0F, alpha);
      if (mouseX >= this.x && mouseX <= this.x + this.width && mouseY >= this.y && mouseY <= this.y + this.height) {
         this.hoverTest(mouseX, mouseY);
      }

      if (this.state == 1) {
         this.renderExpanded(renderer, mouseX, mouseY, alpha);
      } else {
         this.renderCollapsed(renderer, mouseX, mouseY, alpha);
      }
   }

   public void renderCollapsed(Object renderer, float mouseX, float mouseY, float alpha) {
      float rowY = (this.height - 42.0F) * 0.5F + this.y;
      boolean canSave = this.info != null && !this.info.broken && !this.info.group;
      boolean canSettings = this.info != null && !this.info.broken;
      this.copyButton.enabled = canSave;
      this.settingsButton.enabled = canSettings;
      drawNameText(renderer, this.x + 12.0F, rowY, 29, -1, alpha);
      drawPlateButton(renderer, this.x + 12.0F, rowY, this.x + this.width - 12.0F, 42.0F, alpha);
      this.setPanelRects(rowY);
      drawSmallButton(renderer, this.x + 15.0F, rowY + 21.0F, 14.0F, 42.0F, alpha);
      float cursor = rowY;

      for (int i = 0; i < this.collapsedButtons.length; i++) {
         ConfigCard.PlateIconButton current = this.collapsedButtons[i];
         float value = current.enabledAnim.update(this.now()) * 0.5F;
         current.setPosition(this.x + this.width - cursor - value, rowY);
         current.setSize(value, value);
         if (0.001F < value) {
            cursor += value + 4.0F;
         }
      }

      for (int ix = 0; ix < this.collapsedButtons.length; ix++) {
         drawIconButton(renderer, this.collapsedButtons[ix], mouseX, mouseY, alpha);
      }

      drawToggle(renderer, alpha);
   }

   public void renderExpanded(Object renderer, float mouseX, float mouseY, float alpha) {
      float rowY = (this.height - 42.0F) * 0.5F + this.y;
      float value = this.panelAnimA.update(this.now());
      drawNameText(renderer, this.x + 12.0F, rowY, 34, -1, alpha);
      float statusY = this.y + this.height - 12.0F;
      if (this.info != null && this.info.broken) {
         drawTextAt(renderer, 29, this.x + this.width - 12.0F - value, statusY, -1, alpha);
      } else {
         drawTextAt(renderer, 29, this.x + this.width - 12.0F, statusY - 2.0F, -1, alpha);
      }

      float headerHeight = (this.height - 42.0F) * 0.5F;

      for (int i = 0; i < this.expandedButtons.length; i++) {
         ConfigCard.IconButton current = this.expandedButtons[i];
         if ((current != this.iconButtonB || !(0.5F <= this.fadeAnimA.current)) && (current != this.iconButtonD || !(0.5F <= this.fadeAnimB.current))) {
            current.setPosition(this.x + this.width - 12.0F, this.y + 20.0F + i * 0.0F);
            drawIconButton(renderer, current, mouseX, mouseY, alpha);
         }
      }

      this.panelAnimB.update(this.now());
      float panelY = this.y + 42.0F + headerHeight;
      drawProgressBar(renderer, this.x + 12.0F, panelY, this.width - 12.0F - 12.0F, 12.0F);
      drawTextAt(renderer, 29, this.x + 12.0F, panelY + 6.0F, -1, alpha);
      float inputX = this.x + this.width - 12.0F - 16.0F - 16.0F;
      drawInputField(renderer, this.x, panelY, inputX, alpha);
      this.okRect.set(inputX + 12.0F, panelY + 1.0F, 16.0F, 16.0F);
      this.cancelRect.set(inputX + 36.0F, panelY + 5.0F, 12.0F, 12.0F);
      this.inputRectA.set(this.x + 15.0F, panelY + 12.0F, 16.0F, 16.0F);
      this.inputRectB.set(this.x + 15.0F, panelY + 12.0F, 12.0F, 12.0F);
      drawGlow(renderer, this.x + 12.0F, panelY + 24.0F, this.width - 12.0F, 0.4F);
      float footerY = this.y + this.height - 24.0F;
      drawRect(renderer, this.x + 15.0F, footerY, this.x + this.width - 30.0F, 24.0F);
      drawTextAt(renderer, 29, this.x + 15.0F + 12.0F, footerY + 6.0F, -1, alpha);
      drawFavourite(renderer, this.x + 15.0F, footerY + 6.0F, 24.0F, 12.0F, alpha);
      float slotY = this.y + this.height - 42.0F;
      this.addButtonA.setPosition(this.x + 15.0F, slotY);
      this.addButtonB.setPosition(this.x + this.width - 12.0F - 12.0F, slotY);
      drawInputButton(renderer, this.addButtonA, alpha);
      drawInputButton(renderer, this.addButtonB, alpha);
   }

   public void hoverTest(float mouseX, float mouseY) {
      if (this.info == null || !this.info.broken && this.info.valid || !this.info.broken) {
         boolean insideSwitcher = mouseX >= this.favouriteButton.getX()
            && mouseX <= this.favouriteButton.getX() + this.favouriteButton.getWidth()
            && mouseY >= this.favouriteButton.getY()
            && mouseY <= this.favouriteButton.getY() + this.favouriteButton.getHeight();
         if (insideSwitcher) {
            hoverState = 1;
         } else {
            if (this.state == 1) {
               if (mouseX >= this.okRect.x && mouseX <= this.okRect.x + this.okRect.w && mouseY >= this.okRect.y && mouseY <= this.okRect.y + this.okRect.h) {
                  hoverState = 2;
                  return;
               }
            } else if (mouseY >= this.toggleRect.y
               && mouseY <= this.toggleRect.y + this.toggleRect.h
               && mouseX >= this.x + this.width - 12.0F
               && mouseX <= this.x + this.width - 12.0F + 42.0F) {
               hoverState = 2;
               return;
            }

            hoverState = 2;
         }
      }
   }

   protected void setPanelRects(float rowY) {
      this.toggleRect.set(this.x + this.width - 12.0F, rowY, 42.0F, 42.0F);
      this.inputRectA.set(this.x + 12.0F, rowY, 0.0F, 0.0F);
      this.inputRectB.set(this.x + this.width - 12.0F - 12.0F, rowY, 12.0F, 42.0F);
   }

   public boolean onMouse(double mx, double my, int button) {
      if (this.state == 1) {
         if (button == 0 && hit(this.favouriteButton, mx, my) && this.favouriteButton.mousePressed(mx, my, button)) {
            return true;
         }

         for (int i = 0; i < this.expandedButtons.length; i++) {
            ConfigCard.IconButton current = this.expandedButtons[i];
            if ((current != this.iconButtonB || !(0.5F <= this.fadeAnimA.current))
               && (current != this.iconButtonD || !(0.5F <= this.fadeAnimB.current))
               && button == 0
               && hit(current, mx, my)
               && current.mousePressed(mx, my, button)) {
               AbstractCard.blurFocusedChildren(this);
               return true;
            }
         }

         if (button != 0) {
            return false;
         }
      } else {
         for (int ix = 0; ix < this.collapsedButtons.length; ix++) {
            ConfigCard.PlateIconButton current = this.collapsedButtons[ix];
            if (current.enabled && !(0.5F > current.enabledAnim.current) && button == 0 && hit(current, mx, my) && current.mousePressed(mx, my, button)) {
               AbstractCard.blurFocusedChildren(this);
               return true;
            }
         }

         if (button != 0) {
            return false;
         }

         if (hit(this.switcherButton, mx, my) && this.switcherButton.mousePressed(mx, my, button)) {
            AbstractCard.blurFocusedChildren(this);
            return true;
         }
      }

      if ((
            !(0.0F <= this.deleteRectX())
               || !(mx >= this.deleteRectX())
               || !(mx <= this.deleteRectX() + 42.0F)
               || !(my >= this.deleteRectY())
               || !(my <= this.deleteRectY() + 42.0F)
         )
         && (
            this.state != 1
               || !(mx >= this.okInputRectX())
               || !(mx <= this.okInputRectX() + 16.0F)
               || !(my >= this.okInputRectY())
               || !(my <= this.okInputRectY() + 16.0F)
         )) {
         if (0.0F < this.cancelRect.w && hit(this.cancelRect, mx, my)) {
            AbstractCard.blurFocusedChildren(this);
            playClickSound(14);
            if (this.onCancel == null) {
               return true;
            } else {
               this.onCancel.accept(this.info);
               return true;
            }
         } else if (this.info != null && this.info.broken) {
            return false;
         } else if (hit(this.toggleRect, mx, my)) {
            AbstractCard.focusChildWithText(this, this.addButtonB, this.info == null ? "" : this.info.key);
            return true;
         } else if (this.info != null && this.info.broken) {
            return false;
         } else if (mx < this.inputRectA.x || mx > this.inputRectA.x + this.inputRectA.w) {
            return false;
         } else if (!(my < this.inputRectA.y) && !(my > this.inputRectA.y + this.inputRectA.h)) {
            AbstractCard.focusChildWithText(this, this.addButtonA, this.info == null ? "" : this.info.name);
            return true;
         } else {
            return false;
         }
      } else {
         AbstractCard.blurFocusedChildren(this);
         if (this.info != null && !this.info.valid) {
            playClickSound(8);
            if (this.onClose != null) {
               this.onClose.accept(this.info);
               return true;
            }
         }

         return true;
      }
   }

   protected float deleteRectX() {
      return this.deleteRect.x;
   }

   protected float deleteRectY() {
      return this.deleteRect.y;
   }

   protected float okInputRectX() {
      return this.inputRectA.x;
   }

   protected float okInputRectY() {
      return this.inputRectA.y;
   }

   private static boolean hit(Component component, double mx, double my) {
      return component.contains(mx, my);
   }

   private static boolean hit(ConfigCard.Rect rect, double mx, double my) {
      return mx >= rect.x && mx <= rect.x + rect.w && my >= rect.y && my <= rect.y + rect.h;
   }

   public static void playClickSound(int sound) {
      uiSound(sound);
   }

   public static void drawPanel(Object renderer, float x, float y, float width, float height, float radius, float alpha) {
   }

   public static void drawNameText(Object renderer, float x, float y, int id, int color, float alpha) {
   }

   public static void drawPlateButton(Object renderer, float x, float y, float right, float height, float alpha) {
   }

   public static void drawIconButton(Object renderer, Component button, float mouseX, float mouseY, float alpha) {
   }

   public static void drawSmallButton(Object renderer, float x, float y, float width, float height, float alpha) {
   }

   public static void drawToggle(Object renderer, float alpha) {
   }

   public static void drawTextAt(Object renderer, int id, float x, float y, int color, float alpha) {
   }

   public static void drawRect(Object renderer, float x, float y, float right, float height) {
   }

   public static void drawInputField(Object renderer, float x, float y, float right, float alpha) {
   }

   public static void drawInputButton(Object renderer, Component button, float alpha) {
   }

   public static void drawProgressBar(Object renderer, float x, float y, float width, float height) {
   }

   public static void drawGlow(Object renderer, float x, float y, float width, float value) {
   }

   public static void drawFavourite(Object renderer, float x, float y, float width, float height, float alpha) {
   }

   public static void drawNinePatch(Object renderer, float x, float y, float width, float height, int color, float alpha) {
   }

   public static void drawSwitcherButton(Object renderer, Component button, float mouseX, float mouseY, float alpha) {
   }

   public static final class ConfigInfo {
      public String name = "";
      public String key = "";
      public boolean valid;
      public boolean group;
      public boolean broken;
   }

   public static class FavouriteButton extends Component {
      public static final float DEFAULT_SIZE = 12.0F;
      public boolean favourite;
      public float value;
      public final AbstractCard.Anim valueAnim = new AbstractCard.Anim(0.0F, 0.15F, 0);
      public Runnable onClick;

      public FavouriteButton() {
         this.setSize(12.0F, 12.0F);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }
   }

   public static class IconButton extends Component {
      public static final int DEFAULT_VARIANT = 89;
      public int icon;
      public int variant = 89;
      public int flags;
      public float iconSize;
      public String label = "";
      public boolean flagD9;
      public final AbstractCard.Anim anim = new AbstractCard.Anim(0.0F, 0.15F, 0);
      public Runnable onClick;

      public IconButton(int icon, float iconSize) {
         this.icon = icon;
         this.iconSize = iconSize;
         this.setSize(iconSize, iconSize);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }
   }

   public static class IconInputButton extends Component implements AbstractCard.InputChild {
      public int icon;
      public int variant = 89;
      public float iconSize;
      public boolean flagD9;
      public String text = "";
      public Consumer<String> onAction;
      public Consumer<String> onCommit;
      public final AbstractCard.Anim anim = new AbstractCard.Anim(0.0F, 0.15F, 0);

      public IconInputButton(float size) {
         this.iconSize = size;
         this.setSize(size, size);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }

      @Override
      public String getText() {
         return this.text;
      }

      @Override
      public void setText(String value) {
         this.text = value == null ? "" : value;
      }

      @Override
      public boolean isShiftCommit() {
         return this.flagD9;
      }

      @Override
      public void commit() {
         if (this.onAction != null) {
            this.onAction.accept(this.text);
         }

         this.focused = false;
      }

      @Override
      public void cancel() {
         this.focused = false;
      }

      @Override
      public void blur(String value) {
         if (this.onCommit != null) {
            this.onCommit.accept(value);
         }
      }
   }

   public static class PlateIconButton extends Component {
      public static final float DEFAULT_SIZE = 42.0F;
      public int icon;
      public int variant;
      public boolean enabled = true;
      public final AbstractCard.Anim enabledAnim = new AbstractCard.Anim(1.0F, 0.22F, 0);
      public final AbstractCard.Anim hoverAnim = new AbstractCard.Anim(0.0F, 0.15F, 0);
      public String label;
      public Consumer<String> onAction;

      public PlateIconButton(int icon, String label) {
         this.icon = icon;
         this.label = label;
         this.setSize(42.0F, 42.0F);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }
   }

   public static final class Rect {
      public float x;
      public float y;
      public float w;
      public float h;

      public Rect(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }

      public void set(float x, float y, float w, float h) {
         this.x = x;
         this.y = y;
         this.w = w;
         this.h = h;
      }
   }

   public static class SwitcherButton extends Component {
      public static final float DEFAULT_WIDTH = 15.0F;
      public static final float DEFAULT_HEIGHT = 16.0F;
      public static final double DRAG_TIMEOUT = 1.5;
      public boolean selected;
      public boolean flag61;
      public boolean pressed;
      public boolean dragged;
      public boolean flagB6;
      public double pressTime;
      public float valueFrom;
      public float valueCurrent;
      public float valueTarget;
      public Runnable onChange;
      public final AbstractCard.Anim anim = new AbstractCard.Anim(0.0F, 0.15F, 0);

      public SwitcherButton(boolean value) {
         this.selected = value;
         float initial = value ? 1.0F : 0.0F;
         this.valueFrom = initial;
         this.valueCurrent = initial;
         this.valueTarget = initial;
         this.setSize(15.0F, 16.0F);
      }

      public boolean mousePressed(double mx, double my, int button) {
         return button == 0 && this.contains(mx, my);
      }

      @Override
      public boolean mouseDragged(double mx, double my, int button) {
         if (this.pressed && button == 0) {
            if (!this.dragged) {
               if (this.now() / 1.0E9 - this.pressTime < 1.5) {
                  return true;
               }

               this.dragged = true;
            }

            float t = (float)((mx - (this.x + 2.0F + 6.0F)) / (this.width - 12.0F - 4.0F));
            if (t < 0.0F) {
               t = 0.0F;
            }

            if (t > 1.0F) {
               t = 1.0F;
            }

            this.valueFrom = t;
            return true;
         } else {
            return false;
         }
      }

      @Override
      public boolean mouseReleased(double mx, double my, int button) {
         if (this.pressed && button == 0) {
            this.pressed = false;
            this.dragged = false;
            boolean next = this.dragged ? 0.5F <= this.valueFrom : !this.flagB6;
            if (this.selected != next) {
               this.selected = next;
               ConfigCard.playClickSound(next ? 9 : 8);
               if (this.onChange != null) {
                  this.onChange.run();
               }
            }

            if (next) {
               this.valueFrom = 1.0F;
               return true;
            } else {
               this.valueFrom = 0.0F;
               return true;
            }
         } else {
            return false;
         }
      }
   }
}

