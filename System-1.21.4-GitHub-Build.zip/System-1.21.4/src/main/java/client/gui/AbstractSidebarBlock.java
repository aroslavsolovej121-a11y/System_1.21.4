package client.gui;

public class AbstractSidebarBlock extends Component {
   public static final int SLOT_DTOR = 0;
   public static final int SLOT_RENDER = 1;
   public static final int SLOT_MOUSE_CLICKED = 4;
   public static final int SLOT_MOUSE_RELEASED = 5;
   public static final int SLOT_MOUSE_MOVED = 6;
   public static final int SLOT_MOUSE_SCROLLED = 7;
   public static final int SLOT_KEY_PRESSED = 8;
   public static final int SLOT_KEY_RELEASED = 9;
   public static final int SLOT_CHAR_TYPED = 10;
   public static final int SLOT_SET_POSITION = 11;
   public static final int FLAGS_INIT = 256;
   public static final float VISIBLE_EPSILON = 0.001F;
   public static final float FADE_NONE = 0.0F;
   public static final float FULL_ALPHA = 1.0F;
   public static final float LABEL_CLIP_WIDTH_MIN = 0.0F;
   public static final float DEFAULT_BLOCK_WIDTH = 208.0F;
   public static final float DEFAULT_BLOCK_HEIGHT = 32.0F;
   public String label;
   public float fade;

   public AbstractSidebarBlock() {
      this("", 208.0F, 32.0F);
   }

   public AbstractSidebarBlock(String label) {
      this(label, 208.0F, 32.0F);
   }

   public AbstractSidebarBlock(String label, float width, float height) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = width;
      this.height = height;
      this.label = label == null ? "" : label;
      this.fade = 0.0F;
   }

   public String getLabel() {
      return this.label;
   }

   public void setLabel(String value) {
      this.label = value == null ? "" : value;
   }

   public float getFade() {
      return this.fade;
   }

   public void setFade(float value) {
      this.fade = value;
   }

   public float visibleAlpha(float alpha) {
      return (1.0F - this.fade) * alpha;
   }

   protected void drawLabel(Object renderer, float lx, float ly, float lw, float size, int color, float alpha) {
      if (!(lw <= 0.0F) && !(alpha <= 0.001F)) {
         pushScissor(lx, this.y, lw, this.height);
         labelDrawText(renderer, lx, ly, this.label, size, color, alpha);
         popScissor();
      }
   }

   protected static float drawCounters(Object renderer, float cx, String first, String second, int firstColor, int secondColor, float alpha, boolean trailing) {
      return 0.0F;
   }

   protected static void labelDrawText(Object renderer, float tx, float ty, String text, float size, int color, float alpha) {
   }

   protected static void pushScissor(float cx, float cy, float cw, float ch) {
   }

   protected static void popScissor() {
   }

   @Override
   public void dispose() {
      super.dispose();
      this.label = "";
      this.fade = 0.0F;
   }
}

