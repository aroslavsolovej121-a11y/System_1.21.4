package client.gui;

public class ConfigDetailsCard extends Component {
   public static final float CARD_WIDTH = 300.0F;
   public static final float HALF = 0.5F;
   public static final float ONE = 1.0F;
   public static final float PAD = 12.0F;
   public static final float GAP = 4.0F;
   public static final float GAP6 = 6.0F;
   public static final float HEADER_BLOCK = 32.0F;
   public static final float LIST_WIDTH = 252.0F;
   public static final float HEIGHT_288 = 288.0F;
   public static final float SCROLL_STEP = 24.0F;
   public static final float SCROLLBAR_WIDTH = 40.0F;
   public static final int CLOSE_KEY = 27;
   public static final int WIDGET_CLICK_SLOT = 12;
   private ConfigDetailsCard.ConfigInfo config;
   private float openAnim = -1.0F;
   private float openFrom;
   private long openTime;
   private boolean openRunning;
   private boolean overlayClosed;
   private boolean closeOnOutside = true;
   private boolean closeOnEscape = true;
   private Component host;
   private ConfigDetailsCard.HeaderWidget headerA;
   private ConfigDetailsCard.HeaderWidget headerB;
   private ConfigDetailsCard.HeaderWidget headerC;
   private boolean hasKeysMark;
   private boolean hasExtraMark;
   private boolean keysOpen;
   private boolean keysDragging;
   private float keysDragOffset;
   private float sliderAnimA;
   private float sliderTargetA;
   private boolean sliderRunningA;
   private float sliderAnimB;
   private float sliderTargetB;
   private boolean sliderRunningB;
   private float rowAnim;
   private float anchorX;
   private float anchorY;
   private float anchorW;
   private float anchorH;
   private final KeysPanel keysPanel;
   private final float[] rowAnimator = new float[9];
   private Runnable shareCallback;
   private int cursorShape;

   public ConfigDetailsCard() {
      this(null);
   }

   public ConfigDetailsCard(ConfigDetailsCard.ConfigInfo info) {
      this.config = info;
      this.width = 300.0F;
      this.flags = 256;
      this.headerA = new ConfigDetailsCard.HeaderWidget(info != null && info.hasKeys);
      this.headerB = new ConfigDetailsCard.HeaderWidget(info != null && info.hasExtra);
      this.headerC = new ConfigDetailsCard.HeaderWidget(false);
      this.hasKeysMark = info != null && info.hasKeys;
      this.hasExtraMark = info != null && info.hasExtra;
      this.keysPanel = new KeysPanel(info == null ? "" : info.name);
      this.openAnim = -1.0F;
      this.openFrom = -1.0F;
      this.openRunning = false;
      this.overlayClosed = false;
      this.closeOnOutside = true;
      this.closeOnEscape = true;
      this.sliderAnimA = info != null && info.hasKeys ? 1.0F : 0.5F;
      this.sliderTargetA = this.sliderAnimA;
      this.sliderRunningA = false;
      this.sliderAnimB = info != null && info.hasExtra ? 1.0F : 0.5F;
      this.sliderTargetB = this.sliderAnimB;
      this.sliderRunningB = false;
      this.rowAnim = 0.0F;
      this.keysOpen = false;
      this.keysDragging = false;
      this.keysDragOffset = 0.0F;
      this.anchorX = 0.0F;
      this.anchorY = 0.0F;
      this.anchorW = 0.0F;
      this.anchorH = 0.0F;
      this.headerA.setOnClick(this::onHeaderA);
      this.headerB.setOnClick(this::onHeaderB);
      this.headerC.setOnClick(this::onHeaderC);
   }

   private void onHeaderA() {
   }

   private void onHeaderB() {
   }

   private void onHeaderC() {
   }

   public ConfigDetailsCard.ConfigInfo config() {
      return this.config;
   }

   public KeysPanel keysPanel() {
      return this.keysPanel;
   }

   public ConfigDetailsCard.HeaderWidget headerA() {
      return this.headerA;
   }

   public ConfigDetailsCard.HeaderWidget headerB() {
      return this.headerB;
   }

   public ConfigDetailsCard.HeaderWidget headerC() {
      return this.headerC;
   }

   public boolean isKeysOpen() {
      return this.keysOpen;
   }

   public boolean isKeysDragging() {
      return this.keysDragging;
   }

   public int cursor() {
      return this.cursorShape;
   }

   @Override
   public boolean isActive() {
      return true;
   }

   @Override
   public void tick() {
      this.updateOpenAnim(this.now());
   }

   @Override
   public void render() {
      this.renderDetails(null, 0.0F, 0.0F, 0.0F, 0.0F);
   }

   private void renderDetails(Object matrix, float a, float b, float c, float scale) {
      float targetA = 0.5F;
      if (this.config != null && this.config.hasKeys) {
         targetA = 1.0F;
      }

      if (this.sliderTargetA != targetA) {
         this.sliderAnimA = this.sliderAnimA;
         this.sliderTargetA = targetA;
         this.sliderRunningA = true;
      }

      float targetB = 0.5F;
      if (this.config != null && this.config.hasExtra) {
         targetB = 1.0F;
      }

      if (this.sliderTargetB != targetB) {
         this.sliderAnimB = this.sliderAnimB;
         this.sliderTargetB = targetB;
         this.sliderRunningB = true;
      }

      if (this.rowAnimator[2] != this.rowAnim) {
         this.rowAnimator[0] = this.rowAnimatorValue();
         this.rowAnimator[2] = this.rowAnim;
         this.rowAnimator[6] = (float)this.now();
         this.rowAnimator[8] = 1.0F;
      }

      this.renderBody(matrix, a, b, c, scale);
   }

   private float rowAnimatorValue() {
      return this.rowAnimator[2];
   }

   private void renderBody(Object matrix, float a, float b, float c, float scale) {
   }

   private void updateOpenAnim(long time) {
      if (this.openRunning) {
         float t = (float)((time - this.openTime) / 1.0E9);
         if (t >= 1.0F) {
            this.openRunning = false;
            this.openAnim = this.openFrom;
         }
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.keysOpen) {
         float kx = this.keysPanel.getX();
         float ky = this.keysPanel.getY();
         if (kx <= mx && mx <= kx + this.keysPanel.getWidth() && ky <= my && my <= ky + this.keysPanel.getHeight()) {
            return this.onBodyClicked(mx, my, button);
         }
      }

      return this.baseMouseClicked(mx, my, button);
   }

   private boolean baseMouseClicked(double mx, double my, int button) {
      if (this.host != null) {
         this.x = this.host.getX();
         this.y = this.host.getY();
      }

      if (button == 0 && this.closeOnOutside && !this.hitRect(mx, my)) {
         this.onClose();
         return true;
      } else {
         return this.onBodyClicked(mx, my, button);
      }
   }

   private boolean isOverlayOpen() {
      return !this.overlayClosed;
   }

   private boolean hitRect(double mx, double my) {
      return mx >= this.x && mx <= this.x + this.width && my >= this.y && my <= this.y + this.height;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.keysOpen && this.keysDragging && button == 0) {
         this.keysDragging = false;
         this.keysPanel.setDragging(false);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      if (this.keysOpen && this.keysDragging && delta == 0.0) {
         float ksX = this.keysPanel.getX();
         float ksY = this.keysPanel.getY();
         float listTop1 = this.keysListTop(ksY);
         float bottomY = ksY + 288.0F;
         float inner1 = listTop1 + 32.0F + 6.0F;
         float listTop2 = this.keysListTop(ksY);
         float trackTop = inner1 + 4.0F;
         float inner2 = bottomY - (listTop2 + 32.0F + 6.0F) - 12.0F;
         float gauge = this.keysScrollGauge(ksY);
         float value = ((float)my - this.keysDragOffset - trackTop) / (inner2 + inner1 - 4.0F - trackTop - 40.0F) * gauge;
         float clamped = 0.0F;
         if (value >= 0.0F) {
            clamped = value <= gauge ? value : gauge;
         }

         this.keysPanel.setScroll(clamped);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (!this.keysOpen) {
         return false;
      } else {
         float ksX = this.keysPanel.getX();
         float ksY = this.keysPanel.getY();
         float listTop1 = this.keysListTop(ksY);
         float bottomY = ksY + 288.0F;
         float inner1 = listTop1 + 32.0F + 6.0F;
         float listTop2 = this.keysListTop(ksY);
         float inner2 = bottomY - (listTop2 + 32.0F + 6.0F) - 12.0F;
         int count = this.keysPanel.rows().size();
         if (mx >= ksX + 12.0F && mx <= ksX + 12.0F + 252.0F && my >= listTop1 && my <= inner2 + listTop2 && count > 6) {
            float gauge = this.keysScrollGauge(ksY);
            float value = this.keysPanel.scrollOffset() - (float)amount * 24.0F;
            float clamped = 0.0F;
            if (value >= 0.0F) {
               clamped = value <= gauge ? value : gauge;
            }

            this.keysPanel.setScroll(clamped);
            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (this.closeOnEscape && keyCode == 27) {
         this.onClose();
         return true;
      } else {
         return this.closeKeysOnEscape(keyCode);
      }
   }

   private boolean closeKeysOnEscape(int keyCode) {
      if (this.keysOpen && keyCode == 27) {
         this.keysOpen = false;
         return true;
      } else {
         return false;
      }
   }

   private float keysListTop(float ksY) {
      return 30.0F + ksY + 8.0F;
   }

   private float keysScrollGauge(float ksY) {
      int count = this.keysPanel.rows().size();
      float top = this.keysListTop(ksY);
      if (count < 1) {
         float value = 0.0F - top;
         if (value <= 0.0F) {
            value = 0.0F;
         }

         return value;
      } else {
         float value = (count - 1) * 4.0F + count * 20.0F + 8.0F - top;
         if (value <= 0.0F) {
            value = 0.0F;
         }

         return value;
      }
   }

   @Override
   public boolean charTyped(char ch) {
      return false;
   }

   public boolean onBodyClicked(double mx, double my, int button) {
      if (this.keysOpen) {
         if (this.keysPanel.mouseClicked(mx, my, button)) {
            return true;
         } else {
            this.keysOpen = false;
            return true;
         }
      } else {
         if (button == 0
            && this.headerA.x <= mx
            && mx <= this.headerA.x + this.headerA.width
            && this.headerA.y <= my
            && my <= this.headerA.y + this.headerA.height) {
            if (this.headerA.clicked(mx, my, button)) {
               return true;
            }
         } else if (button != 0) {
            return true;
         }

         if (this.headerB.x <= mx
            && mx <= this.headerB.x + this.headerB.width
            && this.headerB.y <= my
            && my <= this.headerB.y + this.headerB.height
            && this.headerB.clicked(mx, my, button)) {
            return true;
         } else {
            boolean headerCConsumed = this.headerC.x <= mx
               && mx <= this.headerC.x + this.headerC.width
               && this.headerC.y <= my
               && my <= this.headerC.y + this.headerC.height
               && this.headerC.clicked(mx, my, button);
            if (!headerCConsumed && this.config != null && !this.config.pending && this.config.hasExtra && this.hitAnchor(mx, my)) {
               this.openKeysPanel();
            }

            return true;
         }
      }
   }

   private boolean hitAnchor(double mx, double my) {
      return mx >= this.anchorX && mx <= this.anchorX + this.anchorW && my >= this.anchorY && my <= this.anchorY + this.anchorH;
   }

   public void openKeysPanel() {
      this.anchorX = this.x;
      this.anchorY = this.layoutRowY();
      this.anchorW = this.width;
      this.anchorH = 32.0F;
      this.keysPanel.open(this);
      this.keysOpen = true;
   }

   private float layoutRowY() {
      return this.y;
   }

   public void onClose() {
      this.keysOpen = false;
      this.shareCallback = null;
   }

   public void resetState() {
      this.keysOpen = false;
      this.keysPanel.setPosition(0.0F, 0.0F);
      this.keysPanel.setSize(0.0F, 0.0F);
      this.overlayClosed = false;
      this.closeOnOutside = true;
      this.closeOnEscape = true;
   }

   public void setHost(Component value) {
      this.host = value;
   }

   public void setShareCallback(Runnable value) {
      this.shareCallback = value;
   }

   public void setKeysOpen(boolean value) {
      this.keysOpen = value;
   }

   public float openAnimValue() {
      return this.openAnim;
   }

   public float openAnimTarget() {
      return this.openFrom;
   }

   public void setOpenAnimTarget(float value) {
      this.openFrom = value;
   }

   public float sliderAnimA() {
      return this.sliderAnimA;
   }

   public float sliderAnimB() {
      return this.sliderAnimB;
   }

   public float rowAnim() {
      return this.rowAnim;
   }

   public void setRowAnim(float value) {
      this.rowAnim = value;
   }

   public float anchorX() {
      return this.anchorX;
   }

   public float anchorY() {
      return this.anchorY;
   }

   public float anchorW() {
      return this.anchorW;
   }

   public float anchorH() {
      return this.anchorH;
   }

   public void setAnchor(float ax, float ay, float aw, float ah) {
      this.anchorX = ax;
      this.anchorY = ay;
      this.anchorW = aw;
      this.anchorH = ah;
   }

   public boolean isCloseOnOutside() {
      return this.closeOnOutside;
   }

   public boolean isCloseOnEscape() {
      return this.closeOnEscape;
   }

   public boolean isOverlayClosed() {
      return this.overlayClosed;
   }

   public static final class ConfigInfo {
      public String name = "";
      public boolean hasKeys;
      public boolean hasExtra;
      public boolean pending;

      public ConfigInfo() {
      }

      public ConfigInfo(String name, boolean hasKeys, boolean hasExtra, boolean pending) {
         this.name = name == null ? "" : name;
         this.hasKeys = hasKeys;
         this.hasExtra = hasExtra;
         this.pending = pending;
      }
   }

   public static final class HeaderWidget {
      public float x;
      public float y;
      public float width;
      public float height;
      public float animValue;
      public boolean enabled;

      public HeaderWidget() {
      }

      public HeaderWidget(boolean enabled) {
         this.enabled = enabled;
      }

      public boolean clicked(double mx, double my, int button) {
         return this.enabled;
      }

      public void setOnClick(Runnable callback) {
      }
   }
}

