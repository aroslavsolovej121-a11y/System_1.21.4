package client.gui;

import client.Setting;

public class HotkeyWidget extends Component {
   public static final int SLOT_RENDER = 1;
   public static final int SLOT_MOUSE_CLICKED = 4;
   public static final int SLOT_KEY_PRESSED = 8;
   public static final int SLOT_KEY_RELEASED = 9;
   public static final int SLOT_SET_POSITION = 11;
   public static final int SLOT_HEIGHT = 12;
   public static final int SLOT_HEIGHT_ALIAS = 13;
   public static final int SLOT_KIND = 17;
   public static final int SLOT_MIN_WIDTH = 18;
   public static final int SLOT_MIN_WIDTH_ALIAS = 19;
   public static final float FOCUS_DURATION = 0.15F;
   public static final float KEY_ANIM_DURATION = 0.55F;
   public static final float EPSILON = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final float SECTION_H = 32.0F;
   public static final float SECTION_TOP = 6.0F;
   public static final float SECTION_PAD = 2.0F;
   public static final float SECTION_PAD2 = 8.0F;
   public static final float BADGE_SIZE = 26.0F;
   public static final float BADGE_INSET = 3.0F;
   public static final float BADGE_TEXT_PAD = 5.0F;
   public static final float BADGE_W = 29.0F;
   public static final float LABEL_FONT_SIZE = 12.0F;
   public static final float DEFAULT_WIDTH = 269.0F;
   public static final float GLYPH_SIZE = 16.0F;
   public static final int KIND = 89;
   public static final float MIN_WIDTH = 16.0F;
   public static final int GLYPH_ICON = 68;
   public static final float BADGE_CORNER = 8.0F;
   public static final float SECTION_CORNER = 10.0F;
   private Setting setting;
   private boolean capturing;
   private int boundKey;
   private int boundModifiers;
   private int pendingModifier;
   private final Component.Anim captureAnim = new Component.Anim(0.0F, 0.15F);
   private final Component.Anim keyAnim = new Component.Anim(0.0F, 0.55F);
   private float labelWidth = -1.0F;
   private float labelWidthCache;
   private float valueWidth = -1.0F;
   private float valueWidthCache;
   public static final float LABEL_GAP = 20.0F;
   public static final float PI = (float) Math.PI;

   public HotkeyWidget() {
   }

   public HotkeyWidget(Setting setting) {
      this.setting = setting;
      this.flags = 256;
      this.width = 269.0F;
      this.boundKey = setting == null ? 0 : setting.getKey();
      this.boundModifiers = 0;
      this.captureAnim.update(this.now());
      this.keyAnim.update(this.now());
   }

   public int kind() {
      return 89;
   }

   public float minWidth() {
      return 16.0F;
   }

   @Override
   public float preferredWidth() {
      return 16.0F;
   }

   @Override
   public float preferredHeight() {
      return this.measuredHeight();
   }

   public float measuredHeight() {
      float lw = this.measureLabel(this.width);
      float vw = this.measureValue();
      if (0.0F < lw) {
         vw = vw + 0.0F + lw;
      }

      return vw + 6.0F + 32.0F;
   }

   public float measureLabel(float avail) {
      if (this.setting == null) {
         return 0.0F;
      } else if (this.labelWidth == avail) {
         return this.labelWidthCache;
      } else {
         this.labelWidth = avail;
         this.labelWidthCache = fontWidth(this.setting == null ? "" : this.setting.getName(), 12.0F);
         return this.labelWidthCache;
      }
   }

   public float measureValue() {
      float avail = this.width - (this.kind() == 89 ? 0.0F : 20.0F);
      if (avail <= 0.0F) {
         avail = 0.0F;
      }

      if (this.valueWidth == avail) {
         return this.valueWidthCache;
      } else {
         this.valueWidth = avail;
         float measured = fontWidth(this.keyLabel(), 12.0F);
         if (measured > avail) {
            measured = avail;
         }

         this.valueWidthCache = measured;
         return this.valueWidthCache;
      }
   }

   public boolean capturing() {
      return this.capturing;
   }

   public Setting setting() {
      return this.setting;
   }

   public int key() {
      return this.boundKey;
   }

   @Override
   public void tick() {
      long time = this.now();
      this.captureAnim.update(time);
      this.keyAnim.update(time);
   }

   @Override
   public void render(Object renderer, float px, float py, float alpha) {
      float label = this.measureLabel(this.width);
      float value = this.measureValue();
      if (0.0F < value) {
         label = label + 0.0F + value;
      }

      float glyphX = px + 3.0F;
      float rowTop = label + py + 6.0F;
      float innerTop = rowTop + 3.0F;
      float sectionRight = px + this.width - 6.0F - 2.0F;
      float labelRight = sectionRight - 26.0F - 29.0F;
      boolean overLabel = mouseX >= glyphX && mouseX <= labelRight && mouseY >= innerTop && mouseY <= innerTop + 26.0F;
      if (overLabel) {
         cursorStyle = 1;
      }

      float badgeX = px + this.width - 3.0F - 26.0F;
      float badgeY = value + py + 6.0F + 3.0F;
      boolean overBadge = mouseX >= badgeX && mouseX <= badgeX + 26.0F && mouseY >= badgeY && mouseY <= badgeY + 26.0F;
      if (overBadge) {
         cursorStyle = 1;
      }

      uiDrawBox(renderer, px, rowTop, this.width, 32.0F, 10.0F, 10.0F, 10.0F, 10.0F, uiThemeColor(0), uiThemeColor(0), 1.0F, 0, 0.0F, 1.0F, 0.0F, alpha, 0);
      this.renderKeyBadge(renderer, glyphX, badgeY, labelRight - glyphX, alpha);
      uiDrawBox(renderer, badgeX, badgeY, 26.0F, 26.0F, 8.0F, 8.0F, 8.0F, 8.0F, uiThemeColor(1), uiThemeColor(1), 1.0F, 0, 0.0F, 1.0F, 0.0F, alpha, 0);
      float iconX = badgeX + 5.0F;
      float iconY = badgeY + 5.0F;
      long time = this.now();
      this.keyAnim.update(time);
      float pop = this.keyAnim.current;
      if (0.001F < pop && pop < 0.999F) {
         uiDrawBox(
            renderer,
            iconX,
            iconY,
            16.0F,
            16.0F,
            (pop + pop) * (float) Math.PI,
            (pop + pop) * (float) Math.PI,
            (pop + pop) * (float) Math.PI,
            (pop + pop) * (float) Math.PI,
            0,
            0,
            0.0F,
            uiThemeColor(0),
            1.0F,
            pop * alpha,
            0.0F,
            alpha,
            0
         );
      }

      uiDrawIcon(renderer, 68, iconX, iconY, 16.0F, 16.0F, uiThemeColor(0), alpha);
      this.height = rowTop + 32.0F - this.y;
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.capturing) {
         int key = 0;
         if (button != 0 || !this.badgeContains(mx, my)) {
            if (button == 0) {
               key = 1;
            } else if (button == 1) {
               key = 2;
            } else if (button == 2) {
               key = 4;
            } else if (button == 3) {
               key = 5;
            } else if (button == 4) {
               key = 6;
            }

            if (this.boundKey != key || this.boundModifiers != 0) {
               this.boundKey = key;
               this.boundModifiers = 0;
               this.applyKey();
            }
         }

         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      } else if (button != 0) {
         return false;
      } else {
         float label = this.measureLabel(this.width);
         float value = this.measureValue();
         if (0.0F < label) {
            value = value + 0.0F + label;
         }

         float badgeX = this.x + this.width - 3.0F - 26.0F;
         float badgeY = value + this.y + 6.0F + 3.0F;
         if (mx >= badgeX && mx <= badgeX + 26.0F && my >= badgeY && my <= badgeY + 26.0F) {
            if (this.boundKey != 0 || this.boundModifiers != 0) {
               this.boundKey = 0;
               this.boundModifiers = 0;
               this.applyKey();
            }

            this.capturing = false;
            this.pendingModifier = 0;
            long time = this.now();
            this.keyAnim.set(0.0F, 0.55F);
            this.keyAnim.retarget(1.0F, time);
            this.keyAnim.update(time);
            return true;
         } else if (this.badgeContains(mx, my)) {
            this.capturing = true;
            this.pendingModifier = 0;
            return true;
         } else {
            return false;
         }
      }
   }

   public boolean badgeContains(double mx, double my) {
      float label = this.measureLabel(this.width);
      float value = this.measureValue();
      if (0.0F < label) {
         value = value + 0.0F + label;
      }

      float left = this.x + 3.0F;
      float right = this.x + this.width - 6.0F - 2.0F - 29.0F;
      float top = value + this.y + 6.0F + 3.0F;
      return mx >= left && mx <= right && my >= top && my <= top + 26.0F;
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      mouseX = (float)mx;
      mouseY = (float)my;
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      mouseX = (float)mx;
      mouseY = (float)my;
      return false;
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (!this.capturing) {
         return false;
      } else if (keyCode == 27) {
         if (this.boundKey != 0 || this.boundModifiers != 0) {
            this.boundKey = 0;
            this.boundModifiers = 0;
            this.applyKey();
         }

         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      } else if ((keyCode < 16 || keyCode > 18) && (keyCode < 160 || keyCode > 165)) {
         if (this.boundKey != keyCode || this.boundModifiers != modifiers) {
            this.boundKey = keyCode;
            this.boundModifiers = modifiers;
            this.applyKey();
         }

         this.capturing = false;
         this.pendingModifier = 0;
         return true;
      } else {
         this.pendingModifier = keyCode;
         return true;
      }
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (!this.capturing) {
         return false;
      } else {
         int pending = this.pendingModifier;
         if (pending != 0 && keyCode == pending) {
            if (this.boundKey != pending || this.boundModifiers != 0) {
               this.boundKey = pending;
               this.boundModifiers = 0;
               this.applyKey();
            }

            this.pendingModifier = 0;
            this.capturing = false;
            return true;
         } else {
            return false;
         }
      }
   }

   private void applyKey() {
      if (this.setting != null) {
         this.setting.setKey(this.boundKey);
      }
   }

   private String keyLabel() {
      return this.boundKey == 0 ? "" : nameOf(this.boundKey);
   }

   private static String nameOf(int key) {
      return "";
   }

   private static float fontWidth(String s, float size) {
      return s != null && !s.isEmpty() ? s.length() * size : 0.0F;
   }

   private void renderKeyBadge(Object renderer, float px, float py, float pw, float alpha) {
      String label;
      if (!this.capturing) {
         label = this.keyLabel();
      } else {
         label = "";
      }

      if (!label.isEmpty()) {
         uiDrawIcon(renderer, 0, px, py, pw, 0.0F, uiThemeColor(0), alpha);
      }
   }
}

