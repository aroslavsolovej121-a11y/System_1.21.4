package client.gui;

import client.Setting;

public class InputWidget extends SettingWidget {
   public static final int NAME_MEASURE_KEY_OFFSET = 104;
   public static final int NAME_MEASURE_OFFSET = 108;
   public static final int DESC_MEASURE_KEY_OFFSET = 112;
   public static final int DESC_MEASURE_OFFSET = 116;
   public static final int MEASURE_LANG_OFFSET = 120;
   public static final int INPUT_SETTING_OFFSET = 128;
   public static final int TEXT_OFFSET = 136;
   public static final int TEXT_SIZE_OFFSET = 152;
   public static final int TEXT_CAP_OFFSET = 160;
   public static final int FONT_SIZE_OFFSET = 168;
   public static final int FIELD_FLAG_OFFSET = 172;
   public static final int MULTILINE_OFFSET = 174;
   public static final int SELECTION_START_OFFSET = 176;
   public static final int SELECTION_END_OFFSET = 184;
   public static final int PLACEHOLDER_OFFSET = 192;
   public static final int PLACEHOLDER_SIZE_OFFSET = 208;
   public static final int PLACEHOLDER_CAP_OFFSET = 216;
   public static final int TEXT_INPUT_OFFSET = 280;
   public static final int VALUE_FIELD_OFFSET = 344;
   public static final int FOCUS_ANIM_OFFSET = 352;
   public static final int FOCUS_ANIM_FROM_OFFSET = 352;
   public static final int FOCUS_ANIM_CURRENT_OFFSET = 356;
   public static final int FOCUS_ANIM_TARGET_OFFSET = 360;
   public static final int FOCUS_ANIM_DURATION_OFFSET = 364;
   public static final int FOCUS_ANIM_EASING_OFFSET = 368;
   public static final int FOCUS_ANIM_LAST_TICK_OFFSET = 376;
   public static final int FOCUS_ANIM_RUNNING_OFFSET = 384;
   public static final int FOCUSED_OFFSET = 392;
   public static final int CACHED_Y_OFFSET = 396;
   public static final int SETTING_NAME_OFFSET = 40;
   public static final int SETTING_DESC_OFFSET = 72;
   public static final int SETTING_VALUE_OFFSET = 232;
   public static final int SETTING_VALUE_SIZE_OFFSET = 248;
   public static final int SETTING_VALUE_CAP_OFFSET = 256;
   public static final int SETTING_PLACEHOLDER_OFFSET = 296;
   public static final int SETTING_PLACEHOLDER_SIZE_OFFSET = 312;
   public static final int SETTING_MULTILINE_OFFSET = 329;
   public static final int EASE_OUT_CUBIC = 0;
   public static final int ICON_ID = 26;
   public static final int ICON_INVALID = 89;
   public static final int HOVER_INPUT = 2;
   public static final int TEXT_ALIGN_LEFT = 0;
   public static final int TEXT_ALIGN_CENTER = 2;
   public static final int KEY_ESCAPE = 27;
   public static final int KEY_ENTER = 13;
   public static final int SOUND_CLICK = 17;
   public static final float FIELD_HEIGHT = 32.0F;
   public static final float FIELD_INSET = 3.0F;
   public static final float FIELD_PAD = 6.0F;
   public static final float TEXT_PAD = 8.0F;
   public static final float FOCUS_ANIM_DURATION = 0.15F;
   public static final float NAME_FONT_SIZE = 14.0F;
   public static final float DESC_FONT_SIZE = 12.0F;
   public static final float ICON_WIDTH = 12.0F;
   public static final float ICON_HEIGHT = 12.0F;
   public static final float ICON_RESERVE = 20.0F;
   public static final float ROW_GAP = 6.0F;
   public static final float ROW_PAD = 8.0F;
   public static final float HALF = 0.5F;
   public static final float ZERO = 0.0F;
   public static final float ONE = 1.0F;
   public static final float NONE = -1.0F;
   public static final float NAME_MEASURE_SCALE = 0.015625F;
   public static final float DESC_MEASURE_SCALE = 14.4F;
   public static final float TEXT_EPSILON = 0.001F;
   public static final String PLACEHOLDER_TEXT = "Введите текст";
   protected Setting inputSetting;
   protected String text = "";
   protected float fontSize = 14.0F;
   protected short fieldFlag;
   protected boolean multiline;
   protected long selectionStart;
   protected long selectionEnd;
   protected String placeholder = "";
   protected Object textInput;
   protected long valueField;
   protected InputWidget.Anim focusAnim;
   protected boolean focused;
   protected float cachedY;
   protected boolean measureLang;
   protected float nameMeasureKey = -1.0F;
   protected float nameMeasure;
   protected float descMeasureKey = -1.0F;
   protected float descMeasure;
   private static boolean languageEnglish;

   public InputWidget(Setting setting) {
      super(setting);
      this.inputSetting = setting;
      this.text = "";
      this.fontSize = 14.0F;
      this.fieldFlag = 0;
      this.multiline = false;
      this.selectionStart = 0L;
      this.selectionEnd = 0L;
      this.placeholder = "";
      this.textInput = null;
      this.valueField = 0L;
      this.focusAnim = InputWidget.Anim.init(0.0F, 0.15F, 0);
      this.focused = false;
      this.cachedY = 0.0F;
      this.measureLang = false;
      this.multiline = settingFlag(setting, 329);
      this.text = settingValueText(setting);
      this.selectionStart = this.text.length();
      this.selectionEnd = this.text.length();
      if (this.textInput != null) {
         notifyTextChanged(this.textInput, this.text);
      }

      setOnChange(this, this.text);
   }

   @Override
   public void dispose() {
      if (Screen.focusedInput == this) {
         Screen.focusedInput = null;
         clearCapture();
      }

      disposeTextInput(this.text);
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      float rowY = this.cachedY;
      if (this.x <= mouseX && mouseX <= this.x + this.width && rowY <= mouseY && mouseY <= rowY + 32.0F && (Screen.focusedWidget == null || Screen.allowHover)) {
         Screen.hoveredWidget = 2;
      }

      if (this.focused) {
         Screen.textInputActive = true;
      }

      float label = this.drawLabel(mat, this.width, alpha);
      float description = this.drawDescription(mat, label, this.width);
      if (0.0F < description) {
         label = label + 0.0F + description;
      }

      rowY = label + this.y + 6.0F;
      this.cachedY = rowY;
      drawFieldBackdrop(mat, this.x, rowY, this.width);
      float fieldX = this.x + 3.0F;
      float fieldY = this.cachedY + 3.0F;
      float fieldWidth = this.width - 6.0F;
      beginField();
      drawFieldBorder(mat, fieldX, fieldY, fieldWidth);
      float focus = this.focusAnim.advance(this.now());
      if (0.001F < focus) {
         fieldTheme();
         drawFieldFill(mat, fieldX, fieldY, fieldWidth);
      }

      float textY = fieldY + 6.0F;
      setFieldClip(fieldX, textY, fieldWidth, 32.0F);
      if (this.text.length() == 0 && !this.focused) {
         Setting setting = this.inputSetting;
         fieldTheme();
         boolean hasPlaceholder = hasSettingPlaceholder(setting);
         String value;
         if (hasPlaceholder) {
            value = settingPlaceholder(setting);
         } else {
            value = "Введите текст";
         }

         drawText(mat, 0, value, fieldX + 8.0F, textY, 32.0F, fieldWidth, 0, alpha);
      } else {
         fieldTheme();
         drawTextInput(this.text, mat, fieldX + 8.0F, textY, alpha);
      }

      resetFieldClip();
      this.height = this.cachedY + 32.0F - this.y;
   }

   @Override
   public void layout(Object mat, float x, float y, float alpha) {
   }

   @Override
   public void update() {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else if (this.x <= mx && mx <= this.x + this.width && this.cachedY <= my && my <= this.cachedY + 32.0F) {
         this.setFocused(true);
         return true;
      } else {
         this.setFocused(false);
         return false;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      return false;
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      return false;
   }

   @Override
   public boolean keyPressed(int key) {
      if (!this.focused) {
         return false;
      } else if (key != 27 && key != 13) {
         insertKey(this.text, key);
         return true;
      } else {
         this.focused = false;
         this.focusAnim.retarget(0.0F, this.now());
         notifyFocusLost(this);
         return true;
      }
   }

   @Override
   public boolean keyReleased(int key) {
      return false;
   }

   @Override
   public boolean charTyped(int codePoint) {
      return !this.focused ? false : insertChar(this.text, codePoint);
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   @Override
   public float contentHeight() {
      float label = this.descriptionHeight(this.width);
      float extra = this.nameHeight(this.width);
      if (0.0F < label) {
         extra = extra + 0.0F + label;
      }

      return extra + 6.0F + 32.0F;
   }

   @Override
   public void measure() {
      this.contentHeight();
   }

   @Override
   public void closeModal() {
   }

   @Override
   public boolean isOpen() {
      return false;
   }

   public int iconId() {
      return 26;
   }

   public float iconWidth() {
      return 12.0F;
   }

   public float iconHeight() {
      return 12.0F;
   }

   @Override
   public void setFocused(boolean value) {
      if (this.focused != value) {
         this.focused = value;
         float target = 1.0F;
         if (!value) {
            target = 0.0F;
         }

         this.focusAnim.retarget(target, this.now());
         if (value) {
            Screen.focusedInput = this;
            requestTextFocus(this);
         } else {
            notifyFocusLost(this);
         }
      }
   }

   @Override
   public boolean isFocused() {
      return this.focused;
   }

   public String getText() {
      return this.text;
   }

   public void setText(String value) {
      this.text = value == null ? "" : value;
   }

   public void commit() {
      this.setFocused(false);
   }

   public void cancel() {
      this.setFocused(false);
   }

   public void blur(String value) {
   }

   private float nameHeight(float width) {
      int icon = this.iconId();
      float reserve = 20.0F;
      if (icon == 89) {
         reserve = 0.0F;
      }

      width -= reserve;
      if (width <= 0.0F) {
         width = 0.0F;
      }

      if (this.measureLang != languageEnglish) {
         this.measureLang = languageEnglish;
         this.descMeasureKey = -1.0F;
         this.nameMeasureKey = -1.0F;
      }

      if (width != this.nameMeasureKey) {
         this.nameMeasureKey = width;
         String name = settingText(40);
         float measured = measureWrapped(name, 14.0F, width);
         this.nameMeasure = (float)((long)measured) * 0.015625F;
      }

      return this.nameMeasure;
   }

   private float descriptionHeight(float width) {
      if (!hasText(settingText(72))) {
         return 0.0F;
      } else {
         if (this.measureLang != languageEnglish) {
            this.measureLang = languageEnglish;
            this.descMeasureKey = -1.0F;
            this.nameMeasureKey = -1.0F;
         }

         if (width != this.descMeasureKey) {
            this.descMeasureKey = width;
            String description = settingText(72);
            float measured = measureWrapped(description, 12.0F, width);
            this.descMeasure = (float)((long)measured) * 14.4F;
         }

         return this.descMeasure;
      }
   }

   private float drawLabel(Object mat, float x, float alpha) {
      float extra = this.nameHeight(x);
      int icon = this.iconId();
      float reserve = 20.0F;
      if (icon == 89) {
         reserve = 0.0F;
      }

      x -= reserve;
      if (x <= 0.0F) {
         x = 0.0F;
      }

      if (icon != 89) {
         float w = this.iconWidth();
         float h = this.iconHeight();
         int color = fieldThemeColor();
         drawIcon(mat, icon, (12.0F - w) * 0.5F + this.x, (14.0F - h) * 0.5F + this.y, w, h, color, alpha);
      }

      int color = fieldThemeColor();
      String name = settingText(40);
      drawText(mat, 2, name, reserve + this.x, this.y, 14.0F, x, color, alpha);
      return extra;
   }

   private float drawDescription(Object mat, float y, float width) {
      if (!hasText(settingText(72))) {
         return 0.0F;
      } else {
         float height = this.descriptionHeight(width);
         int color = fieldThemeColor();
         String description = settingText(72);
         drawText(mat, 0, description, this.x, y + this.y + 0.0F, 12.0F, height, color, width);
         return height;
      }
   }

   private static boolean settingFlag(Setting setting, int offset) {
      return false;
   }

   private static String settingValueText(Setting setting) {
      return "";
   }

   private static String settingText(int offset) {
      return "";
   }

   private static String settingPlaceholder(Setting setting) {
      return "";
   }

   private static boolean hasSettingPlaceholder(Setting setting) {
      return false;
   }

   private static void setOnChange(InputWidget widget, String value) {
   }

   private static void notifyTextChanged(Object textInput, String value) {
   }

   private static void notifyFocusLost(InputWidget widget) {
   }

   private static void requestTextFocus(InputWidget widget) {
   }

   private static void clearCapture() {
   }

   private static void disposeTextInput(String value) {
   }

   private static void insertKey(String text, int key) {
   }

   private static boolean insertChar(String text, int codePoint) {
      return false;
   }

   private static boolean hasText(String value) {
      if (value == null) {
         return false;
      } else {
         int start = 0;
         int end = value.length();

         while (start < end && isBlank(value.charAt(start))) {
            start++;
         }

         if (start == end) {
            return false;
         } else {
            int tail = end;

            while (tail > start && isBlank(value.charAt(tail - 1))) {
               tail--;
            }

            return tail != start;
         }
      }
   }

   private static boolean isBlank(char c) {
      return c == ' ' || (c - '\t' & 250) == 0 && c != 14;
   }

   private static float measureWrapped(String text, float size, float width) {
      return 0.0F;
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float w, float h, int color, float alpha) {
   }

   private static void drawText(Object mat, int align, String text, float x, float y, float size, float maxWidth, int color, float alpha) {
   }

   private static void drawFieldBackdrop(Object mat, float x, float y, float width) {
   }

   private static void drawFieldBorder(Object mat, float x, float y, float width) {
   }

   private static void drawFieldFill(Object mat, float x, float y, float width) {
   }

   private static void drawTextInput(String text, Object mat, float x, float y, float alpha) {
   }

   private static void beginField() {
   }

   private static void setFieldClip(float x, float y, float w, float h) {
   }

   private static void resetFieldClip() {
   }

   private static void fieldTheme() {
   }

   private static int fieldThemeColor() {
      return 0;
   }

   @Override
   protected long now() {
      return System.nanoTime();
   }

   public static final class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing;
      public long lastTick;
      public boolean animating;

      public Anim() {
      }

      public Anim(float value, float seconds, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = seconds;
         this.easing = easing;
      }

      public static InputWidget.Anim init(float value, float seconds, int easing) {
         InputWidget.Anim anim = new InputWidget.Anim(value, seconds, easing);
         anim.lastTick = System.nanoTime();
         anim.animating = false;
         return anim;
      }

      public void retarget(float target, long time) {
         if (this.target != target) {
            this.from = this.advance(time);
            this.lastTick = time;
            this.target = target;
            this.animating = true;
         }
      }

      public float advance(long time) {
         if (this.animating && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.lastTick) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.animating = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = ease(this.easing, k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.animating = false;
            return this.current;
         }
      }

      private static float ease(int easing, float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }
   }
}

