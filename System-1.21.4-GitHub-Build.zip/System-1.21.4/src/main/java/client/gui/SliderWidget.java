package client.gui;

import client.Setting;

public class SliderWidget extends SettingWidget {
   public static final int NAME_MEASURE_KEY_OFFSET = 104;
   public static final int NAME_MEASURE_OFFSET = 108;
   public static final int DESC_MEASURE_KEY_OFFSET = 112;
   public static final int DESC_MEASURE_OFFSET = 116;
   public static final int MEASURE_LANG_OFFSET = 120;
   public static final int SLIDER_SETTING_OFFSET = 128;
   public static final int DRAG_ANIM_OFFSET = 136;
   public static final int DRAG_ANIM_FROM_OFFSET = 136;
   public static final int DRAG_ANIM_CURRENT_OFFSET = 140;
   public static final int DRAG_ANIM_TARGET_OFFSET = 144;
   public static final int DRAG_ANIM_DURATION_OFFSET = 148;
   public static final int DRAG_ANIM_EASING_OFFSET = 152;
   public static final int DRAG_ANIM_LAST_TICK_OFFSET = 160;
   public static final int DRAG_ANIM_RUNNING_OFFSET = 168;
   public static final int DRAGGING_OFFSET = 176;
   public static final int DISPLAY_VALUE_OFFSET = 180;
   public static final int DELTA_STAMP_OFFSET = 184;
   public static final int LAST_TEXT_VALUE_OFFSET = 192;
   public static final int TEXT_OFFSET = 200;
   public static final int TEXT_SIZE_OFFSET = 216;
   public static final int TEXT_CAP_OFFSET = 224;
   public static final int TEXT_DIRTY_OFFSET = 232;
   public static final int TEXT_SETTING_VALUE_OFFSET = 240;
   public static final int TEXT_WIDTH_OFFSET = 248;
   public static final int LANG_FLAG_OFFSET = 252;
   public static final int SETTING_NAME_OFFSET = 40;
   public static final int SETTING_DESC_OFFSET = 72;
   public static final int SETTING_VALUE_TEXT_OFFSET = 272;
   public static final int SETTING_VALUE_OFFSET = 232;
   public static final int SETTING_MIN_OFFSET = 248;
   public static final int SETTING_MAX_OFFSET = 256;
   public static final int EASE_OUT_EXPO = 1;
   public static final int ICON_ID = 64;
   public static final int ICON_INVALID = 89;
   public static final int HOVER_SLIDER = 3;
   public static final int TEXT_ALIGN_CENTER = 2;
   public static final int TEXT_ALIGN_LEFT = 0;
   public static final int SOUND_CLICK = 17;
   public static final float VALUE_EASE_RATE = -14.0F;
   public static final float DRAG_ANIM_DURATION = 0.22F;
   public static final float NAME_FONT_SIZE = 14.0F;
   public static final float DESC_FONT_SIZE = 12.0F;
   public static final float ICON_WIDTH = 16.0F;
   public static final float ICON_HEIGHT = 16.0F;
   public static final float ICON_RESERVE = 20.0F;
   public static final float ROW_PAD = 8.0F;
   public static final float ROW_GAP = 6.0F;
   public static final float HIT_PAD = 10.0F;
   public static final float KNOB_BASE = 14.0F;
   public static final float KNOB_GROWTH = 4.0F;
   public static final float KNOB_LIFT = 2.0F;
   public static final float HALF = 0.5F;
   public static final float ZERO = 0.0F;
   public static final float ONE = 1.0F;
   public static final float NONE = -1.0F;
   public static final float NAME_MEASURE_SCALE = 0.015625F;
   public static final float DESC_MEASURE_SCALE = 14.4F;
   public static final float DELTA_MAX = 0.1F;
   public static final float DELTA_FALLBACK = 0.01666667F;
   public static final long DELTA_SCALE = 1000000000L;
   public static final String FORMAT_TEMPLATE = "{:.{}f}{}";
   protected Setting sliderSetting;
   protected SliderWidget.Anim dragAnim;
   protected boolean dragging;
   protected float displayedValue;
   protected long deltaStamp;
   protected float lastTextValue;
   protected String text = "";
   protected boolean textDirty;
   protected double textSettingValue;
   protected float textWidth = -1.0F;
   protected boolean langFlag;
   protected float nameMeasureKey = -1.0F;
   protected float nameMeasure;
   protected float descMeasureKey = -1.0F;
   protected float descMeasure;
   private static boolean languageEnglish;

   public SliderWidget(Setting setting) {
      super(setting);
      this.sliderSetting = setting;
      this.dragAnim = SliderWidget.Anim.init(0.0F, 0.22F, 1);
      this.dragging = false;
      this.displayedValue = (float)this.settingValue();
      this.deltaStamp = -1L;
      this.lastTextValue = 0.0F;
      this.text = "";
      this.textDirty = false;
      this.textSettingValue = 0.0;
      this.textWidth = -1.0F;
      this.langFlag = false;
      this.nameMeasureKey = -1.0F;
      this.nameMeasure = 0.0F;
      this.descMeasureKey = -1.0F;
      this.descMeasure = 0.0F;
   }

   @Override
   public void dispose() {
      clearString(this.text);
      freeString(this.text);
      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      double target = this.settingValue();
      float delta = this.deltaSeconds();
      float shown = this.displayedValue;
      float decay = (float)Math.exp(delta * -14.0F);
      shown = (1.0F - decay) * ((float)target - shown) + shown;
      this.displayedValue = shown;
      if (this.langFlag != languageEnglish) {
         this.langFlag = languageEnglish;
         this.textDirty = false;
         this.textWidth = -1.0F;
      }

      if (!this.textDirty || shown != this.lastTextValue) {
         String layout = settingText(272);
         String formatted = formatValue(layout, shown, target);
         assignString(this, formatted);
         this.lastTextValue = shown;
         this.textDirty = true;
      }

      float valueWidth = this.valueTextWidth();
      float extra = this.drawLabel(mat, this.width - valueWidth - 8.0F, alpha);
      float description = this.drawDescription(mat, extra, alpha);
      layoutValueText(mat, this.width + this.x, this.y, this.text);
      float bottom = 10.0F;
      if (0.0F < description) {
         extra = extra + 0.0F + description;
      }

      float rowY = extra + this.y + 6.0F;
      if (!this.dragging) {
         if (this.x <= mouseX
            && mouseX <= this.x + this.width
            && rowY - 10.0F <= mouseY
            && mouseY <= rowY - 10.0F + 10.0F + 10.0F
            && (Screen.focusedWidget == null || Screen.allowHover)) {
            Screen.hoveredWidget = 1;
         }
      } else {
         Screen.hoveredWidget = 3;
      }

      double min = this.settingMin();
      double max = this.settingMax();
      double t = (shown - min) / (max - min);
      if (t < 0.0) {
         t = 0.0;
      }

      if (t > 1.0) {
         t = 1.0;
      }

      float knobTrackWidth = this.width;
      float animTarget = 1.0F;
      if (!this.dragging) {
         animTarget = 0.0F;
      }

      if (this.dragAnim.target != animTarget) {
         long time = this.now();
         this.dragAnim.from = this.dragAnim.advance(time);
         this.dragAnim.target = animTarget;
         this.dragAnim.lastTick = time;
         this.dragAnim.animating = true;
      }

      float anim = this.dragAnim.advance(this.now());
      float knobSize = anim * 4.0F + 14.0F;
      float baseX = this.x;
      float half = knobSize * 0.5F;
      sliderTheme();
      sliderTheme();
      drawSliderTrack(mat, this.x, rowY, this.width);
      sliderTheme();
      sliderTheme();
      drawSliderKnob(mat, (float)(knobTrackWidth * t) + baseX - half, rowY - 2.0F, knobSize);
      this.height = rowY + bottom - this.y;
   }

   @Override
   public void layout(Object mat, float x, float y, float alpha) {
   }

   @Override
   public void update() {
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button == 0) {
         float valueWidth = this.valueTextWidth();
         float description = this.descriptionHeight(this.width);
         float extra = this.nameHeight(this.width - valueWidth - 8.0F);
         if (0.0F < description) {
            extra = extra + 0.0F + description;
         }

         if (this.x <= mx && mx <= this.x + this.width) {
            float rowY = extra + this.y + 6.0F;
            if (rowY - 10.0F <= my && my <= rowY + 10.0F) {
               this.dragging = true;
               this.applyValueFromMouse(mx);
               return true;
            }
         }
      }

      return false;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (!this.dragging) {
         return false;
      } else {
         this.dragging = false;
         return true;
      }
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      if (!this.dragging) {
         return false;
      } else {
         this.applyValueFromMouse(mx);
         return true;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      return false;
   }

   @Override
   public boolean keyPressed(int key) {
      return false;
   }

   @Override
   public boolean keyReleased(int key) {
      return false;
   }

   @Override
   public boolean charTyped(int codePoint) {
      return false;
   }

   @Override
   public void setPosition(float x, float y) {
      this.x = x;
      this.y = y;
   }

   @Override
   public float contentHeight() {
      float valueWidth = this.valueTextWidth();
      float extra = this.nameHeight(this.width - valueWidth - 8.0F);
      float description = this.descriptionHeight(this.width);
      if (0.0F < description) {
         extra = extra + 0.0F + description;
      }

      return extra + 6.0F + 10.0F;
   }

   @Override
   public void measure() {
      this.contentHeight();
   }

   @Override
   public void closeModal() {
   }

   @Override
   public boolean isOpen() {
      return false;
   }

   public int iconId() {
      return 64;
   }

   public float iconWidth() {
      return 16.0F;
   }

   public float iconHeight() {
      return 16.0F;
   }

   private void applyValueFromMouse(double mx) {
      double before = this.settingValue();
      double min = this.settingMin();
      double max = this.settingMax();
      double t = (mx - this.x) / this.width;
      if (t < 0.0) {
         t = 0.0;
      }

      if (t > 1.0) {
         t = 1.0;
      }

      setSettingValue(this.sliderSetting, (max - min) * t + min);
      if (this.settingValue() != before) {
         playSound(17);
      }
   }

   private float deltaSeconds() {
      long last = this.deltaStamp;
      long time = this.now();
      this.deltaStamp = time;
      if (last < 0L) {
         return 0.01666667F;
      } else {
         float seconds = (float)((time - last) / 1.0E9);
         float result = 0.0F;
         if (0.0 <= seconds && seconds <= 0.1F) {
            result = seconds;
         }

         return result;
      }
   }

   private float valueTextWidth() {
      if (this.langFlag != languageEnglish) {
         this.langFlag = languageEnglish;
         this.textDirty = false;
         this.textWidth = -1.0F;
      }

      if (this.textWidth < 0.0F || this.settingValue() != this.textSettingValue) {
         String layout = settingText(272);
         String pattern = buildFormat(layout);
         String formatted = formatValue(pattern, this.displayedValue, this.settingValue());
         String token = firstToken(formatted);
         this.textWidth = measureText(token, 12.0F) + 16.0F;
         this.textSettingValue = this.settingValue();
      }

      return this.textWidth;
   }

   private float nameHeight(float width) {
      int icon = this.iconId();
      float reserve = 20.0F;
      if (icon == 89) {
         reserve = 0.0F;
      }

      width -= reserve;
      if (width <= 0.0F) {
         width = 0.0F;
      }

      if (this.langFlag != languageEnglish) {
         this.langFlag = languageEnglish;
         this.descMeasureKey = -1.0F;
         this.nameMeasureKey = -1.0F;
      }

      if (width != this.nameMeasureKey) {
         this.nameMeasureKey = width;
         String name = settingText(40);
         float measured = measureWrapped(name, 14.0F, width);
         this.nameMeasure = (float)((long)measured) * 0.015625F;
      }

      return this.nameMeasure;
   }

   private float descriptionHeight(float width) {
      if (!hasText(settingText(72))) {
         return 0.0F;
      } else {
         if (this.langFlag != languageEnglish) {
            this.langFlag = languageEnglish;
            this.descMeasureKey = -1.0F;
            this.nameMeasureKey = -1.0F;
         }

         if (width != this.descMeasureKey) {
            this.descMeasureKey = width;
            String description = settingText(72);
            float measured = measureWrapped(description, 12.0F, width);
            this.descMeasure = (float)((long)measured) * 14.4F;
         }

         return this.descMeasure;
      }
   }

   private float drawLabel(Object mat, float x, float alpha) {
      float extra = this.nameHeight(x);
      int icon = this.iconId();
      float reserve = 20.0F;
      if (icon == 89) {
         reserve = 0.0F;
      }

      x -= reserve;
      if (x <= 0.0F) {
         x = 0.0F;
      }

      if (icon != 89) {
         float w = this.iconWidth();
         float h = this.iconHeight();
         int color = themeTextColor();
         drawIcon(mat, icon, (16.0F - w) * 0.5F + this.x, (14.0F - h) * 0.5F + this.y, w, h, color, alpha);
      }

      int color = themeTextColor();
      String name = settingText(40);
      drawText(mat, 2, name, reserve + this.x, this.y, 14.0F, x, color, alpha);
      return extra;
   }

   private float drawDescription(Object mat, float y, float alpha) {
      if (!hasText(settingText(72))) {
         return 0.0F;
      } else {
         float height = this.descriptionHeight(this.width);
         int color = themeTextColor();
         String description = settingText(72);
         drawText(mat, 0, description, this.x, y + this.y + 0.0F, 12.0F, height, color, alpha);
         return height;
      }
   }

   private double settingValue() {
      return settingValue(this.sliderSetting);
   }

   private double settingMin() {
      return settingMin(this.sliderSetting);
   }

   private double settingMax() {
      return settingMax(this.sliderSetting);
   }

   private static double settingValue(Setting setting) {
      return 0.0;
   }

   private static double settingMin(Setting setting) {
      return 0.0;
   }

   private static double settingMax(Setting setting) {
      return 0.0;
   }

   private static void setSettingValue(Setting setting, double value) {
   }

   private static String settingText(int offset) {
      return "";
   }

   private static boolean hasText(String value) {
      if (value == null) {
         return false;
      } else {
         int start = 0;
         int end = value.length();

         while (start < end && isBlank(value.charAt(start))) {
            start++;
         }

         if (start == end) {
            return false;
         } else {
            int tail = end;

            while (tail > start && isBlank(value.charAt(tail - 1))) {
               tail--;
            }

            return tail != start;
         }
      }
   }

   private static boolean isBlank(char c) {
      return c == ' ' || (c - '\t' & 250) == 0 && c != 14;
   }

   private static String buildFormat(String layout) {
      return "{:.{}f}{}";
   }

   private static String formatValue(String pattern, float value, double target) {
      return pattern;
   }

   private static String firstToken(String value) {
      if (value == null) {
         return "";
      } else {
         int start = 0;
         int end = value.length();

         while (start < end && isBlank(value.charAt(start))) {
            start++;
         }

         if (start == end) {
            return "";
         } else {
            int tail = end;

            while (tail > start && isBlank(value.charAt(tail - 1))) {
               tail--;
            }

            return value.substring(start, tail);
         }
      }
   }

   private static float measureText(String text, float size) {
      return 0.0F;
   }

   private static float measureWrapped(String text, float size, float width) {
      return 0.0F;
   }

   private static void assignString(SliderWidget widget, String value) {
      widget.text = value == null ? "" : value;
   }

   private static void clearString(String value) {
   }

   private static void freeString(String value) {
   }

   private static void playSound(int id) {
   }

   private static void layoutValueText(Object mat, float x, float y, String text) {
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float w, float h, int color, float alpha) {
   }

   private static void drawText(Object mat, int align, String text, float x, float y, float size, float maxWidth, int color, float alpha) {
   }

   private static void drawSliderTrack(Object mat, float x, float y, float w) {
   }

   private static void drawSliderKnob(Object mat, float x, float y, float size) {
   }

   private static void sliderTheme() {
   }

   private static int themeTextColor() {
      return 0;
   }

   @Override
   protected long now() {
      return System.nanoTime();
   }

   public static final class Anim {
      public float from;
      public float current;
      public float target;
      public float duration;
      public int easing;
      public long lastTick;
      public boolean animating;

      public Anim() {
      }

      public Anim(float value, float seconds, int easing) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = seconds;
         this.easing = easing;
      }

      public static SliderWidget.Anim init(float value, float seconds, int easing) {
         SliderWidget.Anim anim = new SliderWidget.Anim(value, seconds, easing);
         anim.lastTick = System.nanoTime();
         anim.animating = false;
         return anim;
      }

      public float advance(long time) {
         if (this.animating && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.lastTick) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.animating = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = ease(this.easing, k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.animating = false;
            return this.current;
         }
      }

      private static float ease(int easing, float t) {
         return t >= 1.0F ? 1.0F : 1.0F - (float)Math.exp(t * -6.931472F);
      }
   }
}

