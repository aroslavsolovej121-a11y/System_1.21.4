package client.gui;

public class discord {
   public void avatarTexture() {
   }
}
