package client.gui;

public class FavouriteButton extends AbstractButton {
   public static final float DEFAULT_WIDTH = 12.0F;
   public static final float DEFAULT_HEIGHT = 12.0F;
   public static final float ANIM_INIT_VALUE = 0.0F;
   public static final float ANIM_DURATION = 0.15F;
   public static final int CLICK_EFFECT_BASE = 2;
   public static final int CLICK_EFFECT_SELECTED = 3;
   public static final int CLICK_EFFECT_DESELECTED = 2;
   protected boolean selected;
   public final AbstractButton.Anim anim = new AbstractButton.Anim(0.0F, 0.15F);

   public FavouriteButton(boolean favourite) {
      this.selected = favourite;
      this.width = 12.0F;
      this.height = 12.0F;
      float initial = favourite ? 1.0F : 0.0F;
      this.anim.reset(initial, 0.15F);
   }

   @Override
   public boolean onClick(double mx, double my) {
      boolean previous = this.selected;
      this.selected = !previous;
      playClickEffect(previous ? 3 : 2);
      this.notifyChanged();
      return true;
   }

   public boolean isSelected() {
      return this.selected;
   }

   public void setSelected(boolean value) {
      this.selected = value;
   }
}

