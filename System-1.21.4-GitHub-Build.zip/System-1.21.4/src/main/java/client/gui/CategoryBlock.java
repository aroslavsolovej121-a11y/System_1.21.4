package client.gui;

public class CategoryBlock extends IconTextBlock {
   public static final int CATEGORY_COUNT = 6;
   public static final int CATEGORY_NONE = -1;
   public static final int ICON_ALL = 1;
   public static final int BUTTON = 0;
   public static final String NAME_ALL = "All";
   public static final String NAME_COMBAT = "Сомбат";
   public static final String NAME_MOVEMENT = "Мовемент";
   public static final String NAME_PLAYER = "Плайер";
   public static final String NAME_RENDER = "Рендер";
   public static final String NAME_VISUAL = "Визуал";
   public static final String NAME_CLIENT = "Слиент";
   public static final String NAME_UNKNOWN = "";
   public int category;
   public boolean all;
   public boolean selected;
   public int valueA;
   public int valueB;

   public CategoryBlock(int category, boolean all) {
      super(all ? "All" : categoryName(category), all ? 1 : categoryIcon(category));
      this.category = category;
      this.all = all;
      this.selected = false;
      this.valueA = 0;
      this.valueB = 0;
   }

   public CategoryBlock(int category) {
      this(category, false);
   }

   public static String categoryName(int category) {
      switch (category) {
         case 0:
            return "Сомбат";
         case 1:
            return "Мовемент";
         case 2:
            return "Плайер";
         case 3:
            return "Рендер";
         case 4:
            return "Визуал";
         case 5:
            return "Слиент";
         default:
            return "";
      }
   }

   public static int categoryIcon(int category) {
      switch (category) {
         case 0:
            return 3;
         case 1:
            return 4;
         case 2:
            return 7;
         case 3:
            return 8;
         case 4:
            return 28;
         case 5:
            return 2;
         default:
            return 1;
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         return !(mx < this.x) && !(mx > this.x + this.width) ? my >= this.y && my <= this.y + this.height : false;
      }
   }

   @Override
   public boolean isSelected() {
      return this.selected;
   }

   public void setSelected(boolean value) {
      this.selected = value;
   }

   @Override
   public int valueA() {
      return this.valueA;
   }

   public void setValueA(int value) {
      this.valueA = value;
   }

   @Override
   public int valueB() {
      return this.valueB;
   }

   public void setValueB(int value) {
      this.valueB = value;
   }

   public int getCategory() {
      return this.category;
   }

   public boolean isAll() {
      return this.all;
   }

   @Override
   public void dispose() {
      super.dispose();
      this.selected = false;
      this.valueA = 0;
      this.valueB = 0;
   }
}

