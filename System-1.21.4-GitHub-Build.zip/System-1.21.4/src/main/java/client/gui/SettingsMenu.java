package client.gui;

import java.util.ArrayList;
import java.util.List;

public class SettingsMenu extends AbstractOverlay {
   public static final int CALLBACK_OFFSET = 264;
   public static final int KEYBIND_OFFSET = 272;
   public static final int LIGHT_SLOT_OFFSET = 280;
   public static final int LIGHT_SLOT_END_OFFSET = 296;
   public static final int DARK_SLOT_OFFSET = 296;
   public static final int DARK_SLOT_END_OFFSET = 312;
   public static final int LANGUAGE_BUTTON_OFFSET = 312;
   public static final int LANGUAGE_BUTTON_END_OFFSET = 328;
   public static final int MODE_LEFT_OFFSET = 328;
   public static final int MODE_LEFT_END_OFFSET = 344;
   public static final int MODE_RIGHT_OFFSET = 344;
   public static final int MODE_RIGHT_END_OFFSET = 360;
   public static final int ROW_A_OFFSET = 360;
   public static final int ROW_A_END_OFFSET = 376;
   public static final int ROW_B_OFFSET = 376;
   public static final int ROW_B_END_OFFSET = 392;
   public static final int THEME_ANIM_OFFSET = 392;
   public static final int MODE_ANIM_OFFSET = 432;
   public static final int LANGUAGE_ANIM_OFFSET = 472;
   public static final int ROW_A_ANIM_OFFSET = 512;
   public static final int ROW_B_ANIM_OFFSET = 552;
   public static final int LISTENING_OFFSET = 592;
   public static final int PENDING_KEY_OFFSET = 596;
   public static final int RECT_X_OFFSET = 0;
   public static final int RECT_Y_OFFSET = 4;
   public static final int RECT_WIDTH_OFFSET = 8;
   public static final int RECT_HEIGHT_OFFSET = 12;
   public static final int RECT_X = 0;
   public static final int RECT_Y = 1;
   public static final int RECT_WIDTH = 2;
   public static final int RECT_HEIGHT = 3;
   public static final int ANIM_FROM_OFFSET = 0;
   public static final int ANIM_CURRENT_OFFSET = 4;
   public static final int ANIM_TARGET_OFFSET = 8;
   public static final int ANIM_DURATION_OFFSET = 12;
   public static final int ANIM_EASING_OFFSET = 16;
   public static final int ANIM_START_OFFSET = 24;
   public static final int ANIM_RUNNING_OFFSET = 32;
   public static final int CONFIG_NAME_OFFSET = 16;
   public static final int CONFIG_NAME_SIZE_OFFSET = 32;
   public static final int CONFIG_NAME_CAPACITY_OFFSET = 40;
   public static final int CONFIG_KEYBIND_OFFSET = 192;
   public static final int KEY_CALLBACK_OFFSET = 224;
   public static final int KEY_CODE_OFFSET = 232;
   public static final int KEY_MODIFIERS_OFFSET = 236;
   public static final int LABEL_MODIFIERS_OFFSET = 0;
   public static final int LABEL_TEXT_OFFSET = 8;
   public static final int LABEL_TEXT_SIZE_OFFSET = 24;
   public static final int LABEL_TEXT_CAPACITY_OFFSET = 32;
   public static final float CONST_VALUE = 20.0F;
   public static final float PANEL_WIDTH = 220.0F;
   public static final float PANEL_HEIGHT = 202.0F;
   public static final float PANEL_RADIUS = 20.0F;
   public static final float SLIDE_OFFSET = 16.0F;
   public static final float ROW_PAD = 8.0F;
   public static final float ROW_INSET = 6.0F;
   public static final float ROW_STEP = 48.0F;
   public static final float ROW_RADIUS = 14.0F;
   public static final float ROW_HEIGHT = 42.0F;
   public static final float CHIP_RADIUS = 12.0F;
   public static final float CHIP_HEIGHT = 36.0F;
   public static final float CHIP_INSET = 3.0F;
   public static final float CHIP_GAP = 2.0F;
   public static final float HALF = 0.5F;
   public static final float ICON_STRIP_START = 20.0F;
   public static final float ICON_STRIP_GAP = 10.0F;
   public static final float MODE_DIM = 0.3F;
   public static final float MODE_LIFT = 0.7F;
   public static final float ACCENT_BLEND = 0.85F;
   public static final float HINT_SIZE = 11.0F;
   public static final float SLOT_SIZE = 14.0F;
   public static final float TEXT_SIZE = 12.0F;
   public static final float LABEL_INSET = 16.0F;
   public static final float LABEL_LEAD = 4.0F;
   public static final float LABEL_PAD = 8.0F;
   public static final float LABEL_BASELINE = 6.0F;
   public static final float LABEL_TOP = 18.0F;
   public static final float PILL_RADIUS = 24.0F;
   public static final float PILL_ALPHA = 0.5F;
   public static final float DIM_FACTOR = 0.5F;
   public static final float ANIM_SPEED = 0.22F;
   public static final float ANIM_DEFAULT_DURATION = 0.15F;
   public static final int HOVER_DEFAULT = 1;
   public static final int HOVER_LIGHT_DISABLED = 7;
   public static final int TEXT_STYLE_HINT = 4;
   public static final int TEXT_STYLE_LABEL = 5;
   public static final int ICON_LIGHT = 17;
   public static final int ICON_DARK = 18;
   public static final int ICON_LANGUAGE = 19;
   public static final int ICON_MODIFIERS = 21;
   public static final int SOUND_CLICK = 14;
   public static final int VK_ESCAPE = 27;
   public static final int VK_MODIFIER_LOW = 16;
   public static final int VK_MODIFIER_ALT_LOW = 160;
   public static final int THEME_DARK = 1;
   public static final int THEME_LIGHT = 0;
   public static final int MODE_PREFIXED = 1;
   public static final int MODE_PLAIN = 0;
   public static final int MODIFIER_CTRL = 2;
   public static final int MODIFIER_SHIFT = 1;
   public static final int MODIFIER_ALT = 4;
   public static final int PENDING_KEY_NONE = 0;
   public static final int[] MODE_ICONS = new int[]{86, 88, 87};
   public static final String KEYBIND_ENTRY_NAME = "clickgui";
   public static final String ROW_A_TITLE = "Панис & Слеан";
   public static final String ROW_B_TITLE = "СлискГуи";
   public static final String HINT_TEXT = "SHIFT ALT CTRL";
   public static final String LISTENING_TEXT = "...";
   public static final String DEFAULT_KEY_TEXT = "None";
   public static final String MODIFIER_CTRL_TEXT = "CTRL + ";
   public static final String MODIFIER_SHIFT_TEXT = "SHIFT + ";
   public static final String MODIFIER_ALT_TEXT = "ALT + ";
   public static final String EMPTY_TEXT = "";
   public static boolean hoverGatePointerNull = true;
   public static boolean mouseInsideWindow;
   private static boolean lightThemeUnavailable;
   private static boolean russianActive;
   private static boolean modePrefixed;
   private static int currentTheme;
   private static boolean registryInitialized;
   private static final Object HINT_FONT = new Object();
   private static final Object LABEL_FONT = new Object();
   private static final List<SettingsMenu.ConfigEntry> CONFIG_ENTRIES = new ArrayList<>();
   protected Object callback;
   protected SettingsMenu.KeyEntry keybind;
   protected final float[] lightSlotRect = new float[4];
   protected final float[] darkSlotRect = new float[4];
   protected final float[] languageRect = new float[4];
   protected final float[] modeLeftRect = new float[4];
   protected final float[] modeRightRect = new float[4];
   protected final float[] rowARect = new float[4];
   protected final float[] rowBRect = new float[4];
   protected final AbstractOverlay.Animator themeAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator modeAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator languageAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator rowAAnim = new AbstractOverlay.Animator();
   protected final AbstractOverlay.Animator rowBAnim = new AbstractOverlay.Animator();
   protected boolean listening;
   protected int pendingKey;
   protected final float[] frameRect = new float[6];

   public SettingsMenu() {
      this.callback = null;
      if (!registryInitialized) {
         registryInitialized = true;
         ensureRegistryInitialized();
      }

      SettingsMenu.KeyEntry found = null;

      for (int index = 0; index < CONFIG_ENTRIES.size(); index++) {
         SettingsMenu.ConfigEntry candidate = CONFIG_ENTRIES.get(index);
         if (candidate.name.length() == 8 && candidate.name.equals("clickgui")) {
            found = candidate.keybind;
            break;
         }
      }

      this.lightSlotRect[0] = 0.0F;
      this.lightSlotRect[1] = 0.0F;
      this.lightSlotRect[2] = 0.0F;
      this.lightSlotRect[3] = 0.0F;
      this.darkSlotRect[0] = 0.0F;
      this.darkSlotRect[1] = 0.0F;
      this.keybind = found;
      this.darkSlotRect[2] = 0.0F;
      this.darkSlotRect[3] = 0.0F;
      this.languageRect[0] = 0.0F;
      this.languageRect[1] = 0.0F;
      this.languageRect[2] = 0.0F;
      this.languageRect[3] = 0.0F;
      this.modeLeftRect[0] = 0.0F;
      this.modeLeftRect[1] = 0.0F;
      this.modeLeftRect[2] = 0.0F;
      this.modeLeftRect[3] = 0.0F;
      this.modeRightRect[0] = 0.0F;
      this.modeRightRect[1] = 0.0F;
      this.modeRightRect[2] = 0.0F;
      this.modeRightRect[3] = 0.0F;
      this.rowARect[0] = 0.0F;
      this.rowARect[1] = 0.0F;
      this.rowARect[2] = 0.0F;
      this.rowARect[3] = 0.0F;
      this.rowBRect[0] = 0.0F;
      this.rowBRect[1] = 0.0F;
      this.rowBRect[2] = 0.0F;
      this.rowBRect[3] = 0.0F;
      resetAnimator(this.themeAnim, currentTheme == 1 ? 1.0F : 0.0F, 0.22F, 0);
      resetAnimator(this.modeAnim, modeFlag() == 1 ? 1.0F : 0.0F, 0.22F, 0);
      resetAnimator(this.languageAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.rowAAnim, 0.0F, 0.15F, 0);
      resetAnimator(this.rowBAnim, 0.0F, 0.15F, 0);
      this.listening = false;
      this.pendingKey = 0;
      this.width = 220.0F;
      this.height = 202.0F;
   }

   @Override
   public void dispose() {
      super.dispose();
   }

   @Override
   public boolean keyReleased(int keyCode) {
      if (!this.listening) {
         return false;
      } else {
         int pending = this.pendingKey;
         if (pending != 0 && keyCode == pending) {
            if (this.keybind.key != pending || this.keybind.modifiers != 0) {
               this.keybind.key = pending;
               this.keybind.modifiers = 0;
               if (this.keybind.callback != null) {
                  invokeCallback(this.keybind.callback);
               }
            }

            this.pendingKey = 0;
            this.listening = false;
            this.closeOnEscape = true;
            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   public float overlayConst() {
      return 20.0F;
   }

   public void openAt(Object callback) {
      this.callback = callback;
   }

   @Override
   public void setChild(Component value) {
      super.setChild(value);
   }

   @Override
   public void renderBody(Object mat, float mouseX, float mouseY, float parentAlpha) {
      if (this.listening) {
         Screen.textInputActive = true;
      }

      float clampedLow;
      if (0.0F <= parentAlpha) {
         clampedLow = parentAlpha;
      } else {
         clampedLow = 0.0F;
      }

      float clampedAlpha;
      if (parentAlpha <= 1.0F) {
         clampedAlpha = clampedLow;
      } else {
         clampedAlpha = 1.0F;
      }

      float slideY = (1.0F - clampedAlpha) * 16.0F + this.y;
      makeRect(this.frameRect, mat, parentAlpha, this.width * 0.5F + this.x);
      drawThemedBox(this.frameRect, this.x, slideY, this.width, this.height, 20.0F, parentAlpha);
      float rowX = this.x + 8.0F;
      float rowW = this.width - 16.0F;
      slideY += 8.0F;
      animate(this.themeAnim, currentTheme == 1 ? 1.0F : 0.0F);
      float themeProgress = advance(this.themeAnim, this.now());
      this.drawKeyRow(this.frameRect, rowX, slideY, rowW - 6.0F - 42.0F, themeProgress, this.lightSlotRect, this.darkSlotRect, parentAlpha);
      float lightIconAlpha = parentAlpha;
      if (lightThemeUnavailable) {
         lightIconAlpha = parentAlpha * 0.5F;
      }

      float[] icon = iconMetrics(17);
      float iconWidth = icon[0];
      float iconHeight = icon[1];
      drawIcon(
         this.frameRect,
         17,
         (this.lightSlotRect[2] - iconWidth) * 0.5F + this.lightSlotRect[0],
         (this.lightSlotRect[3] - iconHeight) * 0.5F + this.lightSlotRect[1],
         iconWidth,
         iconHeight,
         themeColor(24),
         lightIconAlpha
      );
      icon = iconMetrics(18);
      iconWidth = icon[0];
      iconHeight = icon[1];
      drawIcon(
         this.frameRect,
         18,
         (this.darkSlotRect[2] - iconWidth) * 0.5F + this.darkSlotRect[0],
         (this.darkSlotRect[3] - iconHeight) * 0.5F + this.darkSlotRect[1],
         iconWidth,
         iconHeight,
         themeColor(24),
         parentAlpha
      );
      this.languageRect[0] = rowW + rowX - 42.0F;
      this.languageRect[1] = slideY;
      this.languageRect[2] = 42.0F;
      this.languageRect[3] = 42.0F;
      drawAccentBox(this.frameRect, this.languageRect[0], slideY, 42.0F, this.languageRect[3], 14.0F, parentAlpha);
      float languageHover = 0.0F;
      if (this.languageRect[0] <= mouseX
         && mouseX <= this.languageRect[0] + this.languageRect[2]
         && this.languageRect[1] <= mouseY
         && mouseY <= this.languageRect[1] + this.languageRect[3]
         && (!hoverGatePointerNull || mouseInsideWindow)) {
         languageHover = 1.0F;
      }

      animate(this.languageAnim, languageHover);
      float buttonX = this.languageRect[0] + 3.0F;
      float buttonY = this.languageRect[1] + 3.0F;
      float buttonProgress = advance(this.languageAnim, this.now());
      int accent = accentColor();
      int accentBlend = mixColor(accent, themeColor(8), 0.85F);
      int buttonColor = mixColor(accent, accentBlend, buttonProgress);
      drawBoxStyled(this.frameRect, buttonX, buttonY, 36.0F, 36.0F, 12.0F, buttonColor, 0.0F, 0.0F, 0, 24.0F, 0.5F, parentAlpha);
      icon = iconMetrics(19);
      iconWidth = icon[0];
      iconHeight = icon[1];
      drawIcon(
         this.frameRect, 19, (36.0F - iconWidth) * 0.5F + buttonX, (36.0F - iconHeight) * 0.5F + buttonY, iconWidth, iconHeight, themeColor(24), parentAlpha
      );
      slideY += 48.0F;
      animate(this.modeAnim, modeFlag() == 1 ? 1.0F : 0.0F);
      float modeProgress = advance(this.modeAnim, this.now());
      this.drawKeyRow(this.frameRect, rowX, slideY, rowW, modeProgress, this.modeLeftRect, this.modeRightRect, parentAlpha);
      modeProgress *= 0.3F;
      float modeAlpha = modeProgress + 0.7F;
      float iconStrip = 20.0F;

      for (int stripIndex = 0; stripIndex < MODE_ICONS.length; stripIndex++) {
         icon = iconMetrics(MODE_ICONS[stripIndex]);
         iconStrip += icon[0];
      }

      float stripY = this.modeLeftRect[3] * 0.5F + this.modeLeftRect[1];
      float stripX = (this.modeLeftRect[2] - iconStrip) * 0.5F + this.modeLeftRect[0];

      for (int iconIndex = 0; iconIndex < MODE_ICONS.length; iconIndex++) {
         int iconId = MODE_ICONS[iconIndex];
         icon = iconMetrics(iconId);
         iconWidth = icon[0];
         iconHeight = icon[1];
         drawIcon(this.frameRect, iconId, stripX, stripY - iconHeight * 0.5F, iconWidth, iconHeight, themeColor(24), (1.0F - modeProgress) * parentAlpha);
         stripX = stripX + iconWidth + 10.0F;
      }

      float hintWidth = measureText(HINT_FONT, localize("SHIFT ALT CTRL"), 11.0F);
      drawText(
         4,
         this.frameRect,
         "SHIFT ALT CTRL",
         (this.modeRightRect[2] - hintWidth) * 0.5F + this.modeRightRect[0],
         (this.modeRightRect[3] - 11.0F) * 0.5F + this.modeRightRect[1],
         11.0F,
         themeColor(24),
         modeAlpha * parentAlpha
      );
      slideY += 48.0F;
      this.rowARect[0] = rowX;
      this.rowARect[1] = slideY;
      this.rowARect[2] = rowW;
      this.rowARect[3] = 42.0F;
      this.drawKeySlot(this.frameRect, this.rowARect, "Панис & Слеан", null, this.rowAAnim, mouseX, mouseY, parentAlpha);
      this.rowBRect[0] = rowX;
      this.rowBRect[1] = slideY + 48.0F;
      this.rowBRect[2] = rowW;
      this.rowBRect[3] = 42.0F;
      SettingsMenu.KeyLabel keyLabel;
      if (this.keybind == null) {
         keyLabel = new SettingsMenu.KeyLabel(0, "");
      } else if (!this.listening) {
         if (this.keybind.key != 0 && modeFlag() != 1) {
            keyLabel = new SettingsMenu.KeyLabel(this.keybind.modifiers, keyName(this.keybind.key));
         } else {
            keyLabel = new SettingsMenu.KeyLabel(0, defaultKeyLabel(this.keybind));
         }
      } else {
         keyLabel = new SettingsMenu.KeyLabel(0, "...");
      }

      if (this.keybind == null) {
         keyLabel = null;
      }

      this.drawKeySlot(this.frameRect, this.rowBRect, "СлискГуи", keyLabel, this.rowBAnim, mouseX, mouseY, parentAlpha);
      if (!lightThemeUnavailable
         || !(this.lightSlotRect[0] <= mouseX)
         || !(mouseX <= this.lightSlotRect[0] + this.lightSlotRect[2])
         || !(this.lightSlotRect[1] <= mouseY)
         || !(mouseY <= this.lightSlotRect[1] + this.lightSlotRect[3])
         || hoverGatePointerNull && !mouseInsideWindow) {
         if ((
               mouseX < this.lightSlotRect[0]
                  || this.lightSlotRect[0] + this.lightSlotRect[2] < mouseX
                  || mouseY < this.lightSlotRect[1]
                  || this.lightSlotRect[1] + this.lightSlotRect[3] < mouseY
                  || hoverGatePointerNull && !mouseInsideWindow
            )
            && (
               mouseX < this.darkSlotRect[0]
                  || this.darkSlotRect[0] + this.darkSlotRect[2] < mouseX
                  || mouseY < this.darkSlotRect[1]
                  || this.darkSlotRect[1] + this.darkSlotRect[3] < mouseY
                  || hoverGatePointerNull && !mouseInsideWindow
            )
            && (
               mouseX < this.languageRect[0]
                  || this.languageRect[0] + this.languageRect[2] < mouseX
                  || mouseY < this.languageRect[1]
                  || this.languageRect[1] + this.languageRect[3] < mouseY
                  || hoverGatePointerNull && !mouseInsideWindow
            )
            && (
               mouseX < this.modeLeftRect[0]
                  || this.modeLeftRect[0] + this.modeLeftRect[2] < mouseX
                  || mouseY < this.modeLeftRect[1]
                  || this.modeLeftRect[1] + this.modeLeftRect[3] < mouseY
                  || hoverGatePointerNull && !mouseInsideWindow
            )
            && (
               mouseX < this.modeRightRect[0]
                  || this.modeRightRect[0] + this.modeRightRect[2] < mouseX
                  || mouseY < this.modeRightRect[1]
                  || this.modeRightRect[1] + this.modeRightRect[3] < mouseY
                  || hoverGatePointerNull && !mouseInsideWindow
            )
            && (
               mouseX < this.rowARect[0]
                  || this.rowARect[0] + this.rowARect[2] < mouseX
                  || mouseY < this.rowARect[1]
                  || this.rowARect[1] + this.rowARect[3] < mouseY
                  || hoverGatePointerNull && !mouseInsideWindow
            )) {
            if (this.keybind == null) {
               return;
            }

            if (mouseX < this.rowBRect[0]
               || this.rowBRect[0] + this.rowBRect[2] < mouseX
               || mouseY < this.rowBRect[1]
               || this.rowBRect[1] + this.rowBRect[3] < mouseY
               || hoverGatePointerNull && !mouseInsideWindow) {
               return;
            }
         }

         Screen.hoveredWidget = 1;
      } else {
         Screen.hoveredWidget = 7;
      }
   }

   @Override
   public boolean onMouseClicked(double mouseX, double mouseY, int button) {
      if (this.listening) {
         this.listening = false;
         this.pendingKey = 0;
         this.closeOnEscape = true;
         return true;
      } else {
         if (button == 0) {
            if (this.lightSlotRect[0] <= mouseX
               && mouseX <= this.lightSlotRect[0] + this.lightSlotRect[2]
               && this.lightSlotRect[1] <= mouseY
               && mouseY <= this.lightSlotRect[1] + this.lightSlotRect[3]) {
               if (lightThemeUnavailable) {
                  return true;
               }

               uiSound(14);
               setTheme(0);
               return true;
            }

            if (this.darkSlotRect[0] <= mouseX
               && mouseX <= this.darkSlotRect[0] + this.darkSlotRect[2]
               && this.darkSlotRect[1] <= mouseY
               && mouseY <= this.darkSlotRect[1] + this.darkSlotRect[3]) {
               uiSound(14);
               setTheme(1);
               return true;
            }

            if (this.languageRect[0] <= mouseX
               && mouseX <= this.languageRect[0] + this.languageRect[2]
               && this.languageRect[1] <= mouseY
               && mouseY <= this.languageRect[1] + this.languageRect[3]) {
               uiSound(14);
               russianActive = !russianActive;
               return true;
            }

            if (this.modeLeftRect[0] <= mouseX
               && mouseX <= this.modeLeftRect[0] + this.modeLeftRect[2]
               && this.modeLeftRect[1] <= mouseY
               && mouseY <= this.modeLeftRect[1] + this.modeLeftRect[3]) {
               uiSound(14);
               setModeFlag(0);
               return true;
            }

            if (this.modeRightRect[0] <= mouseX
               && mouseX <= this.modeRightRect[0] + this.modeRightRect[2]
               && this.modeRightRect[1] <= mouseY
               && mouseY <= this.modeRightRect[1] + this.modeRightRect[3]) {
               uiSound(14);
               setModeFlag(1);
               return true;
            }

            if (this.rowARect[0] <= mouseX
               && mouseX <= this.rowARect[0] + this.rowARect[2]
               && this.rowARect[1] <= mouseY
               && mouseY <= this.rowARect[1] + this.rowARect[3]) {
               uiSound(14);
               if (this.callback != null) {
                  invokeCallback(this.callback);
               }

               this.close();
               return true;
            }

            if (this.rowBRect[0] <= mouseX
               && mouseX <= this.rowBRect[0] + this.rowBRect[2]
               && this.rowBRect[1] <= mouseY
               && mouseY <= this.rowBRect[1] + this.rowBRect[3]
               && this.keybind != null) {
               uiSound(14);
               this.listening = true;
               this.pendingKey = 0;
               this.closeOnEscape = false;
            }
         }

         return true;
      }
   }

   @Override
   public boolean onKeyPressed(int keyCode, int modifiers) {
      if (!this.listening) {
         return false;
      } else if (keyCode == 27) {
         this.listening = false;
         this.pendingKey = 0;
         this.closeOnEscape = true;
         return true;
      } else if (2L < (keyCode - 16 & 4294967295L) && 5L < (keyCode - 160 & 4294967295L)) {
         if (this.keybind.key != keyCode || this.keybind.modifiers != modifiers) {
            this.keybind.key = keyCode;
            this.keybind.modifiers = modifiers;
            if (this.keybind.callback != null) {
               invokeCallback(this.keybind.callback);
            }
         }

         this.listening = false;
         this.pendingKey = 0;
         this.closeOnEscape = true;
         return true;
      } else {
         this.pendingKey = keyCode;
         return true;
      }
   }

   @Override
   public void onClosed() {
      this.listening = false;
      this.pendingKey = 0;
      this.closeOnEscape = true;
   }

   protected void drawKeyRow(Object mat, float x, float y, float width, float progress, float[] outA, float[] outB, float alpha) {
      drawThemedBox(mat, x, y, width, 42.0F, 14.0F, alpha);
      float chipX = x + 3.0F;
      float chipY = y + 3.0F;
      float chipW = (width - 6.0F - 2.0F) * 0.5F;
      float shift = chipX + chipW + 2.0F;
      int chipColor = accentColor();
      drawChipBox(mat, (shift - chipX) * progress + chipX, chipY, chipW, 36.0F, 12.0F, chipColor, alpha);
      outA[0] = chipX;
      outA[1] = chipY;
      outA[2] = chipW;
      outA[3] = 36.0F;
      outB[0] = shift;
      outB[1] = chipY;
      outB[2] = chipW;
      outB[3] = 36.0F;
   }

   protected void drawKeySlot(
      Object mat, float[] rect, String title, SettingsMenu.KeyLabel key, AbstractOverlay.Animator hoverAnim, float mouseX, float mouseY, float alpha
   ) {
      drawThemedBox(mat, rect[0], rect[1], rect[2], rect[3], 14.0F, alpha);
      float hoverTarget = 1.0F;
      if (mouseX < rect[0] || rect[0] + rect[2] < mouseX || mouseY < rect[1] || rect[1] + rect[3] < mouseY || hoverGatePointerNull && !mouseInsideWindow) {
         hoverTarget = 0.0F;
      }

      animate(hoverAnim, hoverTarget);
      float chipX = rect[0] + 3.0F;
      float chipY = rect[1] + 3.0F;
      float chipW = rect[2] - 6.0F;
      float hover = advance(hoverAnim, this.now());
      int accent = accentColor();
      int accentBlend = mixColor(accent, themeColor(8), 0.85F);
      int chipColor = mixColor(accent, accentBlend, hover);
      drawBoxStyled(mat, chipX, chipY, chipW, 36.0F, 12.0F, chipColor, 0.0F, 0.0F, 0, 24.0F, 0.5F, alpha);
      float labelY = chipY + 18.0F;
      float labelWidth = 0.0F;
      if (key != null) {
         float[] icon = iconMetrics(21);
         float iconWidth = icon[0];
         float iconHeight = icon[1];
         float modifierWidth = measureModifierWidth(key.modifiers, 12.0F);
         float keyWidth = measureText(LABEL_FONT, localize(key.text), 12.0F);
         labelWidth = iconWidth + 16.0F + 4.0F + modifierWidth + keyWidth;
         float labelX = chipW + chipX - 8.0F - labelWidth;
         drawHoverPill(mat, labelX, labelY - 12.0F, labelWidth, 24.0F, alpha * 0.3F);
         labelX += 8.0F;
         drawIcon(mat, 21, labelX, labelY - iconHeight * 0.5F, iconWidth, iconHeight, themeColor(24), alpha * 0.3F);
         float penX = drawModifierText(mat, key, labelX + iconWidth + 4.0F, labelY - 6.0F, 12.0F, themeColor(24), alpha * 0.3F);
         drawText(5, mat, key.text, penX, labelY - 6.0F, 12.0F, themeColor(24), alpha * 0.3F);
         labelWidth += 8.0F;
      }

      drawText(5, mat, wrapText(title, chipW - 16.0F - labelWidth, 14.0F), chipX + 8.0F, labelY - 6.0F, 14.0F, themeColor(24), alpha);
   }

   private static void ensureRegistryInitialized() {
   }

   private static int modeFlag() {
      return modePrefixed ? 1 : 0;
   }

   private static void setModeFlag(int value) {
      modePrefixed = value == 1;
   }

   private static void setTheme(int index) {
      if (index != currentTheme && (!lightThemeUnavailable || index != 0)) {
         currentTheme = index;
      }
   }

   private static void invokeCallback(Object value) {
   }

   private static int themeColor(int index) {
      return 0;
   }

   private static int accentColor() {
      return 0;
   }

   private static float[] iconMetrics(int icon) {
      return new float[2];
   }

   private static float measureText(Object font, String text, float size) {
      return 0.0F;
   }

   private static float measureModifierWidth(int modifiers, float size) {
      return 0.0F;
   }

   private static String localize(String text) {
      return text;
   }

   private static String keyName(int keyCode) {
      return "";
   }

   private static String defaultKeyLabel(SettingsMenu.KeyEntry entry) {
      if (entry.key == 0) {
         return "None";
      } else {
         StringBuilder builder = new StringBuilder();
         if ((entry.modifiers & 2) != 0) {
            builder.append("CTRL + ");
         }

         if ((entry.modifiers & 1) != 0) {
            builder.append("SHIFT + ");
         }

         if ((entry.modifiers & 4) != 0) {
            builder.append("ALT + ");
         }

         builder.append(keyName(entry.key));
         return builder.toString();
      }
   }

   private static String wrapText(String text, float maxWidth, float size) {
      return text;
   }

   private static float[] makeRect(float[] out, Object mat, float alpha, float x) {
      return out;
   }

   private static void drawThemedBox(Object mat, float x, float y, float width, float height, float radius, float alpha) {
   }

   private static void drawAccentBox(Object mat, float x, float y, float width, float height, float radius, float alpha) {
   }

   private static void drawBoxStyled(
      Object mat,
      float x,
      float y,
      float width,
      float height,
      float radius,
      int color,
      float fadeA,
      float fadeB,
      int border,
      float spread,
      float scale,
      float alpha
   ) {
   }

   private static void drawChipBox(Object mat, float x, float y, float width, float height, float radius, int color, float alpha) {
   }

   private static void drawHoverPill(Object mat, float x, float y, float width, float radius, float alpha) {
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float width, float height, int color, float alpha) {
   }

   private static void drawText(int style, Object mat, String text, float x, float y, float size, int color, float alpha) {
   }

   private static float drawModifierText(Object mat, SettingsMenu.KeyLabel key, float x, float y, float size, int color, float alpha) {
      return x;
   }

   public static final class ConfigEntry {
      public String name = "";
      public SettingsMenu.KeyEntry keybind;
   }

   public static final class KeyEntry {
      public Object callback;
      public int key;
      public int modifiers;
   }

   public static final class KeyLabel {
      public int modifiers;
      public String text;

      public KeyLabel(int modifiers, String text) {
         this.modifiers = modifiers;
         this.text = text;
      }
   }
}

