package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class KeysPanel extends Component {
   public static final int X_OFFSET = 8;
   public static final int Y_OFFSET = 12;
   public static final int WIDTH_OFFSET = 16;
   public static final int HEIGHT_OFFSET = 20;
   public static final int FLAGS_OFFSET = 24;
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int NAME_OFFSET = 96;
   public static final int KEY_INFOS_OFFSET = 128;
   public static final int KEY_INFOS_END_OFFSET = 136;
   public static final int KEY_INFOS_CAP_OFFSET = 144;
   public static final int HIDE_CATEGORIES_OFFSET = 152;
   public static final int VISIBLE_OFFSET = 153;
   public static final int HOST_STORAGE_OFFSET = 160;
   public static final int HOST_OFFSET = 216;
   public static final int ALPHA_ANIM_OFFSET = 224;
   public static final int COPY_ANIM_OFFSET = 264;
   public static final int CREATE_ANIM_OFFSET = 304;
   public static final int HINT_ANIM_OFFSET = 344;
   public static final int ROW_ANIM_CACHE_OFFSET = 384;
   public static final int ROW_ANIM_CACHE_AUX_OFFSET = 392;
   public static final int ROW_ANIM_CACHE_BUCKETS_OFFSET = 408;
   public static final int GLYPH_ANIM_CACHE_OFFSET = 448;
   public static final int GLYPH_ANIM_CACHE_AUX_OFFSET = 456;
   public static final int GLYPH_ANIM_CACHE_BUCKETS_OFFSET = 472;
   public static final int ROWS_OFFSET = 512;
   public static final int ROWS_END_OFFSET = 520;
   public static final int ROWS_CAP_OFFSET = 528;
   public static final int ROW_GAP_OFFSET = 536;
   public static final int FRAME_TIMER_OFFSET = 544;
   public static final int SCROLL_ANIM_OFFSET = 552;
   public static final int SCROLL_OFFSET = 592;
   public static final int SCROLL_FRAME_OFFSET = 596;
   public static final int SCROLL_FRAME_VALID_OFFSET = 600;
   public static final int DRAGGING_OFFSET = 601;
   public static final int DRAG_OFFSET_OFFSET = 604;
   public static final int INFO_NAME_OFFSET = 0;
   public static final int INFO_LENGTH_OFFSET = 16;
   public static final int INFO_CATEGORY_OFFSET = 32;
   public static final int ROW_INFO_OFFSET = 0;
   public static final int ROW_RATE_OFFSET = 16;
   public static final int ROW_ALPHA_OFFSET = 20;
   public static final int ROW_VISIBLE_OFFSET = 24;
   public static final int ROW_DELAY_OFFSET = 28;
   public static final int ROW_EASE_OFFSET = 32;
   public static final int ROW_SMOOTH_OFFSET = 40;
   public static final int ROW_INITIALIZED_OFFSET = 41;
   public static final int ROW_CURRENT_Y_OFFSET = 44;
   public static final int ROW_TARGET_Y_OFFSET = 48;
   public static final int CACHE_VALUE_OFFSET = 0;
   public static final int CACHE_HEAD_OFFSET = 8;
   public static final int CACHE_COUNT_OFFSET = 16;
   public static final int CACHE_BUCKETS_OFFSET = 24;
   public static final int CACHE_MASK_OFFSET = 48;
   public static final int CACHE_BUCKET_COUNT_OFFSET = 56;
   public static final float WIDTH = 276.0F;
   public static final float HEIGHT = 288.0F;
   public static final float PAD = 12.0F;
   public static final float GAP = 4.0F;
   public static final float GAP6 = 6.0F;
   public static final float GAP8 = 8.0F;
   public static final float ROW_HEIGHT = 20.0F;
   public static final float LIST_WIDTH = 252.0F;
   public static final float HEADER_BLOCK = 32.0F;
   public static final float BTN_WIDTH = 120.0F;
   public static final float BTN_HEIGHT = 26.0F;
   public static final float BTN_INSET = 3.0F;
   public static final float PANEL_RADIUS = 14.0F;
   public static final float SCROLLBAR_WIDTH = 40.0F;
   public static final float SCROLLBAR_GRAB = 6.0F;
   public static final float SCROLL_STEP = 24.0F;
   public static final float CLOSE_Y = 14.0F;
   public static final float CLOSE_SIZE = 16.0F;
   public static final float SLIDE_IN = 16.0F;
   public static final float GLYPH_SIZE = 8.0F;
   public static final float LABEL_X = 138.0F;
   public static final float LABEL_Y = 144.0F;
   public static final float SUBTITLE_SIZE = 12.0F;
   public static final float SUBTITLE_WIDTH = 224.0F;
   public static final float SUBTITLE_LINE = 14.4F;
   public static final float ROW_RATE = 4.5F;
   public static final float ROW_GAP = 4.0F;
   public static final float MENU_TITLE_SIZE = 12.0F;
   public static final float BUTTON_TEXT_SIZE = 12.0F;
   public static final float BUTTON_TEXT_INSET = 7.0F;
   public static final float ROW_TEXT_INSET = 6.0F;
   public static final float ROW_GLYPH_INSET = 3.0F;
   public static final float ROW_GLYPH_SPACING = 14.0F;
   public static final float ROW_CONTROL_WIDTH = 13.0F;
   public static final float ROW_CONTROL_HEIGHT = 14.0F;
   public static final float ROW_RESERVED = 11.0F;
   public static final float TEXT_ALPHA = 0.85F;
   public static final float BUTTON_MIX = 0.45F;
   public static final float HINT_DELAY = 1.5F;
   public static final float ANIM_DURATION = 0.15F;
   public static final float FADE_DURATION = 0.22F;
   public static final float SCROLL_DURATION = 0.32F;
   public static final float HINT_DURATION = 0.3F;
   public static final float DEFAULT_STEP = 0.016666668F;
   public static final float MAX_STEP = 0.1F;
   public static final float ALPHA_EPS = 0.001F;
   public static final float NEAR_ONE = 0.999F;
   public static final float HALF = 0.5F;
   public static final float SPRING_EPS = 0.05F;
   public static final float SPRING_SMOOTH = 14.0F;
   public static final float ONE = 1.0F;
   public static final int ICON_CLOSE = 22;
   public static final int ICON_KEY = 54;
   public static final int ICON_REMOVE = 32;
   public static final int ICON_MARK = 20;
   public static final int SHAPE_ROUNDED_QUAD = 4;
   public static final int SHAPE_TEXT = 2;
   public static final int SHAPE_GLYPH = 0;
   public static final int PANEL_SHADOW = 436207616;
   public static final int THEME_BACKGROUND = 0;
   public static final int THEME_ROW = 4;
   public static final int THEME_SURFACE = 8;
   public static final int THEME_TEXT = 16;
   public static final int THEME_HEADER = 24;
   public static final int THEME_ACCENT = 28;
   public static final int SOUND_OPEN = 10;
   public static final int SOUND_CREATE = 12;
   public static final int SOUND_DELETE = 13;
   public static final int SOUND_ACTION = 14;
   public static final int CURSOR_HAND = 1;
   public static final int CURSOR_RESIZE = 4;
   public static final int CLOSE_KEY = 27;
   public static final String TITLE = "Приватные ключи";
   public static final String SUBTITLE = "Управляйте своими приватными ключами.";
   public static final String LABEL_CREATE = "Создать";
   public static final String LABEL_COPY = "Скопировать";
   protected final KeysPanel.Anim rectAnim = new KeysPanel.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected String name = "";
   protected final List<KeysPanel.KeyInfo> keyInfos = new ArrayList<>();
   protected boolean hideCategories;
   protected boolean visible;
   protected final byte[] hostStorage = new byte[56];
   protected Component host;
   protected final KeysPanel.Anim alphaAnim = new KeysPanel.Anim();
   protected final KeysPanel.Anim copyAnim = new KeysPanel.Anim();
   protected final KeysPanel.Anim createAnim = new KeysPanel.Anim();
   protected final KeysPanel.Anim hintAnim = new KeysPanel.Anim();
   protected final KeysPanel.AnimCache rowAnimCache = new KeysPanel.AnimCache();
   protected final KeysPanel.AnimCache glyphAnimCache = new KeysPanel.AnimCache();
   protected final List<KeysPanel.KeyRow> rows = new ArrayList<>();
   protected float rowGap = 4.0F;
   protected long frameTimer = -1L;
   protected final KeysPanel.Anim scrollAnim = new KeysPanel.Anim();
   protected float scroll;
   protected float scrollFrame;
   protected boolean scrollFrameValid;
   protected boolean dragging;
   protected float dragOffset;
   protected String clipboardText;
   protected String lastCreated;
   private static List<KeysPanel.CacheEntry> staticCache;

   public KeysPanel() {
      this("");
   }

   public KeysPanel(String name) {
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.flags = 256;
      initAnim(this.rectAnim, 0.0F, 0.15F, 0);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.name = name != null ? name : "";
      this.keyInfos.clear();
      this.hideCategories = false;
      this.visible = false;
      this.host = null;
      this.alphaAnim.set(0.0F, 0.22F);
      initAnim(this.copyAnim, 0.0F, 0.15F, 0);
      initAnim(this.createAnim, 0.0F, 0.15F, 0);
      initAnim(this.hintAnim, 0.0F, 0.3F, 2);
      this.rowAnimCache.init();
      this.glyphAnimCache.init();
      this.rows.clear();
      this.rowGap = 4.0F;
      this.frameTimer = -1L;
      this.scrollAnim.set(0.0F, 0.32F);
      this.scrollAnim.easing = 1;
      this.scroll = 0.0F;
      this.scrollFrame = 0.0F;
      this.scrollFrameValid = false;
      this.dragging = false;
      this.dragOffset = 0.0F;
      this.width = 276.0F;
      this.height = 288.0F;
   }

   @Override
   public void dispose() {
      resetString(96);
      this.releaseKeyInfos();
      this.shrinkKeyInfos();
      this.rowAnimCache.disposeNodes();
      this.glyphAnimCache.disposeNodes();
      this.removeRows();
      this.shrinkRows();
      this.releaseHost();
      this.freeRows();
      this.glyphAnimCache.disposeBuckets();
      this.glyphAnimCache.disposeNodes();
      this.rowAnimCache.disposeBuckets();
      this.rowAnimCache.disposeNodes();
      this.releaseHost();
      this.freeKeyInfos();
      freeString(96);
      super.dispose();
   }

   public void open(Component hostComponent) {
      if (this.host != hostComponent) {
         if (this.host != null) {
            this.releaseHost();
         }

         this.host = hostComponent;
      }

      if (this.host != null) {
         this.x = this.host.getX();
         this.y = this.host.getY();
      }

      this.visible = true;
      playSound(10);
      this.keyInfos.clear();
      KeysPanel.CacheEntry entry = staticCacheFind(this.name);
      if (entry != null) {
         this.keyInfos.addAll(entry.infos);
      }

      this.refresh();
   }

   public void refresh() {
      this.listKeys(this.name, new Consumer<List<KeysPanel.KeyInfo>>() {
         public void accept(List<KeysPanel.KeyInfo> keys) {
            KeysPanel.this.refreshCallback(keys);
         }
      });
   }

   private void refreshCallback(List<KeysPanel.KeyInfo> keys) {
      if (keys != this.keyInfos) {
         this.keyInfos.clear();
         if (keys != null) {
            this.keyInfos.addAll(keys);
         }
      }

      KeysPanel.CacheEntry entry = staticCacheGet(this.name);
      if (entry != null) {
         entry.infos.clear();
         entry.infos.addAll(this.keyInfos);
      }
   }

   private List<String> collectEntries() {
      List<String> main = new ArrayList<>();
      List<String> separators = new ArrayList<>();

      for (int i = 0; i < this.keyInfos.size(); i++) {
         KeysPanel.KeyInfo info = this.keyInfos.get(i);
         if (info.category == 0) {
            main.add(info.name);
         } else if (!this.hideCategories) {
            separators.add(info.name);
         }
      }

      return main;
   }

   private KeysPanel.KeyInfo findKeyInfo(String value) {
      for (int i = 0; i < this.keyInfos.size(); i++) {
         KeysPanel.KeyInfo info = this.keyInfos.get(i);
         if (info.name.compareTo(value) == 0) {
            return info;
         }
      }

      return null;
   }

   public float listTop(float baseY) {
      return measureWrappedText("Управляйте своими приватными ключами.", 12.0F, 224.0F) * 14.4F + 32.0F + baseY + 8.0F;
   }

   private float scrollGauge(int count, float viewport) {
      if (count < 1) {
         float value = 0.0F - viewport;
         if (value <= 0.0F) {
            value = 0.0F;
         }

         return value;
      } else {
         float value = (count - 1) * 4.0F + count * 20.0F + 8.0F - viewport;
         if (value <= 0.0F) {
            value = 0.0F;
         }

         return value;
      }
   }

   @Override
   public void syncRows() {
      List<String> names = this.collectEntries();
      this.ensureRows(names, 0.0F);

      for (int i = 0; i < this.rows.size(); i++) {
         KeysPanel.KeyRow row = this.rows.get(i);

         for (int j = 0; j < this.keyInfos.size(); j++) {
            KeysPanel.KeyInfo info = this.keyInfos.get(j);
            if (info.name.compareTo(rowName(row)) == 0) {
               row.info = info;
               break;
            }
         }
      }

      this.syncRowOrder(names);
      float delta = this.frameDelta();

      for (int i = 0; i < this.rows.size(); i++) {
         this.springStep(this.rows.get(i), delta);
      }

      this.removeHiddenRows();
   }

   private void ensureRows(List<String> names, float stagger) {
      int index = 0;

      for (int i = 0; i < names.size(); i++) {
         String value = names.get(i);
         KeysPanel.KeyRow match = this.findRow(value);
         if (match != null) {
            if (!match.visible) {
               match.visible = true;
               match.delay = 0.0F;
            }
         } else {
            KeysPanel.KeyRow row = this.createRow(value);
            if (row != null) {
               if (!row.visible) {
                  if (stagger <= 0.0F) {
                     row.delay = 0.0F;
                  } else {
                     float delay = index * stagger;
                     if (delay <= 0.0F) {
                        delay = 0.0F;
                     }

                     row.delay = delay;
                  }

                  row.visible = true;
               }

               this.rows.add(row);
               index++;
            }
         }
      }

      int hidden = 0;

      for (int ix = 0; ix < this.rows.size(); ix++) {
         KeysPanel.KeyRow row = this.rows.get(ix);
         if (findName(names, rowName(row)) == null && row.visible) {
            float delay;
            if (stagger <= 0.0F) {
               delay = 0.0F;
            } else {
               delay = hidden * stagger;
               if (delay <= 0.0F) {
                  delay = 0.0F;
               }
            }

            row.visible = false;
            row.delay = delay;
            hidden++;
         }
      }
   }

   private KeysPanel.KeyRow createRow(String value) {
      KeysPanel.KeyInfo info = this.findKeyInfo(value);
      if (info == null) {
         return null;
      } else {
         KeysPanel.KeyRow row = new KeysPanel.KeyRow();
         row.info = info;
         row.rate = 4.5F;
         row.alpha = 0.0F;
         row.visible = false;
         row.delay = 0.0F;
         row.smooth = true;
         row.initialized = false;
         row.currentY = 0.0F;
         row.targetY = 0.0F;
         return row;
      }
   }

   private void syncRowOrder(List<String> names) {
      List<KeysPanel.KeyRow> ordered = new ArrayList<>();

      for (int i = 0; i < names.size(); i++) {
         String value = names.get(i);
         KeysPanel.KeyRow match = this.findRow(value);
         if (match != null) {
            ordered.add(match);
         }
      }

      for (int ix = 0; ix < this.rows.size(); ix++) {
         KeysPanel.KeyRow row = this.rows.get(ix);
         if (!ordered.contains(row)) {
            ordered.add(row);
         }
      }

      this.rows.clear();
      this.rows.addAll(ordered);
   }

   private void removeHiddenRows() {
      for (int i = this.rows.size() - 1; i >= 0; i--) {
         KeysPanel.KeyRow row = this.rows.get(i);
         if (!row.visible && row.alpha <= 0.001F) {
            this.rows.remove(i);
         }
      }
   }

   private float frameDelta() {
      long previous = this.frameTimer;
      long current = KeysPanel.Anim.now();
      this.frameTimer = current;
      if (previous < 0L) {
         return 0.016666668F;
      } else {
         float delta = (float)((current - previous) / 1.0E9);
         float value = 0.0F;
         if (0.0F <= delta && delta <= 0.1F) {
            value = delta;
         }

         return value;
      }
   }

   private void springStep(KeysPanel.KeyRow row, float dt) {
      float delay = row.delay;
      float step = dt;
      if (0.0F < delay) {
         if (dt < delay) {
            row.delay = delay - dt;
            step = 0.0F;
         } else {
            row.delay = 0.0F;
            step = dt - delay;
         }
      }

      float value;
      if (!row.visible) {
         value = row.alpha - step * row.rate;
         if (value <= 0.0F) {
            value = 0.0F;
         }
      } else {
         value = step * row.rate + row.alpha;
         if (1.0F <= value) {
            value = 1.0F;
         }
      }

      row.alpha = value;
      if (row.smooth && row.initialized) {
         float diff = row.targetY - row.currentY;
         if (Math.abs(diff) < 0.05F) {
            row.currentY = row.targetY;
            return;
         }

         float k = dt * 14.0F;
         if (1.0F <= k) {
            k = 1.0F;
         }

         row.currentY += k * diff;
      }
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      float target = this.visible ? 1.0F : 0.0F;
      if (this.alphaAnim.target != target) {
         long time = KeysPanel.Anim.now();
         float value = this.alphaAnim.advance(time);
         this.alphaAnim.from = value;
         this.alphaAnim.target = target;
         this.alphaAnim.start = time;
         this.alphaAnim.running = true;
      }

      float fade = this.alphaAnim.advance(KeysPanel.Anim.now());
      if (0.001F < fade) {
         if (this.host != null) {
            this.x = this.host.getX();
            this.y = this.host.getY();
         }

         this.syncRows();
         float scaled = fade * alpha;
         float rowY = (1.0F - clamp01(fade)) * 16.0F + this.y;
         pushScissor(mat, fade, this.x + 138.0F, rowY + 144.0F);
         Object rect = makeRect(this.x, rowY, 276.0F, 288.0F, 14.0F);
         float left = this.x + 12.0F;
         float top = rowY + 12.0F;
         drawRoundedQuad(mat, rect, left, top, 14.0F, themeColor(24), scaled);
         drawIcon(mat, rect, 22, this.x + 276.0F - 12.0F - 8.0F, rowY + 14.0F, 8.0F, themeColor(16), scaled);
         drawText(mat, rect, "Приватные ключи", left, top + 14.0F + 4.0F, 12.0F, 224.0F, themeColor(16), scaled);
         float panelTop = this.listTop(rowY);
         drawPanel(mat, rect, left, panelTop, 252.0F, 32.0F, 14.0F, themeColor(8), 436207616, 8.0F, scaled);
         float buttonY = panelTop + 3.0F;
         float buttonX = left + 4.0F;
         this.drawButton(mat, buttonX, buttonY, 120.0F, "Скопировать", this.copyAnim, this.hintAnim, mouseX, mouseY, scaled);
         this.drawButton(mat, buttonX + 120.0F + 4.0F, buttonY, 120.0F, "Создать", this.createAnim, null, mouseX, mouseY, scaled);
         this.drawKeyList(mat, mouseX, mouseY, rowY, scaled);
         if (!this.dragging) {
            float closeY = this.y + 14.0F - 4.0F;
            float closeX = this.x + 276.0F - 12.0F - 8.0F - 4.0F;
            if (closeX <= mouseX && mouseX <= closeX + 16.0F && closeY <= mouseY && mouseY <= closeY + 16.0F) {
               Screen.hoveredWidget = 1;
            }
         } else {
            Screen.hoveredWidget = 4;
         }

         popScissor();
      } else if (!this.visible && this.host != null) {
         this.releaseHost();
      }
   }

   private void drawButton(
      Object mat, float x, float y, float w, String label, KeysPanel.Anim hoverAnim, KeysPanel.Anim hintAnim, float mouseX, float mouseY, float alpha
   ) {
      float hover = 1.0F;
      if (!(mouseX < x) && !(x + w < mouseX) && !(mouseY < y) && !(y + 26.0F < mouseY)) {
         Screen.hoveredWidget = 1;
      } else {
         hover = 0.0F;
      }

      retarget(hoverAnim, hover);
      int color = mixColor(themeColor(8), themeColor(24), 0.85F);
      color = mixColor(themeColor(0), color, hoverAnim.advance(KeysPanel.Anim.now()));
      if (hintAnim != null) {
         float hint = hintAnim.advance(KeysPanel.Anim.now());
         if (0.5F < hintAnim.target && 0.999F < hint) {
            delayedRetarget(hintAnim, 0.0F, 1.5F);
         }

         if (0.001F < hint) {
            hint *= 0.45F;
            color = mixColor(color, themeColor(28), hint);
         }
      }

      drawPanel(mat, null, x, y, w, 26.0F, 6.0F, color, 436207616, 1.0F, alpha);
      float textWidth = measureText(label, 12.0F);
      float textX = (w - textWidth) * 0.5F + x;
      drawText(mat, null, label, textX, y + 7.0F, 12.0F, w, themeColor(24), alpha);
   }

   private void drawKeyList(Object mat, float mouseX, float mouseY, float baseY, float alpha) {
      float left = this.x + 12.0F;
      float panelTop = this.listTop(baseY);
      float innerTop = panelTop + 32.0F + 6.0F;
      float bottom = baseY + 288.0F - (panelTop + 32.0F + 6.0F) - 12.0F;
      drawListBackground(mat, left, innerTop, 252.0F, bottom, 8.0F, alpha);
      float rowLeft = left + 4.0F;
      float rowRight = left + 252.0F - 4.0F;
      int count = this.rows.size();
      float content;
      float viewRight;
      if (count < 7) {
         viewRight = rowRight;
         if (count < 1) {
            content = 0.0F;
         } else {
            content = (count - 1) * 4.0F + count * 20.0F + 8.0F;
         }
      } else {
         viewRight = rowRight - 6.0F - 4.0F;
         content = (count - 1) * 4.0F + count * 20.0F + 8.0F;
      }

      float gauge = content - bottom;
      if (gauge <= 0.0F) {
         gauge = 0.0F;
      }

      float clamped = clampScroll(this.scroll, gauge);
      this.scroll = clamped;
      if (!this.scrollFrameValid || clamped != this.scrollFrame) {
         retarget(this.scrollAnim, clamped);
         this.scrollFrame = this.scroll;
         this.scrollFrameValid = true;
      }

      float scrollValue = this.scrollAnim.advance(KeysPanel.Anim.now());
      float origin = innerTop + 4.0F;
      float rowY = origin - scrollValue;
      boolean first = true;

      for (int i = 0; i < this.rows.size(); i++) {
         KeysPanel.KeyRow row = this.rows.get(i);
         float reveal = rowReveal(row);
         if (!first) {
            rowY += reveal * this.rowGap;
         }

         first = false;
         row.targetY = rowY;
         if (!row.initialized) {
            row.currentY = rowY;
            row.initialized = true;
         }

         rowY += reveal * 20.0F;
      }

      pushListLayer();

      for (int i = 0; i < this.rows.size(); i++) {
         KeysPanel.KeyRow rowx = this.rows.get(i);
         float revealx = rowReveal(rowx);
         if (0.0F < revealx) {
            float currentY = rowx.currentY;
            if (innerTop <= currentY + 4.0F && currentY <= bottom + innerTop) {
               this.drawRow(mat, rowx.info, currentY, rowLeft, viewRight - rowLeft, mouseX, mouseY, revealx * alpha);
            }
         }
      }

      popListLayer();
      if (6 < count) {
         float barX = viewRight - 6.0F;
         float thumb;
         if (content <= 0.0F) {
            thumb = 0.0F;
         } else {
            thumb = (bottom + innerTop - 4.0F - origin - 40.0F) * (scrollValue / gauge);
         }

         drawPanel(mat, null, barX, thumb + origin, 6.0F, 40.0F, 4.0F, themeColor(4), 436207616, 6.0F, alpha);
      }
   }

   private void drawRow(Object mat, KeysPanel.KeyInfo info, float x, float y, float w, float mouseX, float mouseY, float alpha) {
      KeysPanel.Anim anim = rowAnim(this.rowAnimCache, info);
      float hover = 0.0F;
      if (!(mouseX < x) && !(x + w < mouseX) && !(mouseY < y) && !(y + 20.0F < mouseY)) {
         Screen.hoveredWidget = 1;
         if (info != null && info.category != 0) {
            hover = 0.0F;
         } else {
            hover = 1.0F;
         }
      }

      retarget(anim, hover);
      int color = mixColor(themeColor(4), themeColor(8), 0.85F);
      if (info != null && info.category == 0) {
         color = mixColor(themeColor(4), color, anim.advance(KeysPanel.Anim.now()));
      }

      drawPanel(mat, null, x, y, w, 20.0F, 6.0F, color, 436207616, 6.0F, alpha);
      float controlY = y + 3.0F;
      drawIcon(mat, null, 54, x + 6.0F, controlY, 14.0F, themeColor(16), alpha);
      float rightX = x + w - 6.0F;
      float controlX = rightX - 13.0F;
      float textX = x + 6.0F + 14.0F + 6.0F;
      int textColor = info != null && info.category == 0 ? themeColor(16) : themeColor(24);
      float avail = controlX - 6.0F - textX;
      if (avail <= 0.0F) {
         avail = 0.0F;
      }

      String label = ellipsize(info == null ? "" : info.name, avail, 12.0F);
      drawText(mat, null, label, textX, controlY, 12.0F, avail, textColor, alpha);
      int icon;
      int iconColor;
      if (info != null && info.category != 0) {
         controlY = y + 6.0F;
         controlX = rightX - 11.0F;
         iconColor = themeColor(24);
         icon = 20;
      } else {
         KeysPanel.Anim glyphAnim = rowAnim(this.glyphAnimCache, info);
         float glyphHover = 0.0F;
         if (!(mouseX < controlX) && !(controlX + 13.0F < mouseX) && !(mouseY < controlY) && !(controlY + 14.0F < mouseY)) {
            glyphHover = 1.0F;
         }

         retarget(glyphAnim, glyphHover);
         float glyphValue = glyphAnim.advance(KeysPanel.Anim.now());
         iconColor = mixColor(themeColor(16), themeColor(24), glyphValue);
         icon = 32;
      }

      drawIcon(mat, null, icon, controlX, controlY, 13.0F, iconColor, alpha);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (this.visible && button == 0) {
         if (this.host != null) {
            this.x = this.host.getX();
            this.y = this.host.getY();
         }

         float closeY = this.y + 14.0F - 4.0F;
         float closeX = this.x + 276.0F - 12.0F - 8.0F - 4.0F;
         if (!(mx < closeX) && !(closeX + 16.0F < mx) && !(my < closeY) && !(closeY + 16.0F < my)) {
            this.visible = false;
            return true;
         } else {
            float buttonY = this.listTop(this.y) + 3.0F;
            float copyX = this.x + 12.0F + 4.0F;
            float createX = copyX + 120.0F + 4.0F;
            if (!(mx < copyX) && !(copyX + 120.0F < mx) && !(my < buttonY) && !(buttonY + 26.0F < my)) {
               playSound(14);
               String text = this.collectKeyText();
               if (text != null && text.length() != 0) {
                  setClipboard(text);
                  if (text.length() != 0) {
                     playSound(14);
                     initAnim(this.hintAnim, 0.0F, 0.3F, 2);
                     retarget(this.hintAnim, 1.0F);
                  }
               }

               return true;
            } else if (!(mx < createX) && !(createX + 120.0F < mx) && !(my < buttonY) && !(buttonY + 26.0F < my)) {
               playSound(12);
               this.createKey(this.name, new Consumer<String>() {
                  public void accept(String created) {
                     KeysPanel.this.lastCreated = created;
                  }
               });
               return true;
            } else {
               return this.handleListClick(mx, my) ? true : this.hitRect(mx, my);
            }
         }
      } else {
         return false;
      }
   }

   private boolean handleListClick(double mx, double my) {
      float left = this.x + 12.0F;
      float innerTop = this.listTop(this.y) + 32.0F + 6.0F;
      float bottom = this.y + 288.0F - (this.listTop(this.y) + 32.0F + 6.0F) - 12.0F;
      float rowLeft = left + 4.0F;
      float rowRight = left + 252.0F - 4.0F;
      float rowEnd = rowRight - 6.0F;
      int count = this.rows.size();
      if (6 < count) {
         float barX = rowEnd - 4.0F;
         float gauge = (count - 1) * 4.0F + count * 20.0F + 8.0F - bottom;
         if (gauge <= 0.0F) {
            gauge = 0.0F;
         }

         if (gauge <= 0.0F) {
            gauge = 0.0F;
         } else {
            gauge = (bottom + innerTop - 4.0F - (innerTop + 4.0F) - 40.0F) * (this.scrollAnim.current / gauge);
         }

         float thumbY = gauge + innerTop + 4.0F;
         if (barX <= mx && mx <= barX + 6.0F && thumbY <= my && my <= thumbY + 40.0F) {
            this.dragging = true;
            this.dragOffset = (float)my - thumbY;
            return true;
         }
      }

      if (innerTop <= my && my <= bottom + innerTop) {
         for (int i = 0; i < this.rows.size(); i++) {
            KeysPanel.KeyRow row = this.rows.get(i);
            if (0.5F < rowAlphaAt(row, clamp01(row.alpha))) {
               KeysPanel.KeyInfo info = row.info;
               float rowY = row.currentY;
               if (innerTop <= rowY && rowY + 20.0F <= bottom + innerTop) {
                  if (info == null || info.category == 0) {
                     float removeX = rowEnd - 6.0F - 13.0F;
                     if (removeX <= mx && mx <= removeX + 13.0F && rowY + 3.0F <= my && my <= rowY + 3.0F + 14.0F) {
                        playSound(13);
                        this.deleteKey(this.name, info == null ? "" : info.name, new Runnable() {
                           @Override
                           public void run() {
                              KeysPanel.this.onDeleteKeyResult();
                           }
                        });
                        return true;
                     }
                  }

                  if (rowLeft <= mx && mx <= rowRight && rowY <= my && my <= rowY + 20.0F) {
                     playSound(14);
                     if (info != null) {
                        setClipboard(info.name);
                     }

                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.dragging && button == 0) {
         this.dragging = false;
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      if (this.dragging && button == 0) {
         float panelTop = this.listTop(this.y);
         float bottomY = this.y + 288.0F;
         float innerTop = panelTop + 32.0F + 6.0F;
         float trackTop = innerTop + 4.0F;
         float bottom = bottomY - (this.listTop(this.y) + 32.0F + 6.0F) - 12.0F;
         float gauge = this.scrollGauge(this.rows.size(), bottom);
         float value = ((float)my - this.dragOffset - trackTop) / (bottom + innerTop - 4.0F - trackTop - 40.0F) * gauge;
         this.scroll = clampScroll(value, gauge);
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (!this.visible) {
         return false;
      } else {
         float left = this.x + 12.0F;
         float panelTop = this.listTop(this.y);
         float bottomY = this.y + 288.0F;
         float innerTop = panelTop + 32.0F + 6.0F;
         float bottom = bottomY - (this.listTop(this.y) + 32.0F + 6.0F) - 12.0F;
         int count = this.rows.size();
         if (left <= mx && mx <= left + 252.0F && innerTop <= my && my <= bottom + innerTop && 6 < count) {
            float gauge = this.scrollGauge(count, bottom);
            float value = this.scroll - (float)amount * 24.0F;
            this.scroll = clampScroll(value, gauge);
            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   public boolean keyPressed(int keyCode, int modifiers) {
      if (this.visible && keyCode == 27) {
         this.visible = false;
         return true;
      } else {
         return false;
      }
   }

   private String collectKeyText() {
      StringBuilder builder = new StringBuilder();

      for (int i = 0; i < this.keyInfos.size(); i++) {
         KeysPanel.KeyInfo info = this.keyInfos.get(i);
         if (info.category == 0 && info.length != 0) {
            if (builder.length() != 0) {
               builder.append('\n');
            }

            builder.append(info.name);
         }
      }

      return builder.toString();
   }

   public String configName() {
      return this.name;
   }

   public boolean isVisibleFlag() {
      return this.visible;
   }

   public float scrollOffset() {
      return this.scroll;
   }

   public void setScroll(float value) {
      this.scroll = value;
   }

   public boolean isDragging() {
      return this.dragging;
   }

   public void setDragging(boolean value) {
      this.dragging = value;
   }

   public List<KeysPanel.KeyRow> rows() {
      return this.rows;
   }

   public List<KeysPanel.KeyInfo> keyInfos() {
      return this.keyInfos;
   }

   public String takeClipboardText() {
      String value = this.clipboardText;
      this.clipboardText = null;
      return value;
   }

   public String takeCreated() {
      String value = this.lastCreated;
      this.lastCreated = null;
      return value;
   }

   private KeysPanel.KeyRow findRow(String value) {
      for (int i = 0; i < this.rows.size(); i++) {
         KeysPanel.KeyRow row = this.rows.get(i);
         if (rowName(row).compareTo(value) == 0) {
            return row;
         }
      }

      return null;
   }

   private static String findName(List<String> names, String value) {
      for (int i = 0; i < names.size(); i++) {
         if (names.get(i).compareTo(value) == 0) {
            return names.get(i);
         }
      }

      return null;
   }

   private static String rowName(KeysPanel.KeyRow row) {
      return row.info == null ? "" : row.info.name;
   }

   private static float rowReveal(KeysPanel.KeyRow row) {
      return row.alpha;
   }

   private static float rowAlphaAt(KeysPanel.KeyRow row, float alpha) {
      return alpha;
   }

   private boolean hitRect(double mx, double my) {
      return this.x <= mx && mx <= this.x + this.width && this.y <= my && my <= this.y + this.height;
   }

   private static float clamp01(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private static float clampScroll(float value, float limit) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > limit ? limit : value;
      }
   }

   private static void initAnim(KeysPanel.Anim anim, float value, float duration, int easing) {
      anim.from = value;
      anim.current = value;
      anim.target = value;
      anim.duration = duration;
      anim.easing = easing;
      anim.start = KeysPanel.Anim.now();
      anim.running = false;
   }

   private static void retarget(KeysPanel.Anim anim, float target) {
      if (anim.target != target) {
         long time = KeysPanel.Anim.now();
         float value = anim.advance(time);
         anim.from = value;
         anim.target = target;
         anim.start = time;
         anim.running = true;
      }
   }

   private static void delayedRetarget(KeysPanel.Anim anim, float target, float delay) {
      if (anim.target != target) {
         long time = KeysPanel.Anim.now();
         float value = anim.advance(time);
         anim.from = value;
         anim.running = true;
         anim.target = target;
         anim.start = time - (long)(delay * 1.0E9);
      }
   }

   private static KeysPanel.Anim rowAnim(KeysPanel.AnimCache cache, KeysPanel.KeyInfo info) {
      return cache.get(info == null ? "" : info.name);
   }

   private static KeysPanel.CacheEntry staticCacheGet(String key) {
      KeysPanel.CacheEntry entry = staticCacheFind(key);
      if (entry == null) {
         entry = new KeysPanel.CacheEntry(key);
         staticCache().add(entry);
      }

      return entry;
   }

   private static KeysPanel.CacheEntry staticCacheFind(String key) {
      List<KeysPanel.CacheEntry> cache = staticCache();

      for (int i = 0; i < cache.size(); i++) {
         if (cache.get(i).name.compareTo(key) == 0) {
            return cache.get(i);
         }
      }

      return null;
   }

   private static List<KeysPanel.CacheEntry> staticCache() {
      if (staticCache == null) {
         staticCache = new ArrayList<>();
      }

      return staticCache;
   }

   private void releaseKeyInfos() {
   }

   private void shrinkKeyInfos() {
   }

   private void freeKeyInfos() {
   }

   private void removeRows() {
   }

   private void shrinkRows() {
   }

   private void freeRows() {
   }

   private void releaseHost() {
      this.host = null;
   }

   private static void resetString(int offset) {
   }

   private static void freeString(int offset) {
   }

   private void listKeys(String key, Consumer<List<KeysPanel.KeyInfo>> callback) {
      callback.accept(new ArrayList<>());
   }

   private void onDeleteKeyResult() {
   }

   private void createKey(String key, Consumer<String> callback) {
      callback.accept(key);
   }

   private void deleteKey(String key, String value, Runnable callback) {
      callback.run();
   }

   private static void setClipboard(String text) {
   }

   private static void playSound(int id) {
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static int mixColor(int from, int to, float t) {
      return 0;
   }

   private static float measureWrappedText(String text, float size, float width) {
      return 0.0F;
   }

   private static float measureText(String text, float size) {
      return 0.0F;
   }

   private static String ellipsize(String text, float width, float size) {
      return text;
   }

   private static Object pushScissor(Object mat, float alpha, float x, float y) {
      return null;
   }

   private static void popScissor() {
   }

   private static Object makeRect(float x, float y, float width, float height, float radius) {
      return null;
   }

   private static void drawRoundedQuad(Object mat, Object rect, float x, float y, float radius, int color, float alpha) {
   }

   private static void drawPanel(
      Object mat, Object rect, float x, float y, float width, float height, float inset, int color, int shadow, float radius, float alpha
   ) {
   }

   private static void drawListBackground(Object mat, float x, float y, float width, float height, float radius, float alpha) {
   }

   private static void drawIcon(Object mat, Object rect, int icon, float x, float y, float size, int color, float alpha) {
   }

   private static void drawText(Object mat, Object rect, String text, float x, float y, float size, float width, int color, float alpha) {
   }

   private static void pushListLayer() {
   }

   private static void popListLayer() {
   }

   private static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }

   private static final class AnimCache {
      private final List<String> keys = new ArrayList<>();
      private final List<KeysPanel.Anim> values = new ArrayList<>();

      void init() {
         this.keys.clear();
         this.values.clear();
      }

      KeysPanel.Anim get(String key) {
         for (int i = 0; i < this.keys.size(); i++) {
            if (this.keys.get(i).compareTo(key) == 0) {
               return this.values.get(i);
            }
         }

         KeysPanel.Anim anim = new KeysPanel.Anim();
         KeysPanel.initAnim(anim, 0.0F, 0.15F, 0);
         this.keys.add(key);
         this.values.add(anim);
         return anim;
      }

      void disposeNodes() {
         this.keys.clear();
         this.values.clear();
      }

      void disposeBuckets() {
      }
   }

   private static final class CacheEntry {
      final String name;
      final List<KeysPanel.KeyInfo> infos = new ArrayList<>();

      CacheEntry(String name) {
         this.name = name != null ? name : "";
      }
   }

   public static final class KeyInfo {
      public String name = "";
      public int length;
      public byte category;

      public KeyInfo() {
      }

      public KeyInfo(String name) {
         this.name = name != null ? name : "";
         this.length = this.name.length();
         this.category = 0;
      }

      public void setName(String value) {
         this.name = value != null ? value : "";
         this.length = this.name.length();
      }
   }

   public static final class KeyRow {
      public KeysPanel.KeyInfo info;
      public float rate = 4.5F;
      public float alpha;
      public boolean visible;
      public float delay;
      public boolean smooth;
      public boolean initialized;
      public float currentY;
      public float targetY;
   }
}

