package client.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class FriendsPart extends AbstractCollectionPart {
   public static final int ENTRY_SIZE = 232;
   public static final int TAB_ENTRY_SIZE = 72;
   public static final float ADD_TILE_HEIGHT = 62.0F;
   public static final int ICON_TOOLBAR = 76;
   public static final int ICON_ADD_TILE = 34;
   public static final int ICON_DISBAND = 77;
   public static final String TAB_TITLE_FRIENDS = "Фриендз";
   public static final String TAB_TITLE_PARTY = "Партй";
   public static final String TAB_TITLE_INVITATIONS = "Инвитатионз";
   public static final String TOOLBAR_QUERY_FRIENDS = "Введите никнейм...";
   public static final String TOOLBAR_QUERY_PARTY = "Ник друга...";
   public static final String TOOLBAR_BUTTON_FRIENDS = "Адд Фриенд";
   public static final String TOOLBAR_BUTTON_PARTY = "Инвите";
   public static final String ADD_TILE_TITLE = "Адд неш фриенд";
   public static final String ADD_TILE_HINT = "Нажмите, чтобы добавить друга по нику";
   public static final String INVITE_TITLE = "Инвите то партй";
   public static final String PARTY_CARD_HINT = "Позовите друга по нику — он должен быть в сети";
   public static final String PARTY_BETA_HINT = "Пати доступна бета-тестерам";
   public static final String PARTY_LEAVE = "Леаве";
   public static final String PARTY_DISBAND = "Дизбанд";
   public static final String DEFAULT_SELF_NAME = "SystemFriend";
   public static final float CARD_FADE_SECONDS = 0.28F;
   public static final float CHAT_WIDTH_LIMIT = 0.001F;
   public static final float TAB_HALF = 0.5F;
   public static final float TOOLBAR_PAD_X = 16.0F;
   public static final float TOOLBAR_PAD_W = 32.0F;
   public static final float TOOLBAR_PAD_Y = 4.0F;
   public static final float TOOLBAR_QUERY_H = 46.0F;
   public static final float NEARLY_ONE = 0.999F;
   public static final int PARTY_MEMBER_MIN = 1;
   protected static final FriendsPart.Api PLATFORM_API = new FriendsPart.Api();
   protected static final FriendsPart.Api SOCIAL_API = new FriendsPart.Api();
   protected Object partyPeer;
   protected FriendsPart.Api platformApi = PLATFORM_API;
   protected FriendsPart.Api socialApi = SOCIAL_API;
   protected String selfName = "SystemFriend";
   protected int activeTab;
   protected int toolbarTabApplied = -1;
   protected String toolbarQuery = "Введите никнейм...";
   protected String toolbarButton = "Адд Фриенд";
   protected String toolbarCellText = "Дизбанд";
   protected int toolbarCellIcon = 77;
   protected float toolbarQueryWidth = 46.0F;
   protected FriendsPart.StringAction addTileSubmit;

   public FriendsPart() {
      this.activeTab = 0;
      this.partyPeer = null;
      this.selfName = "SystemFriend";
      this.toolbarQuery = "Введите никнейм...";
      this.toolbarButton = "Адд Фриенд";
      this.toolbarCellText = "Дизбанд";
      this.toolbarCellIcon = 77;
      if (this.boardToolbar != null) {
         this.boardToolbar.setTab(2, false);
         this.boardToolbar.onTabChanged = value -> this.showTab(value, true);
         this.boardToolbar.onTitleChanged = value -> this.commitQuery(value);
         this.boardToolbar.onClose = () -> this.commitInputs();
         this.boardToolbar.onTabMenuAction = this::runTabMenuAction;
      }

      this.addTileSubmit = value -> this.commitQuery(value);
      this.applyToolbarCell(2);
      this.platformApi = platformApi();
      this.socialApi = socialApi();
      this.syncHandles();
      this.refresh();
   }

   public static FriendsPart.Api platformApi() {
      return PLATFORM_API;
   }

   public static FriendsPart.Api socialApi() {
      return SOCIAL_API;
   }

   public void installToolbarCallbacks() {
      if (this.boardToolbar != null) {
         this.boardToolbar.onTabChanged = value -> this.showTab(value, true);
         this.boardToolbar.onTitleChanged = value -> this.commitQuery(value);
         this.boardToolbar.onClose = () -> this.commitInputs();
         this.boardToolbar.onTabMenuAction = this::runTabMenuAction;
      }

      if (this.addTile != null) {
         this.addTile.onSubmitText = value -> this.commitQuery(value);
      }

      this.addTileSubmit = value -> this.commitQuery(value);
   }

   public void commitInputs() {
      if (this.addTile != null) {
         this.addTile.plateCommit();
      }
   }

   public void commitQuery(String value) {
      FriendsPart.StringRef text = new FriendsPart.StringRef(value);
      if (!text.empty()) {
         if (this.activeTab == 1) {
            Consumer<String> handler = platformApi().slot178;
            if (handler != null) {
               handler.accept(text.value);
            }
         } else {
            Consumer<String> handler = platformApi().slot278;
            if (handler != null) {
               handler.accept(text.value);
            }

            this.refresh();
         }
      }
   }

   public void runTabMenuAction() {
      List<FriendsPart.TabEntry> entries = this.friendList();
      String activeName = "";

      for (int i = 0; i < entries.size(); i++) {
         FriendsPart.TabEntry entry = entries.get(i);
         if (entry.enabled) {
            activeName = entry.activeName;
         }
      }

      boolean enabled = this.activeTabEnabled();
      if (enabled) {
         Consumer<String> handler = socialApi().slot2F8;
         if (handler != null) {
            handler.accept(activeName);
         }
      } else {
         Consumer<String> handler = socialApi().slot238;
         if (handler != null) {
            handler.accept(activeName);
         }
      }
   }

   public String activeTabName() {
      List<FriendsPart.TabEntry> entries = this.friendList();
      String last = "";

      for (int i = 0; i < entries.size(); i++) {
         FriendsPart.TabEntry entry = entries.get(i);
         last = entry.activeName;
      }

      return last;
   }

   public boolean activeTabEnabled() {
      List<FriendsPart.TabEntry> entries = this.friendList();
      String activeName = "";

      for (int i = 0; i < entries.size(); i++) {
         FriendsPart.TabEntry entry = entries.get(i);
         if (entry.enabled) {
            activeName = entry.activeName;
         }
      }

      return activeName.length() != 0;
   }

   public List<FriendsPart.TabEntry> friendList() {
      List<FriendsPart.TabEntry> out = new ArrayList<>();

      for (Component row : this.rows) {
         if (row instanceof FriendsPart.FriendCard card) {
            FriendsPart.TabEntry entry = new FriendsPart.TabEntry();
            entry.name = card.info != null && card.info.text08 != null ? card.info.text08 : "";
            entry.activeName = entry.name;
            entry.enabled = card.actionable;
            entry.active = entry.enabled;
            out.add(entry);
         }
      }

      return out;
   }

   public void showTab(int tab, boolean animate) {
      int resolved = tab;
      if (tab == 1) {
         if (this.partyPeer == null || !peerEnabled(this.partyPeer) || this.partyBlocked() || this.partyTooSmall() || this.partyNotJoined()) {
            resolved = 0;
         }
      } else if (tab == 2 && this.partyPeer != null && peerInviteSupported(this.partyPeer) && !this.partyBetaOnly()) {
         resolved = 0;
      }

      if (resolved != this.activeTab || !animate) {
         if (this.boardToolbar != null) {
            this.boardToolbar.setTab(resolved, animate);
         }

         this.applyToolbarQuery(resolved, animate);
         this.applyToolbarCell(resolved);
         if (animate) {
            this.setBoardLayout(resolved, true);
         } else {
            this.activeTab = resolved;
            this.layoutDirty = true;
         }
      }
   }

   public void showTab(FriendsPart.Tab tab, boolean animate) {
      this.showTab(tab.ordinal(), animate);
   }

   public void applyToolbarQuery(int tab, boolean animate) {
      boolean party = tab == 1;
      this.toolbarQuery = party ? "Ник друга..." : "Введите никнейм...";
      this.toolbarButton = party ? "Инвите" : "Адд Фриенд";
      this.toolbarQueryWidth = party ? "Ник друга...".length() : "Введите никнейм...".length();
      if (this.addTile != null) {
         this.addTile.text = this.toolbarQuery;
      }
   }

   public void applyToolbarCell(int tab) {
      this.toolbarCellIcon = tab == 2 ? 77 : 76;
      this.toolbarCellText = tab == 2 ? "Дизбанд" : "Леаве";
   }

   public void showTabFromMenu(int tab) {
      this.activeTab = tab;
      this.layoutDirty = true;
      if (this.boardToolbar != null) {
         this.boardToolbar.setTab(tab, false);
      }

      this.applyToolbarQuery(tab, false);
      this.applyToolbarCell(tab);
   }

   public boolean partyBlocked() {
      return true;
   }

   public boolean partyBetaOnly() {
      return true;
   }

   public boolean partyTooSmall() {
      return false;
   }

   public boolean partyNotJoined() {
      return false;
   }

   public static boolean peerEnabled(Object peer) {
      return false;
   }

   public static boolean peerInviteSupported(Object peer) {
      return false;
   }

   public void syncHandles() {
      this.platformApi = platformApi();
      this.socialApi = socialApi();
      Object platformId = null;
      if (this.platformApi.slotId != null) {
         platformId = this.platformApi.slotId.get();
      }

      Object socialId = null;
      if (this.socialApi.slotId != null) {
         socialId = this.socialApi.slotId.get();
      }

      if (platformId == null) {
         platformId = "SystemFriend";
      }

      if (socialId == null) {
         socialId = "SystemFriend";
      }

      Object self = platformId;
      if (platformId == null) {
         self = "SystemFriend";
      }

      this.selfName = String.valueOf(self);
      if (!this.selfName.equals("SystemFriend")) {
         this.refresh();
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button == 0) {
         if (this.boardToolbar != null
            && this.boardToolbar.plateRectHit(mx, my)
            && this.addTile != null
            && this.addTile.plateHasText()
            && !this.boardToolbar.plateHasText()) {
            this.boardToolbar.setPlateText(this.addTile.text);
            return true;
         }

         if (this.addTile != null
            && this.addTile.plateRectHit(mx, my)
            && this.boardToolbar != null
            && this.boardToolbar.plateHasText()
            && !this.addTile.plateHasText()) {
            this.addTile.setText(this.boardToolbar.plate.text);
            return true;
         }
      }

      return super.mouseClicked(mx, my, button);
   }

   @Override
   public void tick() {
      super.tick();
   }

   @Override
   public void render() {
      super.render();
   }

   public void renderHeader() {
      boolean enabled = this.activeTabEnabled();
      String text = enabled ? "Дизбанд" : "Леаве";
      if (this.boardToolbar != null && !this.toolbarCellText.equals(text)) {
         this.toolbarCellText = text;
         this.boardToolbar.setTab(2, false);
      }

      if (this.toolbarTabApplied == 1
         && (this.partyPeer == null || !peerEnabled(this.partyPeer) || this.partyBlocked() || this.partyTooSmall() || this.partyNotJoined())) {
         this.showTab(0, true);
      }

      this.syncHandles();
   }

   public float cardHeight() {
      return 112.0F;
   }

   public FriendsPart.FriendCard buildCard(FriendsPart.Info info) {
      if (info == null) {
         return null;
      } else {
         FriendsPart.FriendCard card = new FriendsPart.FriendCard();
         card.applyInfo(info.copy(), false);
         card.onInvite = value -> {
            Consumer<String> handler = platformApi().slot378;
            if (handler != null) {
               handler.accept(value);
            }
         };
         card.onPrimary = value -> {
            if (value != null) {
               Consumer<String> handler = platformApi().slot2B8;
               if (handler != null) {
                  handler.accept(value.nickname);
               }

               this.refresh();
            }
         };
         card.onSecondary = value -> {
            if (value != null) {
               Consumer<String> handler = socialApi().slot278;
               if (handler != null) {
                  handler.accept(value.nickname);
               }
            }
         };
         card.onTertiary = value -> {
            if (value != null) {
               Consumer<String> handler = socialApi().slot2B8;
               if (handler != null) {
                  handler.accept(value.nickname);
               }
            }
         };
         card.onQuaternary = value -> {
            if (value != null) {
               Consumer<String> handler = socialApi().slot1B8;
               if (handler != null) {
                  handler.accept(value.action);
               }
            }
         };
         card.onQuinary = value -> {
            if (value != null) {
               Consumer<String> handler = socialApi().slot1F8;
               if (handler != null) {
                  handler.accept(value.action);
               }
            }
         };
         card.onSenary = value -> {
            if (value != null) {
               Consumer<String> handler = socialApi().slot2F8;
               if (handler != null) {
                  handler.accept(value.action);
               }
            }
         };
         card.onInviteByName = (value, name) -> {
            if (value != null) {
               if (value.type != 0 && !value.flagAC) {
                  Consumer<String> handler = platformApi().slot2F8;
                  if (handler != null) {
                     handler.accept(value.nickname);
                  }
               } else {
                  Consumer<String> handler = platformApi().slot3F8;
                  if (handler != null) {
                     handler.accept(name);
                  }
               }

               this.refresh();
            }
         };
         return card;
      }
   }

   public void refresh() {
      List<FriendsPart.Info> entries = this.fetchEntries();
      List<FriendsPart.FriendCard> added = new ArrayList<>();

      for (int i = 0; i < entries.size(); i++) {
         FriendsPart.Info entry = entries.get(i);
         FriendsPart.FriendCard existing = this.findCard(entry);
         if (existing == null) {
            FriendsPart.FriendCard created = this.buildCard(entry);
            if (created != null) {
               added.add(created);
            }
         } else if (!existing.collapsed) {
            existing.applyInfo(entry, false);
         }
      }

      for (int ix = 0; ix < added.size(); ix++) {
         FriendsPart.FriendCard card = added.get(ix);
         if (!this.rows.contains(card)) {
            this.rows.add(card);
            card.collapsed = false;
            if (card.getAlpha() != 1.0F) {
               card.animateAlpha(1.0F, 0.28F);
            }
         }
      }

      for (int ixx = 0; ixx < this.rows.size(); ixx++) {
         Component row = this.rows.get(ixx);
         if (row instanceof FriendsPart.FriendCard card && !added.contains(card) && !card.collapsed) {
            card.collapsed = true;
            if (card.getAlpha() != 0.0F) {
               card.animateAlpha(0.0F, 0.28F);
            }
         }
      }
   }

   public FriendsPart.FriendCard findCard(FriendsPart.Info entry) {
      if (entry == null) {
         return null;
      } else {
         for (int i = 0; i < this.rows.size(); i++) {
            Component row = this.rows.get(i);
            if (row instanceof FriendsPart.FriendCard card && !card.collapsed && card.containsName(entry.text08)) {
               return card;
            }
         }

         return null;
      }
   }

   public List<FriendsPart.Info> fetchEntries() {
      return new ArrayList<>();
   }

   public void requestRefresh() {
      this.refresh();
      this.layoutDirty = true;
   }

   @Override
   public void dispose() {
      this.rows.clear();
      this.selfName = "";
      super.dispose();
   }

   public static final class Api {
      public Consumer<String> slot178;
      public Consumer<String> slot1B8;
      public Consumer<String> slot1F8;
      public Consumer<String> slot238;
      public Consumer<String> slot278;
      public Consumer<String> slot2B8;
      public Consumer<String> slot2F8;
      public Consumer<String> slot378;
      public Consumer<String> slot3F8;
      public Consumer<String> slotB8;
      public FriendsPart.IntSupplier slotId;
   }

   public static class FriendCard extends Component {
      public FriendsPart.Info info;
      public boolean collapsed;
      public boolean actionable;
      public String titleText = "";
      public Consumer<String> onInvite;
      public FriendsPart.InfoAction onPrimary;
      public FriendsPart.InfoAction onSecondary;
      public FriendsPart.InfoAction onTertiary;
      public FriendsPart.InfoAction onQuaternary;
      public FriendsPart.InfoAction onQuinary;
      public FriendsPart.InfoAction onSenary;
      public FriendsPart.InfoStringAction onInviteByName;

      public void applyInfo(FriendsPart.Info value, boolean animate) {
         if (value != null) {
            this.info = value.copy();
            this.titleText = value.text08 == null ? "" : value.text08;
            this.actionable = value.type == 1 && value.flagB2;
         }
      }

      public boolean containsName(String name) {
         return this.info != null && this.info.text08 != null ? this.info.text08.equals(name) : false;
      }
   }

   public static final class Info {
      public int type;
      public String text08;
      public String nickname;
      public String text48;
      public String text68;
      public String text88;
      public int fieldA8;
      public boolean flagAC;
      public boolean flagAD;
      public boolean flagAE;
      public boolean flagAF;
      public boolean flagB0;
      public boolean flagB1;
      public boolean flagB2;
      public boolean flagB3;
      public String action;
      public int fieldD8;
      public int fieldDC;
      public int fieldE0;
      public int fieldE4;

      public static FriendsPart.Info of(int type, String text08, String nickname) {
         FriendsPart.Info info = new FriendsPart.Info();
         info.type = type;
         info.text08 = text08;
         info.nickname = nickname;
         return info;
      }

      public FriendsPart.Info copy() {
         FriendsPart.Info copy = new FriendsPart.Info();
         copy.type = this.type;
         copy.text08 = this.text08;
         copy.nickname = this.nickname;
         copy.text48 = this.text48;
         copy.text68 = this.text68;
         copy.text88 = this.text88;
         copy.fieldA8 = this.fieldA8;
         copy.flagAC = this.flagAC;
         copy.flagAD = this.flagAD;
         copy.flagAE = this.flagAE;
         copy.flagAF = this.flagAF;
         copy.flagB0 = this.flagB0;
         copy.flagB1 = this.flagB1;
         copy.flagB2 = this.flagB2;
         copy.flagB3 = this.flagB3;
         copy.action = this.action;
         copy.fieldD8 = this.fieldD8;
         copy.fieldDC = this.fieldDC;
         copy.fieldE0 = this.fieldE0;
         copy.fieldE4 = this.fieldE4;
         return copy;
      }
   }

   public interface InfoAction {
      void invoke(FriendsPart.Info var1);
   }

   public interface InfoStringAction {
      void invoke(FriendsPart.Info var1, String var2);
   }

   public interface IntSupplier {
      int get();
   }

   public interface StringAction {
      void invoke(String var1);
   }

   public static final class StringRef {
      public String value;

      public StringRef(String value) {
         this.value = value == null ? "" : value;
      }

      public int size() {
         return this.value.length();
      }

      public boolean empty() {
         return this.value.length() == 0;
      }
   }

   public static enum Tab {
      FRIENDS,
      PARTY,
      INVITATIONS;
   }

   public static final class TabEntry {
      public String name;
      public String activeName;
      public boolean active;
      public boolean enabled;
   }
}

