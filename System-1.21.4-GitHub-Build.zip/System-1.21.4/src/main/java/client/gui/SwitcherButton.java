package client.gui;

public class SwitcherButton extends AbstractButton {
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int ON_OFFSET = 96;
   public static final int LOCKED_OFFSET = 97;
   public static final int CALLBACK_STORAGE_OFFSET = 104;
   public static final int CALLBACK_OFFSET = 160;
   public static final int TARGET_OFFSET = 168;
   public static final int FADE_OFFSET = 172;
   public static final int KNOB_OFFSET = 176;
   public static final int DRAGGING_OFFSET = 180;
   public static final int DRAG_PAST_THRESHOLD_OFFSET = 181;
   public static final int PRESS_STATE_OFFSET = 182;
   public static final int PRESS_X_OFFSET = 184;
   public static final float DEFAULT_WIDTH = 28.0F;
   public static final float DEFAULT_HEIGHT = 16.0F;
   public static final float ON_VALUE = 1.0F;
   public static final float OFF_VALUE = 0.0F;
   public static final float SNAP_THRESHOLD = 0.5F;
   public static final float DRAG_THRESHOLD = 1.5F;
   public static final float DRAG_ORIGIN_PAD = 2.0F;
   public static final float DRAG_ORIGIN_EXTRA = 6.0F;
   public static final float DRAG_RANGE_INSET = 12.0F;
   public static final float DRAG_RANGE_EXTRA = 4.0F;
   public static final float FADE_RATE = 14.0F;
   public static final float CHASE_RATE = 5.5F;
   public static final float MIN_CHASE_SPEED = 3.5F;
   public static final float RECT_ANIM_DURATION = 0.15F;
   public static final int HOVER_NONE = 0;
   public static final int HOVER_SWITCH = 1;
   public static final int HOVER_DRAG = 3;
   public static final int OPTION_ON_INDEX = 8;
   protected final SwitcherButton.Anim rectAnim = new SwitcherButton.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected boolean on;
   protected byte locked;
   protected final byte[] callbackStorage = new byte[56];
   protected Object callback;
   protected float target;
   protected float fade;
   protected float knob;
   protected boolean dragging;
   protected boolean dragPastThreshold;
   protected boolean pressState;
   protected double pressX;
   private static final float ONE = 1.0F;

   public SwitcherButton() {
      this(false);
   }

   public SwitcherButton(boolean on) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.on = on;
      this.locked = 0;
      this.callback = null;
      float value = on ? 1.0F : 0.0F;
      this.dragging = false;
      this.dragPastThreshold = false;
      this.pressState = false;
      this.pressX = 0.0;
      this.target = value;
      this.fade = value;
      this.knob = value;
      this.width = 0.0F;
      this.height = 0.0F;
      this.width = 28.0F;
      this.height = 16.0F;
   }

   @Override
   public void dispose() {
      Object sub = this.callback;
      if (sub != null) {
         releaseCallback(sub, sub != this.callbackStorage);
         this.callback = null;
      }

      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY) {
      float dt = frameDelta();
      if (this.dragPastThreshold) {
         Screen.hoveredWidget = 3;
      } else if (this.dragging
         || !(mouseX < this.x)
            && !(this.x + this.width < mouseX)
            && !(mouseY < this.y)
            && !(this.y + this.height < mouseY)
            && (Screen.focusedInput == null || Screen.allowHover)) {
         Screen.hoveredWidget = 1;
      }

      float decay = (float)Math.exp(dt * -14.0F);
      float delta = this.target - this.knob;
      this.fade = (1.0F - decay) * (this.target - this.fade) + this.fade;
      float chase = (1.0F - (float)Math.exp(dt * -5.5F)) * delta;
      chase = Math.abs(chase);
      float step = Math.max(dt * 3.5F, chase);
      step = Math.min(step, Math.abs(delta));
      this.knob = this.knob + Math.copySign(step, delta);
      mixColor(themeColor(12), themeColor(20), this.fade);
      mixColor(themeColor(24), themeColor(0), this.fade);
      drawSwitch(mat, this.x, this.y, this.width, this.height, this.knob, this.fade, this.on);
      flush(mat);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      return button == 0 && this.x <= (float)mx && mx <= this.x + this.width && this.y <= (float)my && my <= this.y + this.height ? this.press(mx) : false;
   }

   public boolean press(double mouseX) {
      this.pressState = this.on;
      this.pressX = mouseX;
      this.dragging = true;
      this.dragPastThreshold = false;
      return true;
   }

   @Override
   public boolean mouseDragged(double mx, double my, int button) {
      if (this.dragging && button == 0) {
         if (!this.dragPastThreshold) {
            if (Math.abs(mx - this.pressX) < 1.5) {
               return true;
            }

            this.dragPastThreshold = true;
         }

         float fraction = (float)((mx - (this.x + 2.0F + 6.0F)) / (this.width - 12.0F - 4.0F));
         if (fraction < 0.0F) {
            fraction = 0.0F;
         }

         if (fraction > 1.0F) {
            fraction = 1.0F;
         }

         this.target = fraction;
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.dragging && button == 0) {
         this.dragging = false;
         this.dragPastThreshold = false;
         boolean value;
         if (!this.dragPastThreshold) {
            value = this.pressState;
         } else {
            value = 0.5F <= this.target;
         }

         if (this.on != value) {
            this.on = value;
            if (this.locked == 0) {
               updateOption((value ? 0 : 1) + 8);
            }

            if (this.callback != null) {
               invokeCallback(this.callback);
            }
         }

         if (value) {
            this.target = 1.0F;
            return true;
         } else {
            this.target = 0.0F;
            return true;
         }
      } else {
         return false;
      }
   }

   public boolean isOn() {
      return this.on;
   }

   public void setOn(boolean value) {
      this.on = value;
      this.target = value ? 1.0F : 0.0F;
   }

   public void setCallback(Object value) {
      this.callback = value;
   }

   public float knob() {
      return this.knob;
   }

   public float fade() {
      return this.fade;
   }

   private static float frameDelta() {
      return 0.0F;
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static void mixColor(int from, int to, float t) {
   }

   private static void drawSwitch(Object mat, float x, float y, float width, float height, float knob, float fade, boolean on) {
   }

   private static void flush(Object mat) {
   }

   private static void releaseCallback(Object sub, boolean heap) {
   }

   private static void invokeCallback(Object sub) {
   }

   private static void updateOption(int index) {
   }

   private static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         return this.easing == 1 ? easeOutExpo(t) : easeOutCubic(t);
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }
   }
}

