package client.gui;

import client.Setting;

public class SwitchRow extends Row {
   public static final int SWITCH_OFFSET = 72;
   public static final int CACHED_STATE_OFFSET = 168;
   public static final int TOGGLE_ANIM_OFFSET = 240;
   public static final float SWITCH_WIDTH = 28.0F;
   public static final float SWITCH_HEIGHT = 16.0F;
   public static final float SWITCH_RIGHT_INSET = 8.0F;
   public static final float SWITCH_TOP_INSET = 5.0F;
   public static final float UNIT = 1.0F;
   private SwitcherButton toggle;
   private boolean cachedState;
   private float toggleAnim;

   public SwitchRow() {
   }

   public SwitchRow(Object owner, Setting setting) {
      super(owner, setting);
      this.bound = setting;
      this.toggle = new SwitcherButton(checked(setting));
      this.cachedState = false;
      this.toggleAnim = 0.0F;
   }

   private static boolean checked(Setting setting) {
      return setting != null && setting.getBoolean();
   }

   @Override
   public void render(Object mat, float x, float y, float width, float height, float mouseX, float mouseY) {
      boolean state = checked(this.bound);
      if (this.cachedState != state) {
         this.cachedState = state;
         this.toggleAnim = state ? 1.0F : 0.0F;
      }

      float rowSpan = x + width - 8.0F;
      this.boundsY = y + 5.0F;
      this.boundsX = rowSpan - 28.0F;
      this.boundsWidth = 28.0F;
      this.boundsHeight = 16.0F;
      if (this.toggle != null) {
         this.toggle.render(mat, mouseX, mouseY);
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         return this.boundsX <= mx && mx <= this.boundsX + this.boundsWidth && this.boundsY <= my && my <= this.boundsY + this.boundsHeight
            ? this.toggle != null && this.toggle.press(mx)
            : false;
      }
   }

   @Override
   public float drag(float x, float width) {
      return x + width - 8.0F - 28.0F;
   }

   public SwitcherButton toggle() {
      return this.toggle;
   }

   public boolean state() {
      return this.cachedState;
   }

   public float toggleAnim() {
      return this.toggleAnim;
   }
}

