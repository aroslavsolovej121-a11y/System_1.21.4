package client.gui;

import client.Setting;
import java.util.ArrayList;
import java.util.List;

public class DropDownWidget extends Component {
   public static final int ENTRY_SIZE = 40;
   public static final int SLOT_DESTROY = 0;
   public static final int SLOT_RENDER = 8;
   public static final int SLOT_MOUSE_CLICKED = 32;
   public static final int SLOT_MOUSE_RELEASED = 40;
   public static final int SLOT_MOUSE_DRAGGED = 48;
   public static final int SLOT_MOUSE_SCROLLED = 56;
   public static final int SLOT_GET_HEIGHT = 96;
   public static final int SLOT_CONTENT_HEIGHT = 104;
   public static final int SLOT_CLOSE = 120;
   public static final int SLOT_TYPE_ID = 136;
   public static final int SLOT_VALUE_PAD = 144;
   public static final int SLOT_VALUE_MIN = 152;
   public static final float DEFAULT_WIDTH = 269.0F;
   public static final float ROW_HEIGHT = 32.0F;
   public static final float PAD_Y = 6.0F;
   public static final float PAD_X = 8.0F;
   public static final float LIST_TOP_GAP = 6.0F;
   public static final float LIST_INNER = 4.0F;
   public static final float LIST_SIDE = 6.0F;
   public static final float OPTION_STEP = 30.0F;
   public static final float OPTION_HEIGHT = 26.0F;
   public static final float OPTION_TOP = 3.0F;
   public static final float OPTION_TEXT_TOP = 7.0F;
   public static final float OPTION_TEXT_LEFT = 8.0F;
   public static final float THUMB_HEIGHT = 59.0F;
   public static final float THUMB_WIDTH = 6.0F;
   public static final float LIST_MAX_HEIGHT = 154.0F;
   public static final float LIST_MIN_OPTIONS = 6.0F;
   public static final float LABEL_FONT = 12.0F;
   public static final float VALUE_FONT = 14.0F;
   public static final float LABEL_LINE_HEIGHT = 14.4F;
   public static final float VALUE_LINE_HEIGHT = 16.800001F;
   public static final float VALUE_MIN_HEIGHT = 20.0F;
   public static final float TEXT_PAD = 16.0F;
   public static final float OPEN_DURATION = 0.32F;
   public static final float CLOSE_DURATION = 0.3F;
   public static final float ANIM_DURATION = 0.22F;
   public static final float OPTION_IDLE = 0.4F;
   public static final float OPTION_HOVER = 0.7F;
   public static final float ONE = 1.0F;
   public static final float ZERO = 0.0F;
   public static final float HALF = 0.5F;
   public static final float EPSILON = 0.001F;
   public static final long NANOS_PER_SECOND = 1000000000L;
   public static final int TYPE_ID = 62;
   public static final int HEAD_ICON = 10;
   public static final int SOUND_OPEN = 4;
   public static final int SOUND_CLOSE = 5;
   public static final int SOUND_SELECT = 14;
   public static final int HOVER_KIND_ROW = 1;
   public static final int HOVER_KIND_DROP_DOWN = 4;
   public static boolean hoverGatePointerNull = true;
   public static boolean mouseInsideWindow;
   public static int hoveredWidget;
   protected Setting options;
   protected boolean open;
   protected boolean lastOpen;
   protected final DropDownWidget.Anim openAnim = new DropDownWidget.Anim(0.0F, 0.32F);
   protected final DropDownWidget.Anim scrollAnim = new DropDownWidget.Anim(0.0F, 0.32F);
   protected final List<DropDownWidget.OptionState> entries = new ArrayList<>();
   protected float scroll;
   protected float scrollTarget = -1.0F;
   protected boolean draggingThumb;
   protected float dragOffset;
   protected String label = "";
   protected long cachedCount = -1L;
   protected float cachedWidth;
   protected float labelWidthKey = -1.0F;
   protected float labelHeight;
   protected float valueHeightKey = -1.0F;
   protected float valueHeight;
   public static final float INNER_GAP = 3.0F;
   public static final float ROW_RADIUS = 10.0F;
   public static final float OPTION_RADIUS = 8.0F;

   public DropDownWidget() {
   }

   public DropDownWidget(Setting options) {
      this.initSettingWidget(options);
   }

   protected void initSettingWidget(Setting options) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.animXFrom = 0.0F;
      this.animYFrom = 0.0F;
      this.animatingPosition = false;
      this.options = options;
      this.open = false;
      this.lastOpen = false;
      this.openAnim.duration = 0.32F;
      this.openAnim.start = clock();
      this.openAnim.running = false;
      this.scrollAnim.duration = 0.32F;
      this.scrollAnim.start = clock();
      this.scrollAnim.running = false;
      this.scroll = 0.0F;
      this.scrollTarget = -1.0F;
      this.draggingThumb = false;
      this.dragOffset = 0.0F;
      this.label = "";
      this.cachedCount = -1L;
      this.cachedWidth = 0.0F;
      this.width = 269.0F;
      this.buildEntries();
   }

   protected void buildEntries() {
      this.entries.clear();
      if (this.options != null) {
         for (String mode : this.options.getModes()) {
            boolean selected = mode != null && mode.equals(this.options.getMode());
            float value = selected ? 1.0F : 0.4F;
            DropDownWidget.OptionState entry = new DropDownWidget.OptionState(mode == null ? "" : mode, value, 0.22F);
            entry.selected = selected;
            this.entries.add(entry);
         }
      }
   }

   public Setting getOptions() {
      return this.options;
   }

   public boolean isOpen() {
      return this.open;
   }

   public void setOpen(boolean value) {
      this.open = value;
   }

   protected static long clock() {
      return System.nanoTime();
   }

   protected int getTypeId() {
      return 62;
   }

   protected float getValuePad() {
      return 16.0F;
   }

   protected float getValueMin() {
      return 16.0F;
   }

   protected static float advanceAnim(DropDownWidget.Anim anim) {
      if (anim.running && !(anim.duration <= 0.0F)) {
         float t = (float)((clock() - anim.start) / 1.0E9) / anim.duration;
         if (t <= 0.0F) {
            anim.current = anim.from;
            return anim.current;
         } else if (t >= 1.0F) {
            anim.running = false;
            anim.current = anim.target;
            return anim.current;
         } else {
            anim.current = easeOutCubic(t) * (anim.target - anim.from) + anim.from;
            return anim.current;
         }
      } else {
         anim.current = anim.target;
         anim.running = false;
         return anim.current;
      }
   }

   protected static void setAnimTarget(DropDownWidget.Anim anim, float target) {
      if (anim.target != target) {
         float current = advanceAnim(anim);
         anim.from = current;
         anim.target = target;
         anim.start = clock();
         anim.running = true;
      }
   }

   protected static float advanceEntry(DropDownWidget.OptionState entry) {
      if (entry.running && !(entry.duration <= 0.0F)) {
         float t = (float)((clock() - entry.start) / 1.0E9) / entry.duration;
         if (t <= 0.0F) {
            entry.current = entry.from;
            return entry.current;
         } else if (t >= 1.0F) {
            entry.running = false;
            entry.current = entry.target;
            return entry.current;
         } else {
            entry.current = easeOutCubic(t) * (entry.target - entry.from) + entry.from;
            return entry.current;
         }
      } else {
         entry.current = entry.target;
         entry.running = false;
         return entry.current;
      }
   }

   protected static void setEntryTarget(DropDownWidget.OptionState entry, float target) {
      if (entry.target != target) {
         float current = advanceEntry(entry);
         entry.from = current;
         entry.target = target;
         entry.start = clock();
         entry.running = true;
      }
   }

   protected int optionCount() {
      return this.options == null ? 0 : this.options.getModes().size();
   }

   protected int selectedIndex() {
      if (this.options == null) {
         return 0;
      } else {
         List<String> modes = this.options.getModes();
         int index = modes.indexOf(this.options.getMode());
         return index < 0 ? 0 : index;
      }
   }

   protected int visibleCount() {
      return this.optionCount();
   }

   protected static float optionListHeight(int count) {
      return count == 0 ? 0.0F : (count - 1) * 4.0F + count * 26.0F + 8.0F;
   }

   protected static float listViewHeight(int count) {
      float total = optionListHeight(count);
      return 154.0F <= total ? 154.0F : total;
   }

   protected static float maxScroll(int count) {
      float total = optionListHeight(count);
      float view = listViewHeight(count);
      float result = total - view;
      if (result <= 0.0F) {
         result = 0.0F;
      }

      return result;
   }

   protected String updateLabel() {
      if (this.options == null) {
         return this.label;
      } else {
         int count = this.visibleCount();
         if (count != (int)this.cachedCount) {
            this.label = this.optionCounterLabel();
            this.cachedWidth = AbstractTrackChoiceWidget.textWidth(this.label, 12.0F) + 16.0F;
            this.cachedCount = count;
         }

         return this.label;
      }
   }

   protected String optionCounterLabel() {
      return this.selectedIndex() + "/" + this.visibleCount();
   }

   protected float measureLabelHeight(float available) {
      if (available != this.labelWidthKey) {
         int lines = wrapLineCount(0, this.settingLabel(), 12.0F, available);
         float measured = lines * 14.4F;
         this.labelWidthKey = available;
         this.labelHeight = measured;
         return measured;
      } else {
         return this.labelHeight;
      }
   }

   protected float measureValueHeight(float available) {
      float local = available - 20.0F;
      if (local <= 0.0F) {
         local = 0.0F;
      }

      if (local != this.valueHeightKey) {
         int lines = wrapLineCount(2, this.settingValue(), 14.0F, local);
         float measured = lines * 16.800001F;
         this.valueHeightKey = local;
         this.valueHeight = measured;
         return measured;
      } else {
         return this.valueHeight;
      }
   }

   protected String settingLabel() {
      return this.options == null ? "" : this.options.getName();
   }

   protected String settingValue() {
      return this.options == null ? "" : this.options.getName();
   }

   protected static int wrapLineCount(int align, String text, float size, float available) {
      if (!(available <= 0.0F) && text != null) {
         float measured = AbstractTrackChoiceWidget.textWidth(text, size);

         int lines;
         for (lines = 1; measured > available; lines++) {
            measured -= available;
         }

         return lines;
      } else {
         return available <= 0.0F ? 0 : 1;
      }
   }

   protected float labelTop() {
      float label = this.measureLabelHeight(this.width);
      this.updateLabel();
      float available = this.width;
      if (0.0F < this.cachedWidth) {
         available = this.width - this.cachedWidth - 8.0F;
      }

      float value = this.measureValueHeight(available);
      if (label > 0.0F) {
         value = value + 0.0F + label;
      }

      return value + this.y + 6.0F;
   }

   protected float measureHeight() {
      float label = this.measureLabelHeight(this.width);
      this.updateLabel();
      float available = this.width;
      if (0.0F < this.cachedWidth) {
         available = this.width - this.cachedWidth - 8.0F;
      }

      float value = this.measureValueHeight(available);
      if (label > 0.0F) {
         value = value + 0.0F + label;
      }

      float animated = this.openAnim.current;
      float base = value + 6.0F + 32.0F;
      int count = this.optionCount();
      if (0.001F < animated && count != 0) {
         float listHeight = listViewHeight(count);
         return (listHeight + 6.0F) * animated + base;
      } else {
         return base;
      }
   }

   public void measure() {
      this.measureHeight();
   }

   protected float contentHeight() {
      float label = this.measureLabelHeight(this.width);
      this.updateLabel();
      float available = this.width;
      if (0.0F < this.cachedWidth) {
         available = this.width - this.cachedWidth - 8.0F;
      }

      float value = this.measureValueHeight(available);
      if (label > 0.0F) {
         value = value + 0.0F + label;
      }

      float base = value + 6.0F + 32.0F;
      int count = this.optionCount();
      if (this.open && count != 0) {
         float listHeight = listViewHeight(count);
         return listHeight + base + 6.0F;
      } else {
         return base;
      }
   }

   protected float drawHeader(Object mat, float available, float alpha) {
      float measured = this.measureValueHeight(available);
      drawValueText(mat, this.x + 20.0F, this.y, 14.0F, available, AbstractTrackChoiceWidget.rendererColor(), alpha);
      return measured;
   }

   protected float drawLabel(Object mat, float yOffset, float alpha) {
      float measured = this.measureLabelHeight(this.width);
      drawLabelText(mat, this.x, yOffset + this.y, 12.0F, AbstractTrackChoiceWidget.rendererColor(), alpha);
      return measured;
   }

   protected static void drawValueText(Object mat, float px, float py, float size, float available, int color, float alpha) {
   }

   protected static void drawLabelText(Object mat, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawValueTextAtEdge(Object mat, float px, float py, String text, float alpha) {
   }

   protected static void drawRowBackground(Object mat, float px, float py, float w, float h, float radius, float alpha) {
   }

   protected static void drawRowInner(Object mat, float px, float py, float w, float h, float radius, int color, float alpha) {
   }

   protected static void drawRowDivider(Object mat, float px, float py, float w, float h, int color, float alpha) {
   }

   protected static void drawOptionText(Object mat, String text, float px, float py, float size, int color, float alpha) {
   }

   protected static void drawHead(Object mat, float px, float py, int color, float alpha, float available) {
   }

   protected static float[] iconMetrics(int icon) {
      return new float[]{0.0F, 0.0F};
   }

   protected static void playSound(int id) {
   }

   protected static void pushScissor(float px, float py, float w, float h) {
   }

   protected static void popScissor() {
   }

   protected static boolean rectTest(double mx, double my, float px, float py, float w, float h) {
      return mx >= px && mx <= px + w && my >= py && my <= py + h;
   }

   public static boolean hoverAllowed() {
      return hoverGatePointerNull || mouseInsideWindow;
   }

   protected void setSelectedOption(int index) {
      if (this.options != null) {
         List<String> modes = this.options.getModes();
         if (index >= 0 && index < modes.size()) {
            this.options.setMode(modes.get(index));
         }
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      if (button != 0) {
         return false;
      } else {
         float top = this.labelTop();
         float fieldX = this.x;
         if (mx >= fieldX && mx <= fieldX + this.width && my >= top && my <= top + 32.0F) {
            boolean wasOpen = this.open;
            this.open = !wasOpen;
            playSound(wasOpen ? 5 : 4);
            if (!this.open) {
               return true;
            } else {
               this.scroll = 0.0F;
               this.scrollAnim.from = 0.0F;
               this.scrollAnim.current = 0.0F;
               this.scrollAnim.target = 0.0F;
               this.scrollAnim.running = false;
               return true;
            }
         } else {
            int count = this.optionCount();
            if (this.open && count != 0) {
               float listTop = top + 32.0F + 6.0F;
               float total = optionListHeight(count);
               float view = listViewHeight(count);
               if (!rectTest(mx, my, fieldX, listTop, this.width, view)) {
                  return false;
               } else {
                  float rightEdge = this.width + fieldX - 4.0F;
                  float leftEdge = fieldX + 4.0F;
                  if (count < 6) {
                     if (count != 0) {
                        this.scanOptions(mx, my, listTop, view, total, count, listTop + 4.0F - this.scrollAnim.current, leftEdge, rightEdge);
                     }

                     return true;
                  } else {
                     float thumbTop = 0.0F;
                     float span = total - view;
                     if (span <= 0.0F) {
                        span = 0.0F;
                     }

                     if (0.0F < span) {
                        thumbTop = (view + listTop - 4.0F - (listTop + 4.0F) - 59.0F) * (this.scrollAnim.current / span);
                     }

                     thumbTop = thumbTop + listTop + 4.0F;
                     if (!(mx < rightEdge) && !(my < thumbTop) && !(my > thumbTop + 59.0F)) {
                        this.draggingThumb = true;
                        this.dragOffset = (float)my - thumbTop;
                     } else {
                        this.scanOptions(mx, my, listTop, view, total, count, listTop + 4.0F - this.scrollAnim.current, leftEdge, rightEdge);
                     }

                     return true;
                  }
               }
            } else {
               return false;
            }
         }
      }
   }

   protected void scanOptions(double mx, double my, float listTop, float view, float total, int count, float baseTop, float leftEdge, float rightEdge) {
      int index = 0;

      do {
         float rowTop = index * 30.0F + baseTop;
         if (listTop <= rowTop + 26.0F && rowTop <= view + listTop && mx >= leftEdge && mx <= rightEdge && my >= rowTop && my <= rowTop + 26.0F) {
            playSound(14);
            this.setSelectedOption(index);
            return;
         }
      } while (count > ++index);
   }

   @Override
   public boolean mouseReleased(double mx, double my, int button) {
      if (this.draggingThumb && button == 0) {
         this.draggingThumb = false;
         return true;
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseMoved(double mx, double my, double delta) {
      int button = (int)delta;
      if (this.draggingThumb && button == 0) {
         int count = this.optionCount();
         if (count == 0) {
            return false;
         } else {
            float top = this.labelTop();
            float listTop = top + 32.0F + 6.0F;
            float total = optionListHeight(count);
            float view = listViewHeight(count);
            float limit = total - view;
            if (limit <= 0.0F) {
               limit = 0.0F;
            }

            float value = ((float)my - this.dragOffset - (listTop + 4.0F)) / (view + listTop - 4.0F - (listTop + 4.0F)) - 59.0F;
            value *= limit;
            if (value < 0.0F) {
               value = 0.0F;
            }

            if (value > limit) {
               value = limit;
            }

            this.scroll = value;
            return true;
         }
      } else {
         return false;
      }
   }

   @Override
   public boolean mouseScrolled(double mx, double my, double amount) {
      if (!this.open) {
         return false;
      } else {
         int count = this.optionCount();
         if (count != 0 && 5 < count) {
            float top = this.labelTop();
            float listTop = top + 32.0F + 6.0F;
            float total = optionListHeight(count);
            if (mx >= this.x && mx <= this.x + this.width && my >= listTop) {
               float view = listViewHeight(count);
               if (my <= view + listTop) {
                  float limit = total - view;
                  if (limit <= 0.0F) {
                     limit = 0.0F;
                  }

                  float value = this.scroll - (float)amount * 30.0F;
                  if (value < 0.0F) {
                     value = 0.0F;
                  }

                  if (value > limit) {
                     value = limit;
                  }

                  this.scroll = value;
                  return true;
               }
            }

            return false;
         } else {
            return false;
         }
      }
   }

   public void close() {
      this.open = false;
      this.draggingThumb = false;
   }

   protected void drawOptions(Object mat, float mouseX, float mouseY, float alpha, float top, float openValue) {
      int count = this.optionCount();
      if (count != 0) {
         float listTop = top + 32.0F + 6.0F;
         float total = optionListHeight(count);
         float view = listViewHeight(count);
         float scaled = alpha * openValue;
         pushScissor(this.x, listTop, this.width, view * openValue);
         drawRowBackground(mat, this.x, listTop, this.width, view, 10.0F, scaled);
         float contentX = this.x + 4.0F;
         float contentWidth = this.x + this.width - 4.0F;
         if (5 < count) {
            contentWidth = contentWidth - 6.0F - 4.0F;
         }

         float limit = total - view;
         if (limit <= 0.0F) {
            limit = 0.0F;
         }

         float clamped = this.scroll;
         if (clamped < 0.0F) {
            clamped = 0.0F;
         }

         if (clamped > limit) {
            clamped = limit;
         }

         this.scroll = clamped;
         if (this.scroll != this.scrollTarget) {
            setAnimTarget(this.scrollAnim, this.scroll);
            this.scrollTarget = this.scroll;
         }

         float smooth = advanceAnim(this.scrollAnim);
         boolean inList = rectTest(mouseX, mouseY, this.x, listTop, this.width, view);
         float baseTop = listTop + 4.0F - smooth;

         for (int i = 0; i < count; i++) {
            float rowTop = i * 30.0F + baseTop;
            float rowBottom = rowTop + 26.0F;
            if (listTop <= rowBottom && rowTop <= listTop + view) {
               boolean hovered = inList && mouseX >= contentX && mouseX <= contentX + contentWidth && mouseY >= rowTop && mouseY <= rowBottom;
               if (hovered && hoverAllowed()) {
                  hoveredWidget = 1;
               }

               DropDownWidget.OptionState entry = this.entries.get(i);
               float highlight = 1.0F;
               if (!entry.selected) {
                  highlight = 0.4F;
                  if (hovered) {
                     highlight = 0.7F;
                  }
               }

               setEntryTarget(entry, highlight);
               float level = advanceEntry(entry);
               drawRowInner(mat, contentX, rowTop, contentWidth, 26.0F, 8.0F, AbstractTrackChoiceWidget.rendererColor(), level * scaled);
               drawOptionText(mat, entry.text, contentX + 8.0F, rowTop + 7.0F, 12.0F, AbstractTrackChoiceWidget.rendererColor(), level * scaled);
            }
         }

         if (5 < count) {
            float trackTop = listTop + 4.0F;
            float trackRight = this.width + this.x - 4.0F - 6.0F;
            float thumb = 0.0F;
            if (0.0F < limit) {
               thumb = (total + listTop - 4.0F - trackTop - 59.0F) * (smooth / limit);
            }

            drawRowInner(mat, trackRight, thumb + trackTop, 6.0F, 59.0F, 3.0F, AbstractTrackChoiceWidget.rendererColor(), scaled);
         }

         popScissor();
      }
   }

   public void renderWidget(Object mat, float mouseX, float mouseY, float alpha) {
      this.updateLabel();
      float available = this.width;
      if (0.0F < this.cachedWidth) {
         available = this.width - this.cachedWidth - 8.0F;
      }

      float valueMeasured = this.drawHeader(mat, available, alpha);
      float labelMeasured = this.drawLabel(mat, valueMeasured, alpha);
      if (0.0F < this.cachedWidth) {
         drawValueTextAtEdge(mat, this.x + this.width, this.y, this.updateLabel(), alpha);
      }

      float top = valueMeasured;
      if (0.0F < labelMeasured) {
         top = valueMeasured + 0.0F + labelMeasured;
      }

      top = top + this.y + 6.0F;
      if (rectTest(mouseX, mouseY, this.x, this.y, this.width, 32.0F) && hoverAllowed()) {
         hoveredWidget = 1;
      }

      boolean wasOpen = this.open;
      if (wasOpen != this.lastOpen) {
         this.openAnim.duration = wasOpen ? 0.32F : 0.3F;
         this.lastOpen = wasOpen;
      }

      float target = wasOpen ? 1.0F : 0.0F;
      if (this.openAnim.target != target) {
         setAnimTarget(this.openAnim, target);
      }

      float openValue = advanceAnim(this.openAnim);
      drawRowBackground(mat, this.x, top, this.width, 32.0F, 10.0F, alpha);
      float innerX = this.x + 3.0F;
      float innerY = top + 3.0F;
      float innerWidth = this.width - 6.0F;
      drawRowInner(mat, innerX, innerY, innerWidth, 26.0F, 8.0F, AbstractTrackChoiceWidget.rendererColor(), alpha);
      float[] metrics = iconMetrics(10);
      float iconX = innerWidth + innerX - 8.0F;
      float iconY = (26.0F - metrics[1]) * 0.5F + innerY + 1.0F;
      drawCenteredIcon(mat, 10, iconX - metrics[0], iconY, metrics[0], metrics[1], alpha);
      float headWidth = innerWidth - 16.0F - metrics[0] - 4.0F;
      drawHead(mat, innerX + 8.0F, innerY + 7.0F, AbstractTrackChoiceWidget.rendererSecondaryColor(), alpha, headWidth);
      float fieldBottom = top + 32.0F;
      this.height = fieldBottom - this.y;
      if (0.001F < openValue) {
         this.drawOptions(mat, mouseX, mouseY, alpha, top, openValue);
         if (this.draggingThumb) {
            hoveredWidget = 4;
         }

         float listHeight = listViewHeight(this.optionCount());
         this.height = (listHeight + 6.0F) * openValue + (fieldBottom - this.y);
      }
   }

   protected static void drawCenteredIcon(Object mat, int icon, float px, float py, float w, float h, float alpha) {
   }

   @Override
   public void render() {
   }

   protected static final class Anim {
      protected float from;
      protected float current;
      protected float target;
      protected float duration = 0.32F;
      protected long start;
      protected boolean running;

      protected Anim() {
      }

      protected Anim(float value, float duration0) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration0;
         this.start = DropDownWidget.clock();
         this.running = false;
      }
   }

   public static final class OptionState {
      public float from;
      public float current;
      public float target;
      public float duration = 0.22F;
      public long start;
      public boolean running;
      public boolean selected;
      public String text = "";

      public OptionState() {
      }

      public OptionState(String text, float value, float duration0) {
         this.text = text;
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration0;
         this.start = DropDownWidget.clock();
         this.running = false;
      }
   }
}

