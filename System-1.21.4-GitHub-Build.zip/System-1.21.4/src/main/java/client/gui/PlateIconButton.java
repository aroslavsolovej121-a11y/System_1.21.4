package client.gui;

public class PlateIconButton extends AbstractButton {
   public static final int RECT_ANIM_OFFSET = 32;
   public static final int OWNED_BUFFER_A_OFFSET = 72;
   public static final int OWNED_BUFFER_B_OFFSET = 80;
   public static final int FLAG_58_OFFSET = 88;
   public static final int ICON_OFFSET = 96;
   public static final int TINT_OFFSET = 100;
   public static final int ENABLED_OFFSET = 104;
   public static final int REVEAL_ANIM_OFFSET = 112;
   public static final int PRESS_ANIM_OFFSET = 152;
   public static final int CALLBACK_STORAGE_OFFSET = 192;
   public static final int CALLBACK_OFFSET = 248;
   public static final int LABEL_OFFSET = 256;
   public static final float SIZE = 42.0F;
   public static final float PANEL_RADIUS = 14.0F;
   public static final float INNER_INSET = 3.0F;
   public static final float INNER_SIZE = 36.0F;
   public static final float INNER_RADIUS = 12.0F;
   public static final float REVEAL_DURATION = 0.22F;
   public static final float PRESS_DURATION = 0.15F;
   public static final float REVEAL_EXPONENT = 1.7F;
   public static final float PRESS_SCALE = 0.4F;
   public static final float TINT_SCALE = 0.85F;
   public static final float SNAP_THRESHOLD = 0.5F;
   public static final float HALF = 0.5F;
   public static final float EPSILON = 0.001F;
   public static final float PANEL_STYLE = 0.0F;
   public static final int HOVER_BUTTON = 1;
   public static final int TINT_DEFAULT = 0;
   protected final PlateIconButton.Anim rectAnim = new PlateIconButton.Anim();
   protected long ownedBufferA;
   protected long ownedBufferB;
   protected byte flag58;
   protected int icon;
   protected int tint;
   protected byte enabled = 1;
   protected final PlateIconButton.Anim revealAnim = new PlateIconButton.Anim();
   protected final PlateIconButton.Anim pressAnim = new PlateIconButton.Anim();
   protected Object callback;
   protected final byte[] callbackStorage = new byte[56];
   protected String label = "";
   private static final float ONE = 1.0F;

   public PlateIconButton(int icon, String label) {
      this.flags = 256;
      this.x = 0.0F;
      this.y = 0.0F;
      this.width = 0.0F;
      this.height = 0.0F;
      this.rectAnim.set(0.0F, 0.15F);
      this.ownedBufferA = 0L;
      this.ownedBufferB = 0L;
      this.flag58 = 0;
      this.icon = icon;
      this.tint = 0;
      this.enabled = 1;
      this.revealAnim.set(1.0F, 0.22F);
      this.pressAnim.set(0.0F, 0.15F);
      this.callback = null;
      this.label = "";
      this.label = label != null ? label : "";
      releaseSourceString();
      this.width = 42.0F;
      this.height = 42.0F;
   }

   @Override
   public void dispose() {
      resetString(256);
      if (this.callback != null) {
         releaseCallback(this.callback, this.callback != this.callbackStorage);
         this.callback = null;
      }

      freeString(256);
      if (this.callback != null) {
         releaseCallback(this.callback, this.callback != this.callbackStorage);
         this.callback = null;
      }

      super.dispose();
   }

   @Override
   public void render(Object mat, float mouseX, float mouseY, float alpha) {
      float reveal = this.revealAnim.advance(PlateIconButton.Anim.now());
      float panelWidth = 42.0F;
      float current = this.revealAnim.current;
      this.width = reveal * 42.0F;
      if (0.001F < current) {
         float hover = this.updateHover(mouseX, mouseY);
         if ((this.flags & 0xFF) != 0) {
            Screen.hoveredWidget = 1;
         }

         float press = this.pressAnim.advance(PlateIconButton.Anim.now());
         float fade = clamp01(current);
         fade = (float)Math.pow(fade, 1.7F);
         float value = fade * alpha;
         float panelX = this.x + this.width - panelWidth;
         drawPanel(mat, panelX, this.y, panelWidth, this.height, 14.0F, value, 0.0F);
         int base = themeBorderColor();
         float mix = press * 0.4F + hover;
         if (1.0F <= mix) {
            mix = 1.0F;
         }

         int accent = mixColor(base, themeColor(8), 0.85F);
         int color = mixColor(base, accent, mix);
         drawInnerPlate(mat, panelX + 3.0F, this.y + 3.0F, 36.0F, 36.0F, 12.0F, color, value);
         float[] metrics = iconMetrics(this.icon);
         int iconColor = this.tint;
         if (iconColor == 0) {
            iconColor = themeColor(24);
         }

         drawIcon(
            mat, this.icon, (panelWidth - metrics[0]) * 0.5F + panelX, (this.height - metrics[1]) * 0.5F + this.y, metrics[0], metrics[1], iconColor, value
         );
         if ((this.flags & 0xFF) != 0 && !this.label.isEmpty()) {
            drawTooltip(this.label, this.x, this.y, this.width, this.height);
         }
      } else {
         this.flags &= 65280;
      }
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button) {
      return this.enabled != 0
            && 0.5F <= this.revealAnim.current
            && button == 0
            && this.x <= (float)mx
            && mx <= this.x + this.width
            && this.y <= (float)my
            && my <= this.y + this.height
         ? this.onClick(mx, my)
         : false;
   }

   @Override
   public boolean onClick(double mx, double my) {
      this.pressAnim.from = 1.0F;
      this.pressAnim.current = 1.0F;
      this.pressAnim.target = 1.0F;
      this.pressAnim.running = false;
      long time = PlateIconButton.Anim.now();
      float value = this.pressAnim.advance(time);
      this.pressAnim.current = value;
      this.pressAnim.start = time;
      this.pressAnim.from = value;
      this.pressAnim.target = 0.0F;
      this.pressAnim.running = true;
      if (this.callback != null) {
         invokeCallback(this.callback);
      }

      return true;
   }

   public void setEnabled(boolean value) {
      this.enabled = (byte)(value ? 1 : 0);
      float target = value ? 1.0F : 0.0F;
      if (this.revealAnim.target != target) {
         long time = PlateIconButton.Anim.now();
         float current = this.revealAnim.advance(time);
         this.revealAnim.start = time;
         this.revealAnim.from = current;
         this.revealAnim.target = target;
         this.revealAnim.running = true;
      }
   }

   public boolean isEnabled() {
      return this.enabled != 0;
   }

   public int icon() {
      return this.icon;
   }

   public void setIcon(int value) {
      this.icon = value;
   }

   public int tint() {
      return this.tint;
   }

   public void setTint(int value) {
      this.tint = value;
   }

   public String label() {
      return this.label;
   }

   public void setLabel(String value) {
      this.label = value != null ? value : "";
   }

   public void setCallback(Object value) {
      this.callback = value;
   }

   public float reveal() {
      return this.revealAnim.current;
   }

   private float updateHover(float mouseX, float mouseY) {
      float target;
      if (!(mouseX < this.x)
         && !(this.x + this.width < mouseX)
         && !(mouseY < this.y)
         && !(this.y + this.height < mouseY)
         && (Screen.focusedInput == null || Screen.allowHover)) {
         this.flags = this.flags & 0xFF00 | 1;
         target = 1.0F;
      } else {
         this.flags &= 65280;
         target = 0.0F;
      }

      if (this.rectAnim.target != target) {
         long time = PlateIconButton.Anim.now();
         float value = this.rectAnim.advance(time);
         this.rectAnim.start = time;
         this.rectAnim.from = value;
         this.rectAnim.target = target;
         this.rectAnim.running = true;
      }

      return this.rectAnim.advance(PlateIconButton.Anim.now());
   }

   private static float clamp01(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private static void releaseSourceString() {
   }

   private static void resetString(int offset) {
   }

   private static void freeString(int offset) {
   }

   private static void releaseCallback(Object sub, boolean heap) {
   }

   private static void invokeCallback(Object sub) {
   }

   private static int themeColor(int offset) {
      return 0;
   }

   private static int themeBorderColor() {
      return 0;
   }

   private static int mixColor(int from, int to, float t) {
      return 0;
   }

   private static float[] iconMetrics(int icon) {
      return new float[2];
   }

   private static void drawPanel(Object mat, float x, float y, float width, float height, float radius, float alpha, float style) {
   }

   private static void drawInnerPlate(Object mat, float x, float y, float width, float height, float radius, int color, float alpha) {
   }

   private static void drawIcon(Object mat, int icon, float x, float y, float width, float height, int color, float alpha) {
   }

   private static void drawTooltip(String text, float x, float y, float width, float height) {
   }

   private static final class Anim {
      public static final int ANIM_FROM = 0;
      public static final int ANIM_CURRENT = 4;
      public static final int ANIM_TARGET = 8;
      public static final int ANIM_DURATION = 12;
      public static final int ANIM_EASING = 16;
      public static final int ANIM_START = 24;
      public static final int ANIM_RUNNING = 32;
      public static final int EASING_CUBIC = 0;
      public static final int EASING_EXPO = 1;
      public static final int EASING_IN_OUT_CUBIC = 2;
      float from;
      float current;
      float target;
      float duration;
      int easing;
      long start;
      boolean running;

      void set(float value, float duration) {
         this.from = value;
         this.current = value;
         this.target = value;
         this.duration = duration;
         this.easing = 0;
         this.start = now();
         this.running = false;
      }

      void retarget(float target) {
         if (this.target != target) {
            long time = now();
            float value = this.advance(time);
            this.from = value;
            this.target = target;
            this.start = time;
            this.running = true;
         }
      }

      float advance(long time) {
         if (this.running && !(this.duration <= 0.0F)) {
            float k = (float)((time - this.start) / 1.0E9) / this.duration;
            if (k <= 0.0F) {
               this.current = this.from;
               return this.current;
            } else if (k >= 1.0F) {
               this.running = false;
               this.current = this.target;
               return this.current;
            } else {
               this.current = this.ease(k) * (this.target - this.from) + this.from;
               return this.current;
            }
         } else {
            this.current = this.target;
            this.running = false;
            return this.current;
         }
      }

      float ease(float t) {
         if (this.easing == 1) {
            return easeOutExpo(t);
         } else {
            return this.easing == 2 ? easeInOutCubic(t) : easeOutCubic(t);
         }
      }

      static long now() {
         return System.nanoTime();
      }

      static float easeOutCubic(float t) {
         float inv = 1.0F - t;
         return 1.0F - inv * inv * inv;
      }

      static float easeOutExpo(float t) {
         return 1.0F - (float)Math.pow(2.0, -10.0 * t);
      }

      static float easeInOutCubic(float t) {
         if (t < 0.5F) {
            return 4.0F * t * t * t;
         } else {
            float inv = 2.0F - 2.0F * t;
            return 1.0F - inv * inv * inv / 2.0F;
         }
      }
   }
}

