package client.gui;

import client.Setting;

public class SliderRow extends Row {
   public static final int SMOOTH_OFFSET = 72;
   public static final int VALUE_OFFSET = 80;
   public static final int INITIALIZED_OFFSET = 84;
   public static final int REVEAL_ANIM_OFFSET = 88;
   public static final int CACHED_TEXT_OFFSET = 128;
   public static final int CACHED_WIDTH_OFFSET = 136;
   public static final float LABEL_X_BIAS = 141.0F;
   public static final float LABEL_WIDTH = 70.0F;
   public static final float LABEL_Y_BIAS = 10.0F;
   public static final float DRAG_SPEED = 0.05F;
   public static final float VALUE_EPSILON = 0.01F;
   public static final float LOG_HALF = -0.6931472F;
   public static final float REVEAL_SPEED = 0.22F;
   public static final float NONE = -1.0F;
   public static final float TRACK_HEIGHT = 2.0F;
   public static final float HALF = 0.5F;
   private float smooth;
   private float value;
   private boolean initialized;
   private float revealAnim;
   private float cachedText = -1.0F;
   private float textWidth;
   private float revealTarget;
   private float cachedWidth = -1.0F;
   public static final float HOLD = 6.0F;

   public SliderRow() {
   }

   public SliderRow(Object owner, Setting setting) {
      super(owner, setting);
      this.bound = setting;
      this.smooth = -1.0F;
      this.value = 0.0F;
      this.initialized = false;
      this.revealAnim = 0.0F;
      this.cachedWidth = -1.0F;
   }

   @Override
   public void render(Object mat, float x, float y, float width, float height, float mouseX, float mouseY) {
      float target = (float)this.bound.getNumber();
      float factor = this.smoothFactor();
      if (!this.initialized) {
         this.initialized = true;
      } else {
         float diff = target - this.value;
         if (0.01F <= Math.abs(diff)) {
            factor = (float)Math.exp(factor * -0.6931472F / 0.05F);
            target -= factor * diff;
         }
      }

      this.value = target;
      float labelX = x + 141.0F;
      float labelY = y + 10.0F;
      Object ownerObject = this.owner;
      boolean dragging = this.ownerDragTarget() == this.bound;
      if (dragging) {
         Screen.hoveredWidget = 3;
      } else if (labelX <= mouseX && mouseX <= labelX + 70.0F && y <= mouseY && mouseY <= y + 26.0F && (Screen.focusedWidget == null || Screen.allowHover)) {
         Screen.hoveredWidget = 1;
      }

      double min = this.bound.getMin();
      double max = this.bound.getMax();
      float ratio = (float)clamp((this.value - min) / (max - min), 0.0, 1.0);
      float targetAlpha = dragging ? 0.0F : 1.0F;
      if (this.revealTarget != targetAlpha) {
         this.revealTarget = targetAlpha;
      }

      float reveal = this.revealAnim;
      float trackY = labelY + 4.0F;
      float knobX = labelX + ratio * 70.0F - reveal * 0.5F;
      drawTrack(mat, labelX, trackY, 70.0F * ratio, 2.0F);
      drawKnob(mat, knobX, trackY - 6.0F, 2.0F);
      if (this.cachedText < 0.0F || this.bound.getNumber() != this.cachedText) {
         this.textWidth = measureText(mat, this.bound.getName(), 136.0F);
         this.cachedText = (float)this.bound.getNumber();
      }

      drawValue(mat, this.bound, x + width - 8.0F - this.textWidth, trackY);
   }

   @Override
   public boolean mouseClicked(double mx, double my, int button, float x, float y) {
      if (button != 0) {
         return false;
      } else {
         float labelX = x + 141.0F;
         if (labelX <= mx && mx <= labelX + 70.0F && y <= my && my <= y + 26.0F) {
            this.setOwnerDragTarget(this.bound);
            double before = this.bound.getNumber();
            double ratio = clamp((mx - labelX) / 70.0, 0.0, 1.0);
            double min = this.bound.getMin();
            double max = this.bound.getMax();
            this.bound.setNumber((max - min) * ratio + min);
            if (this.bound.getNumber() != before) {
               this.playClick();
            }

            return true;
         } else {
            return false;
         }
      }
   }

   @Override
   public float drag(float value0, float width) {
      return value0 + 141.0F;
   }

   public boolean mouseDragged(double mx, float y) {
      return false;
   }

   public float value() {
      return this.value;
   }

   public float revealAnim() {
      return this.revealAnim;
   }

   private float smoothFactor() {
      return 0.0F;
   }

   private Object ownerDragTarget() {
      return null;
   }

   private void setOwnerDragTarget(Setting setting) {
   }

   private void playClick() {
   }

   private static double clamp(double value, double min, double max) {
      if (value < min) {
         return min;
      } else {
         return value > max ? max : value;
      }
   }

   private static void drawTrack(Object mat, float x, float y, float width, float height) {
   }

   private static void drawKnob(Object mat, float x, float y, float size) {
   }

   private static float measureText(Object mat, String text, float widthHint) {
      return 0.0F;
   }

   private static void drawValue(Object mat, Setting setting, float x, float y) {
   }
}

