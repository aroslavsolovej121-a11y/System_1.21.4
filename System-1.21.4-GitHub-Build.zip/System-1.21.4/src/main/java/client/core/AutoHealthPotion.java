package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AutoHealthPotion extends client.Feature {
   public static final String MODULE = "autohealthpotion";
   public static final String DISPLAY = "АутоХеалтхПот";
   private static final int STATE_IDLE = 0;
   private static final int STATE_SELECT = 1;
   private static final int STATE_USE = 2;
   private static final int STATE_AIM = 3;
   private static final int STATE_RESTORE = 4;
   private static final int INVENTORY_LIMIT = 36;
   private static final int HOTBAR_LAST = 8;
   private static final int HOTBAR_CONTAINER_OFFSET = 36;
   private static final double NANOS_PER_SECOND = 1.0E9;
   private static final float TARGET_PITCH = Float.intBitsToFloat(1118437376);
   private static final double AIM_EPSILON = 0.05;
   private static final double AIM_SCALE = 0.8;
   private static final double AIM_FACTOR_MIN = 0.01;
   private static final double AIM_FACTOR_MAX = 0.95;
   private static final double AIM_TOLERANCE = 1.5;
   private static final double ANGLE_FULL = 360.0;
   private static final double ANGLE_HALF = 180.0;
   private static final double ANGLE_NEG_FULL = -360.0;
   private static final double ANGLE_NEG_HALF = -180.0;
   private static final int SWAP_NONE = -1;
   private final int[] swapManager = Client.newSwapManager();
   private final boolean[] keyLatch = new boolean[1];
   private int state;
   private float capturedYaw;
   private float capturedPitch;
   private int previousSlot = -1;
   private int swapBackSlot = -1;
   private int targetSlot = -1;
   private float aimYaw;
   private float aimPitch;
   private long lastFrameNanos;

   public AutoHealthPotion() {
      super("autohealthpotion", "АутоХеалтхПот", Category.Player);
      this.add(client.Setting.number("aim_speed", 15.0, 10.0, 30.0));
      this.add(client.Setting.key("trigger", 0));
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
   }

   @Override
   public void onTick() {
      Client.swapManagerTick(this.swapManager);
      if (!Client.inGame()) {
         this.reset();
      } else {
         if (Client.keybindPressed(this.triggerKey(), this.triggerMods(), this.keyLatch) && !Client.isPaused() && this.state == 0) {
            this.startDrink();
         }

         Entity player = Client.player();
         int current = this.state;
         if (current != 0) {
            if (current == 1) {
               if (Client.swapManagerFree(this.swapManager)) {
                  if (this.aimReached()) {
                     int slot = this.targetSlot;
                     if (slot <= 8) {
                        Client.setSelectedSlot(slot);
                     }

                     this.state = 2;
                  }
               }
            } else if (current == 2) {
               Client.interactItem(player);
               this.aimYaw = this.capturedYaw;
               this.aimPitch = this.capturedPitch;
               this.state = 3;
            } else if (current == 3) {
               if (this.aimReached()) {
                  this.state = 4;
               }
            } else if (current == 4) {
               if (Client.swapManagerFree(this.swapManager)) {
                  if (this.swapBackSlot != -1) {
                     int slot = this.swapBackSlot > 8 ? this.swapBackSlot : this.swapBackSlot + 36;
                     Client.swapManagerQueue(this.swapManager, slot, 8, 0);
                     this.swapBackSlot = -1;
                  } else {
                     int restore = this.previousSlot;
                     if (restore >= 0 && restore <= 8) {
                        Client.setSelectedSlot(restore);
                        this.state = 0;
                     } else {
                        this.state = 0;
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void onRender() {
      this.applyAim();
   }

   public void applyAim() {
      if (this.state != 0) {
         if (Client.inGame()) {
            if (!Client.isPauseScreen()) {
               long now = Client.nanos();
               double delta = 0.0;
               if (this.lastFrameNanos > 0L) {
                  delta = (now - this.lastFrameNanos) / 1.0E9;
               }

               this.lastFrameNanos = now;
               Entity player = Client.player();
               double yawDelta = wrap(this.aimYaw - Client.entityYaw(player));
               double pitchDelta = (double)this.aimPitch - Client.entityPitch(player);
               if (!(Math.abs(yawDelta) < 0.05) || !(Math.abs(pitchDelta) < 0.05)) {
                  double factor = clamp(this.aimSpeed() * 0.8 * delta, 0.01, 0.95);
                  Client.rotateBy(player, (float)(factor * yawDelta), (float)(factor * pitchDelta));
               }
            }
         }
      }
   }

   private void startDrink() {
      int candidate = -1;

      for (int index = 0; index < 36; index++) {
         int next = candidate;
         Object stack = Client.inventoryStack(index);
         Object item = Client.stackItem(stack);
         Object potion = Client.potionItem();
         if (Client.sameItem(item, potion)) {
            int amplifier = Client.itemStackEffectAmplifier(stack);
            if (amplifier >= 0) {
               if (amplifier > 0) {
                  candidate = index;
                  break;
               }

               next = candidate;
               if (candidate == -1) {
                  next = index;
               }
            }
         }

         candidate = next;
      }

      if (candidate != -1) {
         Entity player = Client.player();
         this.capturedYaw = Client.entityYaw(player);
         this.capturedPitch = Client.entityPitch(player);
         this.previousSlot = Client.selectedSlot();
         this.aimYaw = this.capturedYaw;
         this.aimPitch = TARGET_PITCH;
         this.lastFrameNanos = Client.nanos();
         if (candidate < 9) {
            this.swapBackSlot = -1;
            this.targetSlot = candidate;
         } else {
            this.swapBackSlot = candidate;
            this.targetSlot = 8;
            Client.swapManagerQueue(this.swapManager, candidate, 8, 0);
         }

         this.state = 1;
      }
   }

   private boolean aimReached() {
      Entity player = Client.player();
      double yawDelta = (double)this.aimYaw - Client.entityYaw(player);
      yawDelta %= 360.0;
      if (yawDelta > 180.0) {
         yawDelta += -360.0;
      }

      if (yawDelta < -180.0) {
         yawDelta += 360.0;
      }

      double pitchDelta = (double)this.aimPitch - Client.entityPitch(player);
      return Math.sqrt(pitchDelta * pitchDelta + yawDelta * yawDelta) < 1.5;
   }

   private void reset() {
      Client.swapManagerReset(this.swapManager);
      this.swapBackSlot = -1;
      this.state = 0;
      this.lastFrameNanos = 0L;
      this.previousSlot = -1;
      this.targetSlot = -1;
   }

   public int state() {
      return this.state;
   }

   public int previousSlot() {
      return this.previousSlot;
   }

   public int targetSlot() {
      return this.targetSlot;
   }

   public int swapBackSlot() {
      return this.swapBackSlot;
   }

   private static double clamp(double value, double min, double max) {
      if (value < min) {
         return min;
      } else {
         return value > max ? max : value;
      }
   }

   private static double wrap(double angle) {
      double wrapped = angle % 360.0;
      if (wrapped > 180.0) {
         wrapped += -360.0;
      }

      if (wrapped < -180.0) {
         wrapped += 360.0;
      }

      return wrapped;
   }

   private double aimSpeed() {
      client.Setting setting = this.setting("aim_speed");
      return setting == null ? 15.0 : setting.getNumber();
   }

   private int triggerKey() {
      client.Setting setting = this.setting("trigger");
      return setting == null ? 0 : setting.getKey();
   }

   private int triggerMods() {
      return 0;
   }

   private client.Setting setting(String name) {
      for (client.Setting value : this.getSettings()) {
         if (value.getName().equals(name)) {
            return value;
         }
      }

      return null;
   }
}

