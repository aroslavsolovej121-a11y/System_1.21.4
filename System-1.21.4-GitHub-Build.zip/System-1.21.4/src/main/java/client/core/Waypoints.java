package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class Waypoints extends client.Feature {
   public static final String MODULE = "waypoints";
   public static final String DISPLAY = "Шайпоинтз";
   private static final double PLATE_XZ_OFFSET = 0.5;
   private static final double PLATE_Y_OFFSET = 1.0;
   private static final double PLATE_MIN_DISTANCE = 0.001;
   private static final double PLATE_CLAMP_DISTANCE = 32.0;
   private static final double PLATE_SIZE_FACTOR = 0.0025;
   private static final double PLATE_SIZE_MIN = 0.02;
   private static final double PLATE_SIZE_MAX = 0.1;
   private static final double PLATE_SCALE_DIVISOR = 100.0;
   private static final long JOIN_REFRESH_DELAY_MS = 2000L;
   private static final long RETRY_DELAY_MS = 6000L;
   private static final long BUSY_DELAY_MS = 5000L;
   private static final long COLLECT_WINDOW_MS = 1200L;
   private static final long REFRESH_MIN_DELAY_MS = 30000L;
   private static final long REFRESH_MAX_DELAY_MS = 300000L;
   private static final long REFRESH_AFTER_EVENT_MS = 3000L;
   private static final long SECONDS_TO_MS = 1000L;
   private static final int EVENT_MARKER_LENGTH = 14;
   private static final int EVENT_TYPE_TIMED = 1;
   private static final String EVENTS_COMMAND = "events delay";
   private static final String EVENT_MARKER = "[Ивенты]";
   private static final String NEXT_EVENT_NAME = "Следующий ивент";
   private static final String[] EVENT_SKIP_PATTERNS = new String[]{"аир-дроп", "аирдроп", "air drop", "airdrop", "алтарь нежити"};
   private static final List<Waypoints.Waypoint> WAYPOINTS = new ArrayList<>();
   private String worldKey = "";
   private Object worldHandle;
   private long refreshAt;
   private long retryAt;
   private long collectUntil;
   private final List<String> pendingLines = new ArrayList<>();

   public Waypoints() {
      super("waypoints", "Шайпоинтз", Category.Client);
      this.add(client.Setting.bool("render_in_world", true));
      this.add(client.Setting.bool("render_in_hud", true));
      this.add(client.Setting.number("max_distance", 1000.0, 16.0, 50000.0));
      this.add(client.Setting.number("plate_scale", 50.0, 10.0, 200.0));
      this.add(client.Setting.bool("toggle_affects_world", true));
      this.add(client.Setting.bool("toggle_affects_hud", true));
      this.add(client.Setting.bool("event_waypoints", false));
   }

   public static List<Waypoints.Waypoint> waypoints() {
      return WAYPOINTS;
   }

   @Override
   public boolean isVisible() {
      return this.renderInWorld() && !this.worldKey.isEmpty() && !WAYPOINTS.isEmpty();
   }

   @Override
   public void onTick() {
      this.worldKey = Client.normalizeWorldKey(Client.currentServerAddress());
      this.updateEvents(Client.uptimeMillis());
   }

   @Override
   public void onRender() {
      if (this.renderInWorld() && !this.worldKey.isEmpty()) {
         double maxDistance = this.maxDistance();
         boolean affectsWorld = this.toggleAffectsWorld();
         double[] view = Client.waypointViewPosition();
         Entity player = Client.player();
         double[] position = Client.entityPosition(player);
         if (position == null) {
            position = new double[3];
         }

         for (int index = 0; index < WAYPOINTS.size(); index++) {
            Waypoints.Waypoint waypoint = WAYPOINTS.get(index);
            if (waypoint.world.length() == this.worldKey.length()
               && waypoint.world.equals(this.worldKey)
               && !waypoint.hidden
               && (!affectsWorld || waypoint.plateVisible)) {
               double offsetX = position[0] - waypoint.x;
               double offsetY = position[1] - waypoint.y;
               double offsetZ = position[2] - waypoint.z;
               double distance = Math.sqrt(offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ);
               if (distance <= maxDistance) {
                  this.drawPlate(view, waypoint, distance);
               }
            }
         }
      }
   }

   @Override
   public void onDisable() {
      this.resetState();
   }

   public void onChat(String message) {
      if (this.eventWaypoints()) {
         String stripped = Client.stripColorCodes(message);
         int marker = 14 <= stripped.length() ? stripped.indexOf("[Ивенты]") : -1;
         if (marker == -1) {
            if (this.collectUntil == 0L) {
               return;
            }
         } else {
            this.pendingLines.clear();
            this.collectUntil = Client.uptimeMillis() + 1200L;
         }

         this.pendingLines.add(message);
      }
   }

   private void drawPlate(double[] view, Waypoints.Waypoint waypoint, double distance) {
      double offsetX = waypoint.x + 0.5 - view[0];
      double offsetY = waypoint.y + 1.0 - view[1];
      double offsetZ = waypoint.z + 0.5 - view[2];
      double length = Math.sqrt(offsetX * offsetX + offsetY * offsetY + offsetZ * offsetZ);
      if (!(length < 0.001)) {
         double clamp = 1.0;
         if (length > 32.0) {
            clamp = 32.0 / length;
         }

         double positionX = offsetX * clamp + view[0];
         double positionY = offsetY * clamp + view[1];
         double positionZ = offsetZ * clamp + view[2];
         double size = clamp * length * 0.0025;
         if (size < 0.02) {
            size = 0.02;
         } else if (size > 0.1) {
            size = 0.1;
         }

         double scale = this.plateScale() / 100.0;
         Client.drawWaypointPlate(new double[]{positionX, positionY, positionZ}, waypoint.name, (float)scale, (float)size, (float)distance);
      }
   }

   private void updateEvents(long now) {
      if (!this.eventWaypoints()) {
         if (this.refreshAt != 0L || this.retryAt != 0L || this.collectUntil != 0L || this.worldHandle != null) {
            this.resetState();
         }
      } else {
         Entity player = Client.player();
         if (player != null) {
            Object world = Client.worldOf(player);
            if (world != null && (this.worldHandle == null || !Client.isSameObject(this.worldHandle, world))) {
               this.worldHandle = world;
               purge();
               this.refreshAt = now + 2000L;
               this.retryAt = 0L;
               this.collectUntil = 0L;
               this.pendingLines.clear();
            }
         }

         if (this.collectUntil != 0L && now >= this.collectUntil) {
            this.collectUntil = 0L;
            this.retryAt = 0L;
            Client.EventQuery query = Client.parseEventQuery(this.pendingLines);
            this.buildFromEvents(query, now);
            this.pendingLines.clear();
         } else if (this.refreshAt != 0L && now >= this.refreshAt) {
            if (Client.inGame() && !this.worldKey.isEmpty()) {
               if (Client.protectGateOpen(Client.holyWorldOwner()) && Client.holyWorldFlagSet(Client.holyWorldOwner())) {
                  this.refreshAt = now + 5000L;
               } else {
                  this.refreshAt = 0L;
                  this.retryAt = now + 6000L;
                  this.collectUntil = 0L;
                  this.pendingLines.clear();
                  Client.sendChatCommand("events delay");
               }
            }
         } else {
            if (this.retryAt != 0L && this.collectUntil == 0L && this.retryAt <= now) {
               this.retryAt = 0L;
            }
         }
      }
   }

   private void buildFromEvents(Client.EventQuery query, long now) {
      purge();
      if (!this.worldKey.isEmpty()) {
         long earliest = Long.MAX_VALUE;

         for (int index = 0; index < query.events.size(); index++) {
            Client.EventEntry event = query.events.get(index);
            if (!skipEvent(event.name)) {
               long expiry;
               if (!event.hasPosition) {
                  if (event.type != 1 || event.seconds < 0) {
                     continue;
                  }

                  expiry = event.seconds * 1000L + now;
               } else if (event.type == 1) {
                  expiry = event.seconds < 0 ? 0L : event.seconds * 1000L + now;
               } else {
                  expiry = 0L;
               }

               int x = event.hasPosition ? event.x : 0;
               int y = event.hasPosition ? event.y : 0;
               int z = event.hasPosition ? event.z : 0;
               this.addWaypoint(event.name, x, y, z, true, !event.hasPosition, expiry);
               if (expiry != 0L && expiry < earliest) {
                  earliest = expiry;
               }
            }
         }

         if (query.nextDelaySeconds >= 0) {
            long expiryx = query.nextDelaySeconds * 1000L + now;
            this.addWaypoint("Следующий ивент", 0, 0, 0, true, true, expiryx);
            if (expiryx < earliest) {
               earliest = expiryx;
            }
         }

         long next = now + 300000L;
         if (earliest != Long.MAX_VALUE && earliest + 3000L < next) {
            next = earliest + 3000L;
         }

         if (next < now + 30000L) {
            next = now + 30000L;
         }

         this.refreshAt = next;
      }
   }

   private static boolean skipEvent(String name) {
      if (name == null) {
         return true;
      } else {
         for (int index = 0; index < EVENT_SKIP_PATTERNS.length; index++) {
            if (name.contains(EVENT_SKIP_PATTERNS[index])) {
               return true;
            }
         }

         return false;
      }
   }

   private Waypoints.Waypoint addWaypoint(String name, int x, int y, int z, boolean plateVisible, boolean noPosition, long expiry) {
      String trimmedName = name == null ? "" : name.trim();
      String trimmedWorld = this.worldKey.trim();
      if (!trimmedName.isEmpty() && !trimmedWorld.isEmpty()) {
         Waypoints.Waypoint waypoint = new Waypoints.Waypoint();
         waypoint.name = trimmedName;
         waypoint.x = x;
         waypoint.y = y;
         waypoint.z = z;
         waypoint.world = trimmedWorld;
         waypoint.plateVisible = plateVisible;
         waypoint.alive = true;
         waypoint.noPosition = noPosition;
         waypoint.expiry = expiry;
         WAYPOINTS.add(waypoint);
         if (!plateVisible) {
            Client.waypointNotify(2);
         }

         return waypoint;
      } else {
         return null;
      }
   }

   private static void purge() {
      int write = 0;

      for (int read = 0; read < WAYPOINTS.size(); read++) {
         Waypoints.Waypoint waypoint = WAYPOINTS.get(read);
         if (waypoint.alive) {
            WAYPOINTS.set(write, waypoint);
            write++;
         }
      }

      while (WAYPOINTS.size() > write) {
         WAYPOINTS.remove(WAYPOINTS.size() - 1);
      }
   }

   private void resetState() {
      this.refreshAt = 0L;
      this.retryAt = 0L;
      this.collectUntil = 0L;
      this.pendingLines.clear();
      this.worldHandle = null;
      purge();
   }

   private boolean renderInWorld() {
      client.Setting setting = this.setting("render_in_world");
      return setting == null || setting.getBoolean();
   }

   private double maxDistance() {
      client.Setting setting = this.setting("max_distance");
      return setting == null ? 1000.0 : setting.getNumber();
   }

   private double plateScale() {
      client.Setting setting = this.setting("plate_scale");
      return setting == null ? 50.0 : setting.getNumber();
   }

   private boolean toggleAffectsWorld() {
      client.Setting setting = this.setting("toggle_affects_world");
      return setting == null || setting.getBoolean();
   }

   private boolean eventWaypoints() {
      client.Setting setting = this.setting("event_waypoints");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }

   public static final class Waypoint {
      public String name = "";
      public int x;
      public int y;
      public int z;
      public String world = "";
      public boolean plateVisible;
      public boolean alive;
      public boolean hidden;
      public boolean noPosition;
      public long expiry;
   }
}

