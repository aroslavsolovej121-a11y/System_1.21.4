package client.core;

import client.Category;
import client.mc.Client;

public final class StreamBypass extends client.Feature {
   public static final String MODULE = "stream_bypass";
   public static final String DISPLAY = "ЗтреамБйпазз";
   public static final int MASK_WORLD_PLATES = 1;
   public static final int MASK_HUD = 2;
   public static final int MASK_OVERLAYS = 4;
   public static final int MASK_GUI = 8;
   public static final String TOOLTIP = "Скрытое рисуется поверх экранов игры (кроме чата), а эффекты кадра — блум, погода, свечение — на записи остаются";
   public static final int TOOLTIP_LENGTH = 204;
   private static StreamBypass active;

   public StreamBypass() {
      super("stream_bypass", "ЗтреамБйпазз", Category.Client);
      this.add(client.Setting.bool("hud", true));
      this.add(client.Setting.bool("gui", true));
      this.add(client.Setting.bool("overlays", true));
      this.add(client.Setting.bool("world_plates", true));
   }

   public static StreamBypass active() {
      return active;
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
   }

   @Override
   public void setEnabled(boolean value) {
      if (!value && this.enabled && Client.streamExclusionOverlayActive()) {
         this.enabled = false;
         Client.teardownStreamExclusion(this);
         this.onDisable();
         Client.notifyModuleToggled(this);
      } else {
         super.setEnabled(value);
      }
   }

   public boolean hud() {
      client.Setting setting = this.setting("hud");
      return setting == null || setting.getBoolean();
   }

   public boolean gui() {
      client.Setting setting = this.setting("gui");
      return setting == null || setting.getBoolean();
   }

   public boolean overlays() {
      client.Setting setting = this.setting("overlays");
      return setting == null || setting.getBoolean();
   }

   public boolean worldPlates() {
      client.Setting setting = this.setting("world_plates");
      return setting == null || setting.getBoolean();
   }

   public static int currentMask() {
      StreamBypass module = active;
      if (module == null || !module.enabled) {
         return 0;
      } else if (!Client.streamCaptureActive()) {
         return 0;
      } else {
         int mask = 0;
         if (module.worldPlates()) {
            mask |= 1;
         }

         if (module.overlays()) {
            mask |= 4;
         }

         if (module.gui()) {
            mask |= 8;
         }

         if (module.hud()) {
            mask |= 2;
         }

         return mask;
      }
   }

   public String tooltip() {
      return "Скрытое рисуется поверх экранов игры (кроме чата), а эффекты кадра — блум, погода, свечение — на записи остаются";
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

