package client.core;

public class Alignment {
}
