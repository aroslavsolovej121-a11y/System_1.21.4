package client.core;

public class Choice {
}
