package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AutoLeave extends client.Feature {
   public static final String MODULE = "autoleave";
   private static final double MAX_RADIUS = 128.0;
   private static final double TELEPORT_DISTANCE = 3.0;
   private static final String REASON_CRYSTAL = "кристалл";
   private static final String REASON_TNT = "ТНТ";
   private boolean left;
   private boolean teleportGuard;
   private String reason = "";
   private Entity cause;

   public AutoLeave() {
      super("autoleave", "", Category.Player);
      this.add(client.Setting.number("distance", 3.0, 0.0, 16.0));
      this.add(client.Setting.bool("crystal", true));
      this.add(client.Setting.number("crystal_distance", 4.0, 0.0, 16.0));
      this.add(client.Setting.bool("tnt", true));
      this.add(client.Setting.number("tnt_distance", 6.0, 0.0, 16.0));
      this.add(client.Setting.number("tnt_fuse", 40.0, 0.0, 80.0));
      this.add(client.Setting.bool("anti_teleport", false));
      this.add(client.Setting.mode("mode", "кристалл", "кристалл", "hub"));
   }

   @Override
   public void onEnable() {
      this.left = false;
      this.cause = null;
      this.reason = "";
   }

   @Override
   public void onDisable() {
      this.left = false;
      this.cause = null;
      this.reason = "";
   }

   @Override
   public void onTick() {
      if (!this.left) {
         if (Client.inGame()) {
            Entity self = Client.player();
            double distance = this.distance();
            double radius = Math.min(distance, 128.0);
            double radiusSquared = radius * radius;
            double[] selfPosition = Client.entityPosition(self);
            this.cause = null;
            this.reason = "";
            Client.forEachEntity(entity -> this.inspect(entity, self, selfPosition, radiusSquared, distance));
            if (this.cause != null) {
               this.left = true;
               Client.leaveServer();
            }
         }
      }
   }

   public void onTeleport(double distance) {
      if (this.teleportGuard && !this.left && 3.0 <= distance) {
         this.setEnabled(false);
      }
   }

   public String reason() {
      return this.reason;
   }

   public boolean hasLeft() {
      return this.left;
   }

   private void inspect(Entity entity, Entity self, double[] selfPosition, double radiusSquared, double distance) {
      if (this.cause == null) {
         double[] position = Client.entityPosition(entity);
         double dx = selfPosition[0] - position[0];
         double dy = selfPosition[1] - position[1];
         double dz = selfPosition[2] - position[2];
         double distanceSquared = dx * dx + dy * dy + dz * dz;
         if (distanceSquared < radiusSquared) {
            double real = Math.sqrt(distanceSquared);
            boolean player = Client.isPlayer(entity);
            if (player && real <= distance && !Client.sameEntity(entity, self)) {
               String name = Client.playerName(entity);
               if (!Client.isIgnoredName(name)) {
                  this.cause = entity;
                  this.reason = name;
               }
            } else {
               boolean crystal = this.crystal() && Client.isCrystalEntity(entity) && !(this.crystalDistance() < real);
               if (crystal) {
                  this.cause = entity;
                  this.reason = "кристалл";
               } else if (this.tnt() && Client.isTntEntity(entity)) {
                  if (!(this.tntDistance() < real)) {
                     int fuse = Client.tntFuse(entity);
                     if (fuse >= 0) {
                        if (!(this.tntFuse() < fuse)) {
                           this.cause = entity;
                           this.reason = "ТНТ";
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public double distance() {
      return this.number("distance", 3.0);
   }

   public boolean crystal() {
      return this.bool("crystal", true);
   }

   public double crystalDistance() {
      return this.number("crystal_distance", 4.0);
   }

   public boolean tnt() {
      return this.bool("tnt", true);
   }

   public double tntDistance() {
      return this.number("tnt_distance", 6.0);
   }

   public double tntFuse() {
      return this.number("tnt_fuse", 40.0);
   }

   public boolean antiTeleport() {
      return this.bool("anti_teleport", false);
   }

   public String mode() {
      client.Setting s = this.setting("mode");
      return s == null ? "кристалл" : s.getMode();
   }

   private double number(String name, double fallback) {
      client.Setting s = this.setting(name);
      return s == null ? fallback : s.getNumber();
   }

   private boolean bool(String name, boolean fallback) {
      client.Setting s = this.setting(name);
      return s == null ? fallback : s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

