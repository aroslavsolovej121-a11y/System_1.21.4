package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class Sprint extends client.Feature {
   public static final String MODULE = "sprint";
   public static final String DISPLAY = "Зпринт";

   public Sprint() {
      super("sprint", "Зпринт", Category.Movement);
   }

   @Override
   public void onDisable() {
      Client.setSprintKeyDown(false);
   }

   @Override
   public void onTick() {
      if (Client.isForwardKeyDown()) {
         Entity player = Client.localPlayer();
         Client.setSprintKeyDown(true);
         if (!Client.isTouchingWater(player)) {
            Client.setSprinting(player, true);
         } else if (Client.isSubmergedInWater(player)) {
            if (player != null) {
               Client.setSwimming(player, true);
               Client.checkJni();
            }
         }
      }
   }
}

