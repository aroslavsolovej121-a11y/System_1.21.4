package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class TntTimer extends client.Feature {
   public static final String MODULE = "tnt_timer";
   public static final String DISPLAY = "ТнтТимер";
   private static final double NANOS_TO_SECONDS = 1.0E-9;
   private static final double MAX_DELTA_SECONDS = 0.1;
   private static final double SMOOTHING = 10.0;
   private static final double MAX_SMOOTHING = 1.0;
   private static final double SCALE_PER_BLOCK = 0.0025;
   private static final double MIN_SCALE = 0.02;
   private static final double MAX_SCALE = 0.1;
   private static final double PLATE_HEIGHT = 1.5;
   private static final double FUSE_TICKS = 20.0;
   private static final double PLATE_SCALE_DEFAULT = 0.3;
   private final List<Entity> tracked = new ArrayList<>();
   private final List<Integer> aliveIds = new ArrayList<>();
   private final List<Float> scales = new ArrayList<>();
   private long lastUpdate;

   public TntTimer() {
      super("tnt_timer", "ТнтТимер", Category.Render);
      this.add(client.Setting.number("plate_scale", 0.3, 0.1, 1.0, 0.1));
   }

   @Override
   public void onDisable() {
      this.tracked.clear();
      this.aliveIds.clear();
      this.scales.clear();
      this.lastUpdate = 0L;
   }

   @Override
   public void onTick() {
      this.aliveIds.clear();
      if (Client.inGame()) {
         Client.forEachEntity(entityx -> {
            if (Client.isPrimedTnt(entityx)) {
               this.aliveIds.add(Client.entityId(entityx));
            }
         });

         for (int i = this.tracked.size() - 1; i >= 0; i--) {
            Entity entity = this.tracked.get(i);
            if (!this.aliveIds.contains(Client.entityId(entity))) {
               this.tracked.remove(i);
               if (i < this.scales.size()) {
                  this.scales.remove(i);
               }
            }
         }
      }
   }

   @Override
   public void onRender() {
      long now = Client.timerNanos();
      float delta;
      if (this.lastUpdate == 0L) {
         delta = 0.0F;
      } else {
         float elapsed = (float)((now - this.lastUpdate) * 1.0E-9);
         delta = elapsed <= 0.1 ? elapsed : 0.1F;
      }

      this.lastUpdate = now;
      float factor = (float)Math.min(delta * 10.0, 1.0);
      double plateScale = this.plateScale();

      while (this.scales.size() < this.tracked.size()) {
         this.scales.add(0.0F);
      }

      for (int i = 0; i < this.tracked.size(); i++) {
         Entity entity = this.tracked.get(i);
         if (Client.isAlive(entity)) {
            double[] position = Client.entityPosition(entity);
            double[] self = Client.playerPosition();
            double dx = position[0] - self[0];
            double dy = position[1] - self[1];
            double dz = position[2] - self[2];
            double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double scale = distance * 0.0025;
            if (scale > 0.1) {
               scale = 0.1;
            }

            if (scale < 0.02) {
               scale = 0.02;
            }

            float target = (float)(scale * plateScale);
            float previous = this.scales.get(i);
            this.scales.set(i, (target - previous) * factor + previous);
            double fuse = Client.tntFuse(entity) / 20.0;
            if (fuse <= 0.0) {
               fuse = 0.0;
            }

            Client.drawTntTimer(position[0], position[1] + 1.5, position[2], fuse, this.scales.get(i));
         }
      }
   }

   private double plateScale() {
      client.Setting setting = this.setting("plate_scale");
      return setting == null ? 0.3 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

