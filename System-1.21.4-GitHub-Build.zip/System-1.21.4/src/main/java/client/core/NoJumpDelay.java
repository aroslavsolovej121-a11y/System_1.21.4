package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class NoJumpDelay extends client.Feature {
   public static final String MODULE = "nojumpdelay";
   public static final String DISPLAY = "НоЖумпДелай";

   public NoJumpDelay() {
      super("nojumpdelay", "НоЖумпДелай", Category.Movement);
      this.add(client.Setting.number("delay", 0.0, 0.0, 10.0));
   }

   @Override
   public void onTick() {
      Entity self = Client.localPlayer();
      if (self != null) {
         int delay = (int)this.delay();
         int cooldown = Client.jumpCooldown(self);
         if (delay < cooldown) {
            Client.setJumpCooldown(self, delay);
         }

         Client.checkJni();
      }
   }

   private double delay() {
      client.Setting setting = this.setting("delay");
      return setting == null ? 0.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

