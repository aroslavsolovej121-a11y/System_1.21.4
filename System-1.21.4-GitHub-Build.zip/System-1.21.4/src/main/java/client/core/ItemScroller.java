package client.core;

import client.Category;
import client.mc.Client;

public final class ItemScroller extends client.Feature {
   public static final String MODULE = "itemscroller";
   public static final String DISPLAY = "ИтемЗсроллер";
   public static final double DELAY_VALUE = 50.0;
   public static final double DELAY_MIN = 0.0;
   public static final double DELAY_MAX = 100.0;
   public static final double DELAY_STEP = 1.0;
   private static final long MILLIS_TO_NANOS = 1000000L;
   private long nextMoveNanos;

   public ItemScroller() {
      super("itemscroller", "ИтемЗсроллер", Category.Player);
      this.add(client.Setting.number("delay", 50.0, 0.0, 100.0, 1.0));
   }

   @Override
   public void onEnable() {
      this.nextMoveNanos = 0L;
   }

   @Override
   public void onDisable() {
      this.nextMoveNanos = 0L;
   }

   @Override
   public void onTick() {
      if ((Client.sneakBindDown() || Client.isSneakKeyPressed()) && Client.keyPressed() && Client.containerScreenOpen()) {
         long now = Client.nanos();
         int slot = Client.quickMoveSlot();
         if (this.nextMoveNanos <= now && slot >= 0 && Client.slotPresent(slot)) {
            Client.quickMoveSlot(slot);
            this.nextMoveNanos = now + (long)(this.delay() * 1000000.0);
         }
      } else {
         this.nextMoveNanos = 0L;
      }
   }

   private double delay() {
      client.Setting setting = this.setting("delay");
      return setting == null ? 50.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }
}

