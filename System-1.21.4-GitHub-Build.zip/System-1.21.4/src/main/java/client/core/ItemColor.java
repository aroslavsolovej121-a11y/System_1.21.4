package client.core;

import client.Category;
import client.mc.Client;
import java.util.ArrayList;
import java.util.List;

public final class ItemColor extends client.Feature {
   public static final String MODULE = "item_color";
   public static final String DISPLAY = "ИтемСолор";
   public static final int HIGHLIGHT_STATIC = 1;
   public static final int HIGHLIGHT_BLINK = 2;
   public static final int WHITE = -1;
   public static final int ITEM_SHULKER = 27;
   public static final ItemColor.Entry[] ENTRIES = new ItemColor.Entry[]{
      new ItemColor.Entry("ender_eye", 1, -1),
      new ItemColor.Entry("fire_charge", 2, -1),
      new ItemColor.Entry("sugar", 3, -1),
      new ItemColor.Entry("netherite_scrap", 6, -1),
      new ItemColor.Entry("dried_kelp", 7, -1),
      new ItemColor.Entry("snowball_freeze", 13, -1),
      new ItemColor.Entry("bozha_aura", 18, -1),
      new ItemColor.Entry("totem", 4, -1),
      new ItemColor.Entry("golden_apple", 8, -1),
      new ItemColor.Entry("god_apple", 9, -1),
      new ItemColor.Entry("snowball", 13, -1),
      new ItemColor.Entry("popped_chorus", 11, -1),
      new ItemColor.Entry("nether_star", 14, -1),
      new ItemColor.Entry("jack_o_lantern", 15, -1),
      new ItemColor.Entry("prismarine", 16, -1),
      new ItemColor.Entry("crossbow", 20, -1),
      new ItemColor.Entry("shulker", 27, -1),
      new ItemColor.Entry("potion_assassin", 19, 3355443),
      new ItemColor.Entry("potion_paladin", 19, 65535),
      new ItemColor.Entry("holy_water", 19, 16777215),
      new ItemColor.Entry("potion_radiation", 19, 3329330),
      new ItemColor.Entry("potion_sleep", 19, 255),
      new ItemColor.Entry("potion_rage", 19, 10040115),
      new ItemColor.Entry("potion_popper", 19, 16738740),
      new ItemColor.Entry("talic_mrak", 4, -1),
      new ItemColor.Entry("talic_vihr", 4, -1),
      new ItemColor.Entry("talic_demon", 4, -1),
      new ItemColor.Entry("talic_razdor", 4, -1),
      new ItemColor.Entry("talic_yarost", 4, -1),
      new ItemColor.Entry("talic_krush", 4, -1),
      new ItemColor.Entry("talic_karatel", 4, -1),
      new ItemColor.Entry("talic_tiran", 4, -1),
      new ItemColor.Entry("ender_pearl", 12, -1),
      new ItemColor.Entry("chorus_fruit", 10, -1),
      new ItemColor.Entry("wind_charge", 17, -1),
      new ItemColor.Entry("experience_bottle", 5, -1)
   };
   public static final int[] SHULKER_ITEM_IDS = new int[]{27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43};
   public static final int[] TALISMAN_IDS = new int[]{1, 2, 3, 4, 5, 6, 7, 8};
   private final List<int[]> highlights = new ArrayList<>();
   private int screenId;
   private boolean applied;

   public ItemColor() {
      super("item_color", "ИтемСолор", Category.Render);
      this.add(client.Setting.mode("highlight", "Статик", "Статик", "Мигать"));
      String[] keys = new String[ENTRIES.length];

      for (int i = 0; i < ENTRIES.length; i++) {
         keys[i] = ENTRIES[i].key;
      }

      this.add(client.Setting.multi("items", keys));

      for (ItemColor.Entry entry : ENTRIES) {
         this.add(client.Setting.color(entry.key, entry.color));
      }

      this.add(client.Setting.multi("options", keys));
   }

   public List<int[]> highlights() {
      return this.highlights;
   }

   public int screenId() {
      return this.screenId;
   }

   public boolean hasHighlights() {
      return !this.highlights.isEmpty();
   }

   public int highlightMode() {
      client.Setting setting = this.setting("highlight");
      if (setting == null) {
         return 1;
      } else {
         return "Мигать".equals(setting.getMode()) ? 2 : 1;
      }
   }

   public int colorOf(String key) {
      client.Setting setting = this.setting(key);
      return setting == null ? -1 : setting.getColor();
   }

   public boolean isItemEnabled(String key) {
      client.Setting setting = this.setting("items");
      return setting != null && setting.isSelected(key);
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
   }

   private void reset() {
      if (!this.highlights.isEmpty()) {
         this.highlights.clear();
      }
   }

   @Override
   public void onTick() {
      this.highlights.clear();
      this.applied = false;
      if (Client.containerScreenOpen()) {
         this.screenId = Client.openScreenId();
         int size = Client.containerSize();

         for (int index = 0; index < size; index++) {
            Object stack = Client.slotStack(index);
            if (stack != null && Client.stackPresent(stack)) {
               Object item = Client.slotItem(index);
               if (item != null && Client.colorComponentMatches(item) && Client.stackPresent(stack)) {
                  ItemColor.Entry entry = this.match(stack);
                  if (entry != null && this.isItemEnabled(entry.key)) {
                     int[] colors = Client.stackColorPair(stack);
                     this.highlights.add(new int[]{colors[0], colors[1], this.colorOf(entry.key)});
                  }
               }
            }
         }
      }
   }

   @Override
   public void onRender() {
      boolean previous = this.applied;
      this.applied = false;
      if (!previous && !this.highlights.isEmpty()) {
         if (Client.containerScreenOpen()) {
            Client.applyItemColors(this);
         }
      }
   }

   private ItemColor.Entry match(Object stack) {
      for (ItemColor.Entry entry : ENTRIES) {
         if (Client.stackMatchesItemId(stack, entry.itemId)) {
            return entry;
         }

         if (entry.itemId == 27 && Client.stackMatchesAnyItemId(stack, SHULKER_ITEM_IDS)) {
            return entry;
         }
      }

      return null;
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }

   public static final class Entry {
      public final String key;
      public final int itemId;
      public final int color;

      Entry(String key, int itemId, int color) {
         this.key = key;
         this.itemId = itemId;
         this.color = color;
      }
   }
}

