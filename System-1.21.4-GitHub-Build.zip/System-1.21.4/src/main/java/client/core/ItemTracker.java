package client.core;

import client.Category;
import java.util.HashMap;
import java.util.Map;

public final class ItemTracker extends client.Feature {
   public static final String MODULE = "itemtracker";
   private final Map<String, Integer> cooldowns = new HashMap<>();
   private final Map<String, Integer> uses = new HashMap<>();
   private final Map<String, Integer> throws_ = new HashMap<>();

   public ItemTracker() {
      super("itemtracker", "", Category.Render);
      this.add(client.Setting.number("radius", 32.0, 8.0, 128.0));
      this.add(client.Setting.mode("track", "Использования", "Использования"));
      this.add(client.Setting.bool("enemy_cooldowns", true));
      this.add(client.Setting.bool("include_self", false));
      this.add(client.Setting.bool("ignore_friends", true));
   }

   @Override
   public void onDisable() {
      this.cooldowns.clear();
      this.uses.clear();
      this.throws_.clear();
   }

   public double radius() {
      client.Setting s = this.setting("radius");
      return s == null ? 32.0 : s.getNumber();
   }

   public String track() {
      client.Setting s = this.setting("track");
      return s == null ? "Использования" : s.getMode();
   }

   public boolean enemyCooldowns() {
      client.Setting s = this.setting("enemy_cooldowns");
      return s != null && s.getBoolean();
   }

   public boolean includeSelf() {
      client.Setting s = this.setting("include_self");
      return s != null && s.getBoolean();
   }

   public boolean ignoreFriends() {
      client.Setting s = this.setting("ignore_friends");
      return s != null && s.getBoolean();
   }

   public void trackUses(String owner, String item) {
      if (owner != null && item != null) {
         if (this.includeSelf() || !owner.equals("self")) {
            this.uses.merge(owner + ":" + item, 1, Integer::sum);
         }
      }
   }

   public void trackThrows(String owner, String item) {
      if (owner != null && item != null) {
         this.throws_.merge(owner + ":" + item, 1, Integer::sum);
      }
   }

   public void reportPotionImpact(String owner, String item) {
      if (owner != null && item != null) {
         this.cooldowns.merge(owner + ":" + item, 1, Integer::sum);
      }
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

