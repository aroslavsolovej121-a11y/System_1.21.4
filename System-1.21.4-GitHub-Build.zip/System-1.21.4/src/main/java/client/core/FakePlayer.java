package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class FakePlayer extends client.Feature {
   public static final String MODULE = "fake_player";
   public static final String DISPLAY = "ФакеПлайер";
   private static final String NAME = "Sуstem";
   private Entity fake;
   private int fakeId = -1;

   public FakePlayer() {
      super("fake_player", "ФакеПлайер", Category.Render);
   }

   @Override
   public void onEnable() {
      if (Client.inGame()) {
         Entity created = Client.spawnNamedPlayer("Sуstem");
         if (created != null) {
            this.fakeId = Client.entityId(created);
            this.fake = created;
         }
      }
   }

   @Override
   public void onDisable() {
      if (this.fake != null && Client.inGame()) {
         Client.removeEntity(this.fakeId);
      }

      this.fake = null;
      this.fakeId = -1;
   }

   @Override
   public void onTick() {
      if (this.fake != null) {
         if (!Client.inGame() || !Client.isAlive(this.fake)) {
            this.fake = null;
            this.fakeId = -1;
            Client.onFakePlayerRemoved();
         }
      }
   }
}

