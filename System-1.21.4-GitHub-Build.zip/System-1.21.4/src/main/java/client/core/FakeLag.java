package client.core;

import client.Category;
import client.mc.Client;

public final class FakeLag extends client.Feature {
   public static final String MODULE = "fake_lag";
   public static final String DISPLAY = "ФакеЛаг";
   public static final double DELAY_VALUE = 200.0;
   public static final double DELAY_MIN = 50.0;
   public static final double DELAY_MAX = 400.0;
   public static final double DELAY_STEP = 10.0;
   private static final long CHECK_INTERVAL_NANOS = 25000000L;
   private static final double NANOS_TO_MILLIS = 1.0E-6;
   private static final double HOLD_SCALE = 2.0;
   private static final double HOLD_CAP_MILLIS = 800.0;
   private long lastCheckNanos;
   private double holdMillis;

   public FakeLag() {
      super("fake_lag", "ФакеЛаг", Category.Movement);
      this.add(client.Setting.number("delay", 200.0, 50.0, 400.0, 10.0));
      this.holdMillis = 0.0;
   }

   @Override
   public void onEnable() {
      Client.setLagStartNanos(0L);
   }

   @Override
   public void onDisable() {
      this.releaseLag();
   }

   public void resetWhenNoPlayer() {
      if (Client.player() == null) {
         this.releaseLag();
      }
   }

   public void releaseLag() {
      Client.setLagPending(false);
      Client.releaseLag();
      Client.setLagStartNanos(0L);
   }

   @Override
   public void onTick() {
      long now = Client.nanos();
      if (now - this.lastCheckNanos > 25000000L) {
         this.lastCheckNanos = now;
         double maxDelay = 0.0;
         boolean any = false;

         for (Object candidate : Client.lagFeatures()) {
            if (candidate instanceof client.Feature module
               && module.isEnabled()
               && !Client.lagSuspended()
               && Client.lagQueueDepth() > 0
               && Client.lagWindowOpen()
               && this.lagActive(module)) {
               double delay = Client.settingNumber(module, "delay");
               any = true;
               if (delay > maxDelay) {
                  maxDelay = delay;
               }
            }
         }

         if (!any) {
            this.releaseLag();
         } else if (!Client.lagPending()) {
            Client.beginLag(Client.tickCount());
            if (Client.canHoldLag() && Client.lagTicking()) {
               Client.setLagPending(true);
            }

            Client.setLagStartNanos(now);
            double hold = Client.lagHoldMillis(maxDelay * 2.0);
            this.holdMillis = Math.min(hold, 800.0);
         } else if (!((now - Client.lagStartNanos()) * 1.0E-6 < this.holdMillis)) {
            this.releaseLag();
         }
      }
   }

   public boolean lagActive(client.Feature module) {
      return true;
   }
}

