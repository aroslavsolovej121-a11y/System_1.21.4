package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class NoWeb extends client.Feature {
   public static final String MODULE = "noweb";
   public static final String DISPLAY = "НоШеб";
   private static final double STUCK_EPSILON = 1.0E-7;
   private static final double DEG_TO_RAD = Math.PI / 180.0;
   private static final float YAW_STEP = 45.0F;

   public NoWeb() {
      super("noweb", "НоШеб", Category.Movement);
      this.add(client.Setting.number("speed", 0.6, 0.0, 1.0));
   }

   @Override
   public void onTick() {
      Entity self = Client.localPlayer();
      if (self != null) {
         double[] stuck = Client.stuckSpeedMultiplier(self);
         if (stuck != null) {
            if (!(stuck[0] * stuck[0] + stuck[1] * stuck[1] + stuck[2] * stuck[2] <= 1.0E-7)) {
               if (Client.isInCobweb(self)) {
                  double speed = this.speed();
                  float[] move = Client.moveVector(self);
                  float strafe = move[0];
                  float forward = move[1];
                  float yaw = Client.viewYaw(self);
                  float base = strafe;
                  if (strafe != 0.0F) {
                     base = 45.0F;
                     if (forward < 0.0F) {
                        if (strafe <= 0.0F) {
                           base = -45.0F;
                        }

                        yaw += base;
                     } else if (forward > 0.0F) {
                        if (strafe > 0.0F) {
                           base = -45.0F;
                        }

                        yaw += base;
                     }

                     forward = 0.0F;
                     base = strafe > 0.0F ? 1.0F : -1.0F;
                  }

                  double radians = (yaw + 90.0) * (Math.PI / 180.0);
                  double sin = Math.sin(radians);
                  double cos = Math.cos(radians);
                  double x = base * speed * cos + forward * speed * sin;
                  double z = base * speed * sin - forward * speed * cos;
                  double y = 0.0;
                  if (Client.isJumpKeyDown()) {
                     y = speed;
                  }

                  if (Client.isSneakKeyDown()) {
                     y -= speed;
                  }

                  Client.setDeltaMovement(self, new double[]{x, y, z});
               }
            }
         }
      }
   }

   private double speed() {
      client.Setting setting = this.setting("speed");
      return setting == null ? 0.6 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

