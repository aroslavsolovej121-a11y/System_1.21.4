package client.core;

import client.Category;
import client.mc.Client;

public final class AuctionHelper extends client.Feature {
   public static final String MODULE = "auction_helper";
   public static final String DISPLAY = "АустионХелпер";
   private static final int NO_SLOT = -1;
   private static final int AUCTION_FILLER_SLOTS = 36;
   private static final int CYCLE_LIMIT = 19;
   private static final int HASH_MULTIPLIER = 31;
   private static final int CLICK_COOLDOWN_TICKS = 4;
   private static AuctionHelper active;
   private int hoverSlot = -1;
   private int pendingSlot = -1;
   private boolean screenActive;
   private boolean cardsDirty;
   private int screenId;
   private int lastSyncId;
   private int cycleCounter;
   private int lastItemHash;
   private int slotCount;
   private boolean rightButtonDown;
   private int pendingClickSlot = -1;
   private int pendingClickSyncId;
   private int clickCooldown;

   public AuctionHelper() {
      super("auction_helper", "АустионХелпер", Category.Render);
      this.add(client.Setting.mode("highlight", "Both", "None", "Plate", "Box", "Both"));
      this.add(client.Setting.bool("options", true));
      this.add(client.Setting.gradient("colors", -10496, -16711936));
      this.add(client.Setting.bool("panel", true));
      this.add(client.Setting.bool("filters", false));
      this.add(client.Setting.bool("armor", false));
      this.add(client.Setting.bool("sword", false));
      this.add(client.Setting.bool("mace", false));
   }

   public static AuctionHelper active() {
      return active;
   }

   public boolean screenActive() {
      return this.screenActive;
   }

   public boolean cardsDirty() {
      return this.cardsDirty;
   }

   public boolean rightButtonDown() {
      return this.rightButtonDown;
   }

   public int hoverSlot() {
      return this.hoverSlot;
   }

   public void setHoverSlot(int value) {
      this.hoverSlot = value;
   }

   public int pendingSlot() {
      return this.pendingSlot;
   }

   public void setPendingSlot(int value) {
      this.pendingSlot = value;
   }

   public int screenId() {
      return this.screenId;
   }

   public int lastSyncId() {
      return this.lastSyncId;
   }

   public int cycleCounter() {
      return this.cycleCounter;
   }

   public int lastItemHash() {
      return this.lastItemHash;
   }

   public void setLastItemHash(int value) {
      this.lastItemHash = value;
   }

   public int slotCount() {
      return this.slotCount;
   }

   public int pendingClickSlot() {
      return this.pendingClickSlot;
   }

   public int pendingClickSyncId() {
      return this.pendingClickSyncId;
   }

   public void setPendingClickSlot(int value) {
      this.pendingClickSlot = value;
   }

   public int clickCooldown() {
      return this.clickCooldown;
   }

   public void resetState() {
      this.hoverSlot = -1;
      this.pendingSlot = -1;
      this.cardsDirty = false;
      this.screenActive = false;
      this.lastSyncId = -1;
      this.clickCooldown = 0;
      this.pendingClickSlot = -1;
   }

   @Override
   public void onEnable() {
      this.resetState();
      active = this;
   }

   @Override
   public void onDisable() {
      this.resetState();
      active = null;
   }

   @Override
   public void onTick() {
      boolean wasActive = this.screenActive;
      boolean containerOpen = Client.containerScreenOpen();
      String title = containerOpen ? Client.openScreenTitle() : "";
      boolean auction = Client.isAuctionScreen(title);
      this.screenActive = auction;
      if (!auction) {
         this.resetState();
      } else {
         this.screenId = Client.openScreenId();
         Client.auctionSearchText(this);
         if (!wasActive) {
            this.slotCount = Client.containerSize() + 24;
            Client.auctionOpenSearch(this);
         }

         int visible = Client.containerSize() - 36;
         if (visible < 1) {
            this.pendingSlot = -1;
         } else {
            int syncId = Client.containerSyncId();
            int previousSyncId = this.lastSyncId;
            this.lastSyncId = syncId;
            this.cycleCounter++;
            boolean cycleEnded = 19 < this.cycleCounter;
            if (cycleEnded) {
               this.cycleCounter = 0;
            }

            int hash = visible;

            for (int index = 0; index < visible; index++) {
               hash = Client.auctionSlotItemId(this, index) + hash * 31;
            }

            if (hash == this.lastItemHash) {
               if (cycleEnded || syncId != previousSyncId) {
                  Client.auctionRebuildCards(this);
               }
            } else {
               this.lastItemHash = hash;
               Client.auctionRebuildCards(this);
            }

            if (this.clickCooldown > 0) {
               this.clickCooldown--;
            }

            int slot = this.pendingClickSlot;
            this.pendingClickSlot = -1;
            if (slot >= 0 && this.pendingClickSyncId == syncId && slot < visible && Client.slotPresent(slot)) {
               Client.clickSlot(slot, 0);
               this.clickCooldown = 4;
               Client.auctionClearPending(this);
            }
         }
      }
   }

   public void onMouseState() {
      int raw = Client.rawKeyState();
      boolean pressed = raw < 0;
      if (pressed && !this.rightButtonDown) {
         boolean first = !Client.mouseConsumed();
         this.rightButtonDown = true;
         if (first) {
            this.handleMouse(1L);
            return;
         }
      } else {
         this.rightButtonDown = false;
      }

      this.handleMouse(0L);
   }

   private void handleMouse(long argument) {
      boolean wasDirty = this.cardsDirty;
      this.cardsDirty = false;
      if (this.screenActive) {
         if (Client.containerScreenOpen()) {
            if (Client.panelEnabled(this)) {
               Client.auctionBuildPanel(this, argument);
            }

            if (!wasDirty && (this.pendingSlot >= 0 || this.hoverSlot >= 0)) {
               Client.auctionClickCard(this, 0);
            }
         }
      }
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

