package client.core;

import client.Category;
import client.mc.Client;

public final class ChestStealer extends client.Feature {
   public static final String MODULE = "cheststealer";
   public static final String DISPLAY = "СхезтЗтеалер";
   private static final double MILLIS_TO_NANOS = 1000000.0;
   private long lastMoveTime;

   public ChestStealer() {
      super("cheststealer", "СхезтЗтеалер", Category.Player);
      this.add(client.Setting.number("delay", 100.0, 0.0, 500.0, 10.0));
      this.add(client.Setting.bool("auto_close", true));
   }

   @Override
   public void onEnable() {
      this.lastMoveTime = 0L;
   }

   @Override
   public void onDisable() {
      this.lastMoveTime = 0L;
   }

   @Override
   public void onTick() {
      if (Client.inGame() && Client.containerScreenOpen()) {
         long now = Client.timerNanos();
         if ((long)(this.delay() * 1000000.0) <= now - this.lastMoveTime) {
            int slot = Client.findStealSlot();
            if (slot == -1) {
               if (this.autoClose()) {
                  Client.closeScreen();
               }
            } else {
               Client.clickSlot(slot, 0, 1);
               this.lastMoveTime = now;
            }
         }
      }
   }

   private double delay() {
      client.Setting setting = this.setting("delay");
      return setting == null ? 100.0 : setting.getNumber();
   }

   private boolean autoClose() {
      client.Setting setting = this.setting("auto_close");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

