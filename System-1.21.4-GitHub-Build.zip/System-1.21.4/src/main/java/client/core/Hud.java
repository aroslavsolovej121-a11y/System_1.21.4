package client.core;

import client.Category;
import client.mc.Client;

public final class Hud extends client.Feature {
   public static final String MODULE = "hud";
   public static final String DISPLAY = "Худ";
   public static final String[] ELEMENTS = new String[]{
      "watermark",
      "keybinds",
      "staff",
      "potions",
      "armor",
      "targethud",
      "cooldowns",
      "usetracker",
      "swapbinds",
      "notifications",
      "coords",
      "waypoints",
      "saturation",
      "inventory"
   };
   public static final String[] ELEMENT_LABELS = new String[]{
      "Ватермарка",
      "Кейбинды",
      "Список стафа",
      "Эффекты зелий",
      "Броня",
      "ТаргетХуд",
      "Кулдауны",
      "Кулдауны цели",
      "Свап бинды",
      "Уведомления",
      "Координаты",
      "Вейпоинты",
      "Насыщение",
      "Инвентарь"
   };
   private static Hud active;

   public Hud() {
      super("hud", "Худ", Category.Client);
      this.add(client.Setting.multi("elements", ELEMENTS));
      this.add(client.Setting.bool("reset_positions", false));

      for (int i = 0; i < ELEMENTS.length; i++) {
         if (!ELEMENTS[i].equals("inventory")) {
            client.Setting elements = this.setting("elements");
            if (elements != null) {
               elements.setSelected(ELEMENTS[i], true);
            }
         }
      }

      this.setEnabled(true);
      active = this;
   }

   public static Hud active() {
      return active;
   }

   public boolean isElementEnabled(String key) {
      client.Setting elements = this.setting("elements");
      return elements != null && elements.isSelected(key);
   }

   public void resetPositions() {
      for (String element : ELEMENTS) {
         Client.resetHudElementPosition(element);
      }
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }
}

