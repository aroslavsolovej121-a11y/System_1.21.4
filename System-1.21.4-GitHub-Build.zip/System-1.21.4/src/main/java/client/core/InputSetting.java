package client.core;

public class InputSetting {
}
