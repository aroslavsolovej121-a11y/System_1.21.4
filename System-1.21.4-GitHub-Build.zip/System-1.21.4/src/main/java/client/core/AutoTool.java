package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AutoTool extends client.Feature {
   public static final String MODULE = "autotool";
   public static final String DISPLAY = "АутоТоол";
   private static final int HOTBAR_SIZE = 9;
   private static final int HOTBAR_OFFSET = 36;
   private static final int MINING_IDLE_LIMIT = 10;
   private boolean mining;
   private int cooldown;
   private int toolMode;
   private int bestSlot = -1;
   private int bestSlotCurrent = -1;
   private int previousSelected = -1;
   private int previousSlot = -1;
   private int previousBestCurrent = -1;

   public AutoTool() {
      super("autotool", "АутоТоол", Category.Player);
      this.add(client.Setting.bool("prevent_break", true));
   }

   @Override
   public void onTick() {
      this.selectTool();
      this.applyTool();
   }

   @Override
   public void onDisable() {
      Client.resetToolSwitcher();
      if (Client.inGame() && this.previousSelected != -1) {
         Client.selectSlot(this.previousSelected);
      }

      this.mining = false;
      this.cooldown = 0;
      this.bestSlot = -1;
      this.bestSlotCurrent = -1;
      this.previousSelected = -1;
      this.previousSlot = -1;
      this.previousBestCurrent = -1;
   }

   private void selectTool() {
      Entity player = Client.player();
      if (Client.inGame() && !Client.isSpectator(player) && !Client.isScreenOpen() && Client.isMining() && Client.canMine()) {
         this.mining = true;
         if ((this.toolMode == 0 || this.toolMode == 3) && this.previousSlot == -1 && this.bestSlot == -1 && Client.canMine()) {
            Object hit = Client.raycastTarget();
            if (hit != null && player != null) {
               Object blockState = Client.blockState(player, hit);
               if (blockState != null) {
                  if (this.previousSelected == -1) {
                     this.previousSelected = Client.selectedSlot();
                  }

                  int current = Client.selectedSlot();
                  int best = Client.findBestTool(blockState);
                  if (best != -1 && best != current) {
                     if (best > 8) {
                        this.bestSlot = best;
                        this.bestSlotCurrent = current;
                        return;
                     }

                     Client.selectSlot(best);
                  }
               }
            }
         }
      } else {
         this.mining = false;
      }
   }

   private void applyTool() {
      Client.updateToolState();
      if (!Client.inGame()) {
         this.bestSlot = -1;
         this.bestSlotCurrent = -1;
      } else if (!this.mining) {
         this.bestSlot = -1;
         this.bestSlotCurrent = -1;
         if (this.previousSlot == -1 && this.previousSelected == -1) {
            this.restoreTool();
         } else if (Client.isMining() && this.cooldown < 10 && Client.isBreakKeyIdle()) {
            this.cooldown++;
         } else {
            this.cooldown = 0;
            this.restoreTool();
         }
      } else {
         this.cooldown = 0;
         if ((this.toolMode == 0 || this.toolMode == 3) && this.bestSlot != -1) {
            if (this.previousSlot == -1) {
               this.previousSlot = this.bestSlot;
               this.previousBestCurrent = this.bestSlotCurrent;
               if (this.bestSlotCurrent < 9) {
                  int target = this.bestSlot > 8 ? this.bestSlot : this.bestSlot + 36;
                  Client.selectToolSlot(target);
               }
            }

            this.bestSlot = -1;
            this.bestSlotCurrent = -1;
         }
      }
   }

   private void restoreTool() {
      if (this.toolMode == 0 || this.toolMode == 3) {
         if (Client.inGame() && this.previousSlot != -1 && this.previousBestCurrent != -1) {
            Client.restoreToolSlot();
         }

         this.previousSlot = -1;
         this.previousBestCurrent = -1;
         if (Client.inGame() && this.previousSelected != -1) {
            Client.selectSlot(this.previousSelected);
         }

         this.previousSelected = -1;
      }
   }
}

