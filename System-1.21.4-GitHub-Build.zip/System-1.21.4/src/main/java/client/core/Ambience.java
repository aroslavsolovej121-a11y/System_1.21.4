package client.core;

import client.Category;
import client.mc.Client;

public final class Ambience extends client.Feature {
   public static final String MODULE = "ambience";
   public static final String DISPLAY = "Амбиенсе";
   private static final double NANOS_PER_SECOND = 1.0E9;
   private static final float TIME_STEP_DIVISOR = 0.35F;
   private static final float TIME_MIN = 0.0F;
   private static final float TIME_MAX = 1.0F;
   private static final float FOG_MIN_VISIBLE = 0.002F;
   private static final float FOG_MIN_PARTICLES = 0.004F;
   private static final float PARTICLE_SPREAD = 14.0F;
   private static final float PARTICLE_MAX_COUNT = 4000.0F;
   private static final float PARTICLE_SCALE_DIVISOR = 100.0F;
   private static final double PARTICLE_HALF_HEIGHT = 0.012;
   private static final double PARTICLE_RISE_SPAN = 20.0;
   private static final float PARTICLE_RISE_TOP = 10.0F;
   private static final float PARTICLE_CURL = 0.6F;
   private static final float PARTICLE_CURL_BIAS = 0.7F;
   private static final float PARTICLE_WRAP = 0.85F;
   private static final double PARTICLE_CAM_RADIUS = 100.0;
   private static final float PARTICLE_HEIGHT_MASK = 0.5F;
   private static final float PARTICLE_HEIGHT_BIAS = 0.55F;
   private static final float PARTICLE_SHADE = 0.5F;
   private static final float PARTICLE_TINT_SCALE = 255.0F;
   private static final int PARTICLE_RGB = 14075058;
   private static final long PARTICLE_SEED_MOD = 100000000000L;
   private static final double NANO_SCALE = 1.0E-9;
   private static final int HASH_STEP_0 = -668265263;
   private static final int HASH_STEP_1 = 668265263;
   private static final int HASH_STEP_2 = 1336530526;
   private static final int HASH_STEP_3 = 2004795789;
   private static final int HASH_MUL = 1274126177;
   private static final int HASH_ADD = 374761393;
   private static final int HASH_SEED = 1336530526;
   private static final float HASH_MASK = 1.6777215E7F;
   private static Ambience active;
   private long lastFrameNanos;
   private float fogTime;

   public Ambience() {
      super("ambience", "Амбиенсе", Category.Render);
      this.add(client.Setting.bool("time_group", false));
      this.add(client.Setting.number("world_group", 0.0, 0.0, 1.0));
      this.add(client.Setting.bool("fog_layer_group", false));
      this.add(client.Setting.mode("fog_color_mode", "Layer", "Layer", "Custom"));
      this.add(client.Setting.bool("wet_group", false));
      this.add(client.Setting.mode("wet_quality", "Medium", "Low", "Medium", "High"));
      this.add(client.Setting.bool("rain_group", false));
   }

   public static Ambience active() {
      return active;
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
   }

   @Override
   public void onRender() {
      this.updateFogTime();
      this.spawnFogParticles();
   }

   public float fogTime() {
      return this.fogTime;
   }

   public void updateFogTime() {
      long now = Client.nanos();
      float step = 1.0F;
      if (this.lastFrameNanos != 0L) {
         step = (float)((now - this.lastFrameNanos) / 1.0E9) / 0.35F;
      }

      this.lastFrameNanos = now;
      if (Client.isFogEnabled(this) && Client.inGame()) {
         boolean negate = true;
         if (Client.player() != null) {
            Object world = Client.worldOf(Client.player());
            if (world != null) {
               double[] position = Client.entityPosition(Client.player());
               int x = (int)Math.floor(position[0]);
               int y = (int)Math.floor(position[1]);
               int z = (int)Math.floor(position[2]);
               if (Client.blockStateAt(x, y, z) != null) {
                  Object list = Client.ambienceTimeBlockList();
                  if (list != null && Client.trackedBlockPresent(world, x, y, z, 0)) {
                     negate = false;
                  }
               }
            }
         }

         if (negate) {
            step = -step;
         }

         float value = step + this.fogTime;
         if (value < 0.0F) {
            this.fogTime = 0.0F;
         } else if (value > 1.0F) {
            this.fogTime = 1.0F;
         } else {
            this.fogTime = value;
         }
      } else {
         this.fogTime = 0.0F;
      }
   }

   public void spawnFogParticles() {
      if (Client.isFogEnabled(this)) {
         if (0.002F < this.fogTime) {
            float span = (float)(Client.settingDouble(this, 6416) / 100.0) * this.fogTime;
            if (0.004F < span) {
               int count = (int)((float)Client.settingDouble(this, 6104) * 4000.0F / 100.0F + 0.5F);
               if (count < 0) {
                  count = 0;
               }

               if (count > 4000) {
                  count = 4000;
               }

               int tint = Math.round(span * 255.0F);
               int color = tint << 24 | 14075058;
               float timeSeed = (float)(Client.nanos() % 100000000000L * 1.0E-9);
               double[] camera = Client.ambienceCameraPosition();
               double baseX = Math.floor(camera[0]);
               double baseY = Math.floor(camera[1]);
               double baseZ = Math.floor(camera[2]);
               int seed = 1336530526;

               for (int i = 0; i < count; i++) {
                  int h12 = hash(seed + -668265263);
                  int h15 = hash(seed) ^ seed;
                  h15 *= 1274126177;
                  int h16 = hash(seed + 668265263);
                  int h17 = hash(seed + 1336530526);
                  float rx = ((h12 >>> 16 ^ h12) & 16777215) / 1.6777215E7F - 0.5F;
                  double x = (rx + rx) * 14.0F + baseX;
                  float rz = ((h15 >>> 16 ^ h15) & 16777215) / 1.6777215E7F - 0.5F;
                  double z = (rz + rz) * 14.0F + baseZ;
                  float curl = (float)Math.IEEEremainder(
                     (((h16 >>> 16 ^ h16) & 16777215) / 1.6777215E7F * 0.6F + 0.7F) * timeSeed * 0.85F + ((h17 >>> 16 ^ h17) & 16777215) / 1.6777215E7F, 1.0
                  );
                  int h18 = hash(seed + 2004795789);
                  int h18High = h18 >>> 16;
                  double y = 10.0 - curl * 20.0 + baseY;
                  double yBottom = y - (((h18 ^ h18High) & 16777215) / 1.6777215E7F * 0.5F + 0.55F);
                  if (Client.renderPassActive()) {
                     float top = (float)(y - camera[1]);
                     float bottom = (float)(yBottom - camera[1]);
                     float zPlus = (float)(z + 0.012 - camera[2]);
                     float zMinus = (float)(z - 0.012 - camera[2]);
                     float xOffset = (float)(x - camera[0]);
                     float[] vertices = new float[]{
                        xOffset,
                        top,
                        zPlus,
                        Float.intBitsToFloat(color),
                        xOffset,
                        bottom,
                        zPlus,
                        Float.intBitsToFloat(color),
                        xOffset,
                        bottom,
                        zMinus,
                        Float.intBitsToFloat(color),
                        xOffset,
                        top,
                        zMinus,
                        Float.intBitsToFloat(color),
                        xOffset,
                        bottom,
                        zMinus,
                        Float.intBitsToFloat(color),
                        xOffset,
                        top,
                        zMinus,
                        Float.intBitsToFloat(color)
                     };
                     Client.drawWorldQuad(h18High, Client.ambienceParticleBatch(), vertices, 6);
                     if (Client.renderPassActive()) {
                        float mirrorNear = (float)(x - 0.012 - camera[0]);
                        float mirrorFar = (float)(x + 0.012 - camera[0]);
                        vertices[0] = mirrorNear;
                        vertices[1] = top;
                        vertices[2] = (float)(z - camera[2]);
                        vertices[4] = mirrorNear;
                        vertices[5] = bottom;
                        vertices[6] = (float)(z - camera[2]);
                        vertices[8] = mirrorNear;
                        vertices[9] = bottom;
                        vertices[10] = (float)(z - camera[2]);
                        vertices[12] = mirrorNear;
                        vertices[13] = top;
                        vertices[14] = (float)(z - camera[2]);
                        vertices[16] = mirrorFar;
                        vertices[17] = bottom;
                        vertices[18] = (float)(z - camera[2]);
                        vertices[20] = mirrorFar;
                        vertices[21] = top;
                        vertices[22] = (float)(z - camera[2]);
                        Client.drawWorldQuad(Float.floatToRawIntBits(vertices[8]), Client.ambienceParticleBatch(), vertices, 6);
                     }
                  }

                  seed += 374761393;
               }
            }
         }
      }
   }

   private static int hash(int value) {
      return (value >>> 13 ^ value) * 1274126177;
   }
}

