package client.core;

import client.Category;
import client.mc.Client;
import java.util.ArrayList;
import java.util.List;

public final class Structures extends client.Feature {
   public static final String MODULE = "structures";
   public static final String DISPLAY = "Зтрустурез";
   private final List<int[]> tracked = new ArrayList<>();

   public Structures() {
      super("structures", "Зтрустурез", Category.Render);
      this.add(client.Setting.mode("tracked", "All", "All", "Stuns", "Marks"));
      this.add(client.Setting.number("plate_scale", 1.0, 0.1, 5.0));
      this.add(client.Setting.color("stun_color", 16755200));
   }

   @Override
   public void onEnable() {
      this.tracked.clear();
   }

   @Override
   public void onDisable() {
      this.tracked.clear();
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            this.tracked.clear();
         }
      }
   }
}

