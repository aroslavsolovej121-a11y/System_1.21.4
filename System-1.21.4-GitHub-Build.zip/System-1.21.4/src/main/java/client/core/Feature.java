package client.core;

public class Feature {
}
