package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class NoFriendDamage extends client.Feature {
   public static final String MODULE = "no_friend_damage";
   public static final String DISPLAY = "НоФриендДамаге";
   public static final int SLOT_ON_CROSSHAIR_PICK = 2;
   public static final String MODE_CANCEL = "Отмена";
   public static final String MODE_THROUGH = "Сквозь";
   private static final double REACH_MARGIN = 4.0;

   public NoFriendDamage() {
      super("no_friend_damage", "НоФриендДамаге", Category.Player);
      this.add(client.Setting.mode("mode", "Сквозь", "Отмена", "Сквозь"));
   }

   @Override
   public void onEnable() {
      Client.registerNoFriendDamage(this);
   }

   @Override
   public void onDisable() {
      Client.registerNoFriendDamage(null);
   }

   public void onCrosshairPick() {
      if ("Сквозь".equals(this.mode())) {
         if (Client.inGame()) {
            Entity target = Client.crosshairEntity();
            if (Client.isFriend(target)) {
               Entity self = Client.localPlayer();
               if (self != null) {
                  double[] eye = Client.eyePosition();
                  double[] view = Client.lookVector(self);
                  double blockRange = Client.blockInteractionRange(self);
                  double entityRange = Client.entityInteractionRange(self);
                  double[] far = new double[]{eye[0] + view[0] * blockRange, eye[1] + view[1] * blockRange, eye[2] + view[2] * blockRange};
                  double blockDistance = Client.clipBlockDistance(self, eye, far);
                  double range = blockDistance;
                  if (entityRange <= blockDistance) {
                     range = entityRange;
                  }

                  double[] end = new double[]{eye[0] + view[0] * range, eye[1] + view[1] * range, eye[2] + view[2] * range};
                  double limit = range + 4.0;
                  double limitSq = limit * limit;
                  Entity[] found = new Entity[1];
                  double[] best = new double[]{range};
                  Client.forEachEntity(entity -> {
                     if (Client.isPlayer(entity)) {
                        if (!Client.sameEntity(entity, self)) {
                           if (!Client.isRemoved(entity)) {
                              double[] position = Client.entityPosition(entity);
                              double dx = position[0] - eye[0];
                              double dy = position[1] - eye[1];
                              double dz = position[2] - eye[2];
                              double distanceSq = dx * dx + dy * dy + dz * dz;
                              if (!(distanceSq > limitSq)) {
                                 if (!Client.isFriend(entity)) {
                                    double[] point = Client.clipEntityBox(entity, eye, end);
                                    if (point != null) {
                                       double px = point[0] - eye[0];
                                       double py = point[1] - eye[1];
                                       double pz = point[2] - eye[2];
                                       double hit = Math.sqrt(px * px + py * py + pz * pz);
                                       if (hit < best[0]) {
                                          best[0] = hit;
                                          found[0] = entity;
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  });
                  if (found[0] == null) {
                     Client.rebuildCrosshairHit(blockRange);
                  } else {
                     Client.setCrosshairTarget(found[0]);
                  }
               }
            }
         }
      }
   }

   private String mode() {
      client.Setting setting = this.setting("mode");
      return setting == null ? "Сквозь" : setting.getMode();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

