package client.core;

import client.Category;
import client.mc.Client;

public final class NoServerRotate extends client.Feature {
   public static final String MODULE = "noserverrotate";
   public static final String DISPLAY = "НоЗерверРотате";

   public NoServerRotate() {
      super("noserverrotate", "НоЗерверРотате", Category.Player);
   }

   @Override
   public void onEnable() {
      Client.registerNoServerRotate(this);
   }

   @Override
   public void onDisable() {
      Client.registerNoServerRotate(null);
   }
}

