package client.core;

import client.Category;
import client.aim.Rotation;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class AimAssist extends client.Feature {
   public static final String MODULE = "aimassist";
   private static final long NANOS_PER_UNIT = 1000000000L;
   private final List<Entity> candidates = new ArrayList<>();
   private Entity cachedTarget;
   private double[] lastSelfPosition = new double[3];
   private double cachedX;
   private double cachedY;
   private double cachedZ;
   private double requiredSpeed = 1.0;
   private boolean hasTarget;
   private long lastTargetSwitch;
   private long lastReset;

   public AimAssist() {
      super("aimassist", "", Category.Combat);
      this.add(client.Setting.mode("rotation", "Linear", "Linear", "Smooth", "Instant"));
      this.add(client.Setting.number("speed", 3.0, 1.0, 10.0));
      this.add(client.Setting.number("strength", 100.0, 0.0, 100.0));
      this.add(client.Setting.number("vertical_freedom", 0.0, -90.0, 90.0));
      this.add(client.Setting.mode("behavior", "Legit", "Legit", "Rage"));
      this.add(client.Setting.number("slow_threshold", 0.4, 0.0, 3.0));
      this.add(client.Setting.number("legit_speed", 1.0, 0.1, 5.0));
      this.add(client.Setting.bool("randomize", false));
      this.add(client.Setting.mode("priority", "Distance", "Distance", "Health", "Angle"));
      this.add(client.Setting.number("distance", 4.5, 1.0, 8.0));
      this.add(client.Setting.number("fov", 90.0, 1.0, 360.0));
      this.add(client.Setting.bool("sticky", false));
      this.add(client.Setting.bool("last_hit_only", false));
      this.add(client.Setting.mode("targets", "Players", "Players", "Mobs", "All"));
      this.add(client.Setting.mode("conditions", "None", "None", "Visible", "Weapon"));
   }

   @Override
   public void onDisable() {
      this.cachedTarget = null;
      this.hasTarget = false;
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (Client.isPlayerAlive()) {
            Entity self = Client.player();
            this.requiredSpeed = this.computeSpeed();
            double[] selfPosition = Client.eyePosition();
            if (this.hasTarget && this.lastSelfPosition[0] != 0.0) {
               double dx = selfPosition[0] - this.lastSelfPosition[0];
               double dy = selfPosition[1] - this.lastSelfPosition[1];
               double dz = selfPosition[2] - this.lastSelfPosition[2];
               double travelled = Math.sqrt(dx * dx + dy * dy + dz * dz);
               this.requiredSpeed = travelled / this.smoothingDivisor();
            }

            this.lastSelfPosition = selfPosition;
            Entity target = this.findTarget(self);
            if (target == null) {
               long resetDelay = (long)(this.resetDelay() * 1.0E9);
               if (resetDelay < 1L || this.cachedTarget == null || System.nanoTime() - this.lastReset >= resetDelay) {
                  this.resetRotation();
               }
            } else {
               double[] targetPosition = Client.entityPosition(target);
               if (this.cachedTarget != null && Client.sameEntity(this.cachedTarget, target)) {
                  double dx = this.cachedX - targetPosition[0];
                  double dy = this.cachedY - targetPosition[1];
                  double dz = this.cachedZ - targetPosition[2];
                  double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
                  if (System.nanoTime() - this.lastTargetSwitch >= (long)(this.resetDelay() * 1.0E9)) {
                     double[] rotation = Client.currentRotation();
                     double[] delta = Rotation.delta(rotation, targetPosition);
                     double yaw = rotation[0] + delta[0] / Math.max(this.requiredSpeed, 1.0E-4);
                     double pitch = rotation[1] + delta[1] / Math.max(this.requiredSpeed, 1.0E-4);
                     Client.setRotation(Rotation.clamp(yaw), Rotation.clampPitch(pitch));
                     this.lastTargetSwitch = System.nanoTime();
                     this.hasTarget = true;
                  }
               } else {
                  this.cachedTarget = target;
                  this.cachedX = targetPosition[0];
                  this.cachedY = targetPosition[1];
                  this.cachedZ = targetPosition[2];
                  this.lastTargetSwitch = System.nanoTime();
                  this.hasTarget = true;
               }
            }
         }
      }
   }

   private void resetRotation() {
      this.cachedTarget = null;
      this.hasTarget = false;
      this.lastReset = System.nanoTime();
   }

   private Entity findTarget(Entity self) {
      this.collectCandidates(self);
      if (this.candidates.isEmpty()) {
         return null;
      } else {
         double[] selfPosition = Client.eyePosition();
         String priority = this.mode("priority");
         Comparator<Entity> comparator;
         if ("Health".equals(priority)) {
            comparator = Comparator.comparingDouble(Client::health);
         } else if ("Angle".equals(priority)) {
            comparator = Comparator.comparingDouble(e -> this.angleTo(selfPosition, e));
         } else {
            comparator = Comparator.comparingDouble(e -> this.distanceTo(selfPosition, e));
         }

         this.candidates.sort(comparator);
         return this.candidates.get(0);
      }
   }

   private void collectCandidates(Entity self) {
      this.candidates.clear();
      double range = this.range();
      double[] selfPosition = Client.eyePosition();
      boolean throughWalls = this.bool("sticky");

      for (Entity entity : Client.entities()) {
         if (entity != self
            && Client.isLiving(entity)
            && !Client.isFriend(entity)
            && (throughWalls || Client.canSee(entity))
            && !(this.distanceTo(selfPosition, entity) > range)) {
            this.candidates.add(entity);
         }
      }
   }

   private double distanceTo(double[] from, Entity entity) {
      double[] p = Client.entityPosition(entity);
      double dx = p[0] - from[0];
      double dy = p[1] - from[1];
      double dz = p[2] - from[2];
      return Math.sqrt(dx * dx + dy * dy + dz * dz);
   }

   private double angleTo(double[] from, Entity entity) {
      double[] p = Client.entityPosition(entity);
      double dx = p[0] - from[0];
      double dz = p[2] - from[2];
      double yaw = Math.toDegrees(Math.atan2(-dx, dz));
      return Math.abs(Rotation.wrap(Client.currentRotation()[0] - yaw));
   }

   private double computeSpeed() {
      client.Setting s = this.setting("speed");
      return s == null ? 3.0 : s.getNumber();
   }

   private double smoothingDivisor() {
      client.Setting s = this.setting("legit_speed");
      return s == null ? 1.0 : s.getNumber();
   }

   private double range() {
      client.Setting s = this.setting("distance");
      return s == null ? 4.5 : s.getNumber();
   }

   private double resetDelay() {
      client.Setting s = this.setting("slow_threshold");
      return s == null ? 0.4 : s.getNumber();
   }

   private String mode(String name) {
      client.Setting s = this.setting(name);
      return s == null ? "Distance" : s.getMode();
   }

   private boolean bool(String name) {
      client.Setting s = this.setting(name);
      return s != null && s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

