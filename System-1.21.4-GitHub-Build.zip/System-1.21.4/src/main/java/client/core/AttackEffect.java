package client.core;

import client.Category;
import client.mc.Client;

public final class AttackEffect extends client.Feature {
   public static final String MODULE = "attack_effect";
   public static final String DISPLAY = "АттаскЕффест";
   private float flashAmount;

   public AttackEffect() {
      super("attack_effect", "АттаскЕффест", Category.Combat);
      this.add(client.Setting.mode("effect", "Flash", "Flash", "Slash", "Impact"));
      this.add(client.Setting.bool("flash", true));
      this.add(client.Setting.color("colors", 16777215));
   }

   @Override
   public void onEnable() {
      this.flashAmount = 0.0F;
   }

   @Override
   public void onDisable() {
      this.flashAmount = 0.0F;
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            this.flashAmount = 0.0F;
         }
      }
   }
}

