package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class TapeMouse extends client.Feature {
   public static final String MODULE = "tapemouse";
   private int delay;

   public TapeMouse() {
      super("tapemouse", "", Category.Player);
      this.add(client.Setting.number("cooldown", 2.0, 0.0, 20.0));
      this.add(client.Setting.bool("pause_in_screen", true));
   }

   @Override
   public void onEnable() {
      this.delay = 0;
   }

   @Override
   public void onDisable() {
      this.delay = 0;
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!this.pauseInScreen() || !Client.isScreenOpen()) {
            if (!Client.isBreakingBlock()) {
               if (this.delay > 0) {
                  this.delay--;
               } else {
                  if (!Client.isScreenOpen()) {
                     client.mc.ItemStack held = Client.heldItem();
                     if (held != null) {
                        Client.useItem(held);
                     }
                  } else {
                     Entity candidate = Client.crosshairTarget();
                     if (candidate != null) {
                        Entity self = Client.player();
                        Client.attackWith(self, candidate);
                     }
                  }

                  this.delay = (int)this.cooldown();
               }
            }
         }
      }
   }

   private boolean pauseInScreen() {
      client.Setting s = this.setting("pause_in_screen");
      return s != null && s.getBoolean();
   }

   private double cooldown() {
      client.Setting s = this.setting("cooldown");
      return s == null ? 2.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

