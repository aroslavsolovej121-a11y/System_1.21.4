package client.core;

import client.Category;

public final class AutoSell extends client.Feature {
   public static final String MODULE = "autosell";
   private boolean running;

   public AutoSell() {
      super("autosell", "", Category.Player);
      this.add(client.Setting.mode("server", "аукцион", "аукцион", "инвентарь"));
      this.add(client.Setting.mode("sell_mode", "Все сразу", "Все сразу", "По одной штуке", "Одна цена"));
      this.add(client.Setting.number("markup", 0.0, 0.0, 100.0));
      this.add(client.Setting.key("sell_bind", 0));
      this.add(client.Setting.bool("one_price", false));
      this.add(client.Setting.mode("one_price_layout", "Выкладка", "Выкладка"));
      this.add(client.Setting.mode("auto_inventory", "Только хотбар", "Только хотбар", "Фулл инвентарь"));
      this.add(client.Setting.number("sweep_range", 3.0, 1.0, 6.0));
      this.add(client.Setting.bool("head_turn", true));
   }

   @Override
   public void onDisable() {
      this.running = false;
   }

   public String server() {
      return this.modeOf("server", "аукцион");
   }

   public String sellMode() {
      return this.modeOf("sell_mode", "Все сразу");
   }

   public double markup() {
      return this.number("markup", 0.0);
   }

   public int sellBind() {
      client.Setting s = this.setting("sell_bind");
      return s == null ? 0 : s.getKey();
   }

   public boolean onePrice() {
      return this.bool("one_price", false);
   }

   public String onePriceLayout() {
      return this.modeOf("one_price_layout", "Выкладка");
   }

   public String autoInventory() {
      return this.modeOf("auto_inventory", "Только хотбар");
   }

   public double sweepRange() {
      return this.number("sweep_range", 3.0);
   }

   public boolean headTurn() {
      return this.bool("head_turn", true);
   }

   public boolean isRunning() {
      return this.running;
   }

   private String modeOf(String name, String fallback) {
      client.Setting s = this.setting(name);
      return s == null ? fallback : s.getMode();
   }

   private double number(String name, double fallback) {
      client.Setting s = this.setting(name);
      return s == null ? fallback : s.getNumber();
   }

   private boolean bool(String name, boolean fallback) {
      client.Setting s = this.setting(name);
      return s == null ? fallback : s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

