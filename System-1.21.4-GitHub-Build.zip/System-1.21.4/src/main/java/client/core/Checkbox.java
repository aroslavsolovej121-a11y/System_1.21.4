package client.core;

public class Checkbox {
}
