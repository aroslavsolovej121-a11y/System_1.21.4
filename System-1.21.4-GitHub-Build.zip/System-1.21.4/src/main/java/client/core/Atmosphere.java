package client.core;

import client.Category;

public final class Atmosphere extends client.Feature {
   public static final String MODULE = "atmosphere";
   public static final String DISPLAY = "Атмозпхере";
   private static Atmosphere active;

   public Atmosphere() {
      super("atmosphere", "Атмозпхере", Category.Render);
      this.add(client.Setting.mode("mode", "Dawn", "Dawn", "Day", "Dusk", "Night", "Dust", "Snow", "Ash"));
      this.add(client.Setting.number("density", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("scatter_height", 64.0, 0.0, 320.0));
      this.add(client.Setting.number("god_rays", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("softness", 1.0, 0.0, 3.0));
      this.add(client.Setting.color("dawn_color", -20384));
      this.add(client.Setting.number("amount", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("speed", 1.0, 0.0, 5.0));
      this.add(client.Setting.number("haze", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("grade", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("vignette", 1.0, 0.0, 3.0));
   }

   public static Atmosphere active() {
      return active;
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
   }
}

