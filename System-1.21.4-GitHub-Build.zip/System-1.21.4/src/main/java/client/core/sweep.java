package client.core;

public class sweep {
   public void sample() {
   }
}
