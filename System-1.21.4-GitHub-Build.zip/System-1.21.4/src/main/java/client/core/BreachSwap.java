package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class BreachSwap extends client.Feature {
   public static final String MODULE = "breachswap";
   public static final int RESTORE_RVA = 448016;
   public static final int FIND_AND_SWAP_RVA = 447536;
   private static final int HOTBAR_SLOTS = 8;
   private static final int RESTORE_DELAY_CALLS = 2;
   private static final int SLOT_NONE = -1;
   private int savedSlot = -1;
   private int restoreDelay;

   public BreachSwap() {
      super("breachswap", "БреасхЗшап", Category.Combat);
      this.add(client.Setting.bool("sword_only", true));
   }

   @Override
   public void onDisable() {
      if (Client.inGame() && this.savedSlot != -1) {
         Client.setSelectedSlot(this.savedSlot);
         this.restoreDelay = 0;
      }

      this.savedSlot = -1;
   }

   @Override
   public void onTick() {
      this.restore();
      this.findAndSwap();
   }

   private void restore() {
      if (this.savedSlot != -1) {
         if (!Client.inGame()) {
            this.savedSlot = -1;
         } else {
            this.restoreDelay++;
            if (this.restoreDelay >= 2) {
               int slot = this.savedSlot;
               if (slot != -1) {
                  if (slot > 8) {
                     this.savedSlot = -1;
                     this.restoreDelay = 0;
                  } else {
                     Client.setSelectedSlotReflective(slot);
                     this.savedSlot = -1;
                     this.restoreDelay = 0;
                  }
               }
            }
         }
      }
   }

   private void findAndSwap() {
      if (this.savedSlot == -1) {
         Entity raw = Client.player();
         if (raw != null) {
            Entity self = Client.resolvePlayer(raw);
            if (self != null) {
               if (!this.swordOnly() || Client.isHoldingSword(self)) {
                  for (int slot = 0; slot <= 8; slot++) {
                     client.mc.ItemStack stack = Client.itemAtSlot(slot);
                     if (stack != null && Client.isMaceItem(stack)) {
                        if (slot == -1) {
                           return;
                        }

                        if (slot == Client.selectedSlot()) {
                           return;
                        }

                        this.savedSlot = Client.selectedSlot();
                        this.restoreDelay = 0;
                        Client.setSelectedSlot(slot);
                        return;
                     }
                  }
               }
            }
         }
      }
   }

   private boolean swordOnly() {
      client.Setting s = this.setting("sword_only");
      return s != null && s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

