package client.core;

public class KeyBind {
}
