package client.core;

import client.Category;
import client.mc.Client;

public final class Panic extends client.Feature {
   public static final String MODULE = "panic";
   public static final String DISPLAY = "Панис";

   public Panic() {
      super("panic", "Панис", Category.Client);
   }

   @Override
   public void setEnabled(boolean value) {
      if (value && !Client.panicRequested()) {
         Client.requestPanic();
      }
   }
}

