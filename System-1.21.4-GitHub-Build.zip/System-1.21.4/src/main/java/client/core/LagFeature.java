package client.core;

public class LagFeature {
}
