package client.core;

import client.Category;
import client.mc.BlockPos;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class PlayerChams extends client.Feature {
   public static final String MODULE = "player_chams";
   public static final String DISPLAY = "ПлайерСхамз";
   private static final double MODEL_HALF_WIDTH = 0.5;
   private static final List<double[]> boxes = new ArrayList<>();
   private static final List<double[]> outlines = new ArrayList<>();
   private Entity localPlayer;

   public PlayerChams() {
      super("player_chams", "ПлайерСхамз", Category.Render);
      this.add(client.Setting.bool("armour", true));
      this.add(client.Setting.number("distance", 64.0, 8.0, 256.0));
   }

   @Override
   public void onEnable() {
      boxes.clear();
      outlines.clear();
      Client.markChamsDirty();
   }

   @Override
   public void onDisable() {
      boxes.clear();
      outlines.clear();
      this.localPlayer = null;
      Client.markChamsDirty();
   }

   @Override
   public void onTick() {
      boxes.clear();
      outlines.clear();
      Entity self = Client.player();
      if (self == null) {
         Client.markChamsDirty();
      } else {
         BlockPos center = Client.blockPosition(Client.playerHandle());
         double x = 0.0;
         double y = 0.0;
         double z = 0.0;
         if (center != null) {
            x = center.x();
            y = center.y();
            z = center.z();
         }

         double reach = this.distance();
         double reachSq = reach * reach;
         boolean armour = this.armour();
         this.localPlayer = self;
         this.collect(self, x, y, z, reachSq, armour);
         this.prune();
         int mode = Client.renderMode();
         if (mode != 1) {
            if (mode != 3) {
               Client.clearChams();
            } else {
               Client.renderChams(outlines, armour);
            }
         }
      }
   }

   private void collect(Entity self, double x, double y, double z, double reachSq, boolean armour) {
      for (Entity entity : Client.entities()) {
         if (entity != null && entity != self && Client.isLiving(entity)) {
            double[] pos = Client.entityPosition(entity);
            double dx = pos[0] - x;
            double dy = pos[1] - y;
            double dz = pos[2] - z;
            if (!(dx * dx + dy * dy + dz * dz > reachSq)) {
               double[] box = new double[]{pos[0] - 0.5, pos[1], pos[2] - 0.5, pos[0] + 0.5, pos[1] + Client.entityHeight(entity), pos[2] + 0.5};
               boxes.add(box);
               outlines.add(box);
            }
         }
      }
   }

   private void prune() {
      for (int i = boxes.size() - 1; i >= 0; i--) {
         if (outlines.size() <= i) {
            boxes.remove(i);
         }
      }
   }

   private boolean armour() {
      client.Setting setting = this.setting("armour");
      return setting == null || setting.getBoolean();
   }

   private double distance() {
      client.Setting setting = this.setting("distance");
      return setting == null ? 64.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

