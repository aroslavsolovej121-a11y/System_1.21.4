package client.core;

public class ItemStack {
   public void effectAmplifier() {
   }

   public void enchantmentLevel() {
   }
}
