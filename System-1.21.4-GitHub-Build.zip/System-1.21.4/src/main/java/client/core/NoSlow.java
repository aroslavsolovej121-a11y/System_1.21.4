package client.core;

import client.Category;
import client.mc.Client;

public final class NoSlow extends client.Feature {
   public static final String MODULE = "noslow";
   public static final String DISPLAY = "НоЗлош";

   public NoSlow() {
      super("noslow", "НоЗлош", Category.Movement);
      this.add(client.Setting.bool("only_ground", false));
      this.add(client.Setting.bool("only_crossbow", false));
   }

   @Override
   public void onEnable() {
      Client.registerNoSlow(this);
   }

   @Override
   public void onDisable() {
      Client.registerNoSlow(null);
   }
}

