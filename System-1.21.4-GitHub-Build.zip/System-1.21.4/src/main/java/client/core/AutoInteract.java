package client.core;

import client.Category;
import client.mc.Client;

public final class AutoInteract extends client.Feature {
   public static final String MODULE = "autointeract";
   public static final String DISPLAY = "АутоИнтераст";
   private static final String FEATURE_INVIS = "invis";
   private static final String FEATURE_FOOD = "food";
   private static final int PHASE_IDLE = 0;
   private static final int PHASE_USE = 1;
   private static final int PHASE_HOLD = 2;
   private static final int PHASE_RELEASE = 3;
   private static final int PHASE_COOLDOWN = 4;
   private static final int TIMER_IDLE = 0;
   private static final int TIMER_DONE = 3;
   private static final int SLOT_MAIN_HAND = 8;
   private static final int HOTBAR_SIZE = 9;
   private static final int INVENTORY_OFFSET = 36;
   private static final int HOLD_LIMIT_TICKS = 60;
   private static final int MIN_HOLD_TICKS = 4;
   private static final int DEFAULT_USE_TICKS = 32;
   private static final int REUSE_COOLDOWN = 20;
   private int timerState;
   private int phase;
   private int lastSlot = -1;
   private int targetSlot = -1;
   private int holdTicks;
   private int cooldown;
   private boolean useKeyHeld;

   public AutoInteract() {
      super("autointeract", "АутоИнтераст", Category.Player);
      this.add(client.Setting.mode("features", "invis", "invis", "food"));
      this.add(client.Setting.number("invis_remaining", 0.0, 0.0, 20.0));
      this.add(client.Setting.number("min_food", 0.0, 0.0, 20.0));
   }

   @Override
   public void onEnable() {
      this.resetTimer();
      this.lastSlot = -1;
      this.phase = 0;
      this.holdTicks = 0;
      this.useKeyHeld = false;
   }

   @Override
   public void onDisable() {
      if (this.useKeyHeld) {
         Client.setUseKey(false);
      }

      if (this.targetSlot >= 0) {
         Client.restoreSlot();
      }

      this.resetTimer();
      this.lastSlot = -1;
      this.targetSlot = -1;
      this.phase = 0;
      this.holdTicks = 0;
      this.cooldown = 0;
      this.useKeyHeld = false;
   }

   @Override
   public void onTick() {
      this.advanceTimer();
      if (Client.inGame() && !Client.isPaused()) {
         Object player = Client.playerHandle();
         if (this.phase == 0) {
            if (this.cooldown > 0) {
               this.cooldown--;
            } else {
               int slot = -1;
               if (this.feature("invis")) {
                  slot = Client.findInvisSlot();
               }

               if (slot == -1) {
                  if (!this.feature("food")) {
                     return;
                  }

                  if ((int)this.minFood() < Client.foodLevel(player)) {
                     return;
                  }

                  slot = Client.findFoodSlot();
                  if (slot == -1) {
                     return;
                  }
               }

               this.beginUse(slot);
            }
         } else if (this.phase == 1) {
            if (this.timerState == 0 || this.timerState == 3) {
               int slotx = this.lastSlot == -1 ? this.targetSlot : 8;
               Client.selectSlot(slotx);
               Client.setUseKey(true);
               this.useKeyHeld = true;
               this.holdTicks = 0;
               this.phase = 2;
            }
         } else if (this.phase == 2) {
            this.holdTicks++;
            int useTicks = Client.itemUseTicks();
            boolean using = Client.isUsingItem();
            boolean finished = using && Client.itemUseRemaining() >= useTicks;
            boolean stalled = !using && this.holdTicks > 4;
            if (finished || stalled || this.holdTicks >= 60) {
               this.phase = 3;
            }
         } else if (this.phase == 3) {
            Client.setUseKey(false);
            int slotx = this.lastSlot;
            this.useKeyHeld = false;
            if (slotx != -1) {
               int mapped = slotx > 8 ? slotx : slotx + 36;
               this.scheduleTimer(mapped, 8);
               this.lastSlot = -1;
            }

            int hotbar = this.targetSlot;
            if (hotbar >= 0 && hotbar <= 8) {
               Client.swapHotbarSlot(hotbar);
            }

            Client.checkPendingException();
            this.targetSlot = -1;
            this.cooldown = 20;
            this.phase = 4;
         } else if (this.phase == 4) {
            if (this.timerState == 0 || this.timerState == 3) {
               this.phase = 0;
            }
         }
      } else if (this.phase != 0) {
         if (this.useKeyHeld) {
            Client.setUseKey(false);
         }

         if (this.targetSlot >= 0) {
            Client.restoreSlot();
         }

         this.resetTimer();
         this.lastSlot = -1;
         this.holdTicks = 0;
         this.useKeyHeld = false;
         this.phase = 0;
      }
   }

   private void beginUse(int slot) {
      this.lastSlot = slot;
      this.targetSlot = slot;
      this.resetTimer();
      this.phase = 1;
   }

   private void resetTimer() {
      this.timerState = 0;
   }

   private void advanceTimer() {
      if (this.timerState != 0) {
         this.timerState = 0;
      }
   }

   private void scheduleTimer(int slot, int duration) {
      this.timerState = 3;
   }

   private boolean feature(String id) {
      client.Setting setting = this.setting("features");
      return setting != null && id.equals(setting.getMode());
   }

   private double minFood() {
      client.Setting setting = this.setting("min_food");
      return setting == null ? 0.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

