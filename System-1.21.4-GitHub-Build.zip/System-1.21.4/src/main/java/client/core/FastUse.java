package client.core;

import client.Category;
import client.mc.Client;

public final class FastUse extends client.Feature {
   public static final String MODULE = "fastuse";
   public static final String DISPLAY = "ФазтУзе";
   private static final int EXPERIENCE_BOTTLE_ID = 5;
   private static final double DEFAULT_DELAY = 0.0;
   private static final double MIN_DELAY = 0.0;
   private static final double MAX_DELAY = 4.0;
   private static final double DELAY_STEP = 1.0;

   public FastUse() {
      super("fastuse", "ФазтУзе", Category.Movement);
      this.add(client.Setting.number("delay", 0.0, 0.0, 4.0, 1.0));
      this.add(client.Setting.bool("only_experience", false));
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!this.onlyExperience() || Client.mainHandItemId() == 5) {
            int delay = (int)this.delay();
            if (Client.itemUseCooldown() > delay) {
               Client.setItemUseCooldown(delay);
            }
         }
      }
   }

   private double delay() {
      client.Setting setting = this.setting("delay");
      return setting == null ? 0.0 : setting.getNumber();
   }

   private boolean onlyExperience() {
      client.Setting setting = this.setting("only_experience");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }
}

