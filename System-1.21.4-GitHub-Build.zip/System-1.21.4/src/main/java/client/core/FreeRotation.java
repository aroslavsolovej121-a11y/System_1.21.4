package client.core;

public class FreeRotation {
}
