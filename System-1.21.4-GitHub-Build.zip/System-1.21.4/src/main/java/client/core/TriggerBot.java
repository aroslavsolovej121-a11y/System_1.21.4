package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class TriggerBot extends client.Feature {
   public static final String MODULE = "triggerbot";
   public static final String DISPLAY = "ТриггерБот";
   public static final String STATUS_NO_PLAYER = "no player";
   public static final String STATUS_SCREEN_OPEN = "a screen is open";
   public static final String STATUS_BREAKING_BLOCK = "breaking a block";
   public static final String STATUS_NO_WEAPON = "no weapon in hand";
   public static final String STATUS_CROSSBOW = "holding a crossbow";
   public static final String STATUS_USING_ITEM = "using an item";
   public static final String STATUS_ATTACKING = "attacking";
   public static final String STATUS_TICK_MISSED = "attacking a target the tick missed";
   public static final String STATUS_STUNSLAM = "handed to StunSlam";
   public static final String STATUS_COMBO = "combo_lunge";
   private static final int RELEASE_TICKS = 10;
   private Entity lockedTarget;
   private Entity pendingTarget;
   private int attackCooldown;
   private int releaseTimer;
   private int rePressDelay;
   private int idleTicks;
   private float attackYaw;
   private float attackPitch;
   private boolean comboActive;
   private float comboYaw;
   private float comboPitch;
   private int lastTargetId = -1;
   private double lastTargetValue;
   private boolean fallStateValid;
   private boolean fallStateFlag;
   private int lastFallTick;
   private double lastFallY;
   private String status = "";

   public TriggerBot() {
      super("triggerbot", "ТриггерБот", Category.Combat);
      this.add(client.Setting.mode("attack_mode", "Обычный", "Обычный"));
      this.add(client.Setting.mode("target_mode", "Невидимых", "Невидимых", "Только игроки"));
      this.add(client.Setting.mode("hit_conditions", "Только криты", "Только криты", "Через траву"));
      this.add(client.Setting.bool("weapon_only", true));
      this.add(client.Setting.number("reach", 3.0, 1.0, 6.0));
      this.add(client.Setting.bool("through_entities", false));
      this.add(client.Setting.bool("custom_cooldown", false));
      this.add(client.Setting.number("custom_cooldown_percent", 100.0, 0.0, 100.0));
      this.add(client.Setting.bool("tps_sync", false));
      this.add(client.Setting.bool("combo_lunge", false));
   }

   @Override
   public void onEnable() {
      this.attackCooldown = 0;
      this.releaseTimer = 0;
      this.rePressDelay = 0;
      this.idleTicks = 0;
      this.comboActive = false;
      this.lastTargetId = -1;
      this.lastTargetValue = 0.0;
      this.pendingTarget = null;
      this.lastFallTick = -1;
      this.lastFallY = 0.0;
      this.fallStateValid = false;
      this.fallStateFlag = false;
      this.status = "";
   }

   @Override
   public void onDisable() {
      this.resetState();
   }

   @Override
   public void onTick() {
      Entity self = Client.player();
      Entity selfHandle = self == null ? null : Client.entityHandle(self);
      if (selfHandle != null) {
         Entity local = Client.player();
         if (local == null) {
            this.status = "no player";
            this.lastFallTick = -1;
            this.lastFallY = 0.0;
            this.fallStateValid = false;
            this.fallStateFlag = false;
         } else {
            Entity handle = Client.entityHandle(local);
            if (handle != null && Client.hasPendingException()) {
               int tick = Client.entityTick(handle);
               if (Client.hasPendingException()) {
                  tick = -1;
               }

               if (!this.fallStateValid || this.lastFallTick != tick) {
                  double[] position = Client.entityPosition(handle);
                  boolean flag;
                  if (this.fallStateValid && tick == this.lastFallTick + 1) {
                     flag = this.lastFallY <= position[1];
                  } else {
                     flag = false;
                  }

                  this.fallStateFlag = flag;
                  this.fallStateValid = true;
                  this.lastFallTick = tick;
                  this.lastFallY = position[1];
               }
            } else {
               this.status = "no player";
               this.lastFallTick = -1;
               this.lastFallY = 0.0;
               this.fallStateValid = false;
               this.fallStateFlag = false;
            }
         }

         if (Client.isPaused()) {
            this.status = "a screen is open";
            return;
         }

         Entity target = this.lockedTarget;
         if (this.lockedTarget != null) {
            this.lockedTarget = null;
         }

         if (this.attackCooldown != 0) {
            this.attackCooldown--;
            if (this.attackCooldown == 1) {
               Client.setAttackKey(false);
            } else {
               Client.setAttackKey(Client.attackKeyState());
            }
         }

         if (this.rePressDelay > 0) {
            this.rePressDelay--;
         }

         if (this.releaseTimer != 0) {
            this.releaseTimer--;
            if (this.releaseTimer < 1) {
               this.releaseTimer = 0;
               if (Client.cameraOverrides() < 1) {
                  Client.setAttackKey(Client.attackKeyState());
               }

               this.rePressDelay = 10;
            }
         }

         if (Client.isBreakingBlock()) {
            this.status = "breaking a block";
            return;
         }

         Entity current = Client.player();
         Entity handlex = current == null ? null : Client.entityHandle(current);
         if (Client.canAttack(handlex)) {
            this.idleTicks++;
         } else {
            this.idleTicks = 0;
         }

         if (Client.hasCrosshairEntity()) {
            if (this.pendingTarget != null) {
               this.cancelPendingTarget();
            }

            this.status = "using an item";
            return;
         }

         if (this.pendingTarget != null) {
            this.resolvePendingTarget();
            return;
         }

         if (Client.isHoldingCrossbow()) {
            this.status = "holding a crossbow";
            return;
         }

         if (this.weaponOnly() && !Client.isHoldingWeaponClass2()) {
            this.status = "no weapon in hand";
            return;
         }

         Entity found = this.findNearestHit(handlex);
         if (found != null) {
            this.status = "attacking";
            this.handToStunSlam(found, handlex);
            return;
         }

         this.attackLockedTarget(target, handlex);
      }
   }

   private void attackLockedTarget(Entity target, Entity selfHandle) {
      if (target != null) {
         if (Client.canAttack(target)) {
            if (this.findThroughEntities(target, selfHandle)) {
               if (Client.canReachTarget(target, this.attackYaw, this.attackPitch, this.reach())) {
                  if (this.canAttackTarget(target)) {
                     this.status = "attacking a target the tick missed";
                     if (!this.comboLunge() && Client.isOnGround(selfHandle) && Client.lungeReady()) {
                        this.startComboLunge(target);
                        this.comboActive = true;
                        this.comboYaw = this.attackYaw;
                        this.comboPitch = this.attackPitch;
                     } else {
                        Client.beginAttack();
                        String name = Client.entityName(target);
                        if (name == null) {
                           name = "";
                        }

                        if (Client.wtapActive() && Client.wtapAttackCheck(target)) {
                           Client.wtapOnAttack(target);
                        }

                        Client.attackWith(selfHandle, target);
                        if (this.releaseTimer != 0) {
                           this.releaseTimer = 0;
                           if (Client.cameraOverrides() <= 0) {
                              Client.setAttackKey(Client.attackKeyState());
                           }
                        } else {
                           Client.completeAttack(this);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private Entity findNearestHit(Entity selfHandle) {
      return Client.findNearestHit(selfHandle);
   }

   private boolean findThroughEntities(Entity target, Entity selfHandle) {
      return Client.findThroughEntities(this, target, selfHandle);
   }

   private boolean canAttackTarget(Entity target) {
      return Client.canAttackTarget(this, target);
   }

   private void handToStunSlam(Entity target, Entity selfHandle) {
      if (!this.canAttackTarget(target)) {
         this.tryComboAttack(target, selfHandle);
      } else {
         this.status = "attacking";
         if (Client.handToStunSlam(this, target, selfHandle)) {
            this.status = "handed to StunSlam";
         }
      }
   }

   private void tryComboAttack(Entity target, Entity selfHandle) {
      if (!this.comboLunge()
         && this.pendingTarget == null
         && Client.combatLock() < 1
         && Client.isOnGround(selfHandle)
         && Client.lungeReady()
         && Client.slamReady()) {
         this.startComboLunge(target);
      } else if (this.comboLunge()) {
         if (Client.attackAllowed(this)) {
            if (this.attackCooldown == 0 && this.rePressDelay == 0 && this.releaseTimer == 0) {
               if (Client.combatLock() <= 0 && Client.cameraOverrides() <= 0) {
                  if (Client.canAttack(selfHandle)) {
                     if (!Client.isOnGround(selfHandle)) {
                        if (!Client.hasCrosshairEntity()) {
                           if (!Client.anyInputPressed()) {
                              if (Client.slamReady()) {
                                 if (Client.comboAttackReady(this, target)) {
                                    Client.setAttackKey(true);
                                    Client.setHeldFlag(selfHandle, true);
                                    this.releaseTimer = 2;
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void startComboLunge(Entity target) {
      Client.startComboLunge(this, target);
   }

   private void resolvePendingTarget() {
      Client.resolvePendingTarget(this);
      this.pendingTarget = null;
   }

   private void cancelPendingTarget() {
      Client.cancelPendingTarget(this);
      this.pendingTarget = null;
   }

   private void resetState() {
      if (this.lockedTarget != null) {
         this.lockedTarget = null;
      }

      this.status = "";
      this.idleTicks = 0;
      this.lastTargetId = -1;
      this.lastTargetValue = 0.0;
      this.comboActive = false;
      this.attackCooldown = 0;
      this.releaseTimer = 0;
      this.rePressDelay = 0;
      if (this.releaseTimer != 0 || this.attackCooldown != 0) {
         this.releaseTimer = 0;
         this.attackCooldown = 0;
         Client.setAttackKey(Client.attackKeyState());
      }

      if (this.pendingTarget != null) {
         this.pendingTarget = null;
      }
   }

   public String status() {
      return this.status;
   }

   public float attackYaw() {
      return this.attackYaw;
   }

   public float attackPitch() {
      return this.attackPitch;
   }

   public boolean comboActive() {
      return this.comboActive;
   }

   public float comboYaw() {
      return this.comboYaw;
   }

   public float comboPitch() {
      return this.comboPitch;
   }

   public int idleTicks() {
      return this.idleTicks;
   }

   public int attackCooldown() {
      return this.attackCooldown;
   }

   public int releaseTimer() {
      return this.releaseTimer;
   }

   public int rePressDelay() {
      return this.rePressDelay;
   }

   public boolean fallStateValid() {
      return this.fallStateValid;
   }

   public boolean fallStateFlag() {
      return this.fallStateFlag;
   }

   private boolean weaponOnly() {
      client.Setting s = this.setting("weapon_only");
      return s != null && s.getBoolean();
   }

   private boolean comboLunge() {
      client.Setting s = this.setting("combo_lunge");
      return s != null && s.getBoolean();
   }

   private double reach() {
      client.Setting s = this.setting("reach");
      return s == null ? 3.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

