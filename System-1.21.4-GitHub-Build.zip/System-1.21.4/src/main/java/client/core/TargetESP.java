package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class TargetESP extends client.Feature {
   public static final String MODULE = "target_esp";
   public static final String DISPLAY = "ТаргетЕЗП";
   private static final String EFFECT_KEY = "effect";
   private static final String SHAPE_KEY = "shape";
   private static final String LOOK_KEY = "look";
   private static final String DISTORTION_KEY = "distortion";
   private static final String TIMING_KEY = "timing";
   private static final String OCCLUDE_KEY = "occlude";
   private static final String RADIUS_KEY = "radius";
   private static final String POINT_SIZE_KEY = "point_size";
   private static final String DENSITY_KEY = "density";
   private static final String TRAIL_KEY = "trail";
   private static final String COLOR_KEY = "color";
   private static final String GLOW_KEY = "glow";
   private static final String SPEED_KEY = "speed";
   private static final String HOLD_KEY = "hold";
   private static final String EFFECT_DEFAULT = "triangle";
   private static final String[] EFFECTS = new String[]{"ring", "triangle", "lightning", "helix", "orbit", "embers", "runes", "pulse"};
   private static final int EFFECT_COUNT = 8;
   private static final int EFFECT_FALLBACK = 0;
   private static final int DISTORTION_EFFECT_LIMIT = 2;
   private static final int DEFAULT_COLOR = -1096636;
   private static final int BATCH_MODE = 8;
   private static final int COLOR_TABLE_VALUE = 8;
   private static final double RADIUS_DEFAULT = 0.7;
   private static final double RADIUS_MIN = 0.4;
   private static final double RADIUS_MAX = 1.6;
   private static final double RADIUS_STEP = 0.05;
   private static final double POINT_SIZE_DEFAULT = 0.17;
   private static final double POINT_SIZE_MIN = 0.04;
   private static final double POINT_SIZE_MAX = 0.4;
   private static final double POINT_SIZE_STEP = 0.01;
   private static final double DENSITY_DEFAULT = 220.0;
   private static final double DENSITY_MIN = 30.0;
   private static final double DENSITY_MAX = 220.0;
   private static final double DENSITY_STEP = 2.0;
   private static final double TRAIL_DEFAULT = 6.0;
   private static final double TRAIL_MIN = 0.0;
   private static final double TRAIL_MAX = 12.0;
   private static final double TRAIL_STEP = 1.0;
   private static final double GLOW_DEFAULT = 0.4;
   private static final double GLOW_MIN = 0.2;
   private static final double GLOW_MAX = 3.0;
   private static final double GLOW_STEP = 0.05;
   private static final double DISTORTION_DEFAULT = 0.0;
   private static final double DISTORTION_MIN = 0.0;
   private static final double DISTORTION_MAX = 100.0;
   private static final double DISTORTION_STEP = 5.0;
   private static final double SPEED_DEFAULT = 0.7;
   private static final double SPEED_MIN = 0.1;
   private static final double SPEED_MAX = 2.0;
   private static final double SPEED_STEP = 0.1;
   private static final double HOLD_DEFAULT = 2.3;
   private static final double HOLD_MIN = 0.3;
   private static final double HOLD_MAX = 10.0;
   private static final double HOLD_STEP = 0.1;
   private static final double NANOS_PER_MS = 1000000.0;
   private static final double MS_PER_SECOND = 1000.0;
   private static final double FRAME_NANOS = 5.0E7;
   private static final double DISTORTION_PERCENT = 100.0;
   private static final float INTERPOLATION_TICKS = 1.0F;
   private static final float FADE_EPSILON = 0.001F;
   private static final float FADE_IN_STEP = 0.15F;
   private static final float FADE_OUT_STEP = 0.3F;
   private static final float FADE_MIN_VISIBLE = 0.03F;
   private static final float FADE_FULL = 1.0F;
   private static final float DISTORTION_SCALE = 0.1F;
   private static final float ENERGY_RAMP = 3.0F;
   private static final float STRIP_THRESHOLD = 0.25F;
   private static TargetESP instance;
   private final List<float[]> vertices = new ArrayList<>();
   private Entity currentTarget;
   private Entity previousTarget;
   private float currentFade;
   private float previousFade;
   private float currentFadePrev;
   private float previousFadePrev;
   private float currentTime;
   private float previousTime;
   private float currentTimePrev;
   private float previousTimePrev;
   private long lastHitNanos;
   private long lastFrameNanos;
   private boolean hitActive;
   private boolean fading;
   private boolean currentLineOfSight;
   private boolean previousLineOfSight;
   private boolean markerActive;

   public TargetESP() {
      super("target_esp", "ТаргетЕЗП", Category.Render);
      this.add(client.Setting.mode("effect", "triangle", EFFECTS));
      this.add(client.Setting.bool("shape", true));
      this.add(client.Setting.number("radius", 0.7, 0.4, 1.6, 0.05));
      this.add(client.Setting.number("point_size", 0.17, 0.04, 0.4, 0.01));
      this.add(client.Setting.number("density", 220.0, 30.0, 220.0, 2.0));
      this.add(client.Setting.number("trail", 6.0, 0.0, 12.0, 1.0));
      this.add(client.Setting.bool("look", true));
      this.add(client.Setting.color("color", -1096636));
      this.add(client.Setting.number("glow", 0.4, 0.2, 3.0, 0.05));
      this.add(client.Setting.number("distortion", 0.0, 0.0, 100.0, 5.0));
      this.add(client.Setting.bool("timing", true));
      this.add(client.Setting.number("speed", 0.7, 0.1, 2.0, 0.1));
      this.add(client.Setting.number("hold", 2.3, 0.3, 10.0, 0.1));
      this.add(client.Setting.bool("occlude", true));
   }

   public static TargetESP instance() {
      return instance;
   }

   public List<float[]> vertices() {
      return this.vertices;
   }

   public Entity currentTarget() {
      return this.currentTarget;
   }

   public Entity previousTarget() {
      return this.previousTarget;
   }

   public boolean markerActive() {
      return this.markerActive;
   }

   public boolean fadingIn() {
      return this.fading;
   }

   public boolean distortionVisible() {
      return this.effectIndex() <= 2;
   }

   @Override
   public void onEnable() {
      instance = this;
      this.currentFadePrev = 0.0F;
      this.previousFadePrev = 0.0F;
      this.currentFade = 0.0F;
      this.previousFade = 0.0F;
      this.currentTimePrev = 0.0F;
      this.previousTimePrev = 0.0F;
      this.currentTime = 0.0F;
      this.previousTime = 0.0F;
      this.lastHitNanos = 0L;
      this.hitActive = false;
      this.fading = false;
      this.currentLineOfSight = false;
      this.previousLineOfSight = false;
      this.lastFrameNanos = Client.nanos();
      this.applyVisibility();
   }

   @Override
   public void onDisable() {
      instance = null;
      this.currentTarget = null;
      this.previousTarget = null;
      this.currentFadePrev = 0.0F;
      this.previousFadePrev = 0.0F;
      this.currentFade = 0.0F;
      this.previousFade = 0.0F;
      this.currentTimePrev = 0.0F;
      this.previousTimePrev = 0.0F;
      this.currentTime = 0.0F;
      this.previousTime = 0.0F;
      this.lastHitNanos = 0L;
      this.hitActive = false;
      this.fading = false;
      this.currentLineOfSight = false;
      this.previousLineOfSight = false;
   }

   @Override
   protected void onSettingsVisibilityChanged(boolean visible) {
      this.applyVisibility();
   }

   @Override
   public void onTick() {
      if (!Client.inGame()) {
         this.currentTarget = null;
         this.previousTarget = null;
         this.currentFadePrev = 0.0F;
         this.previousFadePrev = 0.0F;
         this.currentFade = 0.0F;
         this.previousFade = 0.0F;
         this.currentTimePrev = 0.0F;
         this.previousTimePrev = 0.0F;
         this.currentTime = 0.0F;
         this.previousTime = 0.0F;
         this.lastHitNanos = 0L;
         this.hitActive = false;
         this.fading = false;
         this.currentLineOfSight = false;
         this.previousLineOfSight = false;
      } else {
         long now = Client.nanos();
         this.currentFadePrev = this.currentFade;
         this.previousFadePrev = this.previousFade;
         this.currentTimePrev = this.currentTime;
         this.previousTimePrev = this.previousTime;
         this.lastFrameNanos = now;
         Entity self = Client.resolvePlayer(Client.player());
         boolean invalid = false;
         if (this.currentTarget != null) {
            boolean removed = Client.isRemoved(this.currentTarget);
            boolean alive = Client.isAlive(this.currentTarget);
            if (removed || !alive) {
               invalid = true;
               this.hitActive = false;
            }
         }

         this.currentLineOfSight = false;
         if (this.currentTarget != null) {
            double[] targetPosition = Client.lerpedPosition(this.currentTarget, 1.0F);
            double[] selfPosition = Client.lerpedPosition(self, 1.0F);
            this.currentLineOfSight = !Client.lineOfSightBlocked(self, selfPosition, targetPosition);
         }

         this.previousLineOfSight = false;
         if (this.previousTarget != null) {
            double[] previousPosition = Client.lerpedPosition(this.previousTarget, 1.0F);
            double[] selfPosition = Client.lerpedPosition(self, 1.0F);
            this.previousLineOfSight = !Client.lineOfSightBlocked(self, selfPosition, previousPosition);
         }

         long check = Client.nanos();
         if (this.hitActive && !invalid && !(this.holdSeconds() * 1000.0 <= (check - this.lastHitNanos) / 1000000.0)) {
            float delta = 1.0F - this.currentFade;
            this.fading = true;
            if (0.001F <= Math.abs(delta)) {
               this.currentFade += delta * 0.15F;
            } else {
               this.currentFade = 1.0F;
            }
         } else {
            this.fading = false;
            if (this.currentTarget != null) {
               float delta = 0.0F - this.currentFade;
               if (0.001F <= Math.abs(delta)) {
                  this.currentFade += delta * 0.15F;
               } else {
                  this.currentFade = 0.0F;
               }

               if (this.currentFade < 0.03F) {
                  this.currentFade = 0.0F;
                  this.hitActive = false;
                  this.currentTarget = null;
               }
            }
         }

         if (this.previousTarget != null) {
            float deltax = 0.0F - this.previousFade;
            float next = 0.0F;
            if (0.001F <= Math.abs(deltax)) {
               next = deltax * 0.3F + this.previousFade;
            }

            this.previousFade = next;
            if (next < 0.03F) {
               this.previousFade = 0.0F;
               this.previousTarget = null;
            }
         }

         if (0.03F < this.currentFade) {
            this.currentTime = this.currentTime + (float)this.animationSpeed();
         }

         if (0.03F < this.previousFade) {
            this.previousTime = this.previousTime + (float)this.animationSpeed();
         }

         this.applyVisibility();
      }
   }

   @Override
   public void onEntityHit(Entity entity) {
      if (Client.isLiving(entity)) {
         if (Client.isAlive(entity)) {
            if (!Client.sameEntity(this.currentTarget, entity)) {
               this.previousTarget = this.currentTarget;
               this.previousFade = this.currentFade;
               this.previousTime = this.currentTime;
               this.currentTarget = entity;
               this.currentFade = 0.0F;
               this.currentTime = 0.0F;
            }

            this.lastHitNanos = Client.nanos();
            this.hitActive = true;
         }
      }
   }

   @Override
   public void onRender() {
      if (this.currentTarget != null || this.previousTarget != null) {
         long now = Client.nanos();
         float factor = Math.min((float)((now - this.lastFrameNanos) / 5.0E7), 1.0F);
         float currentValue = this.currentFade;
         float currentDelta = currentValue - this.currentFadePrev;
         if (0.001F <= Math.abs(currentDelta)) {
            currentValue = factor * currentDelta + this.currentFadePrev;
         }

         float previousValue = this.previousFade;
         float previousDelta = previousValue - this.previousFadePrev;
         if (0.001F <= Math.abs(previousDelta)) {
            previousValue = factor * previousDelta + this.previousFadePrev;
         }

         boolean drawCurrent = this.currentTarget != null && this.currentLineOfSight && 0.03F < currentValue;
         boolean drawPrevious = this.previousTarget != null && this.previousLineOfSight && 0.03F < previousValue;
         if (drawCurrent || drawPrevious) {
            int baseColor = this.colorValue();
            int tint = (Client.randomTint(baseColor) ^ baseColor) & 16777215 ^ baseColor;
            int effect = this.effectIndex();
            this.vertices.clear();
            this.markerActive = 0.001F < this.markerEnergy();
            if (drawPrevious) {
               float time = this.previousTime;
               float delta = time - this.previousTimePrev;
               if (0.001F <= Math.abs(delta)) {
                  time = factor * delta + this.previousTimePrev;
               }

               Client.targetEspMarker(this, this.previousTarget, previousValue, time, tint, effect, false);
            }

            if (drawCurrent) {
               float time = this.currentTime;
               float delta = time - this.currentTimePrev;
               if (0.001F <= Math.abs(delta)) {
                  time = factor * delta + this.currentTimePrev;
               }

               Client.targetEspMarker(this, this.currentTarget, currentValue, time, tint, effect, this.fading);
            }

            float brightness = (float)Client.colorTableChannel(tint, 8);
            if (!this.vertices.isEmpty() && Client.renderPassActive()) {
               Client.drawTargetEspStrip(8, this.vertices, (0.25F <= brightness ? 1 : 0) + 1);
            }
         }
      }
   }

   public int effectIndex() {
      client.Setting setting = this.setting("effect");
      if (setting == null) {
         return 0;
      } else {
         List<String> modes = setting.getModes();
         int index = modes.indexOf(setting.getMode());
         return index >= 0 && 8 > index ? index : 0;
      }
   }

   public float markerEnergy() {
      if (!this.distortionVisible()) {
         return 0.0F;
      } else {
         float scale = (float)this.number("distortion") / 100.0F * 0.1F;
         if (scale <= 0.0F) {
            return 0.0F;
         } else {
            long now = Client.nanos();
            float factor = (float)((now - this.lastFrameNanos) / 5.0E7);
            if (factor > 1.0F) {
               factor = 1.0F;
            }

            float current = 0.0F;
            if (this.currentTarget != null && this.currentLineOfSight) {
               current = this.currentFade;
               float delta = current - this.currentFadePrev;
               if (0.001F <= Math.abs(delta)) {
                  current = factor * delta + this.currentFadePrev;
               }
            }

            float previous = 0.0F;
            if (this.previousTarget != null && this.previousLineOfSight) {
               previous = this.previousFade;
               float delta = previous - this.previousFadePrev;
               if (0.001F <= Math.abs(delta)) {
                  previous = factor * delta + this.previousFadePrev;
               }
            }

            if (previous > current) {
               current = previous;
            }

            return (3.0F - (current + current)) * current * scale * current;
         }
      }
   }

   private void applyVisibility() {
      client.Setting shape = this.setting("shape");
      client.Setting look = this.setting("look");
      client.Setting timing = this.setting("timing");
      boolean shapeVisible = shape == null || shape.getBoolean();
      boolean lookVisible = look == null || look.getBoolean();
      boolean timingVisible = timing == null || timing.getBoolean();
      this.setVisible("radius", shapeVisible);
      this.setVisible("point_size", shapeVisible);
      this.setVisible("density", shapeVisible);
      this.setVisible("trail", shapeVisible);
      this.setVisible("color", lookVisible);
      this.setVisible("glow", lookVisible);
      this.setVisible("speed", timingVisible);
      this.setVisible("hold", timingVisible);
      this.setVisible("distortion", this.distortionVisible());
   }

   private void setVisible(String key, boolean value) {
      client.Setting setting = this.setting(key);
      if (setting != null) {
         setting.setVisible(value);
      }
   }

   private double holdSeconds() {
      return this.number("hold");
   }

   private double animationSpeed() {
      return this.number("speed");
   }

   private int colorValue() {
      client.Setting setting = this.setting("color");
      return setting == null ? -1096636 : setting.getColor();
   }

   private double number(String key) {
      client.Setting setting = this.setting(key);
      return setting == null ? 0.0 : setting.getNumber();
   }

   private client.Setting setting(String key) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(key)) {
            return setting;
         }
      }

      return null;
   }
}

