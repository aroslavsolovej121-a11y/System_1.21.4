package client.core;

import client.Category;

public final class Bloom extends client.Feature {
   public static final String MODULE = "bloom";
   public static final String DISPLAY = "Блоом";
   private static Bloom active;

   public Bloom() {
      super("bloom", "Блоом", Category.Render);
      this.add(client.Setting.number("threshold", 0.9, 0.0, 1.0));
      this.add(client.Setting.number("intensity", 4.0, 0.0, 10.0));
      this.add(client.Setting.number("boost", 3.0, 0.0, 8.0));
      this.add(client.Setting.bool("world_only", true));
   }

   public static Bloom active() {
      return active;
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
   }
}

