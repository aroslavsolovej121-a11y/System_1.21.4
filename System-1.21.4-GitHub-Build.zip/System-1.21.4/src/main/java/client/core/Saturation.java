package client.core;

import client.Category;
import client.mc.Client;

public final class Saturation extends client.Feature {
   public static final String MODULE = "saturation";
   public static final String DISPLAY = "Затуратион";
   private static final float NEUTRAL_AMOUNT = 1.0F;
   private static final float CHANGE_EPSILON = 0.001F;
   private static Saturation active;
   private double appliedAmount = 1.0;

   public Saturation() {
      super("saturation", "Затуратион", Category.Render);
      this.add(client.Setting.number("saturation", 1.0, 0.0, 2.0, 0.05));
      this.add(client.Setting.bool("world_only", false));
   }

   public static Saturation active() {
      return active;
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
   }

   public boolean worldOnly() {
      client.Setting setting = this.setting("world_only");
      return setting != null && setting.getBoolean();
   }

   public double amount() {
      client.Setting setting = this.setting("saturation");
      return setting == null ? 1.0 : setting.getNumber();
   }

   public boolean appliesTo(boolean worldPass) {
      return this.enabled && Client.streamCaptureActive() && worldPass == this.worldOnly();
   }

   public double appliedAmount() {
      return this.appliedAmount;
   }

   public static void applyPass(boolean companionActive, int width, int height, boolean worldPass, int flags) {
      Saturation saturation = null;
      Saturation candidate = active;
      if (candidate != null && candidate.appliesTo(worldPass)) {
         saturation = candidate;
      }

      if (companionActive || saturation != null) {
         if (!Client.postProcessReady()) {
            return;
         }

         Client.beginPostProcess(width, height, flags);
         if (saturation != null) {
            double amount = saturation.amount();
            if (Math.abs((float)amount - 1.0F) > 0.001F && Client.postProcessTargetValid()) {
               Client.bindPostProcessTarget();
               Client.unbindPostProcessTarget();
               Client.drawPostProcessQuad();
               Client.setPostProcessValue((float)amount);
               Client.endPostProcess();
            }

            saturation.appliedAmount = amount;
         }

         Client.releasePostProcess();
      }
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

