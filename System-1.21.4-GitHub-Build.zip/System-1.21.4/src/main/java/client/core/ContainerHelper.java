package client.core;

import client.Category;
import client.mc.Client;
import java.util.ArrayList;
import java.util.List;

public final class ContainerHelper extends client.Feature {
   public static final String MODULE = "container_helper";
   public static final String DISPLAY = "СонтаинерХелпер";
   public static final String BUTTON_DROP = "drop";
   public static final String BUTTON_TAKE = "take";
   public static final String BUTTON_SORT = "sort";
   public static final String BUTTON_STASH = "stash";
   private static final int NO_ACTION = -1;
   private static final int ACTION_DROP = 0;
   private static final int ACTION_TAKE_MATCHING = 1;
   private static final int ACTION_TAKE_OTHER = 2;
   private static final int ACTION_OPEN_CONTAINER = 3;
   private static final int BUTTON_COUNT = 4;
   private static final int WAIT_ITERATIONS = 2;
   public static final float BUTTON_HEIGHT = 16.0F;
   public static final float PRESS_ALPHA = 0.5F;
   private final List<ContainerHelper.Button> buttons = new ArrayList<>();
   private final ContainerHelper.Animation[] animations = new ContainerHelper.Animation[4];
   private int action = -1;
   private boolean clicked;
   private boolean waiting;
   private boolean containerOwned;
   private boolean screenFlag;
   private int syncId = -1;

   public ContainerHelper() {
      super("container_helper", "СонтаинерХелпер", Category.Player);
      this.add(client.Setting.bool("drop", true));
      this.add(client.Setting.bool("take", true));
      this.add(client.Setting.bool("sort", true));
      this.add(client.Setting.bool("stash", true));

      for (int i = 0; i < 4; i++) {
         this.animations[i] = new ContainerHelper.Animation();
      }
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
   }

   @Override
   public boolean isVisible() {
      return !this.buttons.isEmpty();
   }

   public boolean hasButtons() {
      return !this.buttons.isEmpty();
   }

   public List<ContainerHelper.Button> buttons() {
      return this.buttons;
   }

   public ContainerHelper.Animation[] animations() {
      return this.animations;
   }

   public int action() {
      return this.action;
   }

   public void setAction(int value) {
      this.action = value;
   }

   public boolean buttonEnabled(int index) {
      client.Setting setting = this.getSettings().get(index);
      return setting != null && setting.getBoolean();
   }

   @Override
   public void onTick() {
      this.buildButtons();
      if (this.buttons.isEmpty()) {
         this.action = -1;
         this.clicked = Client.rawKeyState() < 0;
         this.clearAnimations();
      } else {
         int queued = this.action;
         if (queued >= 0) {
            this.action = -1;
            if (queued == 0) {
               int[] list = Client.containerSlotIndices();

               for (int slot : list) {
                  if (Client.slotPresent(slot)) {
                     Client.clickSlot(slot, 1);
                  }
               }
            } else if (queued == 1) {
               Client.moveMatchingSlots(true);
            } else if (queued == 2) {
               Client.moveMatchingSlots(false);
            } else if (queued == 3) {
               this.waiting = true;
               this.syncId = Client.containerSyncId();
               this.containerOwned = this.screenFlag;
            }
         }
      }

      if (this.waiting) {
         if (Client.inGame() && !this.buttons.isEmpty() && Client.containerSyncId() == this.syncId) {
            int iterations = 0;

            do {
               int[] list = Client.containerSlotIndices();
               if (list.length == 0) {
                  this.waiting = false;
                  return;
               }

               if (Client.containerSlotItemMatches(list[0])) {
                  this.waiting = false;
                  return;
               }

               if (!Client.sortContainer() && !Client.stashContainer()) {
                  this.waiting = false;
                  return;
               }
            } while (++iterations < 2);
         } else {
            this.waiting = false;
         }
      }
   }

   @Override
   public void onRender() {
      if (!Client.containerScreenOpen()) {
         this.reset();
      } else {
         double scale = Client.guiScale();
         if (!(scale <= 0.0)) {
            boolean attackPressed = Client.rawKeyState() < 0;
            boolean freshClick = attackPressed && !this.clicked && !Client.isPaused();
            this.clicked = attackPressed;

            for (ContainerHelper.Button button : this.buttons) {
               boolean hovered = Client.hoveredRect(button.x, button.y, button.width, 16.0);
               float alpha = hovered ? 0.5F : 0.0F;
               if (hovered && freshClick && this.action < 0) {
                  this.action = button.index;
               }

               ContainerHelper.Animation animation = this.animations[button.index];
               if (animation.alpha != alpha) {
                  long now = Client.nanos();
                  animation.seed = Client.animationSeed(now);
                  animation.alpha = alpha;
                  animation.targetNanos = now;
                  animation.active = true;
               }

               Client.drawContainerButton(button, animation, Client.nanos());
            }
         }
      }
   }

   private void reset() {
      this.buttons.clear();
      this.clearAnimations();
      this.action = -1;
      this.clicked = false;
      this.containerOwned = false;
      this.screenFlag = false;
      this.syncId = -1;
      this.waiting = false;
   }

   private void clearAnimations() {
      for (ContainerHelper.Animation animation : this.animations) {
         animation.seed = 0;
         animation.alpha = 0.0F;
         animation.targetNanos = 0L;
         animation.active = false;
      }
   }

   private void buildButtons() {
      double[][] layout = Client.containerButtonLayout();
      this.buttons.clear();
      if (Client.inGame()) {
         boolean auction = Client.isAuctionScreen(Client.openScreenTitle());
         if (auction || Client.inventoryScreenOpen()) {
            this.containerOwned = auction;
            this.screenFlag = auction;
            int[] search = new int[2];
            if (Client.containerSearch(search)) {
               for (int i = 0; i < layout.length; i++) {
                  if (this.buttonEnabled(i)) {
                     ContainerHelper.Button button = new ContainerHelper.Button();
                     button.x = layout[i][0];
                     button.y = layout[i][1];
                     button.width = layout[i][2];
                     button.index = i;
                     this.buttons.add(button);
                  }
               }
            }
         }
      }
   }

   public static final class Animation {
      public int seed;
      public float alpha;
      public long targetNanos;
      public boolean active;
   }

   public static final class Button {
      public double x;
      public double y;
      public double width;
      public int index;
   }
}

