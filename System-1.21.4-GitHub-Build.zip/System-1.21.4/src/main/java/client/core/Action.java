package client.core;

public class Action {
}
