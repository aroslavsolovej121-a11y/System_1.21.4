package client.core;

import client.Category;
import client.mc.Client;

public final class NoInteract extends client.Feature {
   public static final String MODULE = "nointeract";
   public static final String DISPLAY = "НоИнтераст";

   public NoInteract() {
      super("nointeract", "НоИнтераст", Category.Movement);
   }

   @Override
   public void onEnable() {
      Client.registerNoInteract(this);
   }

   @Override
   public void onDisable() {
      Client.registerNoInteract(null);
   }
}

