package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class ShowInvisible extends client.Feature {
   public static final String MODULE = "show_invisible";
   public static final String DISPLAY = "ЗхошИнвизибле";
   private static final double MODEL_HALF_WIDTH = 0.5;
   private static final double BOX_PADDING = 0.1;
   private static final double NAME_PADDING = 0.05;
   private static final int BOX_COLOR = -16776961;
   private static final int OUTLINE_COLOR = 1291845631;
   private static final double OUTLINE_WIDTH = 0.008;
   private final List<Entity> players = new ArrayList<>();
   private final List<double[]> boxes = new ArrayList<>();
   private final List<double[]> names = new ArrayList<>();
   private final List<double[]> outlines = new ArrayList<>();

   public ShowInvisible() {
      super("show_invisible", "ЗхошИнвизибле", Category.Render);
      this.add(client.Setting.bool("solid", true));
      this.add(client.Setting.bool("show_hitbox", true));
   }

   @Override
   public void onEnable() {
      this.stash();
      this.players.clear();
      this.boxes.clear();
      this.names.clear();
      this.outlines.clear();
   }

   @Override
   public void onDisable() {
      this.stash();
      this.players.clear();
      this.boxes.clear();
      this.names.clear();
      this.outlines.clear();
   }

   @Override
   public void onTick() {
      this.stash();
      this.players.clear();
      if (Client.inGame()) {
         Entity self = Client.player();
         if (self != null) {
            boolean solid = this.solid();

            for (Entity entity : Client.entities()) {
               if (entity != null && Client.isLiving(entity) && (solid || Client.isInvisible(entity))) {
                  this.players.add(entity);
               }
            }
         }
      }
   }

   public void render() {
      this.stash();
      if (!this.players.isEmpty()) {
         for (Entity entity : this.players) {
            double[] position = Client.entityPosition(entity);
            double half = 0.5 * Client.entityScale(entity);
            double[] bounds = new double[]{
               position[0] - half - 0.1,
               position[1] - 0.1,
               position[2] - half - 0.1,
               position[0] + half + 0.1,
               position[1] + Client.entityHeight(entity) + 0.1,
               position[2] + half + 0.1
            };
            if (Client.isBoxVisible(bounds)) {
               double[] view = Client.interpolatedPosition(entity);
               double[] box = new double[]{view[0] - half, view[1], view[2] - half, view[0] + half, view[1] + Client.entityHeight(entity), view[2] + half};
               this.boxes.add(box);
               double eye = Client.entityEyeHeight(entity);
               double[] outline = new double[]{view[0] - half, view[1] - 0.05, view[2] - half, view[0] + half, view[1] + eye + 0.05, view[2] + half};
               this.outlines.add(outline);
               double head = Client.entityNameHeight(entity);
               double[] name = new double[]{view[0], view[1] + head + eye, view[2], view[0] + half * 2.0, view[1] + head * 2.0 + half, view[2] + half * 2.0};
               this.names.add(name);
            }
         }

         if (!this.boxes.isEmpty()) {
            Client.fillBoxes(this.boxes, -16776961);
            Client.fillBoxes(this.names, 1291845631);

            for (double[] outline : this.outlines) {
               Client.drawBoxOutline(outline, -16776961, 0.008);
            }
         }
      }
   }

   private void stash() {
      this.names.clear();
      this.boxes.clear();
      this.outlines.clear();
   }

   private boolean solid() {
      client.Setting setting = this.setting("solid");
      return setting == null || setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

