package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AutoShiftTap extends client.Feature {
   public static final String MODULE = "autoshifttap";
   public static final String DISPLAY = "ЗхифтТап";
   private static final long TAP_DURATION_NANOS = 25000000L;
   private long releaseAt;
   private boolean pressed;

   public AutoShiftTap() {
      super("autoshifttap", "ЗхифтТап", Category.Combat);
   }

   public void press() {
      this.releaseAt = Client.timerNanos() + 25000000L;
      if (!this.pressed) {
         Client.setSneak(true);
         this.pressed = true;
      }
   }

   @Override
   public void onDisable() {
      if (this.pressed) {
         Client.setSneak(false);
         this.pressed = false;
      }
   }

   @Override
   public void onTick() {
      Entity player = Client.player();
      if (player != null && !Client.isSneaking(player)) {
         if (!this.pressed) {
            return;
         }

         if (Client.timerNanos() <= this.releaseAt) {
            return;
         }
      }

      if (this.pressed) {
         Client.setSneak(false);
         this.pressed = false;
      }
   }
}

