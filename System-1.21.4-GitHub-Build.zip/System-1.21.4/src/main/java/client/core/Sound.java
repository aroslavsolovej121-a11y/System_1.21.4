package client.core;

import client.Category;
import client.mc.Client;
import java.util.List;

public final class Sound extends client.Feature {
   public static final String MODULE = "sound";
   public static final String DISPLAY = "Зоундз";
   public static final String MODE_LOW = "low";
   public static final String MODE_MID = "mid";
   public static final String MODE_HIGH = "high";
   private static final double VOLUME_DIVISOR = 100.0;
   private static final float VOLUME_MIN = 0.0F;
   private static final float VOLUME_MAX = 1.0F;
   private static final int PITCH_INDEX_DEFAULT = 1;
   private static final int PITCH_INDEX_LAST = 2;

   public Sound() {
      super("sound", "Зоундз", Category.Client);
      this.add(client.Setting.number("master_volume", 20.0, 0.0, 100.0, 1.0));
      this.add(client.Setting.mode("pitch", "Средние", "Низкие", "Средние", "Высокие"));
      this.apply();
   }

   @Override
   public void onEnable() {
      Client.setInterfaceSoundEnabled(true);
      this.apply();
   }

   @Override
   public void onDisable() {
      Client.setInterfaceSoundEnabled(false);
   }

   @Override
   public void onTick() {
      this.apply();
   }

   public void apply() {
      Client.setInterfaceSoundVolume(this.clampVolume(this.masterVolume()));
      Client.setInterfaceSoundPitch(this.pitchIndex());
   }

   public double masterVolume() {
      client.Setting setting = this.setting("master_volume");
      return setting == null ? 20.0 : setting.getNumber();
   }

   public float volumeFactor() {
      return this.clampVolume(this.masterVolume());
   }

   public int pitchIndex() {
      client.Setting setting = this.setting("pitch");
      List<String> modes = setting == null ? null : setting.getModes();
      int count = modes == null ? 0 : modes.size();
      String selected = setting == null ? null : setting.getMode();
      if (count != 0 && selected != null && selected.equals(modes.get(0))) {
         return 0;
      } else {
         return count >= 3 && selected != null && selected.equals(modes.get(2)) ? 2 : 1;
      }
   }

   private float clampVolume(double raw) {
      float value = (float)(raw / 100.0);
      if (0.0F <= value) {
         return value <= 1.0F ? value : 1.0F;
      } else {
         return 0.0F;
      }
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

