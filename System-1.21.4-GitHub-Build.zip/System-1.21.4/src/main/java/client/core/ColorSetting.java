package client.core;

public class ColorSetting {
}
