package client.core;

import client.Category;
import client.mc.Client;

public final class Enchancer extends client.Feature {
   public static final String MODULE = "enchancer";
   public static final String DISPLAY = "Енсхансер";

   public Enchancer() {
      super("enchancer", "Енсхансер", Category.Render);
      this.add(client.Setting.bool("chat", true));
      this.add(client.Setting.bool("clean_f3", false));
      this.add(client.Setting.mode("f3_fields", "All", "All", "Position", "Fps"));
      this.add(client.Setting.bool("typing", true));
      this.add(client.Setting.number("typing_time", 1.0, 0.0, 10.0));
      this.add(client.Setting.mode("typing_style", "Fade", "Fade", "Slide"));
   }

   @Override
   public void onDisable() {
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            ;
         }
      }
   }
}

