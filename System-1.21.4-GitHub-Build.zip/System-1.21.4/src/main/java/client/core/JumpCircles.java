package client.core;

import client.Category;
import client.mc.Client;

public final class JumpCircles extends client.Feature {
   public static final String MODULE = "jump_circles";
   public static final String DISPLAY = "ЖумпСирслез";
   private float progress;

   public JumpCircles() {
      super("jump_circles", "ЖумпСирслез", Category.Combat);
      this.add(client.Setting.mode("mode", "Circle", "Circle", "Wave"));
      this.add(client.Setting.number("lifetime", 1.0, 0.1, 10.0));
      this.add(client.Setting.number("radius", 1.0, 0.1, 5.0));
      this.add(client.Setting.number("wave_strength", 1.0, 0.0, 5.0));
      this.add(client.Setting.number("wave_radius", 1.0, 0.0, 5.0));
      this.add(client.Setting.number("wave_time", 1.0, 0.1, 10.0));
      this.add(client.Setting.number("distortion", 0.0, 0.0, 1.0));
      this.add(client.Setting.color("color", 16777215));
   }

   @Override
   public void onEnable() {
      this.progress = 0.0F;
   }

   @Override
   public void onDisable() {
      this.progress = 0.0F;
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            this.progress = 0.0F;
         }
      }
   }
}

