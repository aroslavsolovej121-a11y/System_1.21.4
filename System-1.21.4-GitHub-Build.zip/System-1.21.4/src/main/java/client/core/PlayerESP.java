package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class PlayerESP extends client.Feature {
   public static final String MODULE = "player_esp";
   public static final String DISPLAY = "ПлайерЕЗП";
   private static final double NANO_SCALE = 1.0E-9;
   private static final float GLOW_RAMP_RATE = 5.0F;
   private static final float RAMP_LOW = 0.0F;
   private static final float RAMP_HIGH = 1.0F;
   private static final int FADE_TICKS = 5;
   private static PlayerESP active;
   private final List<Object> targets = new ArrayList<>();
   private final List<Object> boxes = new ArrayList<>();
   private final List<Object> friendBoxes = new ArrayList<>();
   private final List<Object> drawList = new ArrayList<>();
   private final List<Object> pending = new ArrayList<>();
   private boolean invisibleActive;
   private int fadeTimer;
   private boolean faded;
   private float glowRamp;
   private long lastFrameNanos;

   public PlayerESP() {
      super("player_esp", "ПлайерЕЗП", Category.Render);
      this.add(client.Setting.mode("targets", "players", "players", "mobs", "all"));
      this.add(client.Setting.mode("mode", "box", "box", "glow"));
      this.add(client.Setting.bool("show_friends", true));
      this.add(client.Setting.mode("armor_filter", "all", "all", "armored", "netherite"));
      this.add(client.Setting.number("shape_geometry", 2.0, 0.1, 5.0));
      this.add(client.Setting.color("shape_colors", -1));
      this.add(client.Setting.bool("shape_glow", true));
      this.add(client.Setting.bool("shape_friends", false));
      this.add(client.Setting.gradient("glow_colors", -13183233, -38090));
      this.add(client.Setting.number("glow_halo", 24.0, 4.0, 96.0));
      this.add(client.Setting.bool("glow_animation_group", false));
      this.add(client.Setting.bool("glow_through_walls", true));
      this.add(client.Setting.number("line_width", 2.0, 0.1, 5.0));
      this.add(client.Setting.bool("distance_scale", true));
      this.add(client.Setting.color("line_color", -1));
      this.add(client.Setting.bool("outline", false));
      this.add(client.Setting.color("outline_color", -16777216));
      this.add(client.Setting.bool("fill", false));
      this.add(client.Setting.color("fill_color", 1291845631));
      this.add(client.Setting.bool("box_glow", true));
      this.add(client.Setting.number("box_glow_radius", 20.0, 4.0, 96.0));
      this.add(client.Setting.number("box_glow_intensity", 1.0, 0.1, 4.0));
      this.add(client.Setting.bool("friend_custom_color", false));
      this.add(client.Setting.color("friend_line_color", -16711681));
      this.add(client.Setting.color("friend_fill_color", 1275133951));
      this.add(client.Setting.gradient("glow_color", -13183233, -38090));
      this.add(client.Setting.number("glow_gradient_speed", 0.0, 0.0, 5.0));
      this.add(client.Setting.color("glow_fill_color", 16777215));
      this.add(client.Setting.gradient("glow_friend_color", -16711681, -256));
      this.add(client.Setting.number("glow_radius", 24.0, 4.0, 96.0));
      this.add(client.Setting.number("glow_intensity", 1.5, 0.3, 4.0));
      this.add(client.Setting.bool("glow_animation", false));
      this.add(client.Setting.number("glow_animation_strength", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("glow_animation_scale", 1.0, 1.0, 2.5));
   }

   public static PlayerESP active() {
      return active;
   }

   public List<Object> targets() {
      return this.targets;
   }

   public List<Object> boxes() {
      return this.boxes;
   }

   public List<Object> friendBoxes() {
      return this.friendBoxes;
   }

   public List<Object> drawList() {
      return this.drawList;
   }

   public List<Object> pending() {
      return this.pending;
   }

   public boolean invisibleActive() {
      return this.invisibleActive;
   }

   public int fadeTimer() {
      return this.fadeTimer;
   }

   public boolean faded() {
      return this.faded;
   }

   public float glowRamp() {
      return this.glowRamp;
   }

   public long lastFrameNanos() {
      return this.lastFrameNanos;
   }

   public void tickFade() {
      this.fadeTimer++;
      if (this.fadeTimer > 5 && !this.faded) {
         this.faded = true;
      }
   }

   public void resetFade() {
      this.fadeTimer = 0;
   }

   @Override
   public void onEnable() {
      this.glowRamp = 0.0F;
      this.lastFrameNanos = Client.nanos();
      this.targets.clear();
      this.boxes.clear();
      this.friendBoxes.clear();
      Client.resetPlayerEspTimeline(this);
      this.invisibleActive = false;
      this.fadeTimer = 0;
      active = this;
   }

   @Override
   public void onDisable() {
      this.invisibleActive = false;
      active = null;
      this.targets.clear();
      this.boxes.clear();
      this.friendBoxes.clear();
      Client.resetPlayerEspTimeline(this);
   }

   @Override
   public void onTick() {
      if (!this.targets.isEmpty()) {
         this.targets.clear();
      }

      Client.resetPlayerEspTimeline(this);
      this.invisibleActive = false;
      if (Client.inGame()) {
         boolean players = Client.targetsMatchPlayers(this);
         boolean mobs;
         if (this.modeIs("targets", "mobs")) {
            mobs = true;
         } else {
            mobs = this.modeIs("targets", "all");
         }

         if (players || mobs) {
            Entity local = Client.player();
            double[] reference = Client.entityPosition(local);
            boolean showFriends = this.flag("show_friends");
            boolean glowMode = this.modeIs("mode", "glow");
            boolean throughWallsGlow = glowMode && !this.flag("glow_through_walls");
            boolean armorFilter = Client.armorFilterNetherite(this);
            if (players) {
               Client.forEachPlayer(player -> Client.collectPlayerEspTarget(this, player, reference, throughWallsGlow, armorFilter, showFriends));
            }

            if (mobs) {
               Client.forEachEntity(entity -> Client.collectMobEspTarget(this, entity, reference, armorFilter, throughWallsGlow));
            }

            if (glowMode && !this.pending.isEmpty() && !this.faded) {
               this.invisibleActive = true;
            } else {
               this.invisibleActive = false;
               Client.resetPlayerEspTimeline(this);
            }
         }
      }
   }

   @Override
   public void onRender() {
      long now = Client.nanos();
      long previous = this.lastFrameNanos;
      this.lastFrameNanos = now;
      float ramp = (float)((now - previous) * 1.0E-9) * 5.0F + this.glowRamp;
      float low = ramp >= 0.0F ? ramp : 0.0F;
      this.glowRamp = ramp <= 1.0F ? low : 1.0F;
      Client.updatePlayerEspGroups(this);
      if (!this.boxes.isEmpty() || !this.friendBoxes.isEmpty()) {
         if (this.modeIs("mode", "glow")) {
            Client.renderPlayerEspSolid(this);
         } else {
            Client.PlayerEspStyle style = new Client.PlayerEspStyle();
            style.lineWidth = this.num("line_width");
            style.distanceScale = this.flag("distance_scale");
            style.outline = this.flag("outline");
            style.outlineColor = this.colorOf("outline_color");
            style.fill = this.flag("fill");
            style.boxGlow = this.flag("box_glow");
            style.boxGlowRadius = (float)this.num("box_glow_radius");
            style.boxGlowIntensity = (float)this.num("box_glow_intensity");
            style.glowRamp = this.glowRamp;
            if (this.flag("friend_custom_color") && this.flag("show_friends")) {
               style.lineColor = this.colorOf("line_color");
               style.fillColor = this.colorOf("fill_color");
               Client.renderPlayerEspGroup(this, this.boxes, style);
               style.lineColor = this.colorOf("friend_line_color");
               style.fillColor = this.colorOf("friend_fill_color");
               Client.renderPlayerEspGroup(this, this.friendBoxes, style);
            } else {
               this.drawList.clear();
               this.drawList.addAll(this.boxes);
               this.drawList.addAll(this.friendBoxes);
               style.lineColor = this.colorOf("line_color");
               style.fillColor = this.colorOf("fill_color");
               Client.renderPlayerEspGroup(this, this.drawList, style);
            }
         }
      }
   }

   private boolean flag(String name) {
      client.Setting setting = this.setting(name);
      return setting != null && setting.getBoolean();
   }

   private double num(String name) {
      client.Setting setting = this.setting(name);
      return setting == null ? 0.0 : setting.getNumber();
   }

   private int colorOf(String name) {
      client.Setting setting = this.setting(name);
      return setting == null ? 0 : setting.getColor();
   }

   private String mode(String name) {
      client.Setting setting = this.setting(name);
      return setting == null ? "" : setting.getMode();
   }

   private boolean modeIs(String name, String value) {
      return value.equals(this.mode(name));
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

