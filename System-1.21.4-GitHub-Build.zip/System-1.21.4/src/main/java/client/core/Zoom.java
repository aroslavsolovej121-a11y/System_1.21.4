package client.core;

import client.Category;
import client.mc.Client;

public final class Zoom extends client.Feature {
   public static final String MODULE = "zoom";
   public static final String DISPLAY = "Zоом";
   private boolean zooming;
   private double currentFov;

   public Zoom() {
      super("zoom", "Zоом", Category.Render);
      this.add(client.Setting.key("zoom_key", 0));
      this.add(client.Setting.number("zoom_fov", 30.0, 1.0, 110.0));
      this.add(client.Setting.number("speed", 1.0, 0.1, 10.0));
      this.add(client.Setting.bool("scroll_control", false));
      this.add(client.Setting.number("scroll_step", 5.0, 1.0, 30.0));
   }

   @Override
   public void onEnable() {
      this.zooming = false;
      this.currentFov = 0.0;
   }

   @Override
   public void onDisable() {
      this.zooming = false;
      this.currentFov = 0.0;
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            boolean pressed = Client.isKeyDown(this.zoomKey());
            if (pressed != this.zooming) {
               this.zooming = pressed;
               this.currentFov = this.zooming ? this.zoomFov() : 0.0;
            }
         }
      }
   }

   private int zoomKey() {
      client.Setting setting = this.setting("zoom_key");
      return setting == null ? 0 : setting.getKey();
   }

   private double zoomFov() {
      client.Setting setting = this.setting("zoom_fov");
      return setting == null ? 30.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

