package client.core;

import client.Category;
import client.mc.Client;

public final class FastSearch extends client.Feature {
   public static final String MODULE = "fastsearch";
   public static final String DISPLAY = "ФазтЗеарсх";
   private static final String DEFAULT_TEMPLATE = "ah search {name}";
   private static final String NAME_PLACEHOLDER = "{name}";
   private static final int BIND_MODE = 0;
   private boolean triggerHeld;

   public FastSearch() {
      super("fastsearch", "ФазтЗеарсх", Category.Player);
      this.add(client.Setting.input("template", "ah search {name}"));
      this.add(client.Setting.bool("off_hand", false));
      this.add(client.Setting.bool("strip_brackets", true));
      this.add(client.Setting.key("trigger", 0));
   }

   @Override
   public void onEnable() {
      this.triggerHeld = false;
   }

   @Override
   public void onTick() {
      client.Setting trigger = this.setting("trigger");
      if (trigger != null) {
         if (this.consumeTrigger(trigger.getKey())) {
            if (!Client.isScreenOpen() && Client.inGame()) {
               String name = Client.heldItemName(this.offHand(), this.stripBrackets());
               if (!name.isEmpty()) {
                  String template = this.template();
                  int at = template.indexOf("{name}");
                  String command;
                  if (at < 0) {
                     command = template + " " + name;
                  } else {
                     command = template.substring(0, at) + name + template.substring(at + "{name}".length());
                  }

                  while (command.length() > 0 && command.charAt(0) == '/') {
                     command = command.substring(1);
                  }

                  Client.sendChatCommand(command);
               }
            }
         }
      }
   }

   private String template() {
      client.Setting setting = this.setting("template");
      return setting == null ? "ah search {name}" : setting.getText();
   }

   private boolean offHand() {
      client.Setting setting = this.setting("off_hand");
      return setting != null && setting.getBoolean();
   }

   private boolean stripBrackets() {
      client.Setting setting = this.setting("strip_brackets");
      return setting != null && setting.getBoolean();
   }

   private boolean consumeTrigger(int key) {
      boolean down = key >= 1 && key <= 255 && Client.isBindDown(key, 0);
      boolean fired = down && !this.triggerHeld;
      this.triggerHeld = down;
      return fired;
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }
}

