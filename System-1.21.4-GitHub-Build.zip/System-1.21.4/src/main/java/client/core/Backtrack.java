package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class Backtrack extends client.Feature {
   public static final String MODULE = "backtrack";
   public static final int RENDER_RVA = 380256;
   public static final int WINDOW_REFRESH_RVA = 377776;
   public static final int TRACE_RVA = 379360;
   public static final int TRACE_LIMIT_RVA = 669856;
   public static final String STATUS_WINDOW_CLOSED = "окно закрыто";
   public static final String STATUS_NO_PLAYER = "нет игрока";
   public static final String STATUS_VANILLA_AIMING = "ваниль уже целится в сущность";
   public static final String STATUS_OUTSIDE_WINDOWS = "прицел вне развёрток";
   public static final String STATUS_ON_WINDOW = "прицел наведён на развёртку";
   public static final String STATUS_BLOCKED = "развёртку загораживает блок";
   private static final int FILL_COLOR_ALPHA = 855638016;
   private static final int OUTLINE_COLOR_ALPHA = 1711276032;
   private static final int LABEL_COLOR = -16777216;
   private static final float LABEL_SIZE = 20.0F;
   private static final float LABEL_ALPHA = 1.0F;
   private static final double WINDOW_MIN = 25.0;
   private static double windowScale;
   private final List<Backtrack.Window> windows = new ArrayList<>();
   private final List<Backtrack.Window> processed = new ArrayList<>();
   private String status = "";

   public Backtrack() {
      super("backtrack", "Басктраск", Category.Combat);
      this.add(client.Setting.number("reach", 3.0, 1.0, 8.0));
      this.add(client.Setting.number("window", 200.0, 0.0, 1000.0));
      this.add(client.Setting.bool("show_box", true));
      this.add(client.Setting.color("box_color", -12877066));
   }

   @Override
   public void onEnable() {
      this.refreshWindowScale();
      this.clearWindows();
   }

   @Override
   public void onDisable() {
      windowScale = 0.0;
      this.clearWindows();
   }

   @Override
   public void onTick() {
      this.scanCrosshair();
      this.trackWindows();
   }

   @Override
   public void onRender() {
      if (!this.windows.isEmpty()) {
         int color = this.boxColor();
         Client.drawWindowPass(this.windows, color & 16777215 | 855638016, 20.0F, 1.0F, null, true, false, -16777216);
         Client.drawWindowPass(this.processed, color & 16777215 | 1711276032, 20.0F, 1.0F, Client.WINDOW_ALPHA_STEPS, false, true, -16777216);
      }
   }

   private void trackWindows() {
      this.refreshWindowScale();
      this.clearWindows();
      if (this.showBox()) {
         for (Entity entity : Client.entities()) {
            int id = Client.entityId(entity);
            double[] raw = Client.windowSnapshot(entity);
            this.windows.add(new Backtrack.Window(raw[0], raw[1], raw[2], raw[3], id, 0, 0, 0));
            double[] converted = Client.convertWindowSnapshot(entity);
            this.processed.add(new Backtrack.Window(converted[0], converted[1], converted[2], converted[3], id, 0, 0, 0));
         }
      }
   }

   private void scanCrosshair() {
      if (windowScale <= 0.0) {
         this.setStatus("окно закрыто");
      } else if (Client.crosshairEntity() != null) {
         this.setStatus("ваниль уже целится в сущность");
      } else {
         Entity raw = Client.player();
         if (raw == null) {
            this.setStatus("нет игрока");
         } else {
            Entity self = Client.resolvePlayer(raw);
            if (self == null) {
               this.setStatus("нет игрока");
            } else {
               double reach = this.reach();
               double[] selfPosition = Client.lerpedPosition(self, 1.0F);
               double[] look = Client.lookVector(self);
               double[] rayEnd = new double[]{reach * look[0] + selfPosition[0], reach * look[1] + selfPosition[1], reach * look[2] + selfPosition[2]};
               double[] hitDistance = new double[]{0.0};
               Entity hit = Client.traceWindowTarget(selfPosition, rayEnd, hitDistance);
               if (hit == null) {
                  this.setStatus("прицел вне развёрток");
               } else {
                  double limit = Client.traceDistance(self, selfPosition, rayEnd, reach);
                  if (hitDistance[0] <= limit) {
                     this.setStatus("прицел наведён на развёртку");
                  } else {
                     this.setStatus("развёртку загораживает блок");
                  }
               }
            }
         }
      }
   }

   private void clearWindows() {
      this.windows.clear();
      this.processed.clear();
   }

   private void setStatus(String value) {
      if (!this.status.equals(value)) {
         this.status = value;
      }
   }

   private void refreshWindowScale() {
      windowScale = this.window();
      if (!this.isEnabled() || !Client.clientReady() || windowScale < 25.0) {
         windowScale = 0.0;
      }

      if (windowScale <= 0.0) {
         windowScale = 0.0;
      }
   }

   private double reach() {
      client.Setting s = this.setting("reach");
      return s == null ? 3.0 : s.getNumber();
   }

   private double window() {
      client.Setting s = this.setting("window");
      return s == null ? 200.0 : s.getNumber();
   }

   private boolean showBox() {
      client.Setting s = this.setting("show_box");
      return s != null && s.getBoolean();
   }

   private int boxColor() {
      client.Setting s = this.setting("box_color");
      return s == null ? -12877066 : s.getColor();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }

   public static final class Window {
      private final double posX;
      private final double posY;
      private final double posZ;
      private final double time;
      private final int id;
      private final int field0;
      private final int field1;
      private final int field2;

      public Window(double posX, double posY, double posZ, double time, int id, int field0, int field1, int field2) {
         this.posX = posX;
         this.posY = posY;
         this.posZ = posZ;
         this.time = time;
         this.id = id;
         this.field0 = field0;
         this.field1 = field1;
         this.field2 = field2;
      }

      public double x() {
         return this.posX;
      }

      public double y() {
         return this.posY;
      }

      public double z() {
         return this.posZ;
      }

      public double time() {
         return this.time;
      }

      public int id() {
         return this.id;
      }

      public int field0() {
         return this.field0;
      }

      public int field1() {
         return this.field1;
      }

      public int field2() {
         return this.field2;
      }
   }
}

