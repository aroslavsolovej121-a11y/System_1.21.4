package client.core;

import client.Category;
import client.mc.Client;

public final class FTHotkeys extends client.Feature {
   public static final String MODULE = "fthotkeys";
   public static final String DISPLAY = "ФТХоткеыз";
   private static final int NO_SLOT = -1;
   private boolean menuPending;
   private int menuTicks;
   private int clickCounter = -1;

   public FTHotkeys() {
      super("fthotkeys", "ФТХоткеыз", Category.Player);
      this.add(client.Setting.number("arena_slot", 25.0, 1.0, 54.0, 1.0));
      this.add(client.Setting.number("click_delay", 1.0, 0.0, 20.0, 1.0));
      this.add(client.Setting.number("open_timeout", 60.0, 10.0, 2000.0, 5.0));
      this.add(client.Setting.key("arena_trigger", 0));
      this.add(client.Setting.key("invest_trigger", 0));
      this.add(client.Setting.key("storage_trigger", 0));
   }

   public boolean menuPending() {
      return this.menuPending;
   }

   public void setMenuPending(boolean value) {
      this.menuPending = value;
   }

   public int menuTicks() {
      return this.menuTicks;
   }

   public void setMenuTicks(int value) {
      this.menuTicks = value;
   }

   public int clickCounter() {
      return this.clickCounter;
   }

   public void setClickCounter(int value) {
      this.clickCounter = value;
   }

   @Override
   public void onEnable() {
      this.menuPending = false;
      this.menuTicks = 0;
      this.clickCounter = -1;
   }

   @Override
   public void onDisable() {
      this.menuPending = false;
      this.menuTicks = 0;
      this.clickCounter = -1;
   }

   @Override
   public void onTick() {
      Client.fthotkeyTick(this);
      if (this.menuPending) {
         if (!Client.inGame() || ++this.menuTicks > (int)this.openTimeout()) {
            this.menuTicks = 0;
            this.menuPending = false;
            this.clickCounter = -1;
         } else if (Client.inventoryScreenOpen()) {
            int slot = (int)this.arenaSlot() - 1;
            if (slot >= 0 && slot < Client.containerSize()) {
               int counter = this.clickCounter;
               if (counter < 0) {
                  this.clickCounter = 0;
                  counter = 0;
               }

               if (counter < (int)this.clickDelay()) {
                  this.clickCounter = counter + 1;
                  return;
               }

               Client.clickSlot(slot, 0, 0, 0);
               Client.closeScreen();
            }

            this.menuTicks = 0;
            this.menuPending = false;
            this.clickCounter = -1;
         }
      }
   }

   private double arenaSlot() {
      client.Setting setting = this.setting("arena_slot");
      return setting == null ? 1.0 : setting.getNumber();
   }

   private double clickDelay() {
      client.Setting setting = this.setting("click_delay");
      return setting == null ? 2.0 : setting.getNumber();
   }

   private double openTimeout() {
      client.Setting setting = this.setting("open_timeout");
      return setting == null ? 5.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

