package client.core;

import client.Category;
import client.mc.Client;
import java.util.ArrayList;
import java.util.List;

public final class ShulkerPreview extends client.Feature {
   public static final String MODULE = "shulker_preview";
   public static final String DISPLAY = "ЗхулкерПревиеш";
   public static final int PREVIEW_BIND_DEFAULT = 164;
   public static final int MAX_PREVIEW_SLOTS = 54;
   private final List<Object> contents = new ArrayList<>();
   private int previewId = -1;

   public ShulkerPreview() {
      super("shulker_preview", "ЗхулкерПревиеш", Category.Render);
      this.add(client.Setting.bool("bind_only", false));
      this.add(client.Setting.key("preview_bind", 164));
   }

   public List<Object> contents() {
      return this.contents;
   }

   public int previewId() {
      return this.previewId;
   }

   public boolean hasPreview() {
      return !this.contents.isEmpty();
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
   }

   public void reset() {
      this.contents.clear();
      this.previewId = -1;
   }

   @Override
   public void onTick() {
      this.reset();
      if (this.bindOnly()) {
         client.Setting bind = this.setting("preview_bind");
         int key = bind == null ? 0 : bind.getKey();
         if (key == 0) {
            return;
         }

         if (!Client.isBindTriggered(key, 0)) {
            return;
         }
      }

      Object stack = Client.hoveredStack();
      if (stack != null) {
         List<Object> slots = Client.containerContents(stack);
         if (slots.size() > 54) {
            slots = slots.subList(0, 54);
         }

         boolean any = false;

         for (Object slot : slots) {
            this.contents.add(slot);
            if (any || slot != null) {
               any = true;
            }
         }

         if (!any) {
            this.reset();
         } else {
            this.previewId = Client.openScreenId();
         }
      }
   }

   @Override
   public void onRender() {
      if (!this.contents.isEmpty()) {
         Client.renderShulkerPreview(this.contents);
      }
   }

   public boolean bindOnly() {
      client.Setting setting = this.setting("bind_only");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

