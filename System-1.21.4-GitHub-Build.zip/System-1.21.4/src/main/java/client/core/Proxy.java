package client.core;

import client.Category;
import client.mc.Client;

public final class Proxy extends client.Feature {
   public static final String MODULE = "proxy";
   public static final String DISPLAY = "Про$й";
   public static final String VERSION_SOCKS4 = "SOCKS4";
   public static final String VERSION_SOCKS5 = "SOCKS5";
   public static final String DEFAULT_ADDRESS = "127.0.0.1:1080";

   public Proxy() {
      super("proxy", "Про$й", Category.Client);
      this.add(client.Setting.input("address", "127.0.0.1:1080"));
      this.add(client.Setting.mode("socks5", "SOCKS5", "SOCKS4", "SOCKS5"));
      this.add(client.Setting.input("username", ""));
      this.add(client.Setting.input("password", ""));
   }

   @Override
   public void onEnable() {
      this.applyProxy();
   }

   @Override
   public void onDisable() {
      this.applyProxy();
   }

   private void applyProxy() {
      if (this.enabled && Client.toggleGateOpen()) {
         int[] port = new int[1];
         String host = this.parseAddress(this.text("address"), port);
         if (host == null) {
            Client.applyProxy(false, true, "", 0, "", "");
         } else {
            Client.applyProxy(true, "SOCKS5".equals(this.mode("socks5")), host, port[0], this.text("username"), this.text("password"));
         }
      } else {
         Client.applyProxy(false, true, "", 0, "", "");
      }
   }

   private String parseAddress(String raw, int[] portOut) {
      if (raw == null) {
         return null;
      } else {
         int begin = 0;

         int length;
         for (length = raw.length(); length > 0 && (raw.charAt(begin) == ' ' || raw.charAt(begin) == '\t'); length--) {
            begin++;
         }

         while (length > 0 && (raw.charAt(begin + length - 1) == ' ' || raw.charAt(begin + length - 1) == '\t')) {
            length--;
         }

         if (length <= 0) {
            return null;
         } else {
            int colon = raw.indexOf(58, begin);
            if (colon >= begin && colon < begin + length && colon + 1 < begin + length) {
               int value = 0;

               for (int i = colon + 1; i < begin + length; i++) {
                  char ch = raw.charAt(i);
                  if (ch < '0' || ch > '9') {
                     return null;
                  }

                  value = value * 10 + (ch - '0');
                  if (value > 65535) {
                     return null;
                  }
               }

               if (value == 0) {
                  return null;
               } else {
                  portOut[0] = value;
                  return raw.substring(begin, colon);
               }
            } else {
               return null;
            }
         }
      }
   }

   private String text(String name) {
      client.Setting s = this.setting(name);
      return s == null ? "" : s.getText();
   }

   private String mode(String name) {
      client.Setting s = this.setting(name);
      return s == null ? "" : s.getMode();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

