package client.core;

import client.Category;
import client.mc.Client;

public final class Theme extends client.Feature {
   public static final String MODULE = "theme";
   public static final String DISPLAY = "Тхеме";
   public static final String SETTING_EXCEPT_GUI = "except_gui";
   public static final String SETTING_STYLE = "style";
   public static final String SETTING_GUI_SCALE = "gui_scale";
   public static final String SETTING_GUI_BLUR = "gui_blur";
   public static final String SETTING_GUI_DIM = "gui_dim";
   public static final String SETTING_EFFECTS = "effects";
   public static final String SETTING_GLASS = "glass";
   public static final String SETTING_INTENSITY = "intensity";
   public static final String SETTING_REFRACTION = "refraction";
   public static final String SETTING_CHROMATIC = "chromatic";
   public static final String SETTING_BLUR = "blur";
   public static final String SETTING_TINT_STRENGTH = "tint_strength";
   public static final String SETTING_FROSTED = "frosted";
   public static final String SETTING_POSTERIZE = "posterize";
   public static final String SETTING_PIXELATE = "pixelate";
   public static final String SETTING_WAVE = "wave";
   public static final String SETTING_WAVE_SPEED = "wave_speed";
   public static final String SETTING_WAVE_FREQUENCY = "wave_frequency";
   public static final String SETTING_INNER_GLOW = "inner_glow";
   public static final String SETTING_INNER_GLOW_SIZE = "inner_glow_size";
   public static final String SETTING_INNER_GLOW_COLOR = "inner_glow_color";
   public static final String SETTING_CURSOR_SIZE = "cursor_size";
   public static final String SETTING_CURSOR_STRENGTH = "cursor_strength";
   public static final String SETTING_REVEAL_RADIUS = "reveal_radius";
   public static final String SETTING_REVEAL_STRENGTH = "reveal_strength";
   public static final String SETTING_COLOR_MODE = "color_mode";
   public static final String SETTING_ACCENT = "accent";
   public static final String SETTING_GRADIENT_ANGLE = "gradient_angle";
   public static final String SETTING_ACCENT_TARGETS = "accent_targets";
   public static final String STYLE_PLAIN = "Oбычный";
   public static final String STYLE_TRANSPARENT = "Прoзрачный";
   public static final String EFFECT_FROSTED = "frosted";
   public static final String EFFECT_POSTERIZE = "posterize";
   public static final String EFFECT_PIXELATE = "pixelate";
   public static final String EFFECT_WAVE = "wave";
   public static final String EFFECT_INNER_GLOW = "inner_glow";
   public static final String EFFECT_SHEEN = "sheen";
   public static final String EFFECT_GRAIN = "grain";
   public static final String EFFECT_CURSOR_LIGHT = "cursor_light";
   public static final String EFFECT_CURSOR_INERTIA = "cursor_inertia";
   public static final String EFFECT_REVEAL = "reveal";
   public static final String EFFECT_TINTED_RIM = "tinted_rim";
   public static final String EFFECT_SCENE_RIM = "scene_rim";
   public static final String EFFECT_PRISM = "prism";
   public static final String EFFECT_THICKNESS = "thickness";
   public static final String EFFECT_UNDER_GLOW = "under_glow";
   public static final String EFFECT_AURORA = "aurora";
   public static final String COLOR_MODE_DEFAULT = "default";
   public static final String COLOR_MODE_CUSTOM = "custom";
   public static final String TARGET_BACKGROUND = "background";
   public static final String TARGET_SURFACE = "surface";
   public static final String TARGET_TEXT = "text";
   public static final String TARGET_BORDER = "border";
   public static final double GLASS_STEP = 0.05;
   public static final double GLASS_MIN = 0.05;
   public static final double GLASS_MAX = 1.0;
   public static final double INTENSITY_DEFAULT = 1.0;
   public static final double REFRACTION_DEFAULT = 1.0;
   public static final double CHROMATIC_DEFAULT = 1.0;
   public static final double BLUR_DEFAULT = 0.4;
   public static final double BLUR_MAX = 0.8;
   public static final double BLUR_STEP = 0.1;
   public static final double TINT_DEFAULT = 0.02;
   public static final double TINT_MAX = 0.05;
   public static final double TINT_STEP = 0.001;
   public static final double FROSTED_DEFAULT = 0.5;
   public static final double POSTERIZE_DEFAULT = 0.5;
   public static final double PIXELATE_DEFAULT = 0.3;
   public static final double WAVE_DEFAULT = 0.5;
   public static final double WAVE_SPEED_DEFAULT = 1.0;
   public static final double WAVE_SPEED_MAX = 3.0;
   public static final double WAVE_SPEED_STEP = 0.1;
   public static final double WAVE_FREQUENCY_DEFAULT = 0.5;
   public static final double INNER_GLOW_DEFAULT = 0.3;
   public static final double INNER_GLOW_SIZE_DEFAULT = 0.5;
   public static final int INNER_GLOW_COLOR = -8401921;
   public static final double CURSOR_SIZE_DEFAULT = 1.0;
   public static final double CURSOR_SIZE_MIN = 0.3;
   public static final double CURSOR_STRENGTH_DEFAULT = 1.0;
   public static final double CURSOR_STRENGTH_MIN = 0.2;
   public static final double CURSOR_MAX = 3.0;
   public static final double REVEAL_RADIUS_DEFAULT = 1.0;
   public static final double REVEAL_RADIUS_MIN = 0.3;
   public static final double REVEAL_STRENGTH_DEFAULT = 1.0;
   public static final double REVEAL_STRENGTH_MIN = 0.2;
   public static final double REVEAL_STRENGTH_MAX = 2.0;
   public static final double GUI_SCALE_DEFAULT = 1.0;
   public static final double GUI_SCALE_MIN = 0.5;
   public static final double GUI_SCALE_MAX = 1.5;
   public static final double GUI_BLUR_DEFAULT = 18.0;
   public static final double GUI_BLUR_MAX = 64.0;
   public static final double GUI_BLUR_STEP = 1.0;
   public static final double GUI_DIM_DEFAULT = 35.0;
   public static final double GUI_DIM_MIN = 0.0;
   public static final double GUI_DIM_MAX = 100.0;
   public static final double GUI_DIM_STEP = 5.0;
   public static final int ACCENT_FROM = -2343358;
   public static final int ACCENT_TO = -9814308;
   public static final double GRADIENT_ANGLE_DEFAULT = 45.0;
   public static final double GRADIENT_ANGLE_MIN = 0.0;
   public static final double GRADIENT_ANGLE_MAX = 360.0;
   public static final double GRADIENT_ANGLE_STEP = 5.0;
   private static Theme active;

   public Theme() {
      super("theme", "Тхеме", Category.Client);
      this.add(client.Setting.bool("except_gui", true));
      this.add(client.Setting.mode("style", "Прoзрачный", "Oбычный", "Прoзрачный"));
      this.add(client.Setting.number("gui_scale", 1.0, 0.5, 1.5));
      this.add(client.Setting.number("gui_blur", 18.0, 0.0, 64.0));
      this.add(client.Setting.number("gui_dim", 35.0, 0.0, 100.0));
      this.add(
         client.Setting.mode(
            "effects",
            "sheen",
            "frosted",
            "posterize",
            "pixelate",
            "wave",
            "inner_glow",
            "sheen",
            "grain",
            "cursor_light",
            "cursor_inertia",
            "reveal",
            "tinted_rim",
            "scene_rim",
            "prism",
            "thickness",
            "under_glow",
            "aurora"
         )
      );
      this.add(client.Setting.bool("glass", true));
      this.add(client.Setting.number("intensity", 1.0, 0.0, 1.0));
      this.add(client.Setting.number("refraction", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("chromatic", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("blur", 0.4, 0.0, 0.8));
      this.add(client.Setting.number("tint_strength", 0.02, 0.0, 0.05));
      this.add(client.Setting.number("frosted", 0.5, 0.05, 1.0));
      this.add(client.Setting.number("posterize", 0.5, 0.05, 1.0));
      this.add(client.Setting.number("pixelate", 0.3, 0.05, 1.0));
      this.add(client.Setting.number("wave", 0.5, 0.05, 1.0));
      this.add(client.Setting.number("wave_speed", 1.0, 0.0, 3.0));
      this.add(client.Setting.number("wave_frequency", 0.5, 0.05, 1.0));
      this.add(client.Setting.number("inner_glow", 0.3, 0.05, 1.0));
      this.add(client.Setting.number("inner_glow_size", 0.5, 0.05, 1.0));
      this.add(client.Setting.color("inner_glow_color", -8401921));
      this.add(client.Setting.number("cursor_size", 1.0, 0.3, 3.0));
      this.add(client.Setting.number("cursor_strength", 1.0, 0.2, 3.0));
      this.add(client.Setting.number("reveal_radius", 1.0, 0.3, 3.0));
      this.add(client.Setting.number("reveal_strength", 1.0, 0.2, 2.0));
      this.add(
         client.Setting.mode(
            "color_mode", "default", "default", "custom", "bluepink", "polarize", "water", "lilac", "spring", "winter", "midnight", "earth", "forest", "galaxy"
         )
      );
      this.add(client.Setting.gradient("accent", -2343358, -9814308));
      this.add(client.Setting.number("gradient_angle", 45.0, 0.0, 360.0));
      this.add(client.Setting.mode("accent_targets", "background", "background", "surface", "text", "border"));
      this.applyVisibility();
   }

   public static Theme active() {
      return active;
   }

   @Override
   public void onEnable() {
      active = this;
      this.applyVisibility();
      Client.applyTheme(this);
   }

   @Override
   public void onDisable() {
      active = null;
      Client.resetTheme();
   }

   @Override
   public void onTick() {
      this.applyVisibility();
   }

   @Override
   public void onRender() {
      Client.applyTheme(this);
   }

   @Override
   protected void onSettingsVisibilityChanged(boolean visible) {
      this.applyVisibility();
   }

   public boolean exceptGui() {
      client.Setting setting = this.setting("except_gui");
      return setting != null && setting.getBoolean();
   }

   public boolean transparentStyle() {
      client.Setting setting = this.setting("style");
      return setting != null && "Прoзрачный".equals(setting.getMode());
   }

   public boolean customColorMode() {
      return Client.settingListContains(this, "color_mode", "custom");
   }

   public boolean defaultColorMode() {
      return Client.settingListContains(this, "color_mode", "default");
   }

   public boolean effectEnabled(String effect) {
      return Client.settingListContains(this, "effects", effect);
   }

   private void applyVisibility() {
      boolean style = this.transparentStyle();
      this.show("intensity", style);
      this.show("refraction", style);
      this.show("chromatic", style);
      this.show("blur", style);
      this.show("tint_strength", style);
      this.show("effects", style);
      this.show("glass", style);
      boolean frosted = style && this.effectEnabled("frosted");
      this.show("frosted", frosted);
      boolean posterize = style && this.effectEnabled("posterize");
      this.show("posterize", posterize);
      boolean pixelate = style && this.effectEnabled("pixelate");
      this.show("pixelate", pixelate);
      boolean wave = style && this.effectEnabled("wave");
      this.show("wave", wave);
      this.show("wave_speed", wave);
      this.show("wave_frequency", wave);
      boolean innerGlow = style && this.effectEnabled("inner_glow");
      this.show("inner_glow", innerGlow);
      this.show("inner_glow_size", innerGlow);
      this.show("inner_glow_color", innerGlow);
      boolean cursorLight = style && this.effectEnabled("cursor_light");
      this.show("cursor_size", cursorLight);
      this.show("cursor_strength", cursorLight);
      boolean reveal = style && this.effectEnabled("reveal");
      this.show("reveal_radius", reveal);
      this.show("reveal_strength", reveal);
      boolean custom = this.customColorMode();
      this.show("accent", custom);
      this.show("gradient_angle", style && custom && Client.themeAccentGradientActive());
      this.show("accent_targets", !this.defaultColorMode());
   }

   private void show(String name, boolean visible) {
      client.Setting setting = this.setting(name);
      if (setting != null) {
         setting.setVisible(visible);
      }
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

