package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class NameTags extends client.Feature {
   public static final String MODULE = "nametags";
   public static final String DISPLAY = "НамеТагз";
   public static final String KEY_OFF = "off";
   public static final String KEY_MINEBLAZE = "mineblaze";
   public static final String KEY_FUNTIME = "funtime";
   public static final String KEY_HEARTS = "hearts";
   public static final String KEY_POINTS = "points";
   public static final String KEY_FRIENDS = "friends";
   public static final String KEY_ENEMIES = "enemies";
   public static final String KEY_ARMORED_ENEMIES_ONLY = "armored_enemies_only";
   public static final String KEY_PREFIX = "prefix";
   public static final String KEY_ARMOR = "armor";
   public static final String KEY_OFFHAND = "offhand";
   public static final String KEY_MAINHAND = "mainhand";
   public static final String KEY_COLORED_HP = "colored_hp";
   public static final String KEY_HIDE_EMPTY = "hide_empty";
   public static final String KEY_SHOW_COUNT = "show_count";
   public static final String KEY_BACKGROUND = "background";
   public static final String KEY_BG_OPACITY = "bg_opacity";
   public static final String KEY_LOD = "lod";
   public static final String KEY_LOD_DISTANCE = "lod_distance";
   private static final int SLOT_REFRESH_PERIOD = 5;
   private final List<Object> entries = new ArrayList<>();
   private boolean funtime;
   private boolean mineblaze;
   private boolean prefix;
   private boolean refreshSlot;
   private boolean hearts;
   private boolean slotsEnabled;
   private boolean voiceReady;
   private boolean pulseReady;
   private int slotRefreshCounter;

   public NameTags() {
      super("nametags", "НамеТагз", Category.Render);
      this.add(client.Setting.bool("hp_bypass", false));
      this.add(client.Setting.bool("off", false));
      this.add(client.Setting.bool("mineblaze", false));
      this.add(client.Setting.bool("funtime", true));
      this.add(client.Setting.bool("hp_mode", false));
      this.add(client.Setting.bool("hearts", false));
      this.add(client.Setting.bool("points", true));
      this.add(client.Setting.number("scale", 0.35, 0.01, 1.0));
      this.add(client.Setting.number("max_distance", 64.0, 8.0, 256.0));
      this.add(client.Setting.bool("targets", false));
      this.add(client.Setting.bool("friends", false));
      this.add(client.Setting.bool("enemies", false));
      this.add(client.Setting.bool("armored_enemies_only", false));
      this.add(client.Setting.bool("parts", false));
      this.add(client.Setting.bool("prefix", true));
      this.add(client.Setting.bool("armor", true));
      this.add(client.Setting.bool("offhand", true));
      this.add(client.Setting.bool("mainhand", false));
      this.add(client.Setting.bool("colored_hp", true));
      this.add(client.Setting.bool("voice_icon", true));
      this.add(client.Setting.bool("pulse_icon", true));
      this.add(client.Setting.bool("background", true));
      this.add(client.Setting.number("bg_opacity", 100.0, 0.0, 100.0));
      this.add(client.Setting.bool("plate", true));
      this.add(client.Setting.bool("hide_empty", false));
      this.add(client.Setting.bool("show_count", true));
      this.add(client.Setting.bool("slots", true));
      this.add(client.Setting.bool("keep_vanilla", false));
      this.add(client.Setting.bool("lod", false));
      this.add(client.Setting.number("lod_distance", 30.0, 8.0, 128.0));
      this.add(client.Setting.bool("lod_group", true));
   }

   public List<Object> entries() {
      return this.entries;
   }

   @Override
   public void onEnable() {
      this.reset();
      Client.resetNameTagGroups(this);
   }

   @Override
   public void onDisable() {
      this.reset();
      Client.resetNameTagGroups(this);
   }

   public void reset() {
      this.entries.clear();
      Client.resetNameTagLayout(this);
   }

   @Override
   public void onTick() {
      if (!this.entries.isEmpty()) {
         this.entries.clear();
         Client.resetNameTagLayout(this);
      }

      Client.resetNameTagGroups(this);
      Entity self = Client.player();
      if (self != null) {
         this.funtime = this.flag("funtime");
         this.mineblaze = this.flag("mineblaze");
         if (this.mineblaze) {
            Client.refreshNameTagPrefixes(this);
         }

         this.prefix = this.flag("prefix");
         this.slotRefreshCounter++;
         this.refreshSlot = this.slotRefreshCounter == this.slotRefreshCounter / 5 * 5;
         this.hearts = this.flag("hearts");
         if (!this.flag("armor") && !this.flag("offhand")) {
            this.slotsEnabled = this.flag("mainhand");
         } else {
            this.slotsEnabled = true;
         }

         if (!Client.voiceChatEnabled()) {
            this.voiceReady = false;
         } else {
            Client.initVoiceChatIcon();
            this.voiceReady = Client.voiceChatIconReady();
         }

         if (!Client.isPulseEnabled(this)) {
            this.pulseReady = false;
         } else {
            Client.initPulseIcon();
            this.pulseReady = Client.pulseIconReady();
         }

         double[] position = Client.entityPosition(self);
         double distanceSq = this.maxDistance() * this.maxDistance();
         Client.forEachPlayer(
            player -> Client.buildNameTag(
               this,
               player,
               position,
               distanceSq,
               this.voiceReady,
               this.pulseReady,
               this.prefix,
               this.refreshSlot,
               this.funtime,
               this.mineblaze,
               this.hearts,
               this.slotsEnabled
            )
         );
      }
   }

   @Override
   public void onRender() {
      Client.renderNameTags(this);
   }

   private double maxDistance() {
      client.Setting setting = this.setting("max_distance");
      return setting == null ? 64.0 : setting.getNumber();
   }

   private boolean flag(String name) {
      client.Setting setting = this.setting(name);
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

