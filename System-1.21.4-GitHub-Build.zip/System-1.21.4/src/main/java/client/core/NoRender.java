package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class NoRender extends client.Feature {
   public static final String MODULE = "no_render";
   public static final String DISPLAY = "НоРендер";
   public static final String KEY_SCOREBOARD = "scoreboard";
   public static final String KEY_FIRE = "fire";
   public static final String KEY_IN_WALL = "in_wall";
   public static final String KEY_FROST = "frost";
   public static final String KEY_NAUSEA = "nausea";
   public static final String KEY_BLINDNESS = "blindness";
   public static final String KEY_BUBBLES = "bubbles";
   public static final String KEY_BOSS_BAR = "boss_bar";
   public static final String KEY_EFFECTS = "effects";
   public static final String KEY_ATTACK_INDICATOR = "attack_indicator";
   public static final String KEY_EXPLOSION_PARTICLES = "explosion_particles";
   public static final String KEY_BORDER = "border";
   public static final String KEY_WEATHER = "weather";
   public static final String KEY_XP_BOTTLES = "xp_bottles";
   public static final String KEY_SHADOWS = "shadows";
   public static final String KEY_FOG = "fog";
   public static final String KEY_WITHER_HEARTS = "wither_hearts";
   public static final String KEY_BLOCK_PARTICLES = "block_particles";
   public static final String KEY_DARKNESS = "darkness";
   public static final String KEY_BOB = "bob";
   public static final String KEY_HURT_CAM = "hurt_cam";
   public static final String KEY_VIGNETTE = "vignette";
   public static final String KEY_GLOW = "glow";
   public static final String OPTION_BOB_VIEW = "bobView";
   public static final String OPTION_ENTITY_SHADOWS = "entityShadows";
   public static final String OPTION_DAMAGE_TILT = "damageTiltStrength";
   public static final String OPTION_FOG_ENABLED = "fogEnabled";
   public static final String OPTION_VIGNETTE = "vignette";
   public static final String OPTION_ATTACK_INDICATOR = "attackIndicator";
   public static final String EFFECT_DARKNESS = "darkness";
   public static final String EFFECT_BLINDNESS = "blindness";
   public static final String EFFECT_NAUSEA = "nausea";
   public static final String EFFECT_WITHER = "wither";
   public static final double BORDER_SIZE = 6.0E7;
   public static final float WEATHER_LEVEL = 0.0F;
   private static NoRender active;
   private boolean bossBar;
   private boolean bubbles;
   private boolean blockParticles;
   private boolean explosionParticles;
   private boolean glow;
   private boolean effects;
   private boolean frost;
   private boolean inWall;
   private boolean fire;
   private boolean blindness;
   private boolean darkness;
   private boolean nausea;
   private boolean witherHearts;
   private boolean bobApplied;
   private boolean bobSaved;
   private boolean shadowsApplied;
   private boolean shadowsSaved;
   private boolean hurtCamApplied;
   private double hurtCamSaved;
   private boolean fogApplied;
   private boolean fogSaved;
   private boolean vignetteApplied;
   private boolean vignetteSaved;
   private boolean indicatorApplied;
   private int indicatorSaved;
   private String scoreboardTitle = "";
   private String scoreboardTeam = "";

   public NoRender() {
      super("no_render", "НоРендер", Category.Movement);
      this.add(client.Setting.bool("options", true));
      this.add(client.Setting.bool("scoreboard", true));
      this.add(client.Setting.bool("fire", true));
      this.add(client.Setting.bool("in_wall", true));
      this.add(client.Setting.bool("frost", true));
      this.add(client.Setting.bool("nausea", true));
      this.add(client.Setting.bool("blindness", true));
      this.add(client.Setting.bool("bubbles", true));
      this.add(client.Setting.bool("boss_bar", true));
      this.add(client.Setting.bool("effects", true));
      this.add(client.Setting.bool("attack_indicator", true));
      this.add(client.Setting.bool("explosion_particles", true));
      this.add(client.Setting.bool("border", true));
      this.add(client.Setting.bool("weather", true));
      this.add(client.Setting.bool("xp_bottles", true));
      this.add(client.Setting.bool("shadows", true));
      this.add(client.Setting.bool("fog", true));
      this.add(client.Setting.bool("wither_hearts", true));
      this.add(client.Setting.bool("block_particles", true));
      this.add(client.Setting.bool("darkness", true));
      this.add(client.Setting.bool("bob", true));
      this.add(client.Setting.bool("hurt_cam", true));
      this.add(client.Setting.bool("vignette", true));
      this.add(client.Setting.bool("glow", true));
   }

   public static NoRender active() {
      return active;
   }

   public boolean suppresses(String key) {
      if ("boss_bar".equals(key)) {
         return this.bossBar;
      } else if ("bubbles".equals(key)) {
         return this.bubbles;
      } else if ("block_particles".equals(key)) {
         return this.blockParticles;
      } else if ("explosion_particles".equals(key)) {
         return this.explosionParticles;
      } else if ("glow".equals(key)) {
         return this.glow;
      } else if ("effects".equals(key)) {
         return this.effects;
      } else if ("frost".equals(key)) {
         return this.frost;
      } else if ("in_wall".equals(key)) {
         return this.inWall;
      } else if ("fire".equals(key)) {
         return this.fire;
      } else if ("blindness".equals(key)) {
         return this.blindness;
      } else if ("darkness".equals(key)) {
         return this.darkness;
      } else if ("nausea".equals(key)) {
         return this.nausea;
      } else {
         return "wither_hearts".equals(key) ? this.witherHearts : false;
      }
   }

   public String scoreboardTitle() {
      return this.scoreboardTitle;
   }

   public String scoreboardTeam() {
      return this.scoreboardTeam;
   }

   @Override
   public void onEnable() {
      this.indicatorApplied = false;
      this.vignetteApplied = false;
      this.hurtCamApplied = false;
      this.fogApplied = false;
      this.shadowsApplied = false;
      this.bobApplied = false;
      this.scoreboardTitle = "";
      this.scoreboardTeam = "";
      this.refreshOptionFlags();
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
      if (this.bobApplied) {
         Client.setGameOptionBoolean("bobView", this.bobSaved);
      }

      if (this.shadowsApplied) {
         Client.setGameOptionBoolean("entityShadows", this.shadowsSaved);
      }

      if (this.fogApplied) {
         Client.setGameOptionBoolean("fogEnabled", this.fogSaved);
      }

      if (this.hurtCamApplied) {
         Client.setGameOptionDouble("damageTiltStrength", this.hurtCamSaved);
      }

      if (this.vignetteApplied) {
         Client.setGameOptionBoolean("vignette", this.vignetteSaved);
      }

      if (this.indicatorApplied) {
         Client.setGameOptionInt("attackIndicator", this.indicatorSaved);
      }

      this.indicatorApplied = false;
      this.vignetteApplied = false;
      this.hurtCamApplied = false;
      this.fogApplied = false;
      this.shadowsApplied = false;
      this.bobApplied = false;
      Client.clearScoreboardCache();
      this.scoreboardTitle = "";
      this.scoreboardTeam = "";
      this.bossBar = false;
      this.bubbles = false;
      this.blockParticles = false;
      this.explosionParticles = false;
      this.glow = false;
      this.effects = false;
      this.frost = false;
      this.inWall = false;
      this.fire = false;
      this.blindness = false;
      this.darkness = false;
      this.nausea = false;
      this.witherHearts = false;
   }

   @Override
   public void onTick() {
      this.refreshOptionFlags();
      this.applyBob();
      this.applyShadows();
      this.applyHurtCam();
      this.applyFog();
      this.applyVignette();
      this.applyAttackIndicator();
      if (Client.inGame()) {
         this.applyEffectSuppression();
         this.applyWeather();
         this.applyBorder();
         this.applyScoreboard();
         if (this.option("xp_bottles")) {
            Client.forEachEntity(this::hideXpOrb);
         }
      }
   }

   public void refreshOptionFlags() {
      this.bossBar = this.option("boss_bar");
      this.bubbles = this.option("bubbles");
      this.blockParticles = this.option("block_particles");
      this.explosionParticles = this.option("explosion_particles");
      this.glow = this.option("glow");
      this.effects = this.option("effects");
      this.frost = this.option("frost");
      this.inWall = this.option("in_wall");
      this.fire = this.option("fire");
      this.blindness = this.option("blindness");
      this.darkness = this.option("darkness");
      this.nausea = this.option("nausea");
      this.witherHearts = this.option("wither_hearts");
   }

   private void applyBob() {
      if (!this.option("bob")) {
         if (this.bobApplied) {
            Client.setGameOptionBoolean("bobView", this.bobSaved);
            this.bobApplied = false;
         }
      } else {
         if (!this.bobApplied) {
            this.bobSaved = Client.gameOptionBoolean("bobView");
            this.bobApplied = true;
         }

         if (Client.gameOptionBoolean("bobView")) {
            Client.setGameOptionBoolean("bobView", false);
         }
      }
   }

   private void applyShadows() {
      if (!this.option("shadows")) {
         if (this.shadowsApplied) {
            Client.setGameOptionBoolean("entityShadows", this.shadowsSaved);
            this.shadowsApplied = false;
         }
      } else {
         if (!this.shadowsApplied) {
            this.shadowsSaved = Client.gameOptionBoolean("entityShadows");
            this.shadowsApplied = true;
         }

         if (Client.gameOptionBoolean("entityShadows")) {
            Client.setGameOptionBoolean("entityShadows", false);
         }
      }
   }

   private void applyHurtCam() {
      if (!this.option("hurt_cam")) {
         if (this.hurtCamApplied) {
            Client.setGameOptionDouble("damageTiltStrength", this.hurtCamSaved);
            this.hurtCamApplied = false;
         }
      } else {
         if (!this.hurtCamApplied) {
            this.hurtCamSaved = Client.gameOptionDouble("damageTiltStrength");
            this.hurtCamApplied = true;
         }

         if (Client.gameOptionDouble("damageTiltStrength") != 0.0) {
            Client.setGameOptionDouble("damageTiltStrength", 0.0);
         }
      }
   }

   private void applyFog() {
      if (!this.option("fog")) {
         if (this.fogApplied) {
            Client.setGameOptionBoolean("fogEnabled", this.fogSaved);
            this.fogApplied = false;
         }
      } else {
         if (!this.fogApplied) {
            this.fogSaved = Client.gameOptionBoolean("fogEnabled");
            this.fogApplied = true;
         }

         if (Client.gameOptionBoolean("fogEnabled")) {
            Client.setGameOptionBoolean("fogEnabled", false);
         }
      }
   }

   private void applyVignette() {
      if (!this.option("vignette")) {
         if (this.vignetteApplied) {
            Client.setGameOptionBoolean("vignette", this.vignetteSaved);
            this.vignetteApplied = false;
         }
      } else {
         if (!this.vignetteApplied) {
            this.vignetteSaved = Client.gameOptionBoolean("vignette");
            this.vignetteApplied = true;
         }

         if (Client.gameOptionBoolean("vignette")) {
            Client.setGameOptionBoolean("vignette", false);
         }
      }
   }

   private void applyAttackIndicator() {
      if (!this.option("attack_indicator")) {
         if (this.indicatorApplied) {
            Client.setGameOptionInt("attackIndicator", this.indicatorSaved);
            this.indicatorApplied = false;
         }
      } else {
         if (!this.indicatorApplied) {
            this.indicatorSaved = Client.gameOptionInt("attackIndicator");
            this.indicatorApplied = true;
         }

         if (Client.gameOptionInt("attackIndicator") != 0) {
            Client.setGameOptionInt("attackIndicator", 0);
         }
      }
   }

   private void applyEffectSuppression() {
      Entity self = Client.localPlayer();
      if (this.fire && self != null) {
         Client.setRemainingFireTicks(self, 0);
         Client.setEntityFlag(self, 0, false);
      }

      if (this.darkness) {
         Client.removeStatusEffect(self, "darkness");
      }

      if (this.blindness) {
         Client.removeStatusEffect(self, "blindness");
      }

      if (this.nausea) {
         Client.removeStatusEffect(self, "nausea");
      }

      if (this.witherHearts) {
         Client.removeStatusEffect(self, "wither");
      }
   }

   private void applyWeather() {
      if (this.option("weather")) {
         Client.setRainLevel(0.0F);
         Client.setThunderLevel(0.0F);
      }
   }

   private void applyBorder() {
      if (this.option("border")) {
         Client.setWorldBorderSize(6.0E7);
      }
   }

   private void applyScoreboard() {
      if (this.option("scoreboard")) {
         String title = Client.scoreboardSidebarTitle();
         String team = Client.scoreboardTeamTitle();
         if (!title.isEmpty()) {
            this.scoreboardTitle = title;
         }

         if (!team.isEmpty()) {
            this.scoreboardTeam = team;
         }
      } else {
         if (!this.scoreboardTitle.isEmpty() || !this.scoreboardTeam.isEmpty()) {
            Client.clearScoreboardCache();
            this.scoreboardTitle = "";
            this.scoreboardTeam = "";
         }
      }
   }

   private void hideXpOrb(Entity entity) {
      if (Client.isExperienceOrb(entity)) {
         Client.removeEntityLocal(entity);
      }
   }

   private boolean option(String key) {
      client.Setting setting = this.setting(key);
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

