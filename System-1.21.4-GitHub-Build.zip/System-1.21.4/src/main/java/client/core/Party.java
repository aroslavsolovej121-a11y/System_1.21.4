package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class Party extends client.Feature {
   public static final String MODULE = "party";
   public static final String DISPLAY = "Партй";
   public static final String PARTY_NONE = "PARTY_NONE";
   public static final String NOTIFY_TAG = "Пати";
   public static final int NOTIFY_STYLE = 34;
   private static final long MARK_DEBOUNCE_NANOS = 250000000L;
   private static final int TICK_PARITY_LIMIT = 1;
   private static final int PARTY_SERVER_THRESHOLD = 2;
   private static final double TIME_SCALE = 1.0E-9;
   private static final double MARK_COORD_X_OFFSET = 0.5;
   private static final double MARK_COORD_Y_OFFSET = 1.0;
   private static final double MARK_COORD_Z_OFFSET = 0.5;
   private static final double POP_DURATION = 0.35;
   private static final double POP_BACK_C3 = 2.70158;
   private static final double POP_BACK_C1 = 1.70158;
   private static final float POP_UNIT = 1.0F;
   private static final double PROGRESS_FADE_START = 0.75;
   private static final double PROGRESS_FADE_SCALE = 4.0;
   private static final double ALPHA_BASE = 0.7;
   private static final double ALPHA_FADE = 0.3;
   private static final double ALPHA_THRESHOLD = 0.01;
   private static final double DISTANCE_SCALE = 0.013;
   private static final double DISTANCE_MIN = 0.28;
   private static final double BEAM_RADIUS_FACTOR = 1.55;
   private static final double WAVE_ARG_SCALE = 2.4;
   private static final double LABEL_LIFT_SCALE = 1.6;
   private static final double WAVE_AMPLITUDE = 0.12;
   private static final double BEAM_VERTICAL_OFFSET = 1.25;
   private static final double LABEL_FONT_SIZE = 2.0;
   private static final int LABEL_WORD_A = -1;
   private static final int LABEL_WORD_B = 1;
   private static final int LABEL_COLOR_HIGH = -16777216;
   private static final int LABEL_TINT = 1291845631;
   private static final int LABEL_MODE = 1;
   private static final float LABEL_SCALE = 20.0F;
   private static final float LABEL_ALPHA = 1.0F;
   private static final float LABEL_ALPHA_ALT = 1.0F;
   private static final double TRACK_NANOS = 1.0E-9;
   private static final double TRACK_MAX_DELTA = 0.3;
   private static final double TRACK_DECAY = 0.1;
   private static final double TRACK_VELOCITY_MAX_SQ = 4096.0;
   private static final double TRACK_POSITION_EPSILON = 16.0;
   private static final double TRACK_MIN_DELTA = 0.0;
   private static final double MEMBER_VELOCITY_SCALE = 10.0;
   private static final double LOOK_PROBE_STEP = 0.01;
   private static final double LOOK_REACH = 160.0;
   private static final double DEG_TO_RAD = 0.01745329252;
   private static final double PI = 3.141592654;
   private static final float MAX_ALPHA = 255.0F;
   private static final float MIN_ALPHA = 0.0F;
   private static final int TTL_DEFAULT = 5;
   private static final double TTL_MIN = 1.0;
   private static final double TTL_MAX = 10.0;
   private static final int SIZE_DEFAULT = 1;
   private static final double SIZE_MIN = 0.5;
   private static final double SIZE_MAX = 3.0;
   private static final int COLOR_DEFAULT = -50384;
   private static final int MARK_KEY_DEFAULT = 0;
   private static final int MARK_KEY_MODS_DEFAULT = 0;
   private static boolean connected;
   private static String partyId = "";
   private static final List<Party.Member> globalMembers = new ArrayList<>();
   private static final List<Party.Invite> invites = new ArrayList<>();
   private static final List<Party.Mark> marks = new ArrayList<>();
   private static final List<Party.TrackedPlayer> markedPlayers = new ArrayList<>();
   private static int generation;
   private static long sequence;
   private static boolean active;
   private static boolean pullSubmitted;
   private static boolean pullPending;
   private final client.Setting markKeySetting;
   private final client.Setting ttlSetting;
   private final client.Setting colorSetting;
   private final client.Setting sizeSetting;
   private final boolean[] markKeyState = new boolean[1];
   private int markKeyMods = 0;
   private long lastMarkNanos;
   private Object worldHandle;
   private long lastPartySequence;
   private final List<Party.Member> members = new ArrayList<>();
   private int tickParity;
   private String ownName = "";
   private final List<Party.Label> labels = new ArrayList<>();
   private final List<Party.Beam> beams = new ArrayList<>();

   public Party() {
      super("party", "Партй", Category.Client);
      this.markKeySetting = this.add(client.Setting.key("mark_key", 0));
      this.ttlSetting = this.add(client.Setting.number("ttl", 5.0, 1.0, 10.0));
      this.colorSetting = this.add(client.Setting.color("color", -50384));
      this.sizeSetting = this.add(client.Setting.number("size", 1.0, 0.5, 3.0));
   }

   @Override
   public boolean isVisible() {
      return !marks.isEmpty();
   }

   @Override
   public void onEnable() {
      boolean alreadySubmitted = pullSubmitted;
      active = true;
      pullSubmitted = true;
      if (alreadySubmitted) {
         pullPending = true;
      } else {
         Client.submit(Party::pull);
      }
   }

   @Override
   public void onDisable() {
      if (connected) {
         Client.submit(Party::leave);
      }

      active = false;
      connected = false;
      partyId = "";
      globalMembers.clear();
      invites.clear();
      marks.clear();
      markedPlayers.clear();
      generation++;
      this.lastPartySequence = sequence;
      this.members.clear();
   }

   @Override
   public void onTick() {
      Entity localPlayer = Client.player();
      if (localPlayer != null) {
         Object world = Client.worldOf(localPlayer);
         if (world != null) {
            boolean same = this.worldHandle != null && Client.isSameObject(this.worldHandle, world);
            if (!same) {
               this.worldHandle = world;
               marks.clear();
               markedPlayers.clear();
               this.members.clear();
            }
         }
      }

      if (!marks.isEmpty()) {
         Entity resolved = Client.player();
         Entity handle = resolved == null ? null : Client.resolvePlayer(resolved);
         if (handle == null) {
            this.ownName = "";
         } else {
            String name = Client.playerName(handle);
            this.ownName = name == null ? "" : name;
         }
      }

      this.syncMembers();
      if (!this.members.isEmpty()) {
         this.tickParity++;
         if (this.tickParity > 1) {
            this.tickParity = 0;
            this.refresh();
         }
      }

      if (sequence != this.lastPartySequence) {
         this.lastPartySequence = sequence;
         if (!invites.isEmpty()) {
            Party.Invite invite = invites.get(invites.size() - 1);
            Client.partyNotify(invite.inviter, 34);
         }
      }
   }

   @Override
   public void onKey(int key, boolean pressed) {
      int markKey = this.markKeySetting == null ? 0 : this.markKeySetting.getKey();
      if (markKey != 0) {
         if (Client.keybindPressed(markKey, this.markKeyMods, this.markKeyState)) {
            if (Client.inGame()) {
               if (!Client.screenOpen()) {
                  this.placeMark();
               }
            }
         }
      }
   }

   @Override
   public void onRender() {
      long now = Client.nanos();
      expireState(now);
      int fallbackColor = this.markColor();
      this.labels.clear();
      this.beams.clear();

      for (int i = 0; i < marks.size(); i++) {
         Party.Mark mark = marks.get(i);
         int resolvedColor = mark.color != 0 ? mark.color : fallbackColor;
         if (mark.name.isEmpty()) {
            double[] position = new double[]{mark.x + 0.5, mark.y + 1.0, mark.z + 0.5};
            this.appendBeam(mark, now, position, mark.label, resolvedColor);
         } else if (!this.hasNewerDuplicate(i) && !mark.name.equals(this.ownName)) {
            double[] position = new double[3];
            if (this.resolveTracked(mark.name, now, fallbackColor, position)) {
               this.appendBeam(mark, now, position, mark.name, resolvedColor);
               float progress = markProgress(mark, now);
               float alpha = progress * (resolvedColor >>> 24);
               float clamped = alpha < 0.0F ? 0.0F : Math.min(alpha, 255.0F);
               int faded = resolvedColor & 16777215 | (int)clamped << 24;
               if (((int)clamped & 0xFF) != 0) {
                  Party.Label label = new Party.Label();
                  label.fontSize = 2.0;
                  label.wordA = -1;
                  label.wordB = 1;
                  label.colorLow = faded >>> 8 << 8;
                  label.colorMid = -16777216;
                  label.flag = 0;
                  label.tint = 1291845631;
                  label.mode = faded & -256 | 1;
                  label.scale = 20.0F;
                  label.alpha = 1.0F;
                  label.alphaAlt = 1.0F;
                  this.labels.add(label);
               }
            }
         }
      }

      if (!this.labels.isEmpty()) {
         Party.Label trailing = new Party.Label();
         trailing.fontSize = 2.0;
         trailing.wordA = -1;
         trailing.wordB = 1;
         trailing.colorLow = fallbackColor >>> 8 << 8;
         trailing.colorMid = -16777216;
         trailing.flag = 0;
         trailing.tint = 1291845631;
         trailing.mode = fallbackColor & -256 | 1;
         trailing.scale = 20.0F;
         trailing.alpha = 1.0F;
         trailing.alphaAlt = 1.0F;
         this.labels.add(trailing);
      }

      this.renderBeams();
   }

   private void placeMark() {
      long now = Client.nanos();
      if (now - this.lastMarkNanos >= 250000000L) {
         this.lastMarkNanos = now;
         if (!connected) {
            Client.partyNotify("PARTY_NONE", 34);
         } else {
            Entity self = Client.player();
            if (self != null) {
               Entity handle = Client.resolvePlayer(self);
               if (handle != null) {
                  double[] position = Client.entityInterpolatedPosition(handle);
                  double px;
                  double py;
                  double pz;
                  if (position == null) {
                     px = 0.0;
                     py = 0.0;
                     pz = 0.0;
                  } else {
                     px = position[0];
                     py = position[1];
                     pz = position[2];
                  }

                  float yaw = Client.entityHeadYaw(handle);
                  float pitch = Client.entityHeadPitch(handle);
                  double cosPitch = -Math.cos(-pitch * 0.01745329252);
                  double dirX = Math.sin(-yaw * 0.01745329252 - 3.141592654) * cosPitch;
                  double dirY = Math.sin(-pitch * 0.01745329252);
                  double dirZ = Math.cos(-yaw * 0.01745329252 - 3.141592654) * cosPitch;
                  double[] lookOrigin = new double[]{dirX * 160.0 + px, dirY * 160.0 + py, dirZ * 160.0 + pz};
                  double[] hit = Client.partyLookRaycast(handle);
                  Object[] target = Client.partyPickLookTarget(lookOrigin, new double[]{dirX, dirY, dirZ});
                  String targetName = target == null ? null : (String)target[0];
                  int markX;
                  int markY;
                  int markZ;
                  if (targetName != null && !targetName.isEmpty()) {
                     markX = (int)Math.floor((Double)target[1]);
                     markY = (int)Math.floor((Double)target[2]);
                     markZ = (int)Math.floor((Double)target[3]);
                  } else {
                     if (hit == null) {
                        return;
                     }

                     markX = (int)Math.floor(hit[0] - hit[3] * 0.01);
                     markY = (int)Math.floor(hit[1] - hit[4] * 0.01);
                     markZ = (int)Math.floor(hit[2] - hit[5] * 0.01);
                     targetName = "";
                  }

                  this.sendMark(markX, markY, markZ, targetName);
               }
            }
         }
      }
   }

   private void sendMark(int x, int y, int z, String name) {
      Object world = Client.localWorldRef();
      if (Client.partyServerCount() < 2) {
         String dimension = Client.currentDimensionKey();
         String address = Client.currentServerAddress();
         Client.partySendMark(x, y, z, name, world, dimension, address, this.markColor(), 34);
      } else {
         Client.partySendMarkSimple(x, y, z);
      }
   }

   private void refresh() {
      long now = Client.nanos();
      int serverCount = Client.partyServerCount();
      String address = "";
      String dimension = "";
      Object world = null;
      if (serverCount > 2) {
         address = Client.currentServerAddress();
         dimension = Client.currentDimensionKey();
         world = Client.localWorldRef();
      }

      for (Party.Member member : this.members) {
         Entity entity = member.entity;
         if (entity != null && !Client.isRemoved(entity)) {
            double[] position = Client.entityPosition(entity);
            if (position != null) {
               double vx = 0.0;
               double vy = 0.0;
               double vz = 0.0;
               if (member.hadPosition) {
                  vx = (position[0] - member.x) * 10.0;
                  vy = (position[1] - member.y) * 10.0;
                  vz = (position[2] - member.z) * 10.0;
               }

               member.x = position[0];
               member.y = position[1];
               member.z = position[2];
               member.hadPosition = true;
               float yaw = Client.entityBodyYaw(entity);
               member.yaw = yaw;
               Party.TrackedPlayer tracked = findTracked(member.name);
               if (tracked != null) {
                  updateTracked(tracked, position, new double[]{vx, vy, vz}, now);
                  if (member.world > 0.0) {
                     tracked.world = member.world;
                  }

                  if (yaw > 0.0F) {
                     tracked.yaw = yaw;
                  }

                  tracked.alive = true;
               }

               if (serverCount > 2) {
                  Client.partyPushStatus(dimension, address, world, member.name, position[0], position[1], position[2], yaw, member.world);
               }
            }
         }
      }
   }

   private void pruneMembers() {
      int index;
      for (index = 0; index < this.members.size(); index++) {
         Party.Member member = this.members.get(index);
         if (member.name.isEmpty() || !hasMarkFor(member.name) || member.entity == null || !Client.isRemoved(member.entity)) {
            break;
         }
      }

      int write = index;

      for (int read = index + 1; read < this.members.size(); read++) {
         Party.Member member = this.members.get(read);
         if (!member.name.isEmpty() && hasMarkFor(member.name) && (member.entity == null || !Client.isRemoved(member.entity))) {
            this.members.set(write, member);
            write++;
         }
      }

      while (this.members.size() > write) {
         this.members.remove(this.members.size() - 1);
      }
   }

   private void syncMembers() {
      this.pruneMembers();

      for (Party.Mark mark : marks) {
         if (!mark.name.isEmpty() && !this.hasMember(mark.name)) {
            Client.partyTrackMarkedPlayers(mark.name);
            return;
         }
      }
   }

   private void appendBeam(Party.Mark mark, long now, double[] position, String label, int color) {
      double age = (now - mark.start) * 1.0E-9;
      float fade = markProgress(mark, now);
      double progress = age / 0.35;
      double clamped = progress < 0.0 ? 0.0 : Math.min(progress, 1.0);
      double t = clamped - 1.0;
      double pop = (t * 2.70158 * t * t + 1.0 + t * 1.70158 * t) * (fade * 0.3 + 0.7);
      if (!(pop <= 0.01)) {
         double[] view = Client.partyViewPosition();
         double dx = position[0] - view[0];
         double dy = position[1] - view[1];
         double dz = position[2] - view[2];
         double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
         double distanceFactor = distance * 0.013;
         if (distanceFactor <= 0.28) {
            distanceFactor = 0.28;
         }

         double strength = distanceFactor * this.num("size") * pop;
         double size = strength * 1.55;
         double sway = Math.sin(age * 2.4);
         double lift = age * 1.6;
         Party.Beam beam = new Party.Beam();
         beam.x = position[0];
         beam.y = sway * size * 0.12 + size * 1.25 + position[1];
         beam.z = position[2];
         beam.strength = strength;
         beam.size = size;
         beam.lift = lift;
         beam.fade = fade;
         beam.label = label;
         beam.color = color;
         this.beams.add(beam);
      }
   }

   private void renderBeams() {
      if (!this.beams.isEmpty()) {
         Client.partyDrawBeamBatch(this.beams, this.labels, this.markColor());
      }
   }

   private boolean resolveTracked(String name, long now, int color, double[] out) {
      for (Party.Member member : this.members) {
         if (member.name.equals(name)) {
            if (member.entity != null && !Client.isRemoved(member.entity)) {
               double[] eye = Client.eyePosition();
               if (eye != null) {
                  out[0] = eye[0];
                  out[1] = eye[1];
                  out[2] = eye[2];
                  return true;
               }
            }
            break;
         }
      }

      Party.TrackedPlayer tracked = findTracked(name);
      if (tracked == null) {
         return false;
      } else {
         double delta = (now - (long)tracked.tick) * 1.0E-9;
         if (delta < 0.0) {
            delta = 0.0;
         }

         double lerp = delta > 0.3 ? 0.3 : delta;
         double decay = Math.exp(delta / 0.1);
         out[0] = lerp * tracked.vx + tracked.lastX + decay * tracked.ox;
         out[1] = lerp * tracked.vy + tracked.lastY + decay * tracked.oy;
         out[2] = lerp * tracked.vz + tracked.lastZ + decay * tracked.oz;
         return true;
      }
   }

   private static void updateTracked(Party.TrackedPlayer tracked, double[] position, double[] motion, long now) {
      double predX;
      double predY;
      double predZ;
      if (!tracked.init) {
         predX = position[0];
         predY = position[1];
         predZ = position[2];
      } else {
         double delta = (now - (long)tracked.tick) * 1.0E-9;
         if (delta < 0.0) {
            delta = 0.0;
         }

         double lerp = delta > 0.3 ? 0.3 : delta;
         double decay = Math.exp(delta / 0.1);
         predX = lerp * tracked.vx + tracked.lastX + decay * tracked.ox;
         predY = lerp * tracked.vy + tracked.lastY + decay * tracked.oy;
         predZ = lerp * tracked.vz + tracked.lastZ + decay * tracked.oz;
      }

      double errX = predX - position[0];
      double errY = predY - position[1];
      double errZ = predZ - position[2];
      if (errX * errX + errY * errY + errZ * errZ > 16.0) {
         errX = 0.0;
         errY = 0.0;
         errZ = 0.0;
      }

      tracked.ox = errX;
      tracked.oy = errY;
      tracked.oz = errZ;
      tracked.lastX = position[0];
      tracked.lastY = position[1];
      tracked.lastZ = position[2];
      double mvx;
      double mvy;
      double mvz;
      if (motion != null && !(motion[0] * motion[0] + motion[1] * motion[1] + motion[2] * motion[2] > 4096.0)) {
         mvx = motion[0];
         mvy = motion[1];
         mvz = motion[2];
      } else {
         mvx = 0.0;
         mvy = 0.0;
         mvz = 0.0;
      }

      tracked.tick = now;
      tracked.vx = mvx;
      tracked.vy = mvy;
      tracked.vz = mvz;
      tracked.init = true;
   }

   private static float markProgress(Party.Mark mark, long now) {
      double duration = mark.end - mark.start;
      double progress = 1.0;
      if (duration > 0.0) {
         double raw = (now - mark.start) / duration;
         double clamped;
         if (raw < 0.0) {
            clamped = 0.0;
         } else if (raw > 1.0) {
            clamped = 1.0;
         } else {
            clamped = raw;
         }

         progress = clamped;
         if (clamped <= 0.75) {
            return 1.0F;
         }
      }

      return (float)((1.0 - progress) * 4.0);
   }

   private static void expireState(long now) {
      int write = 0;

      for (int read = 0; read < marks.size(); read++) {
         Party.Mark mark = marks.get(read);
         if (mark.end > now) {
            marks.set(write, mark);
            write++;
         }
      }

      while (marks.size() > write) {
         marks.remove(marks.size() - 1);
      }

      int trackedWrite = 0;

      for (int readx = 0; readx < markedPlayers.size(); readx++) {
         Party.TrackedPlayer tracked = markedPlayers.get(readx);
         if (!tracked.name.isEmpty() && hasMarkFor(tracked.name)) {
            markedPlayers.set(trackedWrite, tracked);
            trackedWrite++;
         }
      }

      while (markedPlayers.size() > trackedWrite) {
         markedPlayers.remove(markedPlayers.size() - 1);
      }
   }

   private boolean hasNewerDuplicate(int index) {
      Party.Mark mark = marks.get(index);

      for (int i = 0; i < marks.size(); i++) {
         if (i != index) {
            Party.Mark other = marks.get(i);
            if (other.name.equals(mark.name) && (mark.end < other.end || other.end == mark.end && index < i)) {
               return true;
            }
         }
      }

      return false;
   }

   private static boolean hasMarkFor(String name) {
      for (Party.Mark mark : marks) {
         if (mark.name.equals(name)) {
            return true;
         }
      }

      return false;
   }

   private boolean hasMember(String name) {
      for (Party.Member member : this.members) {
         if (member.name.equals(name)) {
            return true;
         }
      }

      return false;
   }

   private static Party.TrackedPlayer findTracked(String name) {
      for (Party.TrackedPlayer tracked : markedPlayers) {
         if (tracked.name.equals(name)) {
            return tracked;
         }
      }

      return null;
   }

   private int markColor() {
      return this.colorSetting == null ? -50384 : this.colorSetting.getColor();
   }

   private double num(String name) {
      client.Setting setting = this.setting(name);
      return setting == null ? 0.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }

   private static void pull() {
      connected = true;
   }

   private static void leave() {
      connected = false;
   }

   public static String partyId() {
      return partyId;
   }

   public static boolean isConnected() {
      return connected;
   }

   public static boolean isActive() {
      return active;
   }

   public static boolean isPullPending() {
      return pullPending;
   }

   public static int generation() {
      return generation;
   }

   public static long sequence() {
      return sequence;
   }

   public static int markCount() {
      return marks.size();
   }

   public static void setPartyState(String id, boolean value) {
      partyId = id == null ? "" : id;
      connected = value;
   }

   public static void requestPull() {
      pullPending = true;
   }

   public static void addMark(int x, int y, int z, String label, String tag, String name, int color, long start, long end) {
      Party.Mark mark = new Party.Mark();
      mark.x = x;
      mark.y = y;
      mark.z = z;
      mark.label = label == null ? "" : label;
      mark.tag = tag == null ? "" : tag;
      mark.name = name == null ? "" : name;
      mark.color = color;
      mark.start = start;
      mark.end = end;
      marks.add(mark);
      sequence++;
   }

   public static void addInvite(String from, String inviter) {
      Party.Invite invite = new Party.Invite();
      invite.from = from == null ? "" : from;
      invite.inviter = inviter == null ? "" : inviter;
      invites.add(invite);
      sequence++;
   }

   public static final class Beam {
      public double x;
      public double y;
      public double z;
      public double strength;
      public double size;
      public double lift;
      public float fade;
      public String label = "";
      public int color;
   }

   public static final class Invite {
      public String from = "";
      public String inviter = "";
   }

   public static final class Label {
      public double fontSize;
      public int wordA;
      public int wordB;
      public int colorLow;
      public int colorMid;
      public int flag;
      public int tint;
      public int mode;
      public float scale;
      public float alpha;
      public float alphaAlt;
   }

   public static final class Mark {
      public int x;
      public int y;
      public int z;
      public String label = "";
      public String tag = "";
      public long start;
      public long end;
      public String name = "";
      public int color;
   }

   public static final class Member {
      public String name = "";
      public String tag = "";
      public Entity entity;
      public double world;
      public double x;
      public double y;
      public double z;
      public double yaw;
      public boolean hadPosition;
   }

   public static final class TrackedPlayer {
      public String name = "";
      public double lastX;
      public double lastY;
      public double lastZ;
      public double vx;
      public double vy;
      public double vz;
      public double ox;
      public double oy;
      public double oz;
      public double tick;
      public boolean init;
      public double world;
      public double yaw;
      public boolean alive;
   }
}

