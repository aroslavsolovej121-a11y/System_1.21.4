package client.core;

import client.Category;
import client.mc.Client;

public final class GhostHand extends client.Feature {
   public static final String MODULE = "ghosthand";
   public static final String DISPLAY = "ГхозтХанд";
   public static final int OFFSET_TARGET_HANDLE = 672;
   public static final int OFFSET_ATTACK_THROUGH_WALLS = 984;
   public static final int OFFSET_ONLY_CONTAINERS = 1224;
   private Object targetHandle;

   public GhostHand() {
      super("ghosthand", "ГхозтХанд", Category.Player);
      this.add(client.Setting.number("range", 3.0, 1.0, 6.0));
      this.add(client.Setting.bool("only_containers", false));
      this.add(client.Setting.bool("attack_through_walls", false));
      this.add(client.Setting.bool("attack_players", true));
      this.add(client.Setting.bool("attack_mobs", false));
      this.add(client.Setting.number("attack_range", 3.0, 1.0, 6.0));
   }

   @Override
   public void onDisable() {
      this.targetHandle = null;
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (this.onlyContainers() && Client.isScreenOpen()) {
            Object target = this.findTarget();
            if (target != null) {
               Client.attackTarget(target);
               return;
            }
         }

         Client.interactTarget(this.targetHandle, this.attackThroughWalls());
      }
   }

   private Object findTarget() {
      return Client.raycastEntity();
   }

   private boolean onlyContainers() {
      client.Setting setting = this.setting("only_containers");
      return setting != null && setting.getBoolean();
   }

   private boolean attackThroughWalls() {
      client.Setting setting = this.setting("attack_through_walls");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

