package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class LagRange extends client.Feature {
   public static final String MODULE = "lag_range";
   public static final String DISPLAY = "ЛагРанге";
   public static final double DELAY_VALUE = 200.0;
   public static final double DELAY_MIN = 50.0;
   public static final double DELAY_MAX = 400.0;
   public static final double DELAY_STEP = 10.0;
   public static final double RANGE_VALUE = 10.0;
   public static final double RANGE_MIN = 1.0;
   public static final double RANGE_MAX = 30.0;
   public static final double RANGE_STEP = 0.5;
   private static final long CHECK_INTERVAL_NANOS = 25000000L;
   private static final double NANOS_TO_MILLIS = 1.0E-6;
   private static final double HOLD_SCALE = 2.0;
   private long lastCheckNanos;
   private long outsideSinceNanos;
   private double holdMillis;

   public LagRange() {
      super("lag_range", "ЛагРанге", Category.Movement);
      this.add(client.Setting.number("delay", 200.0, 50.0, 400.0, 10.0));
      this.add(client.Setting.number("range", 10.0, 1.0, 30.0, 0.5));
      this.outsideSinceNanos = 0L;
      this.holdMillis = 0.0;
   }

   @Override
   public void onEnable() {
      Client.setLagStartNanos(0L);
      this.outsideSinceNanos = 0L;
   }

   @Override
   public void onDisable() {
      this.releaseLag();
   }

   public void resetWhenNoPlayer() {
      if (Client.player() == null) {
         this.releaseLag();
      }
   }

   public void releaseLag() {
      Client.setLagPending(false);
      Client.releaseLag();
      Client.setLagStartNanos(0L);
   }

   @Override
   public void onTick() {
      long now = Client.nanos();
      if (now - this.lastCheckNanos > 25000000L) {
         this.lastCheckNanos = now;
         double maxDelay = 0.0;
         boolean any = false;

         for (Object candidate : Client.lagFeatures()) {
            if (candidate instanceof client.Feature module
               && module.isEnabled()
               && !Client.lagSuspended()
               && Client.lagQueueDepth() > 0
               && Client.lagArmed()
               && Client.lagWindowElapsed()
               && this.playerWithin(module)) {
               double delay = Client.settingNumber(module, "delay");
               any = true;
               if (delay > maxDelay) {
                  maxDelay = delay;
               }
            }
         }

         if (!any) {
            this.releaseLag();
         } else if (!Client.lagPending()) {
            Client.beginLag(Client.tickCount());
            if (Client.lagPendingTicks() != -1 && Client.lagHasTicks()) {
               Client.setLagPending(true);
            }

            Client.setLagStartNanos(now);
            this.holdMillis = Math.min(Client.lagHoldMillis(maxDelay * 2.0), Client.lagHoldCap());
         } else if (!((now - Client.lagStartNanos()) * 1.0E-6 < this.holdMillis)) {
            this.releaseLag();
         }
      }
   }

   public boolean playerWithin(client.Feature module) {
      double range = Client.settingNumber(module, "range");
      Entity self = Client.player();
      if (self != null) {
         double[] origin = Client.entityPosition(self);
         boolean[] found = new boolean[]{false};
         Client.forEachPlayer(other -> {
            if (other != null && other != self) {
               double[] position = Client.entityPosition(other);
               double dx = origin[0] - position[0];
               double dz = origin[2] - position[2];
               if (dx * dx + dz * dz <= range * range) {
                  found[0] = true;
               }
            }
         });
         if (found[0]) {
            this.outsideSinceNanos = 0L;
            return true;
         }
      }

      long now = Client.nanos();
      if (this.outsideSinceNanos == 0L) {
         this.outsideSinceNanos = now;
      }

      return (now - this.outsideSinceNanos) * 1.0E-6 < Client.lagGraceMillis();
   }

   public void resetLag() {
      Client.setLagPending(false);
      Client.releaseLag();
      Client.setLagStartNanos(0L);
   }
}

