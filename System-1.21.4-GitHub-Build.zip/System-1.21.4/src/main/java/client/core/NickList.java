package client.core;

public class NickList {
}
