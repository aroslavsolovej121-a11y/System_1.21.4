package client.core;

import client.gui.Component;

public class ItemWheel extends Component {
}
