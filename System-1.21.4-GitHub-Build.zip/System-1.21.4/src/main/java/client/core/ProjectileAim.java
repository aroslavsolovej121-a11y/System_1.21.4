package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class ProjectileAim extends client.Feature {
   public static final String MODULE = "projectileaim";
   public static final String DISPLAY = "ПрожестилеАим";
   private static final double HALF_TURN = Math.PI;
   private static final double LEAD_HALF = 0.5;
   private static final double ONE = 1.0;
   private static final double MIN_FACTOR = 0.01;
   private static final double ROT_EPSILON = 0.02;
   private static final double ROT_MIN = 0.001;
   private static final double STEP_MIN = 0.05;
   private static final double STEP_MAX = 0.5;
   private static final double NANOS_PER_STEP = 1.0E7;
   private static final double LEAD_NEW = 0.35;
   private static final double LEAD_OLD = 0.65;
   private boolean active;
   private boolean hasHistory;
   private float lastYaw;
   private float lastPitch;
   private long lastTime;
   private int lastTargetId = -1;
   private double lastPropA;
   private double lastPropB;
   private double lastPropC;
   private double leadX;
   private double leadY;
   private double leadZ;

   public ProjectileAim() {
      super("projectileaim", "ПрожестилеАим", Category.Combat);
      this.add(client.Setting.mode("weapons", "Лук", "Лук", "Арбалет", "Снежок", "Трезубец"));
      this.add(client.Setting.number("distance", 30.0, 1.0, 100.0));
      this.add(client.Setting.number("fov", 90.0, 1.0, 180.0));
      this.add(client.Setting.number("lead", 100.0, 0.0, 100.0));
      this.add(client.Setting.number("speed", 0.5, 0.05, 1.0));
      this.add(client.Setting.bool("wall_check", true));
   }

   @Override
   public void onTick() {
      this.active = false;
      if (Client.inGame() && !Client.isPaused()) {
         Entity self = Client.player();
         if (self == null) {
            this.hasHistory = false;
         } else {
            double[] trajectory = new double[4];
            if (!Client.prepareProjectileAim(self, trajectory)) {
               this.hasHistory = false;
            } else {
               client.mc.ItemStack held = Client.heldItem();
               double itemA = 0.0;
               double itemB = 0.0;
               double itemC = 0.0;
               if (held != null) {
                  itemA = Client.projectileSpeed(held);
                  itemB = Client.projectileDivergence(held);
                  itemC = Client.projectileGravity(held);
               }

               double[] rotation = Client.currentRotation();
               double yawRad = Math.toRadians(rotation[0]);
               double pitchRad = Math.toRadians(rotation[1]);
               double dirX = -Math.sin(yawRad) * Math.cos(pitchRad);
               double dirY = -Math.sin(pitchRad);
               double dirZ = Math.cos(yawRad) * Math.cos(pitchRad);
               double distanceSq = this.distance() * this.distance();
               double leadCos = Math.cos(this.lead() * 0.5 * (Math.PI / 180.0));
               Entity target = this.findTarget(dirX, dirY, dirZ, distanceSq, leadCos, this.wallCheck());
               if (target == null) {
                  this.hasHistory = false;
               } else {
                  double propA = Client.targetPropA(target);
                  double propB = Client.targetPropB(target);
                  double propC = Client.targetPropC(target);
                  int id = Client.entityNetworkId(target);
                  if (this.hasHistory && id == this.lastTargetId) {
                     double dA = propA - this.lastPropA;
                     double dB = propB - this.lastPropB;
                     double dC = propC - this.lastPropC;
                     this.lastPropA = propA;
                     this.lastPropB = propB;
                     this.lastPropC = propC;
                     if (dB * dB + dA * dA + dC * dC <= Client.leadDeltaLimit()) {
                        this.leadX = dA * 0.35 + this.leadX * 0.65;
                        this.leadY = dB * 0.35 + this.leadY * 0.65;
                        this.leadZ = dC * 0.35 + this.leadZ * 0.65;
                     } else {
                        this.leadX = 0.0;
                        this.leadY = 0.0;
                        this.leadZ = 0.0;
                     }
                  } else {
                     this.lastTargetId = id;
                     this.lastPropA = propA;
                     this.lastPropB = propB;
                     this.lastPropC = propC;
                     this.leadX = 0.0;
                     this.leadY = 0.0;
                     this.leadZ = 0.0;
                     this.hasHistory = true;
                  }

                  this.active = this.applyAim(self, target, trajectory, itemA, itemB, itemC, leadCos);
               }
            }
         }
      } else {
         this.hasHistory = false;
      }
   }

   @Override
   public void onDisable() {
      this.returnRotation();
      this.active = false;
      this.hasHistory = false;
      this.lastTargetId = -1;
      this.lastTime = 0L;
   }

   private void returnRotation() {
      if (Client.inGame() && this.lastTargetId != -1) {
         if (!Client.isScreenOpen()) {
            Entity self = Client.player();
            if (self != null) {
               double yaw = Client.currentRotation()[0];
               double pitch = Client.currentRotation()[1];
               long now = Client.tickTime();
               double factor = 1.0;
               if (this.lastTime > 0L) {
                  double elapsed = (now - this.lastTime) / 1.0E7;
                  double clamped = elapsed;
                  if (0.05 >= elapsed) {
                     clamped = 0.05;
                  }

                  if (clamped >= 0.5) {
                     clamped = 0.5;
                  }

                  factor = clamped;
               }

               this.lastTime = now;
               factor = Math.max(0.01, factor);
               factor = 1.0 - Math.pow(1.0 - this.aimSpeed(), factor);
               double deltaYaw = Client.wrapDegrees(this.lastYaw - yaw);
               double deltaPitch = this.lastPitch - pitch;
               if (Math.abs(deltaYaw) >= 0.02) {
                  deltaYaw *= factor;
               }

               if (Math.abs(deltaPitch) >= 0.02) {
                  deltaPitch *= factor;
               }

               if (Math.abs(deltaYaw) >= 0.001 || Math.abs(deltaPitch) >= 0.001) {
                  Client.addRotation((float)deltaYaw, (float)deltaPitch);
               }
            }
         }
      }
   }

   private Entity findTarget(double dirX, double dirY, double dirZ, double distanceSq, double leadCos, boolean wallCheck) {
      Entity self = Client.player();
      if (self == null) {
         return null;
      } else {
         Entity best = null;
         double bestScore = Double.MAX_VALUE;
         double[] selfPosition = Client.entityPosition(self);
         double fovCos = Math.cos(Math.toRadians(this.fov() * 0.5));

         for (Entity entity : Client.entities()) {
            if (entity != self && Client.isLiving(entity) && !Client.isFriend(entity)) {
               double[] position = Client.entityPosition(entity);
               double dx = position[0] - selfPosition[0];
               double dy = position[1] - selfPosition[1];
               double dz = position[2] - selfPosition[2];
               double rangeSq = dx * dx + dy * dy + dz * dz;
               if (!(rangeSq > distanceSq) && (!wallCheck || Client.canSee(entity))) {
                  double range = Math.sqrt(rangeSq);
                  if (!(range <= 0.0)) {
                     double cosAngle = (dx * dirX + dy * dirY + dz * dirZ) / range;
                     if (!(cosAngle < fovCos)) {
                        double projection = range * cosAngle;
                        if (!(projection <= 0.0) && !(projection < range * leadCos) && projection < bestScore) {
                           bestScore = projection;
                           best = entity;
                        }
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private boolean applyAim(Entity self, Entity target, double[] trajectory, double itemA, double itemB, double itemC, double leadCos) {
      return Client.applyProjectileAim(self, target, trajectory, itemA, itemB, itemC, leadCos);
   }

   public boolean isActive() {
      return this.active;
   }

   public float lastYaw() {
      return this.lastYaw;
   }

   public float lastPitch() {
      return this.lastPitch;
   }

   public double leadX() {
      return this.leadX;
   }

   public double leadY() {
      return this.leadY;
   }

   public double leadZ() {
      return this.leadZ;
   }

   private double distance() {
      client.Setting s = this.setting("distance");
      return s == null ? 30.0 : s.getNumber();
   }

   private double fov() {
      client.Setting s = this.setting("fov");
      return s == null ? 90.0 : s.getNumber();
   }

   private double lead() {
      client.Setting s = this.setting("lead");
      return s == null ? 100.0 : s.getNumber();
   }

   private double aimSpeed() {
      client.Setting s = this.setting("speed");
      return s == null ? 0.5 : s.getNumber();
   }

   private boolean wallCheck() {
      client.Setting s = this.setting("wall_check");
      return s == null || s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

