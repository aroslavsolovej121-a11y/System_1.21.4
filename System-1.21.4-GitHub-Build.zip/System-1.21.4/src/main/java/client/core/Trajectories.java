package client.core;

import client.Category;
import client.mc.Client;
import java.util.ArrayList;
import java.util.List;

public final class Trajectories extends client.Feature {
   public static final String MODULE = "trajectories";
   public static final String DISPLAY = "Тражесториез";
   private static final double NANOS_PER_SECOND = 1.0E-9;
   private static final float FADE_IN = 1.0F;
   private static final float FADE_OUT = -1.0F;
   private static final float ANIMATION_SPEED = 20.0F;
   private static final float PROGRESS_MIN = 0.0F;
   private static final float PROGRESS_MAX = 1.0F;
   private static final float LANDING_VISIBLE_THRESHOLD = 0.001F;
   private final List<Trajectories.Landing> landings = new ArrayList<>();
   private final List<Trajectories.Landing> pendingLandings = new ArrayList<>();
   private float progress;
   private long lastFrameTime;

   public Trajectories() {
      super("trajectories", "Тражесториез", Category.Render);
      this.add(client.Setting.mode("projectiles", "All", "All", "EnderPearl", "Snowball", "Egg", "Potion"));
      this.add(client.Setting.bool("show_line", true));
      this.add(client.Setting.color("line_color", 16711935));
      this.add(client.Setting.bool("show_landing", true));
      this.add(client.Setting.bool("landings", true));
   }

   @Override
   public void onEnable() {
      this.landings.clear();
      this.landings.addAll(this.pendingLandings);
      this.pendingLandings.clear();
      if (this.landings.isEmpty() && !this.pendingLandings.isEmpty()) {
         this.landings.addAll(this.pendingLandings);
      }
   }

   @Override
   public void onDisable() {
      this.landings.clear();
      this.pendingLandings.clear();
      this.progress = 0.0F;
      this.lastFrameTime = 0L;
   }

   @Override
   public void onTick() {
      long now = Client.nanoTime();
      double delta = 0.0;
      if (this.lastFrameTime != 0L) {
         delta = (now - this.lastFrameTime) * 1.0E-9;
      }

      this.lastFrameTime = now;
      float target = -1.0F;
      if (!this.pendingLandings.isEmpty()) {
         for (Trajectories.Landing landing : this.pendingLandings) {
            if (landing.ready) {
               target = 1.0F;
               break;
            }
         }
      }

      this.progress = this.animate(this.progress + (float)delta * target * 20.0F);
      if (!this.pendingLandings.isEmpty()) {
         boolean showLine = this.showLine();
         boolean showLanding = this.showLanding() && this.progress > 0.001F;
         if (showLine || showLanding) {
            this.drawTrails();
            if (showLine) {
               for (Trajectories.Landing landingx : this.pendingLandings) {
                  landingx.advance(this.lineColor());
               }
            }

            if (showLanding) {
               this.drawLandings();
            }
         }
      }
   }

   private float animate(float value) {
      if (value < 0.0F) {
         return 0.0F;
      } else {
         return value > 1.0F ? 1.0F : value;
      }
   }

   private void drawTrails() {
      for (Trajectories.Landing landing : this.pendingLandings) {
         Client.drawTrailLine(landing.x, landing.y, landing.z, this.lineColor(), this.progress);
      }
   }

   private void drawLandings() {
      for (Trajectories.Landing landing : this.pendingLandings) {
         Client.drawLandingBox(landing.x, landing.y, landing.z, this.lineColor(), this.progress);
      }
   }

   private boolean showLine() {
      client.Setting setting = this.setting("show_line");
      return setting == null || setting.getBoolean();
   }

   private boolean showLanding() {
      client.Setting setting = this.setting("show_landing");
      return setting == null || setting.getBoolean();
   }

   private int lineColor() {
      client.Setting setting = this.setting("line_color");
      return setting == null ? 16711935 : setting.getColor();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }

   public static final class Landing {
      double x;
      double y;
      double z;
      double height;
      boolean ready;
      final List<double[]> points = new ArrayList<>();

      void advance(int color) {
         if (!this.ready) {
            this.points.add(new double[]{this.x, this.y, this.z});
         }
      }
   }
}

