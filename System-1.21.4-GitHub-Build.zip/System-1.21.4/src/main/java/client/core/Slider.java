package client.core;

public class Slider {
}
