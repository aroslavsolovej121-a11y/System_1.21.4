package client.core;

import client.Category;
import client.mc.Client;

public final class ItemESP extends client.Feature {
   public static final String MODULE = "item_esp";
   public static final String DISPLAY = "ИтемЕЗП";

   public ItemESP() {
      super("item_esp", "ИтемЕЗП", Category.Render);
      this.add(client.Setting.mode("mode", "Box", "Box", "Plate", "Both"));
      this.add(client.Setting.number("scale", 1.0, 0.1, 5.0));
      this.add(client.Setting.number("plate_opacity", 1.0, 0.0, 1.0));
      this.add(client.Setting.bool("only_valuable", false));
      this.add(client.Setting.bool("highlight_talismans", true));
      this.add(client.Setting.color("talisman_color", 16755200));
      this.add(client.Setting.mode("box_geometry", "Full", "Full", "Corners"));
      this.add(client.Setting.gradient("box_colors", 16777215, 16777215));
   }

   @Override
   public void onDisable() {
   }

   @Override
   public void onTick() {
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            ;
         }
      }
   }
}

