package client.core;

public class GradientSetting {
}
