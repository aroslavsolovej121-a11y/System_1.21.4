package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class MiddleClickFriend extends client.Feature {
   public static final String MODULE = "middle_click_friend";
   public static final String DISPLAY = "МСФ";
   public static final int SLOT_ON_BIND = 4;
   private static final int BIND_MODE = 0;

   public MiddleClickFriend() {
      super("middle_click_friend", "МСФ", Category.Player);
      this.add(client.Setting.key("key", 4));
   }

   @Override
   public void onTick() {
      if (Client.isBindDown(this.bind(), 0)) {
         if (Client.inGame()) {
            if (!Client.isScreenOpen()) {
               Entity target = Client.crosshairEntity();
               if (target != null) {
                  if (Client.isPlayer(target)) {
                     Entity self = Client.localPlayer();
                     if (self != null) {
                        if (Client.entityId(target) != Client.entityId(self)) {
                           String raw = Client.playerName(target);
                           if (!raw.isEmpty()) {
                              if (!Client.friendExists(raw)) {
                                 Client.addFriend(raw);
                              } else {
                                 String name = raw.trim();
                                 if (!name.isEmpty()) {
                                    if (Client.removeFriend(name)) {
                                       Client.bumpFriendRevision();
                                       Client.notifyFriendListChanged();
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private int bind() {
      client.Setting setting = this.setting("key");
      return setting == null ? 4 : setting.getKey();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

