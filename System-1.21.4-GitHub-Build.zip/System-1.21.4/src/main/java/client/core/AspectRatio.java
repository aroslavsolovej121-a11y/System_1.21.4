package client.core;

import client.Category;
import client.mc.Client;

public final class AspectRatio extends client.Feature {
   public static final String MODULE = "aspect_ratio";
   public static final String DISPLAY = "АзпестРатио";
   private int previousAspect;
   private int appliedAspect;
   private long appliedAt;

   public AspectRatio() {
      super("aspect_ratio", "АзпестРатио", Category.Render);
      this.add(client.Setting.mode("preset", "16:9", "16:9", "16:10", "4:3", "1:1", "Своё"));
      this.add(client.Setting.number("ratio", 1.7778, 0.5, 4.0));
   }

   @Override
   public void onEnable() {
      this.previousAspect = Client.windowAspect();
      this.appliedAspect = 0;
      this.appliedAt = Client.timerNanos();
   }
}

