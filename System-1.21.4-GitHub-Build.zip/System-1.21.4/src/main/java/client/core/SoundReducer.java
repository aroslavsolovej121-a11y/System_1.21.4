package client.core;

import client.Category;
import client.mc.Client;
import java.util.Collections;
import java.util.List;

public final class SoundReducer extends client.Feature {
   public static final String MODULE = "sound_reducer";
   public static final String DISPLAY = "ЗоундРедусер";
   public static final String MODE_OFF = "Отключение";
   public static final String MODE_REDUCE = "Приглушение";
   public static final String GROUP_POTIONS = "splash_potion";
   public static final String GROUP_ORBS = "experience_orb";
   public static final String GROUP_LINGERING = "lingering_potion";
   public static final String GROUP_CREEPER = "creeper";
   public static final String GROUP_TNT = "tnt";
   public static final String GROUP_ANVIL = "anvil";
   public static final String GROUP_BELL = "block.bell";
   public static final String GROUP_NOTE_BELL = "note_block.bell";
   public static final String GROUP_ARROW = "arrow";
   public static final String GROUP_GHAST = "ghast";
   public static final String GROUP_SKELETON = "skeleton";
   public static final String GROUP_PORTAL = "portal";
   public static final String GROUP_DRAGON = "entity.ender_dragon.ambient";
   public static final String GROUP_WITHER = "wither";
   public static final String GROUP_PHANTOM = "phantom";
   public static final String GROUP_TRIDENT = "trident";
   public static final String GROUP_TOTEM = "totem";
   public static final String GROUP_WARDEN = "warden";
   public static final String GROUP_SCULK = "sculk";
   public static final int GROUP_COUNT = 17;
   public static final long GROUP_TABLE_STRIDE = 136L;
   public static final long GROUP_TABLE_BYTES = 2312L;
   private static final double DEFAULT_VOLUME = 0.5;
   private static final double MIN_VOLUME = 0.0;
   private static final double MAX_VOLUME = 1.0;
   private static SoundReducer active;

   public SoundReducer() {
      super("sound_reducer", "ЗоундРедусер", Category.Client);
      this.add(client.Setting.mode("mode", "Приглушение", "Отключение", "Приглушение"));
      this.add(client.Setting.number("volume", 0.5, 0.0, 1.0, 0.01));
      this.add(
         client.Setting.multi(
            "groups",
            "splash_potion",
            "experience_orb",
            "lingering_potion",
            "creeper",
            "tnt",
            "anvil",
            "block.bell",
            "note_block.bell",
            "arrow",
            "ghast",
            "skeleton",
            "portal",
            "entity.ender_dragon.ambient",
            "wither",
            "phantom",
            "trident",
            "totem"
         )
      );
   }

   public static SoundReducer active() {
      return active;
   }

   public boolean isReduceMode() {
      client.Setting setting = this.setting("mode");
      return setting != null && "Приглушение".equals(setting.getMode());
   }

   public double volumeFactor() {
      client.Setting setting = this.setting("volume");
      return setting == null ? 0.5 : setting.getNumber();
   }

   public int selectedGroupCount() {
      client.Setting setting = this.setting("groups");
      return setting == null ? 0 : setting.getSelectedModes().size();
   }

   public boolean isGroupSelected(String group) {
      client.Setting setting = this.setting("groups");
      return setting != null && setting.isSelected(group);
   }

   public static boolean processingActive() {
      SoundReducer reducer = active;
      return reducer != null && reducer.enabled && Client.streamCaptureActive();
   }

   public static boolean shouldFilter() {
      return !processingActive() ? false : active.selectedGroupCount() != 0;
   }

   public void applyTo(Object soundId) {
      if (Client.streamCaptureActive()) {
         List<String> selected = this.selectedGroups();
         if (!selected.isEmpty()) {
            for (int i = 0; i < selected.size(); i++) {
               Client.soundReducerApply(this, soundId, selected.get(i), this.isReduceMode(), this.volumeFactor());
            }
         }
      }
   }

   private List<String> selectedGroups() {
      client.Setting setting = this.setting("groups");
      return setting == null ? Collections.emptyList() : setting.getSelectedModes();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

