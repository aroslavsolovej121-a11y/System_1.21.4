package client.core;

import client.Category;
import client.mc.Client;

public final class SafeMode extends client.Feature {
   public static final String MODULE = "safe_mode";
   public static final String DISPLAY = "ЗафеМоде";
   public static final String STATUS_START = "Старт";
   public static final String STATUS_STOP = "Остановить";
   private boolean startApplied;
   private boolean stopApplied;

   public SafeMode() {
      super("safe_mode", "ЗафеМоде", Category.Client);
      this.add(client.Setting.bool("start", false));
      this.add(client.Setting.bool("stop", false));
   }

   @Override
   public void onEnable() {
      this.startApplied = false;
      this.stopApplied = false;
   }

   @Override
   public void onDisable() {
      Client.safeModeShutdown();
      Client.removeLogFilter();
   }

   @Override
   public void onTick() {
      if (Client.toggleGateOpen()) {
         boolean start = this.flag("start");
         boolean stop = this.flag("stop");
         if (start && !this.startApplied) {
            Client.safeModeStart();
         }

         if (stop && !this.stopApplied) {
            Client.safeModeStop();
         }

         this.startApplied = start;
         this.stopApplied = stop;
      }
   }

   public boolean stopping() {
      return this.stopApplied;
   }

   private boolean flag(String name) {
      client.Setting s = this.setting(name);
      return s != null && s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

