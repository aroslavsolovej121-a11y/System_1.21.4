package client.core;

import client.Category;

public final class RPSpoofer extends client.Feature {
   public static final String MODULE = "rpspoofer";
   public static final String DISPLAY = "РПЗпоофер";
   private static RPSpoofer instance;

   public RPSpoofer() {
      super("rpspoofer", "РПЗпоофер", Category.Client);
   }

   public static RPSpoofer instance() {
      return instance;
   }

   @Override
   public void onEnable() {
      instance = this;
   }

   @Override
   public void onDisable() {
      instance = null;
   }
}

