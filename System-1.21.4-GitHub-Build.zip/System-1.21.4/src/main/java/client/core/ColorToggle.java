package client.core;

public class ColorToggle {
}
