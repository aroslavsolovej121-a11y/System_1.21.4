package client.core;

import client.Category;
import client.mc.BlockPos;
import client.mc.Client;
import client.mc.Entity;

public final class CrystalTap extends client.Feature {
   public static final String MODULE = "crystaltap";
   private static final int ITEM_NETHERITE = 49;
   private static final int ATTACK_COOLDOWN_TICKS = 9;
   private static final double OFFSET_A = 0.5;
   private static final double OFFSET_B = 1.0;
   private int tickCounter;
   private int lastAttackTick;
   private int lastActionTick;
   private int lastCrystalId = -1;
   private boolean placed;

   public CrystalTap() {
      super("crystaltap", "", Category.Combat);
      this.add(client.Setting.bool("auto_place", true));
      this.add(client.Setting.number("place_cooldown", 2.0, 0.0, 20.0));
      this.add(client.Setting.number("attack_cooldown", 2.0, 0.0, 20.0));
   }

   @Override
   public void onDisable() {
      this.lastCrystalId = -1;
      this.placed = false;
   }

   @Override
   public void onTick() {
      this.tickCounter++;
      if (Client.inGame()) {
         if (!Client.isPaused()) {
            Entity localPlayer = Client.player();
            boolean wantsCrystal = false;
            if (this.autoPlace() && localPlayer != null && Client.isHoldingItem(49) && (int)this.delay() < this.tickCounter - this.lastActionTick) {
               wantsCrystal = true;
            }

            Entity crosshair = Client.crosshairEntity();
            if (crosshair != null && Client.isLiving(crosshair)) {
               if (Client.isCrystal(crosshair)) {
                  if (!Client.isOwnCrystal(crosshair)) {
                     int entityId = Client.entityId(crosshair);
                     if (entityId == this.lastCrystalId && this.tickCounter - this.lastAttackTick <= 9) {
                        if (wantsCrystal) {
                           if (!this.placed) {
                              double[] pos = Client.entityPosition(crosshair);
                              int x = (int)Math.floor(pos[0]);
                              int y = (int)Math.floor(pos[1]) - 1;
                              int z = (int)Math.floor(pos[2]);
                              BlockPos base = new BlockPos(x, y, z);
                              if (Client.isObsidian(base)) {
                                 double[] spawn = new double[]{x + 0.5, y + 1.0, z + 0.5};
                                 Entity crystal = Client.spawnEndCrystal(spawn);
                                 if (crystal != null) {
                                    Client.swingMainHand();
                                 }

                                 this.placed = true;
                                 this.lastActionTick = this.tickCounter;
                              }
                           }
                        }
                     } else if (this.tickCounter - this.lastAttackTick > (int)this.delay()) {
                        Client.attack(crosshair);
                        this.lastAttackTick = this.tickCounter;
                        this.lastCrystalId = entityId;
                        this.placed = false;
                     }
                  }
               }
            } else if (wantsCrystal) {
               BlockPos hit = Client.raycastBlock();
               if (hit != null) {
                  if (Client.isObsidian(hit)) {
                     boolean[] didPlace = new boolean[1];
                     this.crystalOn(hit, didPlace);
                     if (!didPlace[0]) {
                        Client.swingMainHand();
                     }
                  }
               }
            }
         }
      }
   }

   private boolean crystalOn(BlockPos pos, boolean[] didPlace) {
      if (!Client.canPlaceCrystal(pos)) {
         return false;
      } else {
         int x = pos.x();
         int y = pos.y() + 1;
         int z = pos.z();
         double[] spawn = new double[]{x + 0.5, y, z + 0.5};
         Entity crystal = Client.spawnEndCrystal(spawn);
         if (crystal != null) {
            didPlace[0] = true;
            return true;
         } else {
            return false;
         }
      }
   }

   private boolean autoPlace() {
      client.Setting s = this.setting("auto_place");
      return s == null || s.getBoolean();
   }

   private double delay() {
      client.Setting s = this.setting("place_cooldown");
      return s == null ? 2.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

