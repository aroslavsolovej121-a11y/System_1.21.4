package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AutoTotem extends client.Feature {
   public static final String MODULE = "autototem";
   public static final String DISPLAY = "АутоТотем";
   public static final int HOTBAR_SIZE = 9;
   public static final int HOTBAR_OFFSET = 36;
   public static final int INVENTORY_SCAN_SIZE = 36;
   private static final int NO_SLOT = -1;
   private static final long ACTION_DELAY_NANOS = 400000000L;
   private static final double FALL_HEALTH_LIMIT = 5.0;
   private static final double CRYSTAL_HEALTH_LIMIT = 10.0;
   private static final String KEY_HAND = "hand";
   private static final String KEY_HEALTH = "health";
   private static final String KEY_ELYTRA = "elytra";
   private static final String KEY_ELYTRA_HEALTH = "elytra_health";
   private static final String KEY_ABSORPTION = "absorption";
   private static final String KEY_CRYSTAL = "crystal";
   private static final String KEY_TRIDENT = "trident";
   private static final String KEY_TNT = "tnt";
   private static final String KEY_TNT_RANGE = "tnt_range";
   private static final String KEY_TNT_ANY_DISTANCE = "tnt_any_distance";
   private static final String KEY_FALLING = "falling";
   private static final String KEY_MACE = "mace";
   private static final String KEY_MACE_RANGE = "mace_range";
   private static final String KEY_MACE_HEIGHT = "mace_height";
   private static final String KEY_MACE_ROOF = "mace_roof";
   private static final String KEY_MACE_ROOF_RADIUS = "mace_roof_radius";
   private static final String KEY_SAVE_ENCHANTED = "save_enchanted";
   private static final String KEY_SKIP_COOLDOWN = "skip_cooldown";
   private static final String KEY_SWAP_BACK = "swap_back";
   private static final String KEY_NO_SWAP_WHILE_EATING = "no_swap_while_eating";
   private static final String KEY_NO_BALL_SWITCH = "no_ball_switch";
   private final AutoTotem.ItemSwap swap = new AutoTotem.ItemSwap();
   private int targetSlot = -1;
   private int pendingSlot = -1;
   private int pendingCurrent = -1;
   private boolean swapQueued;
   private int enchantedCount;
   private boolean keyLatch;
   private long lastActionNanos;
   public static final int HOTBAR_OFFHAND_SLOT = 35;

   public AutoTotem() {
      super("autototem", "АутоТотем", Category.Combat);
      this.add(client.Setting.mode("hand", "Правая", "Правая", "Левая"));
      this.add(client.Setting.bool("no_swap_while_eating", true));
      this.add(client.Setting.bool("swap_back", true));
      this.add(client.Setting.bool("no_ball_switch", false));
      this.add(client.Setting.bool("save_enchanted", false));
      this.add(client.Setting.bool("skip_cooldown", true));
      this.add(client.Setting.number("health", 5.0, 0.0, 20.0, 0.5));
      this.add(client.Setting.bool("absorption", true));
      this.add(client.Setting.bool("elytra", false));
      this.add(client.Setting.number("elytra_health", 10.0, 0.0, 20.0, 0.5));
      this.add(client.Setting.bool("crystal", true));
      this.add(client.Setting.bool("trident", true));
      this.add(client.Setting.bool("tnt", true));
      this.add(client.Setting.bool("tnt_any_distance", false));
      this.add(client.Setting.number("tnt_range", 6.0, 1.0, 16.0, 0.5));
      this.add(client.Setting.bool("falling", false));
      this.add(client.Setting.bool("mace", true));
      this.add(client.Setting.number("mace_range", 5.0, 1.0, 16.0, 0.5));
      this.add(client.Setting.number("mace_height", 2.0, 1.0, 10.0, 0.5));
      this.add(client.Setting.bool("mace_roof", true));
      this.add(client.Setting.number("mace_roof_radius", 2.0, 1.0, 4.0, 1.0));
   }

   @Override
   public void onDisable() {
      Client.itemSwapStop(this.swap);
      this.targetSlot = -1;
      this.pendingSlot = -1;
      this.pendingCurrent = -1;
      this.swapQueued = false;
      this.lastActionNanos = 0L;
      this.swap.selected = -1;
   }

   @Override
   public void onTick() {
      Client.itemSwapTick(this.swap);
      Entity player = Client.player();
      if (Client.inGame() && player != null && !(Client.health(player) <= 0.0)) {
         boolean latched = this.keyLatch;
         this.keyLatch = false;
         if (latched) {
            if (!this.swapQueued) {
               this.pendingSlot = -1;
            }

            this.lastActionNanos = Client.nanos();
         }

         if (this.swap.state == 0 || this.swap.state == 3) {
            this.enchantedCount = 0;
            if (this.saveEnchanted()) {
               for (int i = 0; i < 36; i++) {
                  if (Client.inventorySlotMatches(i) && !Client.inventorySlotEmpty(i)) {
                     this.enchantedCount++;
                  }
               }
            }

            this.updateCore();
         }
      } else {
         Client.itemSwapStop(this.swap);
         this.targetSlot = -1;
         this.pendingSlot = -1;
         this.swapQueued = false;
         this.lastActionNanos = 0L;
      }
   }

   public void onSlotChanged(int slot, Object stack) {
      if (slot == 35 && Client.isTotemStack(stack)) {
         Client.itemSwapStop(this.swap);
         this.lastActionNanos = 0L;
      }
   }

   private void updateCore() {
      long now = Client.nanos();
      if (now - this.lastActionNanos >= 400000000L) {
         if (!this.offhandHasTotem() && (this.fallDanger() || this.healthDanger()) && !this.entityDanger()) {
            int slot = this.findTotemSlot();
            if (slot != -1) {
               this.applySlot(slot);
               return;
            }
         }

         if (!this.noSwapWhileEating() || !Client.isUsingItem(Client.player())) {
            if (this.swapBack()) {
               if (this.targetSlot != -1 || this.pendingSlot != -1) {
                  if (!this.offhandHasTotem()) {
                     if (this.fallDanger()) {
                        return;
                     }

                     if (this.healthDanger()) {
                        return;
                     }
                  }

                  if (this.targetSlot != -1) {
                     int restore = this.targetSlot;
                     this.targetSlot = -1;
                     Client.setSelectedSlot(restore);
                     this.lastActionNanos = now;
                  } else if (this.pendingSlot != -1) {
                     this.swapQueued = false;
                     if (this.pendingCurrent == -1) {
                        Client.itemSwapBegin(this.swap, this.pendingSlot);
                     } else {
                        Client.itemSwapBegin(this.swap, this.pendingSlot, this.pendingCurrent);
                     }
                  }
               }
            }
         }
      }
   }

   private void applySlot(int slot) {
      if (this.handMode() != 0) {
         int current = Client.selectedSlot();
         if (slot < 9) {
            if (slot != current) {
               if (this.targetSlot == -1) {
                  this.targetSlot = current;
               }

               Client.setSelectedSlot(slot);
               this.lastActionNanos = Client.nanos();
            }
         } else {
            if (this.pendingSlot == -1) {
               this.pendingSlot = slot;
               this.pendingCurrent = current;
            }

            this.swapQueued = true;
            if (current <= 8) {
               Client.itemSwapBegin(this.swap, slot, current);
            }
         }
      } else {
         Client.equipOffhandTotem(slot);
         this.lastActionNanos = Client.nanos();
      }
   }

   private boolean offhandHasTotem() {
      if (this.handMode() != 0) {
         return false;
      } else if (this.falling() && Client.health(Client.player()) > 5.0) {
         return false;
      } else {
         return !this.noBallSwitch() ? false : Client.offhandHasTotem();
      }
   }

   private boolean fallDanger() {
      Entity player = Client.player();
      if (this.falling() && !Client.isOnGround(player) && !Client.isRiding(player) && player != null) {
         return Client.health(player) > 10.0;
      } else if (this.mace()) {
         return Client.maceAbove(this, this.maceRange(), this.maceHeight(), this.maceRoof(), this.maceRoofRadius());
      } else if (!this.crystal() && !this.tnt() && !this.trident()) {
         return false;
      } else {
         double range = this.tntAnyDistance() ? Client.defaultDangerRange() : this.tntRange();
         if (!this.tnt()) {
            range = 0.0;
         }

         return Client.dangerNearby(this, range);
      }
   }

   private boolean healthDanger() {
      double absorption = this.absorption() ? Client.absorption(Client.player()) : 0.0;
      double health = Client.health(Client.player());
      if (this.elytra()) {
         double limit = Client.elytraHealthLimit(this, this.elytraHealth());
         return health + absorption <= limit;
      } else {
         return health + absorption <= Client.settingNumber(this, "health") + Client.absorptionLimit();
      }
   }

   private boolean entityDanger() {
      return Client.entityDanger(this);
   }

   private int findTotemSlot() {
      if (!this.saveEnchanted() || Client.findSlotWithItem(0) == -1) {
         int slot = Client.findTotemSlot(this);
         if (slot != -1) {
            return slot;
         }
      }

      return Client.findTotemSlotSkippingCooldown(this, this.skipCooldown());
   }

   private int handMode() {
      client.Setting setting = this.setting("hand");
      return setting == null ? 0 : setting.getModes().indexOf(setting.getMode());
   }

   private boolean falling() {
      return this.bool("falling");
   }

   private boolean saveEnchanted() {
      return this.bool("save_enchanted");
   }

   private boolean skipCooldown() {
      return this.bool("skip_cooldown");
   }

   private boolean noSwapWhileEating() {
      return this.bool("no_swap_while_eating");
   }

   private boolean swapBack() {
      return this.bool("swap_back");
   }

   private boolean noBallSwitch() {
      return this.bool("no_ball_switch");
   }

   private boolean absorption() {
      return this.bool("absorption");
   }

   private boolean elytra() {
      return this.bool("elytra");
   }

   private boolean crystal() {
      return this.bool("crystal");
   }

   private boolean trident() {
      return this.bool("trident");
   }

   private boolean tnt() {
      return this.bool("tnt");
   }

   private boolean tntAnyDistance() {
      return this.bool("tnt_any_distance");
   }

   private boolean mace() {
      return this.bool("mace");
   }

   private boolean maceRoof() {
      return this.bool("mace_roof");
   }

   private double tntRange() {
      return this.number("tnt_range");
   }

   private double maceRange() {
      return this.number("mace_range");
   }

   private double maceHeight() {
      return this.number("mace_height");
   }

   private double maceRoofRadius() {
      return this.number("mace_roof_radius");
   }

   private double elytraHealth() {
      return this.number("elytra_health");
   }

   public int targetSlot() {
      return this.targetSlot;
   }

   public int pendingSlot() {
      return this.pendingSlot;
   }

   public int enchantedCount() {
      return this.enchantedCount;
   }

   public void latchKey() {
      this.keyLatch = true;
   }

   private boolean bool(String key) {
      client.Setting setting = this.setting(key);
      return setting != null && setting.getBoolean();
   }

   private double number(String key) {
      client.Setting setting = this.setting(key);
      return setting == null ? 0.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }

   private static final class ItemSwap {
      int state;
      int selected = -1;
      int count;
      boolean active;
   }
}

