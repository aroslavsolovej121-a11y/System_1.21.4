package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AirStuck extends client.Feature {
   public static final String MODULE = "airstuck";
   public static final int STACK_LIMIT = 3;
   public static final long KICK_PROTECTION_NANOS = 28000000000L;
   public static final String MSG_KICK_PROTECTION = "§c[AirStuck] Автоматически выключен (защита от кика)";
   public static final String MSG_NEED_AIR = "§cВам нужно находиться в воздухе";
   private final double[] savedVelocity = new double[3];
   private boolean active;
   private long enableTime;

   public AirStuck() {
      super("airstuck", "АирЗтуск", Category.Movement);
      this.add(client.Setting.mode("mode", "Vanilla", "Vanilla", "Packet"));
      this.add(client.Setting.bool("fall_check", true));
   }

   @Override
   public void setEnabled(boolean value) {
      if (value && this.fallCheck() && Client.inGame()) {
         Entity self = Client.localPlayer();
         if (Client.isOnGround(self)) {
            Client.sendMessage(self, "§cВам нужно находиться в воздухе");
            return;
         }
      }

      super.setEnabled(value);
   }

   @Override
   public void onEnable() {
      Client.registerAirStuck(this);
      this.enableTime = Client.nanoTime();
      Entity self = Client.localPlayer();
      double[] motion = Client.deltaMovement(self);
      this.savedVelocity[0] = motion[0];
      this.savedVelocity[1] = motion[1];
      this.savedVelocity[2] = motion[2];
      Client.setNoGravity(self, true);
      this.active = true;
      Client.incrementAirStuckCounter();
      Client.setAirStuckCleanupPending(false);
      if (Client.airStuckCounter() > 3 && !Client.airStuckStacked()) {
         Client.setAirStuckStacked(true);
      }

      Client.refreshAirStuck();
   }

   @Override
   public void onDisable() {
      Client.registerAirStuck(null);
      if (this.active) {
         this.active = false;
         Client.decrementAirStuckCounter();
         if (Client.airStuckCounter() == 0) {
            Client.finishAirStuck();
         }
      }

      if (Client.inGame()) {
         Entity self = Client.localPlayer();
         Client.setNoGravity(self, false);
         if (!this.fallCheck() || !Client.isOnGround(self)) {
            Client.setDeltaMovement(self, this.savedVelocity);
         }
      }
   }

   @Override
   public void onTick() {
      if (Client.airStuckCounter() < 1) {
         if (Client.airStuckCleanupPending()) {
            Client.finishAirStuck();
         }
      } else {
         Client.refreshAirStuck();
      }

      Entity self = Client.localPlayer();
      if (this.kickProtection() && Client.nanoTime() - this.enableTime >= 28000000000L) {
         Client.sendMessage(self, "§c[AirStuck] Автоматически выключен (защита от кика)");
         this.setEnabled(false);
      } else {
         Client.setDeltaMovement(self, new double[]{0.0, 0.0, 0.0});
         Client.setNoGravity(self, true);
      }
   }

   private boolean fallCheck() {
      client.Setting s = this.setting("fall_check");
      return s != null && s.getBoolean();
   }

   private boolean kickProtection() {
      client.Setting s = this.setting("ft");
      return s != null && s.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

