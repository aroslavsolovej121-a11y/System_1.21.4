package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class FreeLook extends client.Feature {
   public static final String MODULE = "free_look";
   public static final String DISPLAY = "ФрееЛоок";
   private static final int DEFAULT_LOOK_KEY = 164;
   private static final int BIND_MODE = 0;
   public static final int PERSPECTIVE_FIRST_PERSON = 0;
   public static final int PERSPECTIVE_THIRD_PERSON_BACK = 1;
   private static final double ANGLE_PERIOD = 360.0;
   private static final double ANGLE_HALF = 180.0;
   private boolean active;
   private float yaw;
   private float pitch;
   private boolean overridden;
   private float overriddenYaw;
   private float overriddenPitch;
   private boolean thirdPersonApplied;
   private int previousPerspective;

   public FreeLook() {
      super("free_look", "ФрееЛоок", Category.Render);
      this.add(client.Setting.key("look_key", 164));
      this.add(client.Setting.bool("auto_third_person", true));
      this.active = false;
      this.yaw = 0.0F;
      this.pitch = 0.0F;
      this.overridden = false;
      this.overriddenYaw = 0.0F;
      this.overriddenPitch = 0.0F;
      this.previousPerspective = 0;
   }

   @Override
   public void onEnable() {
      this.active = false;
      this.overridden = false;
      this.thirdPersonApplied = false;
      this.overriddenYaw = 0.0F;
      this.overriddenPitch = 0.0F;
      this.previousPerspective = 0;
   }

   @Override
   public void onDisable() {
      this.disable();
   }

   public void applyRotation() {
      if (this.active && !this.overridden) {
         Entity entity = Client.cameraEntity();
         if (entity != null) {
            this.overriddenYaw = Client.entityYaw(entity);
            this.overriddenPitch = Client.entityPitch(entity);
            this.overridden = true;
            Client.setEntityYaw(entity, this.yaw);
            Client.setEntityPitch(entity, this.pitch);
         }
      }
   }

   public float[] modifyRotation(float[] rotation) {
      if (!this.active) {
         if (this.overridden) {
            this.restoreRotation();
         }

         return rotation;
      } else {
         rotation[0] = this.yaw;
         rotation[1] = this.pitch;
         if (this.overridden) {
            rotation[2] = this.overriddenYaw;
            rotation[3] = this.overriddenPitch;
            this.overridden = false;
         }

         return rotation;
      }
   }

   @Override
   public void onTick() {
      if (this.overridden) {
         this.restoreRotation();
      }

      if (!this.keyDown() || !Client.inGame() || Client.screenOpen()) {
         this.disable();
      } else if (!this.active && Client.player() != null) {
         Entity entity = Client.cameraEntity();
         if (entity != null) {
            this.active = true;
            this.yaw = Client.entityYaw(entity);
            this.pitch = Client.entityPitch(entity);
            this.previousPerspective = Client.perspectiveMode();
            this.thirdPersonApplied = false;
            if (this.autoThirdPerson() && this.previousPerspective == 0) {
               Client.setPerspectiveMode(1);
               this.thirdPersonApplied = true;
            }
         }
      }
   }

   public boolean active() {
      return this.active;
   }

   public boolean overridden() {
      return this.overridden;
   }

   private void restoreRotation() {
      this.overridden = false;
      Entity entity = Client.cameraEntity();
      if (entity != null) {
         float restoredPitch = this.overriddenPitch;
         Client.setEntityYaw(entity, this.overriddenYaw);
         Client.setEntityPitch(entity, restoredPitch);
      }
   }

   private void disable() {
      if (this.active) {
         this.active = false;
         this.overridden = false;
         if (this.thirdPersonApplied) {
            Client.setPerspectiveMode(this.previousPerspective);
            this.thirdPersonApplied = false;
         }

         Entity entity = Client.cameraEntity();
         if (entity != null) {
            float currentYaw = Client.entityYaw(entity);
            float currentPitch = Client.entityPitch(entity);
            double delta = (this.yaw - currentYaw) % 360.0;
            if (delta > 180.0) {
               delta -= 360.0;
            }

            if (delta < -180.0) {
               delta += 360.0;
            }

            Client.turnEntity(entity, (float)delta, this.pitch - currentPitch);
         }
      }
   }

   private boolean keyDown() {
      client.Setting setting = this.setting("look_key");
      int key = setting == null ? 0 : setting.getKey();
      return key >= 1 && key <= 255 && Client.isBindDown(key, 0);
   }

   private boolean autoThirdPerson() {
      client.Setting setting = this.setting("auto_third_person");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }
}

