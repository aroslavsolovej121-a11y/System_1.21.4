package client.core;

public class CompactGroup {
}
