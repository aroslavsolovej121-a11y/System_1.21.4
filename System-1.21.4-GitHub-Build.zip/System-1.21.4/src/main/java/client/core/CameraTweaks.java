package client.core;

import client.Category;
import client.mc.Client;

public final class CameraTweaks extends client.Feature {
   public static final String MODULE = "camera_tweaks";
   public static final String DISPLAY = "СамераТшеакз";
   private static final double NANOS_PER_MILLI = 1000000.0;
   private float currentDistance;
   private float lastTarget;
   private long lastChangeTime = -1L;
   private long animationNanos;

   public CameraTweaks() {
      super("camera_tweaks", "СамераТшеакз", Category.Render);
      this.add(client.Setting.number("distance", 4.0, 0.0, 20.0));
      this.add(client.Setting.bool("clip_through", false));
      this.add(client.Setting.number("animation_ms", 0.0, 0.0, 2000.0));
   }

   @Override
   public void onEnable() {
      this.currentDistance = 0.0F;
      this.lastTarget = 0.0F;
      this.lastChangeTime = -1L;
      this.animationNanos = 0L;
   }

   @Override
   public void onDisable() {
      this.lastChangeTime = -1L;
      this.currentDistance = 0.0F;
      this.lastTarget = 0.0F;
      this.animationNanos = 0L;
   }

   @Override
   public void onTick() {
      float target = Client.isThirdPerson() ? (float)this.distance() : 0.0F;
      if (target != this.lastTarget) {
         this.currentDistance = this.animateDistance();
         this.lastTarget = target;
         Client.setCameraDistance(target, this.clipThrough());
         this.lastChangeTime = Client.nanoTime();
         this.animationNanos = (long)(this.animationMs() * 1000000.0);
      }
   }

   private float animateDistance() {
      if (this.lastChangeTime != -1L && this.animationNanos > 0L) {
         long elapsed = Client.nanoTime() - this.lastChangeTime;
         if (elapsed >= this.animationNanos) {
            return this.lastTarget;
         } else {
            float progress = (float)elapsed / (float)this.animationNanos;
            return this.currentDistance + (this.lastTarget - this.currentDistance) * progress;
         }
      } else {
         return this.lastTarget;
      }
   }

   private double distance() {
      client.Setting setting = this.setting("distance");
      return setting == null ? 4.0 : setting.getNumber();
   }

   private boolean clipThrough() {
      client.Setting setting = this.setting("clip_through");
      return setting != null && setting.getBoolean();
   }

   private double animationMs() {
      client.Setting setting = this.setting("animation_ms");
      return setting == null ? 0.0 : setting.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

