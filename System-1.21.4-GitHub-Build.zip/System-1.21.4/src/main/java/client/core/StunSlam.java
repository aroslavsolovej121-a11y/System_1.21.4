package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class StunSlam extends client.Feature {
   public static final String MODULE = "stunslam";
   public static final String DISPLAY = "ЗтунЗлам";
   private static final int HOTBAR_LAST = 8;
   private boolean slamPending;
   private boolean restorePending;
   private int savedSlot = -1;

   public StunSlam() {
      super("stunslam", "ЗтунЗлам", Category.Combat);
      this.add(client.Setting.number("min_fall", 3.0, 0.0, 10.0));
      this.add(client.Setting.number("delay", 0.0, 0.0, 1000.0));
   }

   @Override
   public void onTick() {
      this.applyPendingSlot();
      this.tickSlam();
      this.scanForSlam();
   }

   @Override
   public void onDisable() {
      if (Client.inGame() && this.savedSlot != -1) {
         Client.selectSlot(this.savedSlot);
      }

      this.slamPending = false;
      this.restorePending = false;
      this.savedSlot = -1;
   }

   private void applyPendingSlot() {
      if (this.savedSlot != -1) {
         if (!Client.inGame()) {
            this.slamPending = false;
            this.savedSlot = -1;
         } else if (!this.restorePending) {
            int slot = this.savedSlot;
            if (slot != -1) {
               if (slot <= 8) {
                  Client.setSelectedSlot(slot);
               }

               this.slamPending = false;
               this.savedSlot = -1;
            }
         }
      }
   }

   private void tickSlam() {
      if (!Client.inGame()) {
         this.slamPending = false;
         this.savedSlot = -1;
      } else if (this.restorePending) {
         this.restorePending = false;
         Entity self = Client.player();
         if (self != null) {
            if (Client.isAlive(self) && Client.canAttack(self) && Client.isVisibleTarget(self)) {
               int slot = Client.findSlotWithItem(2);
               if (slot != -1) {
                  Client.selectSlot(slot);
                  Client.resetAttackStrength(Client.player());
               }
            }
         }
      } else if (this.slamPending) {
         this.slamPending = false;
         if (this.readyToSlam()) {
            int slamSlot = Client.findSlotWithItem(1);
            if (slamSlot != -1) {
               int mainSlot = Client.findSlotWithItem(2);
               if (mainSlot != -1) {
                  Entity target = Client.findSlamTarget();
                  if (target != null) {
                     if (Client.entityId(target) == Client.entityNetworkId(target)) {
                        if (Client.isTargetValid(target)) {
                           slamSlot = Client.findSlotWithItem(1);
                           if (slamSlot != -1) {
                              this.savedSlot = Client.selectedSlot();
                              Client.selectSlot(slamSlot);
                              Client.resetAttackStrength(Client.player());
                              this.restorePending = true;
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void scanForSlam() {
      this.slamPending = false;
      if (Client.inGame()) {
         if (this.savedSlot != -1) {
            Client.slamKeyPressed();
         } else if (Client.slamKeyPressed()) {
            Entity self = Client.player();
            if (self != null) {
               if (Client.isAlive(self) && Client.canAttack(self) && Client.isVisibleTarget(self)) {
                  if (this.readyToSlam()) {
                     int slamSlot = Client.findSlotWithItem(1);
                     if (slamSlot != -1) {
                        int mainSlot = Client.findSlotWithItem(2);
                        if (mainSlot != -1) {
                           Entity target = Client.findSlamTarget();
                           if (target != null) {
                              if (Client.entityId(target) == Client.entityNetworkId(target)) {
                                 if (Client.isTargetValid(target)) {
                                    this.slamPending = Client.slamKeyPressed();
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean readyToSlam() {
      if (Client.combatLock() > 0) {
         return false;
      } else if (Client.cameraOverrides() > 0) {
         return false;
      } else {
         Entity self = Client.player();
         if (self == null) {
            return false;
         } else {
            double fall = Client.fallDistance(self);
            if (Double.isNaN(fall)) {
               fall = 0.0;
            }

            return fall > this.minFall();
         }
      }
   }

   public client.Setting minFallSetting() {
      return this.setting("min_fall");
   }

   public client.Setting delaySetting() {
      return this.setting("delay");
   }

   private double minFall() {
      client.Setting s = this.setting("min_fall");
      return s == null ? 3.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

