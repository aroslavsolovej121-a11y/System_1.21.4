package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class AutoRespawn extends client.Feature {
   public static final String MODULE = "autorespawn";
   public static final String DISPLAY = "АутоРезпашн";
   private static final String MESSAGE_DEATH_COORDS = "Вы умерли на координатах: X={} Y={} Z={}";
   private static final long RESPAWN_DELAY = 500000000L;
   private long respawnAt;
   private boolean deathLatch;

   public AutoRespawn() {
      super("autorespawn", "АутоРезпашн", Category.Movement);
      this.add(client.Setting.bool("show_coordinates", true));
   }

   @Override
   public void onEnable() {
      this.respawnAt = 0L;
      this.deathLatch = false;
   }

   @Override
   public void onDisable() {
      this.respawnAt = 0L;
      this.deathLatch = false;
   }

   @Override
   public void onTick() {
      if (!Client.inGame()) {
         this.respawnAt = 0L;
         this.deathLatch = false;
      } else {
         Entity player = Client.player();
         if (Client.health(player) > 0.0 && !Client.isDeathScreenOpen()) {
            this.deathLatch = false;
            this.respawnAt = 0L;
         } else if (!this.deathLatch && Client.isDeathScreenOpen()) {
            this.deathLatch = true;
            if (this.showCoordinates()) {
               double[] position = Client.entityPosition(player);
               Client.sendSystemMessage(Client.formatMessage("Вы умерли на координатах: X={} Y={} Z={}", (int)position[0], (int)position[1], (int)position[2]));
            }

            this.respawnAt = Client.nanos() + 500000000L;
         } else if (this.respawnAt != 0L) {
            if (Client.nanos() >= this.respawnAt) {
               this.respawnAt = 0L;
               if (Client.isDeathScreenOpen()) {
                  Client.closeScreen();
               }

               if (player != null) {
                  Client.requestRespawn(player);
               }
            }
         }
      }
   }

   public long respawnAt() {
      return this.respawnAt;
   }

   public boolean deathLatch() {
      return this.deathLatch;
   }

   private boolean showCoordinates() {
      client.Setting setting = this.setting("show_coordinates");
      return setting != null && setting.getBoolean();
   }

   private client.Setting setting(String name) {
      for (client.Setting value : this.getSettings()) {
         if (value.getName().equals(name)) {
            return value;
         }
      }

      return null;
   }
}

