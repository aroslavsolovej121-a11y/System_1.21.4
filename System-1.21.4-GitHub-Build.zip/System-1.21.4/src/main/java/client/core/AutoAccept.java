package client.core;

import client.Category;
import client.mc.Client;

public final class AutoAccept extends client.Feature {
   public static final String MODULE = "autoaccept";
   public static final String DISPLAY = "АутоАссепт";
   private boolean pending;
   private int delayTicks;

   public AutoAccept() {
      super("autoaccept", "АутоАссепт", Category.Player);
      this.add(client.Setting.bool("friends_only", false));
      this.add(client.Setting.number("delay", 40.0, 1.0, 40.0, 1.0));
      this.add(client.Setting.input("command", "tpaccept"));
   }

   @Override
   public void onEnable() {
      this.pending = false;
      this.delayTicks = 0;
   }

   @Override
   public void onDisable() {
      this.pending = false;
      this.delayTicks = 0;
   }

   public void onChat(String message) {
      if (!this.pending) {
         if (message.contains("teleport") && message.contains("request")) {
            if (!this.friendsOnly() || Client.isFriendTeleportRequest()) {
               this.pending = true;
               this.delayTicks = (int)this.delay();
            }
         }
      }
   }

   @Override
   public void onTick() {
      if (this.pending && Client.inGame()) {
         if (this.delayTicks > 0) {
            this.delayTicks--;
         } else {
            this.pending = false;
            String command = this.command();

            while (command.startsWith("/")) {
               command = command.substring(1);
            }

            if (!command.isEmpty()) {
               Client.sendChatCommand(command);
            }
         }
      }
   }

   private boolean friendsOnly() {
      client.Setting setting = this.setting("friends_only");
      return setting != null && setting.getBoolean();
   }

   private double delay() {
      client.Setting setting = this.setting("delay");
      return setting == null ? 40.0 : setting.getNumber();
   }

   private String command() {
      client.Setting setting = this.setting("command");
      return setting == null ? "" : setting.getText();
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

