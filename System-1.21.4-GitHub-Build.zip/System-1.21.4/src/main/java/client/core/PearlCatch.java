package client.core;

import client.Category;
import client.mc.Client;

public final class PearlCatch extends client.Feature {
   public static final String MODULE = "pearlcatch";
   public static final String DISPLAY = "ПеарлСатсх";
   public static final String STATUS_NOT_IN_HOTBAR = "Нет в хотбаре";
   public static final String STATUS_ON_COOLDOWN = "На откате";
   private static final String ITEM_ENDER_PEARL = "ender_pearl";
   private static final int ITEM_WIND_CHARGE_ID = 17;
   private static final float PITCH_STRAIGHT_UP = -90.0F;
   private static final double YAW_FULL_TURN = 360.0;
   private static final double YAW_HALF_TURN = 180.0;
   private static final double YAW_NEGATIVE_HALF_TURN = -180.0;
   private static final double YAW_NEGATIVE_FULL_TURN = -360.0;
   private static final float EASE_SPLIT = 0.5F;
   private static final float EASE_DOUBLE = 2.0F;
   private static final float EASE_ONE = 1.0F;
   private static final float EASE_QUAD = 4.0F;
   private static final int PHASE_STEPS = 2;
   private static final int MIN_STATE_FLAG = 2;
   private int phase;
   private int turnTicks;
   private int delayTicks;
   private int returnSlot = -1;
   private int chargeSlot = -1;
   private float savedYaw;
   private float savedPitch;
   private float lastYaw;
   private String status = "";

   public PearlCatch() {
      super("pearlcatch", "ПеарлСатсх", Category.Movement);
      this.add(client.Setting.key("key", 0));
      this.add(client.Setting.bool("auto_turn", true));
      this.add(client.Setting.number("delay", 6.0, 1.0, 19.0));
   }

   @Override
   public void onDisable() {
      if (this.phase != 0) {
         Client.setSelectedSlot(this.returnSlot);
      }

      this.returnSlot = -1;
      this.phase = 0;
      this.delayTicks = 0;
   }

   @Override
   public void onTick() {
      if (!Client.inGame()) {
         this.returnSlot = -1;
         this.phase = 0;
         this.delayTicks = 0;
      } else {
         boolean pressed = Client.keybindPressed(this.key(), this.keyMods());
         if (this.phase == 0) {
            if (pressed) {
               this.begin();
            }
         } else {
            float yaw = (float)Client.currentRotation()[0];
            float pitch = (float)Client.currentRotation()[1];
            float targetPitch = this.autoTurn() ? -90.0F : pitch;
            int state = this.phase;
            if (state == 1) {
               this.turnTicks++;
               if (this.autoTurn()) {
                  this.lastYaw = yaw;
                  float[] turned = this.interpolate(this.lastYaw, this.savedPitch, yaw, targetPitch, this.turnTicks, 2);
                  Client.setRotation(turned[0], turned[1]);
               }

               if (this.turnTicks >= 2) {
                  this.phase = 2;
               }
            } else if (state == 2) {
               if (this.autoTurn()) {
                  Client.setRotation(yaw, targetPitch);
               }

               Client.swapRotation(yaw, targetPitch);
               if (Client.stateFlag() < 2) {
                  Client.setStateFlag(2);
               }

               Client.setSelectedSlot(this.chargeSlot);
               Client.checkJni();
               this.delayTicks = 0;
               this.phase = 3;
            } else if (state == 3) {
               if (this.autoTurn()) {
                  Client.setRotation(yaw, targetPitch);
               }

               this.delayTicks++;
               if (this.delayTicks >= (int)this.delay()) {
                  Client.swapRotation(yaw, targetPitch);
                  Client.setSelectedSlot(this.returnSlot);
                  Client.checkJni();
                  this.savedYaw = yaw;
                  this.savedPitch = targetPitch;
                  this.phase = 4;
               }
            } else if (state == 4) {
               if (this.autoTurn()) {
                  this.turnTicks++;
                  float[] turned = this.interpolate(this.savedYaw, this.savedPitch, yaw, pitch, this.turnTicks, 2);
                  Client.setRotation(turned[0], turned[1]);
                  if (this.turnTicks < 2) {
                     return;
                  }
               }

               this.phase = 0;
               this.delayTicks = 0;
               this.returnSlot = -1;
            }
         }
      }
   }

   private void begin() {
      int pearlSlot = Client.findHotbarSlotByName("ender_pearl");
      int chargeSlotFound = Client.findHotbarSlotByItemId(17);
      if (pearlSlot != -1 && chargeSlotFound != -1) {
         boolean ready = false;

         for (int i = 0; i < 2; i++) {
            int slot = i == 0 ? pearlSlot : chargeSlotFound;
            if (Client.hotbarItemCooldown(slot) == -1 && Client.hotbarItemUsable(slot)) {
               ready = true;
               break;
            }
         }

         if (!ready) {
            this.status = "На откате";
         } else {
            this.returnSlot = Client.selectedSlot();
            this.chargeSlot = chargeSlotFound;
            this.savedYaw = (float)Client.currentRotation()[0];
            this.savedPitch = (float)Client.currentRotation()[1];
            this.turnTicks = 0;
            Client.setSelectedSlot(pearlSlot);
            this.phase = 1;
         }
      } else {
         this.status = pearlSlot != -1 ? "На откате" : "Нет в хотбаре";
      }
   }

   private float[] interpolate(float fromYaw, float fromPitch, float toYaw, float toPitch, int step, int steps) {
      float t = (float)step / steps;
      if (0.5F <= t) {
         t = 2.0F - (t + t);
         t = 1.0F - t * t * t * 0.5F;
      } else {
         t = t * 4.0F * t * t;
      }

      double delta = (double)toYaw - fromYaw;
      delta %= 360.0;
      if (180.0 < delta) {
         delta += -360.0;
      }

      if (delta < -180.0) {
         delta += 360.0;
      }

      return new float[]{(float)delta * t + fromYaw, (toPitch - fromPitch) * t + fromPitch};
   }

   private int key() {
      client.Setting s = this.setting("key");
      return s == null ? 0 : s.getKey();
   }

   private int keyMods() {
      return 0;
   }

   private boolean autoTurn() {
      client.Setting s = this.setting("auto_turn");
      return s != null && s.getBoolean();
   }

   private double delay() {
      client.Setting s = this.setting("delay");
      return s == null ? 6.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }

   public String status() {
      return this.status;
   }

   public int phase() {
      return this.phase;
   }

   public int delayTicks() {
      return this.delayTicks;
   }

   public int turnTicks() {
      return this.turnTicks;
   }
}

