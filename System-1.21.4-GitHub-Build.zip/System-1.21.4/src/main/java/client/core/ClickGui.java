package client.core;

import client.Category;
import client.mc.Client;

public final class ClickGui extends client.Feature {
   public static final String MODULE = "clickgui";
   public static final String DISPLAY = "СлискГуи";
   private static ClickGui instance;
   private boolean requested;

   public ClickGui() {
      super("clickgui", "СлискГуи", Category.Client);
      instance = this;
   }

   public static ClickGui instance() {
      return instance;
   }

   public boolean requested() {
      return this.requested;
   }

   @Override
   public void setEnabled(boolean value) {
      if (value && Client.enableGateOpen() && !Client.shuttingDown()) {
         this.requested = true;
      }
   }
}

