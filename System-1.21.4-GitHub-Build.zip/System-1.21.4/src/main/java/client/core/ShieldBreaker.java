package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;

public final class ShieldBreaker extends client.Feature {
   public static final String MODULE = "shieldbreaker";
   private static final double NANOS_PER_MILLI = 1000000.0;
   private static final long MAX_HOLD_NANOS = 100000000L;
   private static final int NO_TARGET = -1;
   private int targetId = -1;
   private long startTime;
   private boolean active;
   private Entity target;

   public ShieldBreaker() {
      super("shieldbreaker", "", Category.Combat);
      this.add(client.Setting.number("hold_time", 1000.0, 0.0, 5000.0));
      this.add(client.Setting.number("range", 3.0, 1.0, 6.0));
   }

   @Override
   public void onDisable() {
      this.releaseAndReset();
   }

   @Override
   public void onTick() {
      this.process();
      this.tryStart();
   }

   private void process() {
      if (this.active) {
         if (Client.inGame()) {
            if (this.targetId == -1) {
               return;
            }

            int current = Client.crosshairEntityId();
            int other = Client.blockingEntityId();
            if (current != other && current != this.targetId) {
               this.reset();
               return;
            }

            long elapsed = Client.nanoTime() - this.startTime;
            long holdNanos = (long)(this.holdTime() * 1000000.0);
            boolean holding = Client.isBlocking(this.target) && Client.isTargetBlocking(this.target);
            if (holding) {
               if (elapsed < holdNanos) {
                  return;
               }
            } else {
               if (holdNanos <= elapsed) {
                  this.releaseAndReset();
                  return;
               }

               if (elapsed < 100000000L) {
                  return;
               }
            }
         }

         this.releaseAndReset();
      }
   }

   private void tryStart() {
      if (!this.active) {
         if (Client.inGame()) {
            if (Client.isSneaking()) {
               Entity candidate = Client.crosshairTarget();
               boolean allowed = this.canBreak(candidate);
               if (allowed && candidate != null) {
                  this.startBreaking(candidate);
               }
            }
         }
      }
   }

   private boolean canBreak(Entity candidate) {
      if (candidate == null) {
         return false;
      } else if (!Client.isAttackable(candidate)) {
         return false;
      } else if (!Client.isBlocking(candidate)) {
         return false;
      } else if (!Client.isHoldingShield(candidate)) {
         return false;
      } else {
         double range = this.range();
         double[] targetPosition = Client.entityPosition(candidate);
         double[] selfPosition = Client.entityPosition(Client.player());
         double dx = selfPosition[0] - targetPosition[0];
         double dy = selfPosition[1] - targetPosition[1];
         double dz = selfPosition[2] - targetPosition[2];
         return dx * dx + dy * dy + dz * dz <= range * range ? Client.isTargetBlocking(candidate) : false;
      }
   }

   private void startBreaking(Entity candidate) {
      int id = Client.blockingEntityId();
      if (id != -1) {
         if (this.targetId == -1) {
            this.targetId = Client.crosshairEntityId();
         }

         Client.releaseAttack(id);
         this.active = true;
         this.startTime = Client.nanoTime();
         this.target = candidate;
      }
   }

   private void releaseAndReset() {
      if (this.targetId >= 0) {
         Client.releaseAttack();
      }

      this.reset();
   }

   private void reset() {
      this.targetId = -1;
      this.startTime = 0L;
      this.active = false;
      this.target = null;
   }

   private double holdTime() {
      client.Setting s = this.setting("hold_time");
      return s == null ? 1000.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }

   private double range() {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals("range")) {
            return s.getNumber();
         }
      }

      return 3.0;
   }
}

