package client.core;

import client.Category;
import client.mc.Client;
import java.util.List;

public final class SafeLeave extends client.Feature {
   public static final String MODULE = "safeleave";
   public static final String DISPLAY = "ЗафеЛеаве";
   private static final String MODE_HOLYWORLD = "holyworld";
   private static final String MODE_SCOREBOARD = "scoreboard";
   private static final long MESSAGE_WINDOW_NANOS = 30000000000L;
   private static final long NANOS_PER_MILLI = 1000000L;
   private boolean leaving;
   private long holdUntil;

   public SafeLeave() {
      super("safeleave", "ЗафеЛеаве", Category.Movement);
      this.add(client.Setting.mode("mode", "scoreboard", "holyworld", "scoreboard"));
   }

   @Override
   public void onDisable() {
      this.leaving = false;
      this.holdUntil = 0L;
   }

   @Override
   public void onTick() {
      if (!Client.inGame()) {
         this.leaving = false;
      } else {
         boolean combat;
         if (this.isHolyWorld()) {
            combat = Client.holyWorldCombatTicks() > 0;
         } else {
            List<String> lines = Client.scoreboardLines();
            combat = Client.containsLeaveMarker(lines);
         }

         if (combat && !this.leaving) {
            this.leaving = true;
            Client.leaveServer();
         }

         this.leaving = combat;
      }
   }

   public void onMessage(String message) {
      if (this.isHolyWorld()) {
         if (Client.listContains(Client.boardSections(), message)) {
            long seconds = Client.messageNumber(message);
            if (seconds <= 0L) {
               this.holdUntil = 0L;
            } else {
               long now = Client.timerNanos();
               if (this.holdUntil != 0L) {
                  long remaining = this.holdUntil - now;
                  if (remaining > 0L && Client.playerHealth() <= 0.0) {
                     return;
                  }
               }

               this.holdUntil = seconds * 1000000000L + now;
               if (Client.textNumber(message, 6) > 0) {
                  this.holdUntil = now;
               }
            }
         }
      }
   }

   public boolean pending() {
      return this.holdUntil != 0L && this.holdUntil - Client.timerNanos() > 1000000000L;
   }

   private boolean isHolyWorld() {
      client.Setting setting = this.setting("mode");
      return setting != null && "holyworld".equals(setting.getMode());
   }

   private client.Setting setting(String name) {
      for (client.Setting setting : this.getSettings()) {
         if (setting.getName().equals(name)) {
            return setting;
         }
      }

      return null;
   }
}

