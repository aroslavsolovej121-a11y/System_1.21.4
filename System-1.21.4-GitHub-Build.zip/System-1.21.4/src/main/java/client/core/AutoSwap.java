package client.core;

import client.Category;
import client.mc.Client;

public final class AutoSwap extends client.Feature {
   public static final String MODULE = "autoswap";
   public static final String DISPLAY = "АутоЗшап";
   private static final int BIND_LATCH_COUNT = 7;
   private static final int COMMON_BIND_MASK = 31;
   private static final int SWAP_STEP_NONE = 0;
   private static final int SWAP_STEP_ONE = 1;
   private static final int SWAP_STEP_TWO = 2;
   private static final String GROUP_CHORUS_FRUIT = "chorus_fruit";
   private static final String GROUP_EXPERIENCE_BOTTLE = "experience_bottle";
   private static final String BIND_WIND_CHARGE = "wind_charge";
   private static final String BIND_ENDER_PEARL = "ender_pearl";
   private static final String BIND_TOTEM_TO_TOTEM = "totem_to_totem";
   private static final String EFFECT_ALL = "all";
   private static final String EFFECT_SPHERE_TO_SPHERE = "sphere_to_sphere";
   private final boolean[] swapLatch = new boolean[1];
   private final boolean[] sphereLatch = new boolean[1];
   private final boolean[] totemLatch = new boolean[1];
   private final boolean[] totemTotemLatch = new boolean[1];
   private final boolean[] commonLatch = new boolean[1];
   private final boolean[] ftLatch = new boolean[1];
   private final boolean[] hwLatch = new boolean[1];
   private int swapStep;

   public AutoSwap() {
      super("autoswap", "АутоЗшап", Category.Movement);
      this.add(client.Setting.mode("server", "Авто", "Авто", "HolyWorld", "FunTime", "Другой"));
      this.add(client.Setting.mode("mode", "Тап", "Тап", "Холд"));
      this.add(client.Setting.mode("trigger", "Клавиша", "Клавиша", "Урон", "Тотем"));
      this.add(client.Setting.bool("cooldown_done", false));
      this.add(client.Setting.bool("silent_swap", false));
      this.add(client.Setting.key("swap_bind", 0));
      this.add(client.Setting.key("totem_swap_bind", 0));
      this.add(client.Setting.key("sphere_swap_bind", 0));
      this.add(client.Setting.key("totem_totem_bind", 0));
      this.add(client.Setting.key("common_binds", 0));
      this.add(client.Setting.key("ft_binds", 0));
      this.add(client.Setting.key("hw_binds", 0));
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      if (Client.autoSwapUseKeyHeld(this) || Client.autoSwapUseKey2Held(this)) {
         Client.setUseKey(false);
      }

      if (Client.autoSwapPendingUse(this) && Client.autoSwapPendingCount(this) != 0) {
         Client.setUseKey2(false);
      }

      this.reset();
   }

   @Override
   public void onTick() {
      Client.swapManagerTick(Client.autoSwapManager(this));
      if (!Client.inGame()) {
         this.reset();
      } else {
         Client.autoSwapRefreshItems(this);
         Client.autoSwapTickState(this);
         Client.autoSwapGroup(this, "chorus_fruit");
         Client.autoSwapGroup(this, "experience_bottle");
         Client.autoSwapPendingUseTick(this);
         Client.autoSwapStateStep(Client.autoSwapManager(this));
         boolean sphere = Client.keybindPressed(this.bind("sphere_swap_bind"), 0, this.sphereLatch);
         boolean totem = Client.keybindPressed(this.bind("totem_swap_bind"), 0, this.totemLatch);
         boolean totemTotem = Client.keybindPressed(this.bind("totem_totem_bind"), 0, this.totemTotemLatch);
         boolean common = Client.keybindPressed(this.bind("common_binds"), 0, this.commonLatch);
         boolean ft = Client.keybindPressed(this.bind("ft_binds"), 0, this.ftLatch);
         boolean hw = Client.keybindPressed(this.bind("hw_binds"), 0, this.hwLatch);
         boolean swap = Client.keybindPressed(this.bind("swap_bind"), 0, this.swapLatch);
         Client.autoSwapProcessGroups(this);
         if (!Client.isPaused()) {
            if (sphere || totem) {
               Client.autoSwapSwapStep(this, "wind_charge", totem);
            }

            if (totemTotem && Client.autoSwapUseKeyHeld(this)) {
               Client.autoSwapHandleBind(this, "ender_pearl");
            }

            if (Client.hasStatusEffect("all")) {
               if (common) {
                  Client.autoSwapSwapStep(this, null, false);
               }

               if (swap) {
                  Client.autoSwapSwapStep(this, null, true);
               }

               if (ft) {
                  Client.autoSwapSwapStep(this, null, true);
               }
            } else if (hw) {
               if (Client.hasItemNamed("sphere_to_sphere")) {
                  if (Client.settingListContains(this, "common_binds", "totem_to_totem")) {
                     Client.autoSwapSwapStep(this, null, false);
                  } else {
                     Client.autoSwapSwapStep(this, null, true);
                  }
               }
            }
         }
      }
   }

   public void onBindScan() {
      Client.autoSwapScanBinds(this);
   }

   public int swapStep() {
      return this.swapStep;
   }

   public void reset() {
      Client.swapManagerReset(Client.autoSwapManager(this));
      Client.autoSwapResetPending(this);
      this.swapStep = 0;
      this.swapLatch[0] = false;
      this.sphereLatch[0] = false;
      this.totemLatch[0] = false;
      this.totemTotemLatch[0] = false;
      this.commonLatch[0] = false;
      this.ftLatch[0] = false;
      this.hwLatch[0] = false;
   }

   public boolean swapStepActive() {
      return Client.autoSwapStepActive(Client.autoSwapManager(this));
   }

   private int bind(String name) {
      client.Setting setting = this.setting(name);
      return setting == null ? 0 : setting.getKey();
   }

   private client.Setting setting(String name) {
      for (client.Setting value : this.getSettings()) {
         if (value.getName().equals(name)) {
            return value;
         }
      }

      return null;
   }
}

