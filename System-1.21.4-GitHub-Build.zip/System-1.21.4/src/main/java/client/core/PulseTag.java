package client.core;

import client.Category;
import client.mc.Client;
import client.mc.Entity;
import java.util.ArrayList;
import java.util.List;

public final class PulseTag extends client.Feature {
   public static final String MODULE = "pulse_tag";
   private static final int REFRESH_INTERVAL = 40;
   private static final int NOTIFY_STYLE_DEFAULT = 96;
   private static final int NOTIFY_STYLE_ALTERNATE = 144;
   private static final int NOTIFY_STYLE_SWITCH = 1;
   private static final List<String> TAGS = new ArrayList<>();
   private static boolean active;
   private static int notifyStyleDefault = 1;
   private static int notifyStyleAlternate = 1;
   private static int notifyCounter;
   private int tickCounter;
   private int taggedCount = -1;
   private String session = "";

   public PulseTag() {
      super("pulse_tag", "", Category.Client);
      this.add(client.Setting.bool("login", true));
      this.add(client.Setting.bool("logout", true));
   }

   @Override
   public boolean isVisible() {
      return !TAGS.isEmpty();
   }

   @Override
   public void onEnable() {
      active = true;
      this.tickCounter = 40;
      this.taggedCount = -1;
      this.session = "";
   }

   @Override
   public void onDisable() {
      active = false;
      this.taggedCount = -1;
      notifyCounter = 0;
      TAGS.clear();
   }

   @Override
   public void onTick() {
      this.tickCounter++;
      if (this.tickCounter > 39) {
         this.tickCounter = 0;
         String current = Client.currentUsername();
         if (!current.equals(this.session)) {
            this.session = current;
         }

         this.collectTagged();
         if (TAGS.size() != this.taggedCount) {
            this.taggedCount = TAGS.size();
         }
      }
   }

   @Override
   public void onRender() {
      if (!TAGS.isEmpty()) {
         notifyCounter++;

         for (Entity entity : Client.entities()) {
            String name = Client.playerName(entity);
            int style = TAGS.size() > 1 ? 144 : 96;
            if ((style == 144 ? notifyStyleAlternate : notifyStyleDefault) != 0) {
               Client.notifyPulseTag(name);
            }
         }

         notifyCounter--;
         if (notifyCounter == 0) {
            Client.flushPulseTag();
         }

         TAGS.clear();
      }
   }

   public static void requestLogin(String name) {
      if (name != null) {
         TAGS.add(name);
      }
   }

   public static void requestLogout(String name) {
      if (name != null) {
         TAGS.remove(name);
      }
   }

   public int taggedCount() {
      return this.taggedCount;
   }

   private void collectTagged() {
      TAGS.clear();
      Client.forEachPlayer(player -> {
         if (Client.isTaggedPlayer(player)) {
            TAGS.add(Client.playerName(player));
         }
      });
   }
}

