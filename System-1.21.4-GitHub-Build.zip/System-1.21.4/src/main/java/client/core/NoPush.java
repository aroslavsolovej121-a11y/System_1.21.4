package client.core;

import client.Category;
import client.mc.Client;

public final class NoPush extends client.Feature {
   public static final String MODULE = "nopush";
   public static final String DISPLAY = "НоПузх";

   public NoPush() {
      super("nopush", "НоПузх", Category.Movement);
   }

   @Override
   public void onEnable() {
      Client.registerNoPush(this);
   }

   @Override
   public void onDisable() {
      Client.registerNoPush(null);
   }
}

