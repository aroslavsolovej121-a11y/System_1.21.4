package client.core;

import client.Category;
import client.mc.Client;

public final class SpearSwap extends client.Feature {
   public static final String MODULE = "spearswap";
   public static final int FIND_LUNGE_RVA = 404080;
   public static final int RESTORE_SAVED_RVA = 403984;
   public static final String MSG_NO_LUNGE_SPEAR = "Копьё с Выпадом не найдено";
   public static final String MSG_LUNGE = "Выпад";
   private static final int HOTBAR_SLOTS = 8;
   private static final int HOLD_COUNTER_TICKS = 15;
   private static final int LOCK_VALUE = 2;
   private static final float ATTACK_READY = 1.0F;
   private static final int SLOT_NONE = -1;
   private int savedSlot = -1;
   private int holdCounter;
   private int lastLungeSlot = -1;
   private int tickCounter;

   public SpearSwap() {
      super("spearswap", "ЗпеарЗшап", Category.Combat);
      this.add(client.Setting.key("lunge_bind", 0));
      this.add(client.Setting.number("hold_ticks", 3.0, 0.0, 20.0));
   }

   @Override
   public void onDisable() {
      if (Client.inGame()) {
         this.restoreSaved();
      }

      this.holdCounter = 0;
      this.savedSlot = -1;
   }

   @Override
   public void onTick() {
      boolean hasLunge = Client.hasLungeSpear();
      if (!Client.inGame()) {
         this.savedSlot = -1;
         this.holdCounter = 0;
      } else {
         if (this.savedSlot != -1) {
            this.tickCounter++;
            if (this.tickCounter >= (int)this.holdTicks()) {
               if (Client.selectedSlot() == this.lastLungeSlot) {
                  int slot = this.savedSlot;
                  if (slot < 9) {
                     Client.setSelectedSlotReflective(slot);
                  }

                  if (Client.combatLock() < 2) {
                     Client.setCombatLock(2);
                  }
               }

               this.savedSlot = -1;
            }
         }

         if (hasLunge && !Client.isScreenOpen()) {
            int lungeSlot = Client.findSlotWithLungeSpear();
            if (lungeSlot == -1) {
               Client.notifyMissingLungeSpear("Копьё с Выпадом не найдено", "Выпад");
               return;
            }

            this.holdCounter = 15;
         }

         if (this.holdCounter != 0) {
            this.holdCounter--;
            if (!Client.isScreenOpen()) {
               if (Client.combatLock() < 1) {
                  if (Client.airStuckCounter() < 1) {
                     if (!(Client.attackCooldown(Client.localPlayer()) < 1.0)) {
                        int lungeSlot = Client.findSlotWithLungeSpear();
                        this.holdCounter = 0;
                        if (lungeSlot != -1) {
                           if (Client.selectedSlot() != lungeSlot) {
                              if (this.savedSlot == -1) {
                                 this.savedSlot = Client.selectedSlot();
                              }

                              this.lastLungeSlot = lungeSlot;
                              this.tickCounter = 0;
                              Client.setSelectedSlot(lungeSlot);
                              if (Client.combatLock() < 2) {
                                 Client.setCombatLock(2);
                              }
                           }

                           Client.performLungeAttack();
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void restoreSaved() {
      if (this.savedSlot != -1) {
         if (Client.selectedSlot() == this.lastLungeSlot) {
            Client.setSelectedSlot(this.savedSlot);
            if (Client.combatLock() < 2) {
               Client.setCombatLock(2);
            }
         }

         this.savedSlot = -1;
      }
   }

   private double holdTicks() {
      client.Setting s = this.setting("hold_ticks");
      return s == null ? 3.0 : s.getNumber();
   }

   private client.Setting setting(String name) {
      for (client.Setting s : this.getSettings()) {
         if (s.getName().equals(name)) {
            return s;
         }
      }

      return null;
   }
}

