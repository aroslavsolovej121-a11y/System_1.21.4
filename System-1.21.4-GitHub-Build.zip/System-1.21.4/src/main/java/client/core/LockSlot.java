package client.core;

import client.Category;

public final class LockSlot extends client.Feature {
   public static final String MODULE = "lockslot";
   public static final String DISPLAY = "ЛоскЗлот";
   public static final int OPTION_COUNT = 9;
   private static LockSlot active;

   public LockSlot() {
      super("lockslot", "ЛоскЗлот", Category.Player);
      String[] slots = new String[9];

      for (int i = 0; i < 9; i++) {
         slots[i] = Integer.toString(i + 1);
      }

      this.add(client.Setting.multi("slots", slots));
   }

   public static LockSlot active() {
      return active;
   }

   public static boolean isLocked(int slot) {
      if (active != null && slot >= 0 && slot < 9) {
         client.Setting setting = active.setting("slots");
         if (setting == null) {
            return false;
         } else {
            String value = Integer.toString(slot + 1);

            for (String selected : setting.getSelectedModes()) {
               if (selected.equals(value)) {
                  return true;
               }
            }

            return false;
         }
      } else {
         return false;
      }
   }

   @Override
   public void onEnable() {
      active = this;
   }

   @Override
   public void onDisable() {
      active = null;
   }

   private client.Setting setting(String name) {
      for (client.Setting candidate : this.getSettings()) {
         if (candidate.getName().equals(name)) {
            return candidate;
         }
      }

      return null;
   }
}

