package client.core;

public class LegitRotation {
}
