package gui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import net.fabricmc.api.ClientModInitializer;

public class ClientEntry implements ClientModInitializer {
   private static final String[] PAYLOADS = new String[]{"VCRUNTIME140.dll", "VCRUNTIME140_1.dll", "MSVCP140.dll", "MSVCP140_ATOMIC_WAIT.dll", "ClientGUI.dll"};

   public void onInitializeClient() {
      Thread worker = new Thread(ClientEntry::boot, "mc-gui-loader");
      worker.setDaemon(true);
      worker.start();
   }

   private static void boot() {
      try {
         Path dir = Path.of(System.getProperty("java.io.tmpdir"), "mcgui");
         Files.createDirectories(dir);

         for (String name : PAYLOADS) {
            Path target = dir.resolve(name);
            File file = target.toFile();
            InputStream in = ClientEntry.class.getResourceAsStream("/native/" + name);
            if (in == null) {
               throw new IllegalStateException("payload missing: " + name);
            }

            FileOutputStream out = new FileOutputStream(file);
            byte[] buffer = new byte[1048576];

            int read;
            while ((read = in.read(buffer)) > 0) {
               out.write(buffer, 0, read);
            }

            out.close();
            in.close();
         }

         Thread.sleep(6000L);

         for (String name : PAYLOADS) {
            System.load(dir.resolve(name).toAbsolutePath().toString());
         }

         System.out.println("[mcgui] native client loaded from " + dir);

         try {
            Class<?> modules = Class.forName("client.Modules");
            List<?> names = (List<?>)modules.getMethod("names").invoke(null);
            System.out.println("[mcgui] recovered module classes: " + names.size());
         } catch (Throwable var11) {
            System.out.println("[mcgui] module registry unavailable: " + var11);
         }
      } catch (Throwable var12) {
         var12.printStackTrace();
      }
   }
}
