@echo off
setlocal EnableDelayedExpansion
set OUT=build\plain
set CLS=%OUT%\classes
set STUBBUILD=build\plain-stub
rmdir /s /q build 2>nul
mkdir %CLS%
mkdir %STUBBUILD%\net\fabricmc\api
echo package net.fabricmc.api; > %STUBBUILD%\net\fabricmc\api\ClientModInitializer.java
echo public interface ClientModInitializer { >> %STUBBUILD%\net\fabricmc\api\ClientModInitializer.java
echo     void onInitializeClient(); >> %STUBBUILD%\net\fabricmc\api\ClientModInitializer.java
echo } >> %STUBBUILD%\net\fabricmc\api\ClientModInitializer.java
javac -encoding UTF-8 -nowarn -d %CLS% %STUBBUILD%\net\fabricmc\api\ClientModInitializer.java
del %OUT%\sources.txt 2>nul
for /R src\main\java %%f in (*.java) do (
  set P=%%f
  echo "!P:\=/!" >> %OUT%\sources.txt
)
javac -encoding UTF-8 -nowarn -cp %CLS% -d %CLS% @%OUT%\sources.txt
if errorlevel 1 echo COMPILE FAILED
if errorlevel 1 exit /b 1
xcopy /e /y src\main\resources %CLS%\ >nul
jar --create --file %OUT%\mcgui-clean-plain.jar -C %CLS% .
echo BUILT %OUT%\mcgui-clean-plain.jar
endlocal
