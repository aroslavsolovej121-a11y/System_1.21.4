System 1.21.11 - Clean Source (decompiled + cleaned)
==================================================
Source: System 1.21.11.jar (mcgui 1.0.0)
Decompiler: Vineflower 1.11.2
Date: 2026-09-30
Files: 237 java files

CLEANING DONE:
- Removed 3306 native mapping lines (RVA_*, VTABLE_*, OFF_*, VA_*, BASE, IMAGE_END, MODULES_*, MAX_*, ENABLE/DISABLE/TICK_RVA)
- Removed Unsafe memory dumper from gui.ClientEntry (initUnsafe, rd8, rdn, collect, dump, toHex, objects map)
- Kept loader: extract native/*.dll to tmp/mcgui + System.load + client.Modules.names() check
- SLOT_SETTER obf mappings removed: was [d, setSelectedSlot, method_61496, setSelectedSlot, m_385457_], now single Mojang 1.21.11: setSelectedSlot (I)V
- Renamed obf stubs: flag16e8 -> isFogEnabled, flagC48 -> isPulseEnabled
- Removed dead native stubs: flag56, flag54, flag340, flag430, flag520, flag610, flagA40, flag1c0, flag1590, flag5d8
- Kept MODULE strings, settings, logic in client.core.*, client.gui.*, client.mc.*

NOTE: client.mc.Client methods are native stubs (return false/0/null). Real logic lives in native/ClientGUI.dll.
To re-implement: replace Client.java stubs with Yarn/Mojang 1.21.11 calls or JNI.
Native DLLs included under src/main/resources/native/ for runtime.

BUILD:
- Requires JDK 21, Gradle 8+, Fabric Loom 1.7
- gradle build / gradle runClient
- Or open in IntelliJ IDEA 2026.1 as Gradle project

STRUCTURE:
src/main/java/client/... - modules, settings, gui, hud, mc wrappers
src/main/java/gui/ClientEntry.java - Fabric entrypoint (clean loader)
src/main/resources/fabric.mod.json
src/main/resources/native/*.dll
